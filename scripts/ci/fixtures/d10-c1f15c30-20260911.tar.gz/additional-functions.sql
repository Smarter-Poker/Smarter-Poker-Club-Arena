SET check_function_bodies=false;
CREATE OR REPLACE FUNCTION auth.jwt()
 RETURNS jsonb
 LANGUAGE sql
 STABLE
AS $function$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$function$
;
CREATE OR REPLACE FUNCTION auth.role()
 RETURNS text
 LANGUAGE sql
 STABLE
AS $function$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$function$
;
CREATE OR REPLACE FUNCTION auth.uid()
 RETURNS uuid
 LANGUAGE sql
 STABLE
AS $function$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$function$
;
CREATE OR REPLACE FUNCTION public.atomic_distribute_rake(p_table_id uuid, p_club_id uuid, p_hand_id uuid, p_hand_number integer, p_rake numeric, p_bbj numeric DEFAULT 0, p_pot numeric DEFAULT NULL::numeric, p_num_players integer DEFAULT (NULL::numeric)::integer, p_contributions jsonb DEFAULT NULL::jsonb, p_tournament_id uuid DEFAULT NULL::uuid, p_returned_uncalled jsonb DEFAULT NULL::jsonb, p_rake_method text DEFAULT 'DEALT_EQUAL'::text)
 RETURNS TABLE(applied boolean, already_processed boolean, recovered boolean, rake_record_id uuid, club_net_credit numeric, spendable_route text, spendable_amount numeric, union_id_out uuid)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
 SET statement_timeout TO '30s'
AS $function$
DECLARE
  v_union_id     uuid;
  v_g_union      uuid;
  v_is_private   boolean := false;
  v_club_name    text;
  v_net          numeric;
  v_bbj          numeric := COALESCE(p_bbj, 0);
  v_rr_id        uuid;
  v_first_claim  boolean := false;
  v_recovered    boolean := false;
  v_leg_key      uuid;
  v_n            integer;
  v_cw_after     numeric;
  v_union_rake   numeric;
  v_route        text;
  v_method       text;
  v_alloc_sum    numeric;
  v_st           text;
  v_msg          text;
  v_dup_id       uuid;
BEGIN
  IF p_club_id IS NULL OR p_rake IS NULL OR p_rake <= 0 THEN
    RETURN QUERY SELECT false, false, false, NULL::uuid, 0::numeric,
                        NULL::text, 0::numeric, NULL::uuid;
    RETURN;
  END IF;

  /* ZERO-DRIFT (2026-08-31): declare the ledger context for this transaction
     so every auto-journaled balance delta below is categorized as rake coming
     off the felt, not an anonymous adjustment against suspense. */
  PERFORM set_config('app.ledger_category', 'rake', true);
  PERFORM set_config('app.ledger_counterparty', 'table_stack', true);
  PERFORM set_config('app.ledger_counterparty_entity', COALESCE(p_table_id::text, ''), true);
  -- PHASE 6.4 (2026-09-05): the rake's legs name the hand when it is known.
  PERFORM set_config('app.ledger_hand_id', COALESCE(p_hand_id::text, ''), true);

  v_method := CASE WHEN p_rake_method = 'WEIGHTED_CONTRIBUTED'
                   THEN 'WEIGHTED_CONTRIBUTED' ELSE 'DEALT_EQUAL' END;

  v_net := p_rake - v_bbj;

  SELECT c.name INTO v_club_name FROM public.clubs c WHERE c.id = p_club_id;

  -- UNION LAW (Dan, restored 2026-08-30): route by the GAME's union stamp,
  -- not club membership. A private club game's rake NEVER touches the union.
  IF p_table_id IS NOT NULL THEN
    SELECT COALESCE(t.is_private, false), t.union_id
      INTO v_is_private, v_g_union
      FROM public.tables t WHERE t.id = p_table_id;
  END IF;
  IF p_tournament_id IS NOT NULL AND NOT v_is_private AND v_g_union IS NULL THEN
    SELECT COALESCE(tr.is_private, false), tr.union_id
      INTO v_is_private, v_g_union
      FROM public.tournaments tr WHERE tr.id = p_tournament_id;
  END IF;

  IF v_is_private THEN
    v_union_id := NULL;
  ELSE
    v_union_id := v_g_union;
    IF v_union_id IS NULL THEN
      SELECT c.union_id INTO v_union_id FROM public.clubs c WHERE c.id = p_club_id;
    END IF;
  END IF;

  /* A HAND THAT CANNOT NAME ITSELF BY ID STILL NAMES ITSELF BY TABLE AND
     NUMBER (2026-09-06). Both idempotency guards below key on p_hand_id, and
     both are disabled when it is NULL: ON CONFLICT (hand_id) WHERE hand_id IS
     NOT NULL matches nothing, and v_leg_key fell back to a FRESH RANDOM uuid,
     so rake_distribution_legs could not dedupe either. The engine calls this
     before logHandHistory has produced a hand row and again after, and the
     second call was treated as a new hand: a duplicate rake_records row, and
     a second increment of the club wallet's period and lifetime rake. 4,452
     such rows exist, 2026-04-16 to 2026-09-05, carrying 16,426.46 of rake and
     2,068.82 of BBJ contribution that no hand ever dropped - measured against
     hand_history and bbj_contributions, which agree with the LINKED rows alone
     in 283 of the 284 cases where the hand still exists.

     So: ask hand_history for the id first, and if it genuinely is not there
     yet, key on what the caller always knows - the table and the hand number. */
  IF p_hand_id IS NULL AND p_table_id IS NOT NULL AND p_hand_number IS NOT NULL THEN
    SELECT h.id INTO p_hand_id
      FROM public.hand_history h
     WHERE h.table_id = p_table_id
       AND h.hand_number = p_hand_number
     ORDER BY h.created_at DESC
     LIMIT 1;
    -- Phase 6.4: the legs name the hand as soon as we know it.
    PERFORM set_config('app.ledger_hand_id', COALESCE(p_hand_id::text, ''), true);
  END IF;

  IF p_hand_id IS NULL AND p_table_id IS NOT NULL AND p_hand_number IS NOT NULL THEN
    SELECT rr.id INTO v_dup_id
      FROM public.rake_records rr
     WHERE rr.table_id = p_table_id
       AND rr.hand_id IS NULL
       AND (rr.metadata->>'hand_number') = p_hand_number::text
       AND rr.created_at > now() - interval '2 days'
     ORDER BY rr.created_at
     LIMIT 1;
    IF v_dup_id IS NOT NULL THEN
      RETURN QUERY SELECT false, true, false, v_dup_id, 0::numeric,
                          NULL::text, 0::numeric, v_union_id;
      RETURN;
    END IF;
  END IF;

  INSERT INTO public.rake_records (
    hand_id, table_id, club_id, rake_amount, bbj_contribution, pot_size,
    num_players, player_contributions, is_tournament, tournament_id, source,
    metadata, rake_method, returned_uncalled
  ) VALUES (
    p_hand_id, p_table_id, p_club_id, p_rake, v_bbj, p_pot,
    p_num_players, p_contributions, (p_tournament_id IS NOT NULL), p_tournament_id,
    'atomic_distribute_rake',
    jsonb_build_object('hand_number', p_hand_number, 'is_private', v_is_private),
    v_method, p_returned_uncalled
  )
  ON CONFLICT (hand_id) WHERE hand_id IS NOT NULL DO NOTHING
  RETURNING id INTO v_rr_id;

  IF v_rr_id IS NOT NULL THEN
    v_first_claim := true;
  ELSE
    SELECT id INTO v_rr_id FROM public.rake_records
      WHERE hand_id = p_hand_id ORDER BY created_at LIMIT 1;
  END IF;

  IF v_first_claim AND p_hand_id IS NOT NULL
     AND p_contributions IS NOT NULL AND jsonb_typeof(p_contributions) = 'object' THEN
    INSERT INTO public.rake_attributions (
      hand_id, player_id, rake_amount, rake_record_id, table_id, club_id,
      gross_contribution, returned_uncalled, eligible_contribution,
      contribution_weight, weighted_rake_credit, bbj_attributed_contribution,
      rake_method
    )
    SELECT p_hand_id,
           a.user_id,
           a.credit,
           v_rr_id, p_table_id,
           COALESCE((SELECT ts.club_id FROM public.table_seats ts
                      WHERE ts.table_id = p_table_id AND ts.user_id = a.user_id
                      ORDER BY ts.joined_at DESC NULLS LAST LIMIT 1), p_club_id),
           (p_contributions ->> a.user_id::text)::numeric
             + COALESCE((p_returned_uncalled ->> a.user_id::text)::numeric, 0),
           COALESCE((p_returned_uncalled ->> a.user_id::text)::numeric, 0),
           (p_contributions ->> a.user_id::text)::numeric,
           a.weight,
           a.credit,
           COALESCE(b.credit, 0),
           v_method
      FROM public.fn_allocate_rake_credits(p_rake, p_contributions, v_method) a
      LEFT JOIN public.fn_allocate_rake_credits(v_bbj, p_contributions, v_method) b
        ON b.user_id = a.user_id
    ON CONFLICT (hand_id, player_id) DO NOTHING;

    SELECT COALESCE(SUM(a.credit), 0) INTO v_alloc_sum
      FROM public.fn_allocate_rake_credits(p_rake, p_contributions, v_method) a;
    IF v_alloc_sum <> round(p_rake, 2) AND v_alloc_sum <> 0 THEN
      INSERT INTO public.financial_alerts (severity, source, message, context)
      VALUES ('critical', 'atomic_distribute_rake', 'RAKE_ALLOCATION_MISMATCH',
        jsonb_build_object('hand_id', p_hand_id, 'rake', p_rake,
          'allocated', v_alloc_sum, 'method', v_method));
    END IF;
  END IF;

  /* THE LEG KEY IS DERIVED, NEVER RANDOM (2026-09-06). A random key made
     rake_distribution_legs' ON CONFLICT (leg_key, leg) unreachable, so the
     club wallet's period and lifetime rake were incremented again for a hand
     already counted. When the hand has no id, the key is the table and the
     hand number - the same hand always produces the same key. */
  v_leg_key := COALESCE(
    p_hand_id,
    CASE WHEN p_table_id IS NOT NULL AND p_hand_number IS NOT NULL
         THEN md5('rake:' || p_table_id::text || ':' || p_hand_number::text)::uuid
    END,
    gen_random_uuid());
  PERFORM set_config('app.ledger_settlement', 'rake:' || v_leg_key::text, true);

  INSERT INTO public.rake_distribution_legs (leg_key, leg, club_id, union_id, amount)
  VALUES (v_leg_key, 'club_accumulator', p_club_id, v_union_id, v_net)
  ON CONFLICT (leg_key, leg) DO NOTHING;
  GET DIAGNOSTICS v_n = ROW_COUNT;
  IF v_n > 0 THEN
    UPDATE public.club_wallets
       SET period_rake_collected     = period_rake_collected     + p_rake,
           period_bbj_contribution   = period_bbj_contribution   + v_bbj,
           lifetime_rake_collected   = lifetime_rake_collected   + p_rake,
           lifetime_bbj_contribution = lifetime_bbj_contribution + v_bbj,
           chip_balance              = chip_balance,  -- 2026-09-02 ruling: the club share is paid weekly from the rake treasury, not per hand
           updated_at                = NOW()
     WHERE club_id = p_club_id
     RETURNING chip_balance INTO v_cw_after;

    IF v_cw_after IS NULL THEN
      INSERT INTO public.club_wallets (
        club_id, chip_balance, period_rake_collected, period_bbj_contribution,
        lifetime_rake_collected, lifetime_bbj_contribution
      ) VALUES (
        p_club_id, 0, p_rake, v_bbj, p_rake, v_bbj
      )
      ON CONFLICT (club_id) DO UPDATE SET
        period_rake_collected     = club_wallets.period_rake_collected     + EXCLUDED.period_rake_collected,
        period_bbj_contribution   = club_wallets.period_bbj_contribution   + EXCLUDED.period_bbj_contribution,
        lifetime_rake_collected   = club_wallets.lifetime_rake_collected   + EXCLUDED.lifetime_rake_collected,
        lifetime_bbj_contribution = club_wallets.lifetime_bbj_contribution + EXCLUDED.lifetime_bbj_contribution,
        chip_balance              = club_wallets.chip_balance              + EXCLUDED.chip_balance,
        updated_at                = NOW()
      RETURNING chip_balance INTO v_cw_after;
    END IF;

    INSERT INTO public.club_wallet_transactions (
      club_id, type, amount, balance_after, related_id, reason
    ) VALUES (
      p_club_id, 'rake_in', v_net, v_cw_after, p_hand_id,
      'Rake collected (hand ' || COALESCE('#' || p_hand_number::text, 'unknown') ||
        ', BBJ contribution ' || v_bbj::text || ')'
    );

    IF NOT v_first_claim THEN v_recovered := true; END IF;
  END IF;

  IF v_union_id IS NOT NULL THEN
    v_route := 'union_rake_wallet';
    INSERT INTO public.rake_distribution_legs (leg_key, leg, club_id, union_id, amount)
    VALUES (v_leg_key, 'union_rake', p_club_id, v_union_id, p_rake)
    ON CONFLICT (leg_key, leg) DO NOTHING;
    GET DIAGNOSTICS v_n = ROW_COUNT;
    IF v_n > 0 THEN
      -- UNION LAW (restored 2026-08-30): RAKE TREASURY ONLY. chip_balance
      -- (Union Bank) is deliberately NOT touched.
      INSERT INTO public.union_wallets (union_id, chip_balance, rake_wallet, total_rake_collected)
           VALUES (v_union_id, 0, p_rake, p_rake)
      ON CONFLICT (union_id) DO UPDATE SET
           rake_wallet          = public.union_wallets.rake_wallet + p_rake,
           total_rake_collected = COALESCE(public.union_wallets.total_rake_collected, 0) + p_rake,
           updated_at           = NOW()
      RETURNING rake_wallet INTO v_union_rake;

      INSERT INTO public.union_wallet_transactions (
        union_id, club_id, amount, tx_type, wallet, direction, balance_after, notes
      ) VALUES (
        v_union_id, p_club_id, p_rake, 'rake', 'rake_wallet', 'credit', v_union_rake,
        'Cash game rake: hand #' || COALESCE(p_hand_number::text, '?') ||
          ' (' || COALESCE(v_club_name, 'club') || ')'
      );

      IF NOT v_first_claim THEN v_recovered := true; END IF;
    END IF;
  ELSE
    v_route := 'club_chip_treasury';
    INSERT INTO public.rake_distribution_legs (leg_key, leg, club_id, union_id, amount)
    VALUES (v_leg_key, 'chip_treasury', p_club_id, NULL, p_rake)
    ON CONFLICT (leg_key, leg) DO NOTHING;
    GET DIAGNOSTICS v_n = ROW_COUNT;
    IF v_n > 0 THEN
      /* ZERO-DRIFT: this leg writes its own chip_ledger row below; suppress
         the clubs auto-journal for this one statement. */
      PERFORM set_config('app.ledger_autoskip_clubs', '1', true);
      UPDATE public.clubs
         SET chip_treasury = COALESCE(chip_treasury, 0) + p_rake,
             total_rake    = COALESCE(total_rake, 0) + p_rake,
             updated_at    = NOW()
       WHERE id = p_club_id;
      PERFORM set_config('app.ledger_autoskip_clubs', '0', true);

      /* JOURNAL THE TREASURY LEG (2026-08-31). Inside the leg_key first-claim
         guard, so a replayed hand credits once and journals once. Journal failure rolls back this distribution. */
      BEGIN
        INSERT INTO public.chip_ledger
          (performed_by, from_type, from_entity_id, to_type, to_entity_id,
           amount, category, club_id, table_id, hand_id, tournament_id, description)
        VALUES (
          COALESCE(auth.uid(), '2d1cd6c3-5700-4af9-a271-d4863fdab20d'::uuid),
          'table_stack',   p_table_id,
          'club_treasury', p_club_id,
          p_rake, 'rake', p_club_id, p_table_id, p_hand_id, p_tournament_id,
          'Rake to club treasury, hand ' || COALESCE('#' || p_hand_number::text, 'unknown')
            || ' (atomic_distribute_rake)');
      EXCEPTION WHEN OTHERS THEN
      -- A journal failure must abort the enclosing chip movement.
      -- Preserve SQLSTATE so the existing caller can retry the whole operation.
      RAISE;
    END;

      IF NOT v_first_claim THEN v_recovered := true; END IF;
    END IF;
  END IF;

  RETURN QUERY SELECT v_first_claim, (NOT v_first_claim), v_recovered, v_rr_id,
                      v_net, v_route, p_rake, v_union_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.award_diamonds_v2(p_user_id uuid, p_action_key text, p_reference_id text DEFAULT NULL::text, p_target_id text DEFAULT NULL::text, p_metadata jsonb DEFAULT '{}'::jsonb)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
    c_catalog_version   constant integer := 3;
    c_platform_budget   constant bigint  := 2500000;

    c_login_base        constant integer := 10;
    c_login_step        constant integer := 5;
    c_login_max         constant integer := 110;

    c_egg_monthly_cap   constant integer := 1000;
    c_egg_max_single    constant integer := 1000;

    c_streak_monthly_cap       constant integer := 1000;
    c_daily_bonus_monthly_cap  constant integer := 3750;
    c_training_monthly_cap     constant integer := 1500;
    c_achievement_monthly_cap  constant integer := 1000;
    c_challenge_monthly_cap    constant integer := 1000;

    v_now               timestamptz := now();
    v_today             date;
    v_day_start         timestamptz;
    v_day_end           timestamptz;
    v_month_start       timestamptz;
    v_month_end         timestamptz;
    v_period            text;

    v_found_action      boolean;
    v_base_diamonds     integer;
    v_max_per_day       integer;
    v_counts_cap        boolean;
    v_lifetime          boolean;
    v_category          text;

    v_balance           integer := 0;
    v_multiplier        numeric(6,2) := 1.00;
    v_is_vip            boolean := false;
    v_vip_tier          text;
    v_vip_expires_at    timestamptz;

    v_daily_cap         integer;
    v_monthly_cap       integer;
    v_daily_used        integer := 0;
    v_monthly_used      integer := 0;
    v_daily_remaining   integer;
    v_monthly_remaining integer;

    v_reference_id      text;
    v_requested         integer := 0;
    v_award             integer := 0;
    v_capped            boolean := false;
    v_streak            integer := 0;
    v_action_count      integer := 0;
    v_egg_request       integer := 0;
    v_family_request    integer := 0;
    v_streak_entitlement_continuation boolean := false;
    v_streak_entitlement_initialization boolean := false;
    v_streak_milestone_days integer := 0;
    v_streak_milestone_base integer := 0;
    v_streak_entitlement integer := 0;
    v_streak_already_awarded integer := 0;
    v_streak_claim_count integer := 0;
    v_expected_streak_reference text;

    -- These values always describe the same action family. The allowance is
    -- deliberately applied only after v_requested has been multiplied.
    v_family_monthly_cap integer;
    v_family_month_total bigint := 0;
    v_family_remaining   bigint := 0;
    v_family_all_or_nothing boolean := false;

    v_budget_total      bigint;
    v_budget_spent      bigint;
    v_budget_left       bigint;
    v_new_balance       integer;
    v_metadata          jsonb;
    v_profile_rows      integer := 0;
    v_constraint_name   text;
BEGIN
    v_today       := (v_now AT TIME ZONE 'America/Chicago')::date;
    v_day_start   := v_today::timestamp AT TIME ZONE 'America/Chicago';
    v_day_end     := (v_today + 1)::timestamp AT TIME ZONE 'America/Chicago';
    v_month_start := date_trunc('month', v_today::timestamp) AT TIME ZONE 'America/Chicago';
    v_month_end   := (date_trunc('month', v_today::timestamp) + interval '1 month')
                     AT TIME ZONE 'America/Chicago';
    v_period      := to_char(v_today, 'YYYY-MM');

    IF p_user_id IS NULL OR p_action_key IS NULL OR btrim(p_action_key) = '' THEN
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0, 'requested', 0,
            'reason', 'invalid_input', 'capped', false,
            'daily_remaining', 0, 'monthly_remaining', 0, 'balance_after', 0
        );
    END IF;

    v_reference_id := COALESCE(btrim(p_reference_id), '');
    v_metadata     := COALESCE(p_metadata, '{}'::jsonb);

    -- Only the server-owned milestone claim ledger may submit an amount that
    -- is already post-multiplier. The row and exact part reference are checked
    -- again below; arbitrary service callers cannot use metadata to bypass a
    -- user's multiplier or manufacture an entitlement.
    BEGIN
        v_streak_entitlement_continuation :=
            p_action_key = 'streak_reward'
            AND COALESCE(v_metadata ->> '_source', '') = 'fn_claim_training_streak_milestone_v2'
            AND COALESCE((v_metadata ->> 'post_multiplier_entitlement')::boolean, false);
        v_streak_entitlement_initialization :=
            p_action_key = 'streak_reward'
            AND COALESCE(v_metadata ->> '_source', '') = 'fn_claim_training_streak_milestone_v2'
            AND NOT v_streak_entitlement_continuation;
    EXCEPTION WHEN invalid_text_representation THEN
        v_streak_entitlement_continuation := false;
        v_streak_entitlement_initialization := false;
    END;

    -- Serialize every award for one user before reading any user-owned state.
    -- The first integer is a namespace reserved for award_diamonds_v2; a hash
    -- collision can only over-serialize two users, never weaken correctness.
    PERFORM pg_catalog.pg_advisory_xact_lock(
        1799876946,
        pg_catalog.hashtext(p_user_id::text)
    );

    SELECT true, c.diamonds, c.max_per_day, c.counts_toward_daily_cap,
           c.lifetime, c.category
      INTO v_found_action, v_base_diamonds, v_max_per_day, v_counts_cap,
           v_lifetime, v_category
      FROM public.diamond_reward_catalog c
     WHERE c.action_key = p_action_key
       AND c.active = true;

    IF NOT FOUND OR NOT COALESCE(v_found_action, false) THEN
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0, 'requested', 0,
            'reason', 'unknown_action', 'capped', false,
            'daily_remaining', 0, 'monthly_remaining', 0, 'balance_after', 0
        );
    END IF;

    -- This row lock is both a cross-function serialization boundary and the
    -- authoritative balance/multiplier snapshot used by every write below.
    SELECT COALESCE(pr.diamonds, 0),
           COALESCE(pr.diamond_multiplier, 1.00),
           COALESCE(pr.is_vip, false),
           pr.vip_tier,
           pr.vip_expires_at
      INTO v_balance, v_multiplier, v_is_vip, v_vip_tier, v_vip_expires_at
      FROM public.profiles pr
     WHERE pr.id = p_user_id
     FOR UPDATE;

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0, 'requested', 0,
            'reason', 'user_not_found', 'capped', false,
            'daily_remaining', 0, 'monthly_remaining', 0, 'balance_after', 0
        );
    END IF;

    -- Keep the currently deployed 1x..10x validation contract. Regardless of
    -- the stored multiplier, the post-multiplier caps below remain absolute.
    IF v_multiplier IS NULL OR v_multiplier <= 0 OR v_multiplier > 10 THEN
        v_multiplier := 1.00;
    END IF;

    -- COALESCE is intentional: SQL NULL must never make this VIP check fail
    -- open. The standing economy invariant inspects this exact property.
    v_is_vip := COALESCE(v_is_vip, false)
        AND (
            COALESCE(v_vip_tier, '') = 'lifetime'
            OR (v_vip_expires_at IS NOT NULL AND v_vip_expires_at > v_now)
        );

    -- Kill switch (Diamond Accounting Standard 3.4 layer 6, review D11): a human-opened
    -- diamond_issuance freeze refuses every promotional award until it is cleared.
    IF EXISTS (SELECT 1 FROM public.ca_payout_freeze f WHERE f.scope = 'diamond_issuance' AND f.cleared_at IS NULL) THEN
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0, 'requested', 0,
            'reason', 'diamond_issuance_frozen', 'capped', false,
            'daily_remaining', 0, 'monthly_remaining', 0, 'balance_after', v_balance
        );
    END IF;

    v_daily_cap   := CASE WHEN v_is_vip THEN 150 ELSE 110 END;
    v_monthly_cap := CASE WHEN v_is_vip THEN 4500 ELSE 3300 END;

    IF v_counts_cap THEN
        SELECT COALESCE(SUM(t.amount), 0)::int
          INTO v_daily_used
          FROM public.diamond_transactions t
          JOIN public.diamond_reward_catalog c ON c.action_key = t.transaction_type
         WHERE t.user_id = p_user_id
           AND t.amount > 0
           AND c.counts_toward_daily_cap = true
           AND t.created_at >= v_day_start
           AND t.created_at < v_day_end;

        SELECT COALESCE(SUM(t.amount), 0)::int
          INTO v_monthly_used
          FROM public.diamond_transactions t
          JOIN public.diamond_reward_catalog c ON c.action_key = t.transaction_type
         WHERE t.user_id = p_user_id
           AND t.amount > 0
           AND c.counts_toward_daily_cap = true
           AND t.created_at >= v_month_start
           AND t.created_at < v_month_end;
    END IF;

    v_daily_remaining   := GREATEST(v_daily_cap - v_daily_used, 0);
    v_monthly_remaining := GREATEST(v_monthly_cap - v_monthly_used, 0);

    IF v_max_per_day IS NOT NULL THEN
        SELECT COUNT(*)::int
          INTO v_action_count
          FROM public.diamond_transactions t
         WHERE t.user_id = p_user_id
           AND t.transaction_type = p_action_key
           AND t.amount > 0
           AND t.created_at >= v_day_start
           AND t.created_at < v_day_end;

        IF v_action_count >= v_max_per_day THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', 0,
                'reason', 'action_limit', 'capped', true,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance,
                'multiplier', v_multiplier
            );
        END IF;
    END IF;

    IF v_lifetime AND EXISTS (
        SELECT 1
          FROM public.diamond_transactions t
         WHERE t.user_id = p_user_id
           AND t.transaction_type = p_action_key
           AND t.amount > 0
    ) THEN
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0, 'requested', 0,
            'reason', 'already_claimed', 'capped', false,
            'daily_remaining', v_daily_remaining,
            'monthly_remaining', v_monthly_remaining,
            'balance_after', v_balance
        );
    END IF;

    IF v_reference_id <> '' AND EXISTS (
        SELECT 1
          FROM public.diamond_transactions t
         WHERE t.user_id = p_user_id
           AND t.reference_id = v_reference_id
    ) THEN
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0, 'requested', 0,
            'reason', 'duplicate', 'capped', false,
            'daily_remaining', v_daily_remaining,
            'monthly_remaining', v_monthly_remaining,
            'balance_after', v_balance
        );
    END IF;

    v_requested := COALESCE(v_base_diamonds, 0);

    IF p_action_key = 'daily_login' THEN
        BEGIN
            WITH ranked AS (
                SELECT (created_at AT TIME ZONE 'America/Chicago')::date AS d,
                       ROW_NUMBER() OVER (
                           ORDER BY (created_at AT TIME ZONE 'America/Chicago')::date DESC
                       ) AS rn
                  FROM public.diamond_transactions
                 WHERE user_id = p_user_id
                   AND transaction_type = 'daily_login'
                   AND amount > 0
                   AND (created_at AT TIME ZONE 'America/Chicago')::date < v_today
                 GROUP BY 1
            )
            SELECT COUNT(*)::int
              INTO v_streak
              FROM ranked
             WHERE d = v_today - rn;
        EXCEPTION WHEN others THEN
            v_streak := 0;
        END;

        v_streak    := v_streak + 1;
        v_requested := LEAST(c_login_base + (v_streak - 1) * c_login_step, c_login_max);

    ELSIF p_action_key = 'easter_egg' THEN
        BEGIN
            v_egg_request := COALESCE((v_metadata ->> 'egg_diamonds')::int, 0);
        EXCEPTION WHEN others THEN
            v_egg_request := 0;
        END;

        v_egg_request := LEAST(GREATEST(v_egg_request, 0), c_egg_max_single);
        v_requested := v_egg_request;
        v_family_monthly_cap := c_egg_monthly_cap;
        v_family_all_or_nothing := true;

    ELSIF p_action_key = 'streak_reward' THEN
        IF v_streak_entitlement_continuation OR v_streak_entitlement_initialization THEN
            BEGIN
                v_streak_milestone_days := COALESCE((v_metadata ->> 'milestone_days')::int, 0);
            EXCEPTION WHEN others THEN
                v_streak_milestone_days := 0;
            END;

            v_streak_milestone_base := CASE v_streak_milestone_days
                WHEN 3 THEN 25
                WHEN 7 THEN 75
                WHEN 14 THEN 150
                WHEN 30 THEN 400
                WHEN 60 THEN 800
                WHEN 100 THEN 2000
                WHEN 365 THEN 10000
                ELSE 0
            END;

            SELECT claims.entitlement_diamonds,
                   claims.diamonds_awarded,
                   claims.claim_count
              INTO v_streak_entitlement,
                   v_streak_already_awarded,
                   v_streak_claim_count
              FROM public.training_streak_milestone_claims claims
             WHERE claims.user_id = p_user_id
               AND claims.milestone_days = v_streak_milestone_days
               AND claims.completed_at IS NULL
             FOR UPDATE;

            v_expected_streak_reference := 'streak_' || p_user_id::text || '_'
                || v_streak_milestone_days::text || '_part_'
                || (v_streak_claim_count + 1)::text;
            v_family_request := CASE
                WHEN v_streak_entitlement_continuation THEN GREATEST(
                    COALESCE(v_streak_entitlement, 0)
                      - COALESCE(v_streak_already_awarded, 0),
                    0
                )
                ELSE v_streak_milestone_base
            END;

            IF NOT FOUND
               OR (
                 v_streak_entitlement_continuation
                 AND COALESCE(v_streak_entitlement, 0) <= 0
               )
               OR (
                 v_streak_entitlement_initialization
                 AND v_streak_entitlement IS NOT NULL
               )
               OR v_streak_milestone_base <= 0
               OR COALESCE(v_streak_already_awarded, 0) > v_streak_milestone_base * 10
               OR v_family_request <= 0
               OR v_family_request > 100000
               OR v_reference_id <> v_expected_streak_reference
               OR COALESCE((v_metadata ->> 'streak_diamonds')::int, -1) <> v_family_request THEN
                RETURN jsonb_build_object(
                    'success', false, 'awarded', 0, 'requested', 0,
                    'reason', 'invalid_entitlement', 'capped', false,
                    'daily_remaining', v_daily_remaining,
                    'monthly_remaining', v_monthly_remaining,
                    'balance_after', v_balance
                );
            END IF;
        ELSE
            BEGIN
                v_family_request := COALESCE((v_metadata ->> 'streak_diamonds')::int, 0);
            EXCEPTION WHEN others THEN
                v_family_request := 0;
            END;
            v_family_request := LEAST(GREATEST(v_family_request, 0), 10000);
        END IF;
        IF v_family_request <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_family_request,
                'reason', 'invalid_amount', 'capped', false,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance
            );
        END IF;
        v_requested := v_family_request;
        v_family_monthly_cap := c_streak_monthly_cap;

    ELSIF p_action_key IN ('daily_bonus', 'daily_bonus_boost') THEN
        BEGIN
            v_family_request := COALESCE((v_metadata ->> 'bonus_diamonds')::int, 0);
        EXCEPTION WHEN others THEN
            v_family_request := 0;
        END;
        v_family_request := LEAST(GREATEST(v_family_request, 0), 125);
        IF v_family_request <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_family_request,
                'reason', 'invalid_amount', 'capped', false,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance
            );
        END IF;
        v_requested := v_family_request;
        v_family_monthly_cap := c_daily_bonus_monthly_cap;

    ELSIF p_action_key = 'training_reward' THEN
        BEGIN
            v_family_request := COALESCE((v_metadata ->> 'reward_diamonds')::int, 0);
        EXCEPTION WHEN others THEN
            v_family_request := 0;
        END;
        v_family_request := LEAST(GREATEST(v_family_request, 0), 50);
        IF v_family_request <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_family_request,
                'reason', 'invalid_amount', 'capped', false,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance
            );
        END IF;
        v_requested := v_family_request;
        v_family_monthly_cap := c_training_monthly_cap;

    ELSIF p_action_key = 'achievement' THEN
        BEGIN
            v_family_request := COALESCE((v_metadata ->> 'achievement_diamonds')::int, 0);
        EXCEPTION WHEN others THEN
            v_family_request := 0;
        END;
        v_family_request := LEAST(GREATEST(v_family_request, 0), 500);
        IF v_family_request <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_family_request,
                'reason', 'invalid_amount', 'capped', false,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance
            );
        END IF;
        v_requested := v_family_request;
        v_family_monthly_cap := c_achievement_monthly_cap;

    ELSIF p_action_key = 'challenge' THEN
        BEGIN
            v_family_request := COALESCE((v_metadata ->> 'challenge_diamonds')::int, 0);
        EXCEPTION WHEN others THEN
            v_family_request := 0;
        END;
        v_family_request := LEAST(GREATEST(v_family_request, 0), 500);
        IF v_family_request <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_family_request,
                'reason', 'invalid_amount', 'capped', false,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance
            );
        END IF;
        v_requested := v_family_request;
        v_family_monthly_cap := c_challenge_monthly_cap;

    ELSIF p_action_key = 'tournament_prize' THEN
        BEGIN
            v_family_request := COALESCE((v_metadata ->> 'prize_diamonds')::int, 0);
        EXCEPTION WHEN others THEN
            v_family_request := 0;
        END;
        v_family_request := LEAST(GREATEST(v_family_request, 0), 10000);
        IF v_family_request <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', 0,
                'reason', 'invalid_amount', 'capped', false,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance
            );
        END IF;
        v_requested := v_family_request;
    END IF;

    IF v_requested <= 0 THEN
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0, 'requested', 0,
            'reason', 'not_eligible', 'capped', false,
            'daily_remaining', v_daily_remaining,
            'monthly_remaining', v_monthly_remaining,
            'balance_after', v_balance
        );
    END IF;

    -- This is the only multiplier application. Every family and general cap
    -- below is therefore enforced against the amount that could be credited.
    IF NOT v_streak_entitlement_continuation THEN
        v_requested := GREATEST(ROUND(v_requested * v_multiplier)::int, 1);
    END IF;

    IF v_streak_entitlement_initialization THEN
        -- Snapshot the full post-multiplier milestone entitlement only after
        -- the server-owned claim RPC proves post-epoch eligibility. Historical
        -- transaction-backed credit is then deducted exactly once; it is not
        -- multiplied a second time.
        v_streak_entitlement := GREATEST(
            v_requested,
            COALESCE(v_streak_already_awarded, 0)
        );
        IF v_streak_entitlement > v_requested THEN
            -- Historical exact-reference credit can exceed today's price when
            -- the claim-time multiplier was higher. Report an effective
            -- multiplier that reproduces the clamped integer entitlement so
            -- every replay/API response remains internally consistent.
            v_multiplier := ROUND(
                v_streak_entitlement::numeric / v_streak_milestone_base::numeric,
                6
            );
        END IF;
        v_requested := GREATEST(
            v_streak_entitlement - COALESCE(v_streak_already_awarded, 0),
            0
        );
        IF v_requested = 0 THEN
            RETURN jsonb_build_object(
                'success', true, 'awarded', 0, 'requested', 0,
                'entitlement', v_streak_entitlement,
                'reason', 'entitlement_already_paid', 'capped', false,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance,
                'multiplier', v_multiplier
            );
        END IF;
    END IF;
    v_award := v_requested;

    IF v_family_monthly_cap IS NOT NULL THEN
        SELECT COALESCE(SUM(t.amount), 0)::bigint
          INTO v_family_month_total
          FROM public.diamond_transactions t
         WHERE t.user_id = p_user_id
           AND t.transaction_type = p_action_key
           AND t.amount > 0
           AND t.created_at >= v_month_start
           AND t.created_at < v_month_end;

        v_family_remaining := GREATEST(
            v_family_monthly_cap::bigint - v_family_month_total,
            0::bigint
        );

        IF v_family_remaining <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_requested,
                'entitlement', CASE
                    WHEN v_streak_entitlement_initialization
                      OR v_streak_entitlement_continuation
                      THEN v_streak_entitlement
                    ELSE NULL
                END,
                'reason', 'action_limit', 'capped', true,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance,
                'multiplier', v_multiplier
            );
        END IF;

        -- Easter eggs preserve their documented whole-award/defer behavior.
        IF v_family_all_or_nothing AND v_award::bigint > v_family_remaining THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_requested,
                'reason', 'action_limit', 'capped', true,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance
            );
        END IF;

        v_award := LEAST(v_award::bigint, v_family_remaining)::int;
    END IF;

    IF v_counts_cap THEN
        IF v_daily_remaining <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_requested,
                'entitlement', CASE
                    WHEN v_streak_entitlement_initialization
                      OR v_streak_entitlement_continuation
                      THEN v_streak_entitlement
                    ELSE NULL
                END,
                'reason', 'daily_cap', 'capped', true,
                'daily_remaining', 0,
                'monthly_remaining', v_monthly_remaining,
                'balance_after', v_balance,
                'multiplier', v_multiplier
            );
        END IF;

        IF v_monthly_remaining <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_requested,
                'entitlement', CASE
                    WHEN v_streak_entitlement_initialization
                      OR v_streak_entitlement_continuation
                      THEN v_streak_entitlement
                    ELSE NULL
                END,
                'reason', 'monthly_cap', 'capped', true,
                'daily_remaining', v_daily_remaining,
                'monthly_remaining', 0,
                'balance_after', v_balance,
                'multiplier', v_multiplier
            );
        END IF;

        v_award := LEAST(v_award, v_daily_remaining, v_monthly_remaining);
    END IF;

    -- RULING 21 (Dan, 2026-09-08): a platform-wide pot never refuses a player, and never
    -- quietly shrinks what they earned. This block read diamond_platform_budget FOR UPDATE,
    -- refused with 'budget_exhausted' when the shared pot was dry, and - worse - did
    --
    --     v_award := LEAST(v_award::bigint, v_budget_left)::int;
    --
    -- so a player owed 100 who arrived when the pot held 7 was paid 7, flagged `capped`, with no
    -- way to learn that the number had nothing to do with anything they had done. Both are gone.
    -- The per-user daily and monthly allowances above are the whole of the limit now, and they
    -- have already been applied to v_award.
    --
    -- v_budget_total, v_budget_spent and v_budget_left are left declared and unused rather than
    -- editing the DECLARE block of a long money function for cosmetics.
    IF v_award <= 0 THEN
            RETURN jsonb_build_object(
                'success', false, 'awarded', 0, 'requested', v_requested,
                'entitlement', CASE
                    WHEN v_streak_entitlement_initialization
                      OR v_streak_entitlement_continuation
                      THEN v_streak_entitlement
                    ELSE NULL
                END,
                'reason', 'nothing_to_award', 'capped', true,
            'daily_remaining', v_daily_remaining,
            'monthly_remaining', v_monthly_remaining,
            'balance_after', v_balance,
            'multiplier', v_multiplier
        );
    END IF;

    v_capped := v_award < v_requested;
    v_new_balance := v_balance + v_award;

    -- The running total on this one row is gone with the gate it fed. It was also the same
    -- one-hot-row-per-month shape that lost 5,860 awards to lock timeouts on the engine table
    -- this morning, so removing it takes a second contention point out of an award path. What
    -- this award cost is recorded by the journal trigger, in ca_diamond_engine_spend.

    UPDATE public.profiles
       SET diamonds = v_new_balance,
           diamond_balance = v_new_balance,
           updated_at = now()
     WHERE id = p_user_id;
    GET DIAGNOSTICS v_profile_rows = ROW_COUNT;

    IF v_profile_rows <> 1 THEN
        RAISE EXCEPTION 'award_diamonds_v2 profile row disappeared for user %', p_user_id
            USING ERRCODE = 'P0001';
    END IF;

    v_metadata := v_metadata || jsonb_build_object(
        'catalog_version', c_catalog_version,
        'action_key', p_action_key,
        'target_id', p_target_id,
        'requested', v_requested,
        'awarded', v_award,
        'capped', v_capped,
        'multiplier', v_multiplier,
        'entitlement', CASE
            WHEN v_streak_entitlement_initialization
              OR v_streak_entitlement_continuation
              THEN v_streak_entitlement
            ELSE NULL
        END,
        'category', v_category,
        'reference_id', v_reference_id,
        'streak', CASE WHEN p_action_key = 'daily_login' THEN v_streak ELSE NULL END,
        'is_vip', v_is_vip
    );

    INSERT INTO public.diamond_transactions (
        user_id, amount, transaction_type, type, description,
        balance_after, reference_id, metadata, created_at,
        counterparty, issuance_class
    ) VALUES (
        p_user_id,
        v_award,
        p_action_key,
        p_action_key,
        format(
            'Diamond Rewards v2: %s%s',
            p_action_key,
            CASE WHEN v_capped THEN ' (capped)' ELSE '' END
        ),
        v_new_balance,
        CASE WHEN v_reference_id = '' THEN NULL ELSE v_reference_id END,
        v_metadata,
        v_now,
        'promo_budget:catalog_v2',
        'promotional'
    );

    IF v_counts_cap THEN
        v_daily_remaining := GREATEST(v_daily_remaining - v_award, 0);
        v_monthly_remaining := GREATEST(v_monthly_remaining - v_award, 0);
    END IF;

    RETURN jsonb_build_object(
        'success', true,
        'awarded', v_award,
        'requested', v_requested,
        'entitlement', CASE
            WHEN v_streak_entitlement_initialization
              OR v_streak_entitlement_continuation
              THEN v_streak_entitlement
            ELSE NULL
        END,
        'reason', 'ok',
        'capped', v_capped,
        'daily_remaining', v_daily_remaining,
        'monthly_remaining', v_monthly_remaining,
        'balance_after', v_new_balance
        , 'multiplier', v_multiplier
    );

EXCEPTION
    WHEN unique_violation THEN
        -- Entering this handler rolls back every statement in the function
        -- body, including budget/profile updates. Only the two canonical
        -- reference-id idempotency indexes represent a duplicate award;
        -- unrelated uniqueness defects must stay loud and roll back.
        GET STACKED DIAGNOSTICS v_constraint_name = CONSTRAINT_NAME;
        IF v_constraint_name NOT IN (
            'idx_diamond_transactions_reference_id',
            'diamond_transactions_user_reference_uidx'
        ) THEN
            RAISE;
        END IF;
        RETURN jsonb_build_object(
            'success', false, 'awarded', 0,
            'requested', COALESCE(v_requested, 0),
            'reason', 'duplicate', 'capped', false,
            'daily_remaining', COALESCE(v_daily_remaining, 0),
            'monthly_remaining', COALESCE(v_monthly_remaining, 0),
            'balance_after', COALESCE(v_balance, 0)
        );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.ca_hand_player_facts_one(p_hand_id uuid, p_user uuid DEFAULT NULL::uuid)
 RETURNS TABLE(user_id uuid, hand_id uuid, created_at timestamp with time zone, is_cash boolean, tournament_id uuid, game_variant text, big_blind numeric, small_blind numeric, n_players integer, seat_position text, my_blind numeric, won_amt numeric, is_winner boolean, invested_actions numeric, aggro_cnt integer, call_cnt integer, vpip boolean, pfr boolean, folded boolean, three_bet boolean, three_bet_opp boolean, faced_three_bet boolean, folded_to_three_bet boolean, cbet_opp boolean, cbet_made boolean, showdown boolean, hand_secs numeric, profit numeric)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
WITH my_hands AS MATERIALIZED (
  SELECT h.id, h.tournament_id,
         lower(coalesce(h.game_variant, 'nlh')) AS game_variant,
         coalesce(h.big_blind, 0)::numeric   AS big_blind,
         coalesce(h.small_blind, 0)::numeric AS small_blind,
         coalesce(h.pot_size, 0)::numeric    AS pot_size,
         h.button_seat, h.created_at, h.started_at, h.ended_at,
         h.players,
         coalesce(h.actions, '[]'::jsonb) AS actions,
         coalesce(h.winners, '[]'::jsonb) AS winners
  FROM hand_history h
  WHERE h.id = p_hand_id
),
acts AS MATERIALIZED (
  SELECT mh.id AS hand_id, x.ord,
         x.act->>'userId' AS auid, x.act->>'stage' AS stage,
         lower(x.act->>'action') AS action,
         coalesce((x.act->>'amount')::numeric, 0) AS amount,
         coalesce((x.act->>'dead')::boolean, false) AS dead_flag
  FROM my_hands mh
  CROSS JOIN LATERAL jsonb_array_elements(mh.actions) WITH ORDINALITY x(act, ord)
),
players_all AS (
  SELECT mh.id AS hand_id, pl->>'userId' AS puid, (pl->>'seat')::int AS seat
  FROM my_hands mh
  CROSS JOIN LATERAL jsonb_array_elements(mh.players) pl
),
seatmap AS (
  SELECT hand_id, array_agg(seat ORDER BY seat) AS seats
  FROM players_all GROUP BY hand_id
),
-- The ONLY thing p_user narrows.
seated AS (
  SELECT hand_id, puid::uuid AS uid, seat AS my_seat
  FROM players_all
  WHERE puid ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    AND (p_user IS NULL OR puid = p_user::text)
),
folders AS (
  SELECT DISTINCT hand_id, auid FROM acts WHERE action = 'fold' AND auid IS NOT NULL
),
no_fold AS (
  SELECT p.hand_id,
         count(*) FILTER (WHERE f.auid IS NULL AND p.puid IS NOT NULL) AS no_fold_players
  FROM players_all p
  LEFT JOIN folders f ON f.hand_id = p.hand_id AND f.auid = p.puid
  GROUP BY p.hand_id
),
pf_raise AS (
  SELECT hand_id, ord, auid FROM acts
  WHERE stage = 'preflop' AND action IN ('raise','all_in','allin')
),
pf_ranked AS (
  SELECT hand_id, ord, auid,
         first_value(auid) OVER w AS first_actor,
         first_value(ord)  OVER w AS first_ord,
         last_value(auid)  OVER (PARTITION BY hand_id ORDER BY ord
                                 ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS last_actor
  FROM pf_raise
  WINDOW w AS (PARTITION BY hand_id ORDER BY ord)
),
hand_pf AS (
  SELECT hand_id,
         min(first_ord)   AS first_ord,
         min(first_actor) AS first_actor,
         min(last_actor)  AS last_pf_raiser,
         min(ord) FILTER (WHERE auid IS DISTINCT FROM first_actor) AS first_other_ord
  FROM pf_ranked GROUP BY hand_id
),
flop_first AS (
  SELECT DISTINCT ON (hand_id) hand_id, auid AS first_flop_bettor
  FROM acts WHERE stage = 'flop' AND action IN ('bet','all_in','allin')
  ORDER BY hand_id, ord
),
-- ── MONEY. actions[].amount is NOT one unit (src/utils/handReplay.ts:16-35):
--    bet / raise / all_in  -> raise-TO level for the street (CUMULATIVE)
--    call, blind posts     -> chips actually added           (INCREMENTAL)
--    return                -> uncalled chips handed back     (SUBTRACT)
--    ante (or dead=true)   -> in the pot, NOT in the live bet level
-- Computed for EVERY seat in the hand, not just p_user: the uncalled-bet
-- inference below needs the whole table's bet levels.
money_acts AS (
  SELECT a.hand_id, a.auid, a.stage, a.ord, a.amount,
         CASE
           WHEN a.action IN ('bet','raise','all_in','allin') THEN 'to'
           WHEN a.action = 'return' THEN 'ret'
           WHEN a.action IN ('call','sb','bb','post','post_sb','post_bb','blind',
                             'small_blind','big_blind','straddle','ante') THEN 'inc'
           ELSE 'none'
         END AS kind,
         (a.dead_flag OR a.action = 'ante') AS dead,
         a.action IN ('sb','bb','post','post_sb','post_bb','blind','small_blind','big_blind') AS is_blind_post
  FROM acts a
  WHERE a.auid IS NOT NULL
),
hand_log_shape AS (
  SELECT hand_id,
         bool_or(is_blind_post) AS has_posts,
         bool_or(kind = 'ret')  AS has_returns
  FROM money_acts GROUP BY hand_id
),
-- Position-implied blind for every seat (the rows written before
-- FORCED_BETS_POSTED carry no post rows, so the blinds have to be synthesised
-- exactly as src/utils/handReplay.ts does when !logHasBlinds).
seat_blind AS (
  SELECT p.hand_id, p.puid AS auid, p.seat,
         CASE
           WHEN ofs.pos_offset IS NULL THEN 0
           WHEN array_length(sm.seats, 1) = 2 THEN
             CASE WHEN ofs.pos_offset = 0 THEN mh.small_blind ELSE mh.big_blind END
           WHEN ofs.pos_offset = 1 THEN mh.small_blind
           WHEN ofs.pos_offset = 2 THEN mh.big_blind
           ELSE 0
         END AS implied_blind
  FROM players_all p
  JOIN my_hands mh ON mh.id = p.hand_id
  JOIN seatmap sm ON sm.hand_id = p.hand_id
  CROSS JOIN LATERAL (SELECT CASE
      WHEN mh.button_seat IS NULL OR sm.seats IS NULL
        OR p.seat IS NULL OR array_length(sm.seats, 1) < 2
        OR array_position(sm.seats, mh.button_seat::int) IS NULL THEN NULL
      ELSE (array_position(sm.seats, p.seat)
            - array_position(sm.seats, mh.button_seat::int)
            + array_length(sm.seats, 1)) % array_length(sm.seats, 1)
    END AS pos_offset) ofs
  WHERE p.puid IS NOT NULL
),
money_w AS (
  SELECT m.*,
         max(ord) FILTER (WHERE kind = 'to')
           OVER (PARTITION BY hand_id, auid, stage ORDER BY ord
                 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS last_to_ord,
         coalesce(sum(amount) FILTER (WHERE kind = 'inc' AND NOT dead)
           OVER (PARTITION BY hand_id, auid, stage ORDER BY ord
                 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW), 0) AS inc_cum,
         row_number() OVER (PARTITION BY hand_id, auid, stage ORDER BY ord DESC) AS rn_desc
  FROM money_acts m
),
street_committed_raw AS (
  SELECT w.hand_id, w.auid, w.stage,
         CASE WHEN w.last_to_ord IS NULL THEN w.inc_cum
              ELSE t.amount + (w.inc_cum - t.inc_cum) END AS committed,
         (w.last_to_ord IS NOT NULL) AS to_level
  FROM money_w w
  LEFT JOIN money_w t ON t.hand_id = w.hand_id AND t.auid = w.auid
                     AND t.stage = w.stage AND t.ord = w.last_to_ord
  WHERE w.rn_desc = 1
),
-- Seed the blinds into preflop when the log has no post rows. A player whose
-- preflop bet level is a raise-TO already has the blind inside it.
street_committed AS (
  SELECT r.hand_id, r.auid, r.stage,
         r.committed
           + CASE WHEN r.stage = 'preflop' AND NOT r.to_level AND NOT coalesce(hs.has_posts, false)
                  THEN coalesce(sb.implied_blind, 0) ELSE 0 END AS committed
  FROM street_committed_raw r
  LEFT JOIN hand_log_shape hs ON hs.hand_id = r.hand_id
  LEFT JOIN seat_blind sb ON sb.hand_id = r.hand_id AND sb.auid = r.auid
  UNION ALL
  -- Blind seats that never acted (walk, or a fold with no logged row).
  SELECT sb.hand_id, sb.auid, 'preflop', sb.implied_blind
  FROM seat_blind sb
  LEFT JOIN hand_log_shape hs ON hs.hand_id = sb.hand_id
  LEFT JOIN street_committed_raw r
         ON r.hand_id = sb.hand_id AND r.auid = sb.auid AND r.stage = 'preflop'
  WHERE sb.implied_blind > 0
    AND NOT coalesce(hs.has_posts, false)
    AND r.hand_id IS NULL
),
-- An uncalled bet on a log that does not record returns: the street's top
-- contributor's excess over the next highest was matched by nobody.
street_rank AS (
  SELECT sc.hand_id, sc.stage, sc.auid, sc.committed,
         row_number() OVER (PARTITION BY sc.hand_id, sc.stage ORDER BY sc.committed DESC) AS rn,
         lead(sc.committed) OVER (PARTITION BY sc.hand_id, sc.stage ORDER BY sc.committed DESC) AS next_committed
  FROM street_committed sc
),
inferred_ret AS (
  SELECT r.hand_id, r.auid,
         sum(r.committed - coalesce(r.next_committed, 0)) AS inferred
  FROM street_rank r
  JOIN hand_log_shape hs ON hs.hand_id = r.hand_id
  WHERE r.rn = 1 AND NOT hs.has_returns
    AND r.committed - coalesce(r.next_committed, 0) > 0.005
  GROUP BY r.hand_id, r.auid
),
money_extras AS (
  SELECT hand_id, auid,
         coalesce(sum(amount) FILTER (WHERE kind = 'inc' AND dead), 0) AS dead_money,
         coalesce(sum(amount) FILTER (WHERE kind = 'ret'), 0) AS returned,
         coalesce(sum(amount) FILTER (WHERE is_blind_post AND NOT dead), 0) AS posted_blind
  FROM money_acts GROUP BY hand_id, auid
),
money_per_player AS (
  SELECT sc.hand_id, sc.auid,
         sum(sc.committed) AS live_committed
  FROM street_committed sc GROUP BY sc.hand_id, sc.auid
),
-- THE STORED POT ARBITRATES THE INFERENCE (handReplay.ts, same rule): if the
-- rebuild WITH inferred returns misses pot_size and the rebuild WITHOUT them
-- lands on it, the inference was wrong for this hand and is withdrawn.
--
-- Per-hand totals are GROUPed once and joined, never re-scanned per hand:
-- the correlated form this replaced walked the whole CTE for every hand,
-- which is quadratic in the window and is why the range form took 10 s for
-- four minutes of hands (2026-09-04). Same numbers, hash joins.
pot_live AS (
  SELECT hand_id, sum(live_committed) AS s FROM money_per_player GROUP BY hand_id
),
pot_extras AS (
  SELECT hand_id, sum(dead_money - returned) AS s FROM money_extras GROUP BY hand_id
),
pot_inferred AS (
  SELECT hand_id, sum(inferred) AS s FROM inferred_ret GROUP BY hand_id
),
hand_pot_check AS (
  SELECT mh.id AS hand_id,
         mh.pot_size,
         coalesce(pl.s, 0) + coalesce(px.s, 0) AS pot_without,
         coalesce(pi.s, 0) AS inferred_total
  FROM my_hands mh
  LEFT JOIN pot_live     pl ON pl.hand_id = mh.id
  LEFT JOIN pot_extras   px ON px.hand_id = mh.id
  LEFT JOIN pot_inferred pi ON pi.hand_id = mh.id
),
inference_ok AS (
  SELECT hand_id,
         NOT (inferred_total > 0
              AND abs((pot_without - inferred_total) - pot_size) >= 0.02
              AND abs(pot_without - pot_size) < 0.02) AS use_inference
  FROM hand_pot_check
),
per_player_base AS (
  SELECT s.hand_id, s.uid, s.my_seat,
    coalesce(bool_or(a.stage = 'preflop' AND a.action IN ('call','bet','raise','all_in','allin')), false) AS vpip,
    coalesce(bool_or(a.stage = 'preflop' AND a.action IN ('raise','all_in','allin')), false) AS pfr,
    count(*) FILTER (WHERE a.action IN ('bet','raise','all_in','allin'))::int AS aggro_cnt,
    count(*) FILTER (WHERE a.action = 'call')::int AS call_cnt,
    coalesce(bool_or(a.action = 'fold'), false) AS folded,
    coalesce(bool_or(a.stage = 'flop'), false) AS acted_on_flop,
    min(a.ord) FILTER (WHERE a.stage = 'preflop' AND a.action IN ('raise','all_in','allin')) AS my_first_pf_raise,
    max(a.ord) FILTER (WHERE a.stage = 'preflop' AND a.action IN ('raise','all_in','allin')) AS my_last_pf_raise,
    max(a.ord) FILTER (WHERE a.stage = 'preflop' AND a.action NOT IN ('sb','bb','post','post_sb','post_bb','blind','small_blind','big_blind','ante','straddle','return')) AS my_last_pf_any,
    max(a.ord) FILTER (WHERE a.stage = 'preflop' AND a.action = 'fold') AS my_last_pf_fold
  FROM seated s
  LEFT JOIN acts a ON a.hand_id = s.hand_id AND a.auid = s.uid::text
  GROUP BY s.hand_id, s.uid, s.my_seat
),
with_first_other AS (
  SELECT b.*,
    CASE WHEN hp.first_actor IS DISTINCT FROM b.uid::text
         THEN hp.first_ord ELSE hp.first_other_ord END AS first_other_pf_raise,
    hp.last_pf_raiser
  FROM per_player_base b
  LEFT JOIN hand_pf hp ON hp.hand_id = b.hand_id
),
reraise AS (
  SELECT b.hand_id, b.uid, min(p.ord) AS reraise_after_me
  FROM with_first_other b
  JOIN pf_raise p ON p.hand_id = b.hand_id
  WHERE p.auid IS DISTINCT FROM b.uid::text AND p.ord > b.my_first_pf_raise
  GROUP BY b.hand_id, b.uid
)
SELECT
  d.uid, mh.id, mh.created_at,
  (mh.tournament_id IS NULL), mh.tournament_id, mh.game_variant,
  mh.big_blind, mh.small_blind, array_length(sm.seats, 1),
  pos.seat_position,
  -- my_blind: what the log says was posted when it says anything, else the
  -- blind the position implies (rows written before FORCED_BETS_POSTED).
  inv.my_blind,
  w.won_amt, w.is_winner,
  -- invested_actions EXCLUDES the blind above, so `invested_actions + my_blind`
  -- keeps meaning "everything this seat put in", as every reader assumes.
  inv.total_invested - inv.my_blind,
  d.aggro_cnt, d.call_cnt, d.vpip, d.pfr, d.folded,
  coalesce(d.my_last_pf_raise > d.first_other_pf_raise, false),
  coalesce(d.my_last_pf_any   > d.first_other_pf_raise, false),
  (r.reraise_after_me IS NOT NULL),
  coalesce(d.my_last_pf_fold > r.reraise_after_me, false),
  coalesce(d.last_pf_raiser = d.uid::text AND d.acted_on_flop, false),
  coalesce(d.last_pf_raiser = d.uid::text AND ff.first_flop_bettor = d.uid::text, false),
  (NOT d.folded AND nf.no_fold_players >= 2),
  CASE
    WHEN mh.started_at IS NOT NULL AND mh.ended_at IS NOT NULL
    THEN GREATEST(0, LEAST(1800, EXTRACT(epoch FROM (mh.ended_at - mh.started_at))))::numeric
    ELSE 45
  END,
  (w.won_amt - inv.total_invested)
FROM with_first_other d
JOIN my_hands mh ON mh.id = d.hand_id
JOIN seatmap  sm ON sm.hand_id = d.hand_id
JOIN no_fold  nf ON nf.hand_id = d.hand_id
LEFT JOIN reraise    r  ON r.hand_id  = d.hand_id AND r.uid = d.uid
LEFT JOIN flop_first ff ON ff.hand_id = d.hand_id
LEFT JOIN money_per_player mp ON mp.hand_id = d.hand_id AND mp.auid = d.uid::text
LEFT JOIN money_extras     mx ON mx.hand_id = d.hand_id AND mx.auid = d.uid::text
LEFT JOIN inferred_ret     ir ON ir.hand_id = d.hand_id AND ir.auid = d.uid::text
LEFT JOIN hand_log_shape   hs ON hs.hand_id = d.hand_id
LEFT JOIN inference_ok     io ON io.hand_id = d.hand_id
CROSS JOIN LATERAL (
  SELECT
    coalesce(sum((w1->>'amount')::numeric) FILTER (WHERE w1->>'userId' = d.uid::text), 0) AS won_amt,
    count(*) FILTER (WHERE w1->>'userId' = d.uid::text) > 0 AS is_winner
  FROM jsonb_array_elements(mh.winners) w1
) w
CROSS JOIN LATERAL (
  SELECT
    CASE
      WHEN ofs.pos_offset IS NULL THEN 0
      WHEN array_length(sm.seats, 1) = 2 THEN
        CASE WHEN ofs.pos_offset = 0 THEN mh.small_blind ELSE mh.big_blind END
      WHEN ofs.pos_offset = 1 THEN mh.small_blind
      WHEN ofs.pos_offset = 2 THEN mh.big_blind
      ELSE 0
    END AS my_blind,
    CASE
      WHEN ofs.pos_offset IS NULL THEN 'UNK'
      WHEN array_length(sm.seats, 1) = 2 THEN CASE WHEN ofs.pos_offset = 0 THEN 'BTN' ELSE 'BB' END
      WHEN ofs.pos_offset = 0 THEN 'BTN'
      WHEN ofs.pos_offset = 1 THEN 'SB'
      WHEN ofs.pos_offset = 2 THEN 'BB'
      WHEN ofs.pos_offset = array_length(sm.seats, 1) - 1 THEN 'CO'
      WHEN ofs.pos_offset = 3 THEN 'UTG'
      WHEN ofs.pos_offset = 4 AND array_length(sm.seats, 1) >= 8 THEN 'UTG+1'
      ELSE 'MP'
    END AS seat_position
  FROM (SELECT CASE
      WHEN mh.button_seat IS NULL OR sm.seats IS NULL
        OR d.my_seat IS NULL OR array_length(sm.seats, 1) < 2
        OR array_position(sm.seats, mh.button_seat::int) IS NULL THEN NULL
      ELSE (array_position(sm.seats, d.my_seat)
            - array_position(sm.seats, mh.button_seat::int)
            + array_length(sm.seats, 1)) % array_length(sm.seats, 1)
    END AS pos_offset) ofs
) pos
CROSS JOIN LATERAL (
  -- Everything this seat put in: live bet levels per street (blinds seeded
  -- when the log has no post rows), plus dead money, minus what came back -
  -- recorded, or inferred when the log predates recorded returns.
  SELECT coalesce(mp.live_committed, 0)
       + coalesce(mx.dead_money, 0)
       - coalesce(mx.returned, 0)
       - CASE WHEN coalesce(io.use_inference, true) THEN coalesce(ir.inferred, 0) ELSE 0 END AS total_invested,
         CASE WHEN coalesce(hs.has_posts, false) THEN coalesce(mx.posted_blind, 0) ELSE pos.my_blind END AS my_blind
) inv;
$function$
;
CREATE OR REPLACE FUNCTION public.ca_refresh_reporting_rollups(p_start date, p_end date)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_base jsonb; v_cash jsonb;
BEGIN
  v_base:=public.ca_refresh_reporting_rollups_base(p_start,p_end);
  v_cash:=public.ca_refresh_reporting_cash_rollup(p_start,p_end);
  RETURN v_base || jsonb_build_object('cash_repair',v_cash);
END;
$function$
;
CREATE OR REPLACE FUNCTION public.ca_reporting_tournament_clubs_for_user(p_user_id uuid)
 RETURNS TABLE(club_id uuid)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT h.club_id
    FROM (
      SELECT DISTINCT ON (uc.union_id) cm.club_id, uc.union_id
        FROM public.club_members cm
        JOIN public.union_clubs uc ON uc.club_id = cm.club_id
       WHERE cm.user_id = p_user_id
       ORDER BY uc.union_id, cm.joined_at ASC NULLS LAST, cm.club_id
    ) h
  UNION
  SELECT cm.club_id
    FROM public.club_members cm
   WHERE cm.user_id = p_user_id
     AND NOT EXISTS (
       SELECT 1 FROM public.union_clubs uc WHERE uc.club_id = cm.club_id
     );
$function$
;
CREATE OR REPLACE FUNCTION public.enqueue_daily_challenge_event(p_user_id uuid, p_event_key text, p_amounts jsonb, p_magnitudes jsonb, p_values jsonb, p_occurred_at timestamp with time zone)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_event public.daily_challenge_event_outbox%ROWTYPE;
  v_receipt public.daily_challenge_progress_events%ROWTYPE;
  v_receipt_found boolean;
BEGIN
  PERFORM public.fn_lock_daily_mission_user(p_user_id);

  INSERT INTO public.daily_challenge_event_outbox (
    user_id,
    event_key,
    amounts,
    magnitudes,
    threshold_values,
    occurred_at
  ) VALUES (
    p_user_id,
    p_event_key,
    p_amounts,
    p_magnitudes,
    p_values,
    p_occurred_at
  )
  ON CONFLICT (user_id, event_key) DO NOTHING;

  SELECT * INTO STRICT v_event
  FROM public.daily_challenge_event_outbox
  WHERE user_id = p_user_id
    AND event_key = p_event_key
  FOR UPDATE;

  IF v_event.amounts IS DISTINCT FROM p_amounts
     OR v_event.magnitudes IS DISTINCT FROM p_magnitudes
     OR v_event.threshold_values IS DISTINCT FROM p_values
     OR v_event.occurred_at IS DISTINCT FROM p_occurred_at
  THEN
    RAISE EXCEPTION 'Daily Missions event key is already bound to another payload';
  END IF;

  SELECT * INTO v_receipt
  FROM public.daily_challenge_progress_events
  WHERE user_id = p_user_id
    AND event_key = p_event_key
  FOR UPDATE;
  v_receipt_found := FOUND;

  IF v_receipt_found
     AND (
       v_receipt.amounts IS DISTINCT FROM v_event.amounts
       OR v_receipt.magnitudes IS DISTINCT FROM v_event.magnitudes
       OR v_receipt.threshold_values IS DISTINCT FROM v_event.threshold_values
       OR v_receipt.occurred_at IS DISTINCT FROM v_event.occurred_at
     )
  THEN
    RAISE EXCEPTION 'Daily Missions event key is already bound to another payload';
  END IF;

  BEGIN
    PERFORM public.record_daily_challenge_event(
      v_event.user_id,
      v_event.event_key,
      v_event.amounts,
      v_event.magnitudes,
      v_event.threshold_values,
      v_event.occurred_at
    );
    DELETE FROM public.daily_challenge_event_outbox
    WHERE user_id = v_event.user_id
      AND event_key = v_event.event_key;
    RETURN true;
  EXCEPTION WHEN OTHERS THEN
    UPDATE public.daily_challenge_event_outbox
    SET attempts = attempts + 1,
        last_error = left(SQLERRM, 1000),
        next_attempt_at = now() + interval '1 minute'
    WHERE user_id = v_event.user_id
      AND event_key = v_event.event_key;
    RETURN false;
  END;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.enqueue_daily_challenge_event(p_user_id uuid, p_event_key text, p_amounts jsonb, p_magnitudes jsonb, p_occurred_at timestamp with time zone)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_event public.daily_challenge_event_outbox%ROWTYPE;
  v_receipt public.daily_challenge_progress_events%ROWTYPE;
  v_receipt_found boolean;
BEGIN
  PERFORM public.fn_lock_daily_mission_user(p_user_id);

  INSERT INTO public.daily_challenge_event_outbox (
    user_id,
    event_key,
    amounts,
    magnitudes,
    occurred_at
  ) VALUES (
    p_user_id,
    p_event_key,
    p_amounts,
    p_magnitudes,
    p_occurred_at
  )
  ON CONFLICT (user_id, event_key) DO NOTHING;

  SELECT * INTO STRICT v_event
  FROM public.daily_challenge_event_outbox
  WHERE user_id = p_user_id
    AND event_key = p_event_key
  FOR UPDATE;

  IF v_event.amounts IS DISTINCT FROM p_amounts
     OR v_event.magnitudes IS DISTINCT FROM p_magnitudes
     OR v_event.threshold_values IS DISTINCT FROM '{}'::jsonb
     OR v_event.occurred_at IS DISTINCT FROM p_occurred_at
  THEN
    RAISE EXCEPTION 'Daily Missions event key is already bound to another payload';
  END IF;

  SELECT * INTO v_receipt
  FROM public.daily_challenge_progress_events
  WHERE user_id = p_user_id
    AND event_key = p_event_key
  FOR UPDATE;
  v_receipt_found := FOUND;

  IF v_receipt_found
     AND (
       v_receipt.amounts IS DISTINCT FROM v_event.amounts
       OR v_receipt.magnitudes IS DISTINCT FROM v_event.magnitudes
       OR v_receipt.threshold_values IS DISTINCT FROM '{}'::jsonb
       OR v_receipt.occurred_at IS DISTINCT FROM v_event.occurred_at
     )
  THEN
    RAISE EXCEPTION 'Daily Missions event key is already bound to another payload';
  END IF;

  BEGIN
    PERFORM public.record_daily_challenge_event(
      v_event.user_id,
      v_event.event_key,
      v_event.amounts,
      v_event.magnitudes,
      v_event.occurred_at
    );
    DELETE FROM public.daily_challenge_event_outbox
    WHERE user_id = v_event.user_id
      AND event_key = v_event.event_key;
    RETURN true;
  EXCEPTION WHEN OTHERS THEN
    UPDATE public.daily_challenge_event_outbox
    SET attempts = attempts + 1,
        last_error = left(SQLERRM, 1000),
        next_attempt_at = now() + interval '1 minute'
    WHERE user_id = v_event.user_id
      AND event_key = v_event.event_key;
    RETURN false;
  END;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.increment_union_wallet(p_union_id uuid, p_amount numeric, p_club_id uuid DEFAULT NULL::uuid, p_notes text DEFAULT NULL::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_amount numeric; v_new_rake numeric;
BEGIN
  IF p_union_id IS NULL THEN RETURN jsonb_build_object('success', false, 'error', 'p_union_id required'); END IF;
  IF p_amount IS NULL OR p_amount <= 0 THEN RETURN jsonb_build_object('success', true, 'skipped', 'zero_amount'); END IF;
  v_amount := round(p_amount, 2);

  -- ZERO-DRIFT phase 2: declare the ledger category unless the caller
  -- already set one in this transaction (caller context is richer).
  IF COALESCE(current_setting('app.ledger_category', true), '') = '' THEN
    PERFORM set_config('app.ledger_category', 'rake', true);
    PERFORM set_config('app.ledger_counterparty', 'table_stack', true);
    PERFORM set_config('app.ledger_counterparty_entity', '', true);
  END IF;

  -- Rake Treasury only - see rake_lands_only_in_rake_treasury_not_union_bank.
  INSERT INTO public.union_wallets (union_id, chip_balance, rake_wallet, total_rake_collected)
       VALUES (p_union_id, 0, v_amount, v_amount)
  ON CONFLICT (union_id) DO UPDATE SET
       rake_wallet          = public.union_wallets.rake_wallet + v_amount,
       total_rake_collected = COALESCE(public.union_wallets.total_rake_collected, 0) + v_amount,
       updated_at           = NOW()
  RETURNING rake_wallet INTO v_new_rake;

  IF p_notes IS NOT NULL OR p_club_id IS NOT NULL THEN
    INSERT INTO public.union_wallet_transactions
      (union_id, club_id, amount, tx_type, wallet, direction, balance_after, notes)
    VALUES (p_union_id, p_club_id, v_amount, 'rake', 'rake_wallet', 'credit', v_new_rake,
            COALESCE(p_notes, 'Union rake credit'));
  END IF;

  RETURN jsonb_build_object('success', true, 'union_id', p_union_id, 'amount', v_amount,
                            'new_rake_wallet', v_new_rake);
END $function$
;
CREATE OR REPLACE FUNCTION public.is_club_admin(p_club_id uuid, p_user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public', 'extensions'
AS $function$
BEGIN
  IF EXISTS (SELECT 1 FROM public.clubs WHERE id=p_club_id AND asset='diamonds') THEN RETURN false; END IF;
    RETURN EXISTS (
        SELECT 1 FROM clubs WHERE id = p_club_id AND owner_id = p_user_id
    ) OR EXISTS (
        SELECT 1 FROM club_members
        WHERE club_id = p_club_id
        AND user_id = p_user_id
        AND role IN ('owner', 'co_owner', 'admin')
        AND status = 'active'
    );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.is_club_admin(p_club_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.club_members
    WHERE club_id = p_club_id
      AND user_id = auth.uid()
      AND role IN ('owner', 'co_owner', 'admin', 'manager', 'agent')
  );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.is_reserved_username(p_username text)
 RETURNS boolean
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
DECLARE
  v text;
  v_exact text[] := ARRAY[
    -- System / admin
    'admin','administrator','root','sudo','superuser','system','sys','default',
    'staff','owner','mod','moderator','manager','team','official','officials',
    'verified','certified','authentic','authorized','employee','employees',
    'founder','ceo','cto','cfo','coo','exec','executive',
    -- Support / contact
    'support','helpdesk','helpcenter','helpcentre','help','helpme','helpus',
    'contact','contactus','contact_us','info','inquiry','hello','hi',
    'customerservice','customer_service','customersupport','customer_support',
    'cs','csr','faq','feedback','report','abuse',
    -- Brand: Smarter.Poker
    'smarter','smarterpoker','smartpoker','smarter_poker','smarter.poker',
    'smarter_pkr','smarterpkr','smarter_official','smarterofficial',
    'smarter_support','smarter_team','smarter_admin','smarter_help',
    'smarter_staff','smarter_mod','smarterpoker_official','smarterpoker_team',
    'smarterpoker_support','smarterpoker_admin','smarterpoker_help',
    'sp_official','sp_support','sp_admin','sp_team',
    -- Sub-products
    'jarvis','geeves','pokerbrain','poker_brain','clubarena','club_arena',
    'clubcommander','club_commander','clubcomm','pokernearme','poker_near_me',
    -- Founder / known accounts
    'kingfish','danbekavac','dan_bekavac','dan.bekavac','bekavac','dbekavac',
    -- Generic AI / bots
    'bot','robot','ai','gpt','chatgpt','claude','openai','anthropic',
    -- Web / dev infra
    'api','apis','www','web','app','apps','mobile','http','https','ftp',
    'dev','prod','staging','localhost','test','testing','demo','example',
    'sample','samples',
    -- Auth / security
    'password','passwd','login','signup','signin','signout','logout',
    'register','security','auth','authentication','oauth','sso','session',
    'token','mfa','2fa','otp','verify','verification',
    -- Communication
    'email','mail','postmaster','webmaster','hostmaster','noreply','no_reply',
    'mailer','mailerdaemon','newsletter',
    -- Money / finance
    'money','cash','bank','banking','wallet','treasury','payment','payments',
    'billing','invoice','stripe','paypal','venmo','cashapp','zelle','square',
    'applepay','googlepay','plaid',
    -- Poker terms
    'poker','dealer','tournament','tournaments','cashier','casino','casinos',
    'vip','vips','premium','pro','pros','gold','silver','platinum',
    'diamond','diamonds','chip','chips','table','tables','lobby',
    -- Competitor / impersonation
    'pokerstars','ggpoker','partypoker','888poker','americascardroom','acr',
    'wsop','worldseries','pokerbros','clubgg','pokerrrr','suprema','pokerdom',
    'naturalpoker','x-poker','xpoker',
    -- Scam / spam
    'free','freemoney','free_money','winner','winners','prize','jackpot',
    'lottery','claim','claimnow','claim_now','urgent','alert','warning',
    'notice','security_alert','account_locked','password_reset','verify_now',
    -- Generic placeholders
    'null','undefined','nil','none','void','anonymous','anon','guest','user',
    'users','everyone','all','nobody','somebody','default','me','you','i',
    -- Edge cases
    'dot','period','underscore','hyphen','space','tab'
  ];
BEGIN
  v := lower(trim(both ' @' from coalesce(p_username, '')));
  IF v IS NULL OR v = '' THEN RETURN true; END IF;

  -- Exact-match
  IF v = ANY(v_exact) THEN RETURN true; END IF;

  -- Prefix patterns - brand impersonation
  IF v ~ '^smarter[._]'      THEN RETURN true; END IF;  -- smarter_X, smarter.X
  IF v ~ '^smarterpoker'     THEN RETURN true; END IF;  -- anything starting with smarterpoker
  IF v ~ '^smartpoker'       THEN RETURN true; END IF;
  IF v ~ '^smarterpkr'       THEN RETURN true; END IF;
  IF v ~ '^jarvis[._0-9]'    THEN RETURN true; END IF;
  IF v ~ '^geeves[._0-9]'    THEN RETURN true; END IF;
  IF v ~ '^kingfish'         THEN RETURN true; END IF;  -- kingfish*, no impersonation of Dan
  IF v ~ '^bekavac'          THEN RETURN true; END IF;
  IF v ~ '^danbekavac'       THEN RETURN true; END IF;
  IF v ~ '^pokerbrain'       THEN RETURN true; END IF;
  IF v ~ '^clubarena'        THEN RETURN true; END IF;
  IF v ~ '^clubcommander'    THEN RETURN true; END IF;

  -- Prefix patterns - system role impersonation (must have separator to avoid blocking 'admins'-as-substring etc)
  IF v ~ '^admin[._]'        THEN RETURN true; END IF;
  IF v ~ '^support[._]'      THEN RETURN true; END IF;
  IF v ~ '^staff[._]'        THEN RETURN true; END IF;
  IF v ~ '^official[._]'     THEN RETURN true; END IF;
  IF v ~ '^moderator[._]'    THEN RETURN true; END IF;
  IF v ~ '^help[._]'         THEN RETURN true; END IF;

  -- Suffix patterns - system role impersonation
  IF v ~ '_admin$'           THEN RETURN true; END IF;
  IF v ~ '_support$'         THEN RETURN true; END IF;
  IF v ~ '_staff$'           THEN RETURN true; END IF;
  IF v ~ '_official$'        THEN RETURN true; END IF;
  IF v ~ '_team$'            THEN RETURN true; END IF;
  IF v ~ '_mod$'             THEN RETURN true; END IF;
  IF v ~ '_moderator$'       THEN RETURN true; END IF;
  IF v ~ '_help$'            THEN RETURN true; END IF;

  RETURN false;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.recompute_union_levels(p_union_id uuid DEFAULT NULL::uuid, p_force boolean DEFAULT false)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE v_id uuid;
BEGIN
  FOR v_id IN SELECT id FROM public.unions WHERE p_union_id IS NULL OR id = p_union_id LOOP
    PERFORM public.fn_apply_union_ladder(v_id);
  END LOOP;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.sp_cosmetic_is_owned(p_user uuid, p_token text, p_kind text DEFAULT NULL::text)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_token    text := public.sp_normalize_cosmetic_token(p_token);
  v_is_vip   boolean;
  v_free     text[] := ARRAY[
    'frame_slate', 'frame_ivory', 'frame_copper',
    'aura_mist',   'aura_dusk',   'aura_moss'
  ];
  v_catalog  text[] := ARRAY[
    'frame_gold', 'frame_diamond', 'frame_cyber', 'frame_hellfire',
    'aura_fire',  'aura_glitch',
    'frame_slate', 'frame_ivory', 'frame_copper',
    'aura_mist',   'aura_dusk',   'aura_moss'
  ];
BEGIN
  IF v_token = '' THEN
    RETURN true;
  END IF;

  IF NOT (v_token = ANY (v_catalog)) THEN
    RETURN false;
  END IF;

  IF p_kind IS NOT NULL AND v_token NOT LIKE (p_kind || '\_%') THEN
    RETURN false;
  END IF;

  -- FREE TIER: no user, no VIP, no ledger row required.
  IF v_token = ANY (v_free) THEN
    RETURN true;
  END IF;

  IF p_user IS NULL THEN
    RETURN false;
  END IF;

  SELECT p.is_vip INTO v_is_vip FROM public.profiles p WHERE p.id = p_user;
  IF coalesce(v_is_vip, false) THEN
    RETURN true;
  END IF;

  RETURN EXISTS (
    SELECT 1
    FROM public.avatar_unlocks au
    WHERE au.user_id = p_user
      AND public.sp_normalize_cosmetic_token(au.avatar_id) = v_token
  );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.ca_refresh_reporting_cash_rollup(p_start date, p_end date)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_start date:=LEAST(p_start,p_end); v_end date:=GREATEST(p_start,p_end);
  v_from timestamptz; v_to timestamptz; v_rows bigint;
BEGIN
  IF v_start IS NULL OR v_end IS NULL OR v_end-v_start>400 THEN
    RAISE EXCEPTION 'cash reporting refresh requires a 0-400 day range'; END IF;
  PERFORM pg_advisory_xact_lock(918273645);
  v_from:=v_start::timestamp AT TIME ZONE 'UTC';
  v_to:=(v_end+1)::timestamp AT TIME ZONE 'UTC';
  UPDATE public.ca_club_player_daily SET cash_net=0,updated_at=now()
   WHERE stat_date BETWEEN v_start AND v_end AND cash_net<>0;
  WITH home AS MATERIALIZED (
    SELECT DISTINCT ON(uc.union_id,cm.user_id) uc.union_id,cm.user_id,cm.club_id
      FROM public.club_members cm JOIN public.union_clubs uc ON uc.club_id=cm.club_id
     ORDER BY uc.union_id,cm.user_id,cm.joined_at ASC NULLS LAST,cm.club_id
  ), cash AS (
    SELECT x.club_id,x.user_id,x.stat_date,SUM(x.cash_net) AS cash_net FROM (
      SELECT h.club_id,wt.user_id,(wt.created_at AT TIME ZONE 'UTC')::date stat_date,
             SUM(CASE WHEN wt.type='credit' THEN wt.amount
                      WHEN wt.type='debit' THEN -wt.amount ELSE 0 END) cash_net
        FROM public.wallet_transactions wt
        JOIN public.tables tb ON tb.id=wt.table_id AND tb.union_id IS NOT NULL
         AND tb.tournament_id IS NULL
        JOIN home h ON h.union_id=tb.union_id AND h.user_id=wt.user_id
       WHERE wt.created_at>=v_from AND wt.created_at<v_to
         AND wt.category IN('buyin','cashout','addon','rebuy','refund') AND wt.table_id IS NOT NULL
       GROUP BY 1,2,3
      UNION ALL
      -- 2026-09-04: standalone tables, which this rollup never read.
      SELECT tb.club_id,wt.user_id,(wt.created_at AT TIME ZONE 'UTC')::date,
             SUM(CASE WHEN wt.type='credit' THEN wt.amount
                      WHEN wt.type='debit' THEN -wt.amount ELSE 0 END)
        FROM public.wallet_transactions wt
        JOIN public.tables tb ON tb.id=wt.table_id AND tb.union_id IS NULL
         AND tb.tournament_id IS NULL AND tb.club_id IS NOT NULL
       WHERE wt.created_at>=v_from AND wt.created_at<v_to
         AND wt.category IN('buyin','cashout','addon','rebuy','refund') AND wt.table_id IS NOT NULL
       GROUP BY 1,2,3
    ) x GROUP BY 1,2,3
  )
  INSERT INTO public.ca_club_player_daily AS d
    (club_id,user_id,stat_date,cash_net,tournament_net,updated_at)
  SELECT club_id,user_id,stat_date,cash_net,0,now() FROM cash
  ON CONFLICT(club_id,user_id,stat_date) DO UPDATE
   SET cash_net=EXCLUDED.cash_net,updated_at=now();
  SELECT count(*) INTO v_rows FROM public.ca_club_player_daily
   WHERE stat_date BETWEEN v_start AND v_end AND cash_net<>0;
  RETURN jsonb_build_object('start',v_start,'end',v_end,'cash_facts',v_rows,'refreshed_at',now());
END;
$function$
;
CREATE OR REPLACE FUNCTION public.ca_refresh_reporting_rollups_base(p_start date, p_end date)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_start date := LEAST(p_start, p_end);
  v_end date := GREATEST(p_start, p_end);
  v_from timestamptz;
  v_to timestamptz;
  v_players bigint;
  v_tournaments bigint;
  v_participants bigint;
BEGIN
  IF v_start IS NULL OR v_end IS NULL OR v_end - v_start > 400 THEN
    RAISE EXCEPTION 'reporting refresh requires a 0-400 day range';
  END IF;
  PERFORM pg_advisory_xact_lock(918273645);
  v_from := v_start::timestamp AT TIME ZONE 'UTC';
  v_to := (v_end + 1)::timestamp AT TIME ZONE 'UTC';

  DELETE FROM public.ca_club_player_daily WHERE stat_date BETWEEN v_start AND v_end;
  DELETE FROM public.ca_club_tournament_daily WHERE stat_date BETWEEN v_start AND v_end;
  DELETE FROM public.ca_club_tournament_player_daily WHERE stat_date BETWEEN v_start AND v_end;

  WITH home AS MATERIALIZED (
    SELECT DISTINCT ON (uc.union_id, cm.user_id)
           uc.union_id, cm.user_id, cm.club_id
      FROM public.club_members cm
      JOIN public.union_clubs uc ON uc.club_id = cm.club_id
     ORDER BY uc.union_id, cm.user_id, cm.joined_at ASC NULLS LAST, cm.club_id
  ), standalone AS MATERIALIZED (
    SELECT cm.user_id, cm.club_id
      FROM public.club_members cm
     WHERE NOT EXISTS (SELECT 1 FROM public.union_clubs uc WHERE uc.club_id=cm.club_id)
  ), affiliations AS MATERIALIZED (
    SELECT user_id, club_id FROM home
    UNION
    SELECT user_id, club_id FROM standalone
  ), mapped AS MATERIALIZED (
    -- 2026-09-04: cash rows are the ones with a table (buy-in, cash-out,
    -- add-on, rebuy, refund); tournament rows have a tournament and no table
    -- (buy-in, add-on, rebuy, refund, prize, bounty, prize reversal). The sign
    -- is the row's type. This read buy-in/cash-out and buy-in/prize/bounty.
    SELECT 'cash'::text AS kind,wt.user_id,(wt.created_at AT TIME ZONE 'UTC')::date AS stat_date,
           h.club_id,wt.category,wt.type,wt.amount,wt.related_entity_id AS tournament_id
      FROM public.wallet_transactions wt
      JOIN public.tables tb ON tb.id=wt.table_id AND tb.union_id IS NOT NULL
       AND tb.tournament_id IS NULL
      JOIN home h ON h.union_id=tb.union_id AND h.user_id=wt.user_id
     WHERE wt.created_at>=v_from AND wt.created_at<v_to
       AND wt.category IN ('buyin','cashout','addon','rebuy','refund') AND wt.table_id IS NOT NULL
    UNION ALL
    -- standalone tables, which this rollup never read.
    SELECT 'cash',wt.user_id,(wt.created_at AT TIME ZONE 'UTC')::date,
           tb.club_id,wt.category,wt.type,wt.amount,wt.related_entity_id
      FROM public.wallet_transactions wt
      JOIN public.tables tb ON tb.id=wt.table_id AND tb.union_id IS NULL
       AND tb.tournament_id IS NULL AND tb.club_id IS NOT NULL
     WHERE wt.created_at>=v_from AND wt.created_at<v_to
       AND wt.category IN ('buyin','cashout','addon','rebuy','refund') AND wt.table_id IS NOT NULL
    UNION ALL
    SELECT 'tournament',wt.user_id,(wt.created_at AT TIME ZONE 'UTC')::date,
           a.club_id,wt.category,wt.type,wt.amount,wt.related_entity_id
      FROM public.wallet_transactions wt
      JOIN affiliations a ON a.user_id=wt.user_id
     WHERE wt.created_at>=v_from AND wt.created_at<v_to
       AND wt.category IN ('tournament_buyin','prize','bounty','addon','rebuy','refund','prize_reversal')
       AND wt.related_entity_id IS NOT NULL AND wt.table_id IS NULL
  )
  INSERT INTO public.ca_club_player_daily
    (club_id,user_id,stat_date,cash_net,tournament_net,updated_at)
  SELECT m.club_id,m.user_id,m.stat_date,
         SUM(CASE WHEN m.kind='cash'
                  THEN CASE WHEN m.type='credit' THEN m.amount
                            WHEN m.type='debit' THEN -m.amount ELSE 0 END ELSE 0 END),
         SUM(CASE WHEN m.kind='tournament'
                  THEN CASE WHEN m.type='credit' THEN m.amount
                            WHEN m.type='debit' THEN -m.amount ELSE 0 END ELSE 0 END),now()
    FROM mapped m GROUP BY 1,2,3;

  WITH home AS MATERIALIZED (
    SELECT DISTINCT ON (uc.union_id,cm.user_id)
           uc.union_id,cm.user_id,cm.club_id
      FROM public.club_members cm JOIN public.union_clubs uc ON uc.club_id=cm.club_id
     ORDER BY uc.union_id,cm.user_id,cm.joined_at ASC NULLS LAST,cm.club_id
  ), standalone AS MATERIALIZED (
    SELECT cm.user_id,cm.club_id FROM public.club_members cm
     WHERE NOT EXISTS (SELECT 1 FROM public.union_clubs uc WHERE uc.club_id=cm.club_id)
  ), affiliations AS MATERIALIZED (
    SELECT user_id,club_id FROM home UNION SELECT user_id,club_id FROM standalone
  ), wallet_mapped AS MATERIALIZED (
    SELECT a.club_id,wt.related_entity_id AS tournament_id,wt.user_id,
           (wt.created_at AT TIME ZONE 'UTC')::date AS stat_date,
           CASE WHEN wt.type='credit' THEN wt.amount
                WHEN wt.type='debit' THEN -wt.amount ELSE 0 END AS winnings
      FROM public.wallet_transactions wt JOIN affiliations a ON a.user_id=wt.user_id
     WHERE wt.created_at>=v_from AND wt.created_at<v_to
       AND wt.category IN ('tournament_buyin','prize','bounty','addon','rebuy','refund','prize_reversal')
       AND wt.related_entity_id IS NOT NULL AND wt.table_id IS NULL
  ), entrant_totals AS MATERIALIZED (
    SELECT tp.tournament_id,count(*)::numeric AS total_players
      FROM public.tournament_players tp GROUP BY tp.tournament_id
  ), entrant_clubs AS MATERIALIZED (
    SELECT tp.tournament_id,a.club_id,count(*)::numeric AS club_players
      FROM public.tournament_players tp JOIN affiliations a ON a.user_id=tp.user_id
     GROUP BY tp.tournament_id,a.club_id
  ), rake_mapped AS MATERIALIZED (
    SELECT r.tournament_id,(r.created_at AT TIME ZONE 'UTC')::date AS stat_date,
           CASE WHEN r.metadata ? 'user_id' THEN a.club_id ELSE ec.club_id END AS club_id,
           CASE WHEN r.metadata ? 'user_id' THEN r.rake_amount
                ELSE r.rake_amount*ec.club_players/NULLIF(et.total_players,0) END AS fee
      FROM public.rake_records r
      LEFT JOIN affiliations a ON r.metadata ? 'user_id'
       AND a.user_id::text=r.metadata->>'user_id'
      LEFT JOIN entrant_clubs ec ON NOT (r.metadata ? 'user_id')
       AND ec.tournament_id=r.tournament_id
      LEFT JOIN entrant_totals et ON et.tournament_id=r.tournament_id
     WHERE r.created_at>=v_from AND r.created_at<v_to AND r.is_tournament
       AND r.tournament_id IS NOT NULL AND r.rake_amount<>0
  ), combined AS (
    SELECT wm.club_id,wm.tournament_id,wm.stat_date,0::numeric AS fee,
           sum(wm.winnings) AS winnings FROM wallet_mapped wm GROUP BY 1,2,3
    UNION ALL
    SELECT rm.club_id,rm.tournament_id,rm.stat_date,sum(rm.fee),0::numeric
      FROM rake_mapped rm WHERE rm.club_id IS NOT NULL GROUP BY 1,2,3
  )
  INSERT INTO public.ca_club_tournament_daily
    (club_id,tournament_id,stat_date,fee,winnings,updated_at)
  SELECT club_id,tournament_id,stat_date,sum(fee),sum(winnings),now()
    FROM combined GROUP BY 1,2,3;

  WITH home AS MATERIALIZED (
    SELECT DISTINCT ON (uc.union_id,cm.user_id) uc.union_id,cm.user_id,cm.club_id
      FROM public.club_members cm JOIN public.union_clubs uc ON uc.club_id=cm.club_id
     ORDER BY uc.union_id,cm.user_id,cm.joined_at ASC NULLS LAST,cm.club_id
  ), standalone AS MATERIALIZED (
    SELECT cm.user_id,cm.club_id FROM public.club_members cm
     WHERE NOT EXISTS (SELECT 1 FROM public.union_clubs uc WHERE uc.club_id=cm.club_id)
  ), affiliations AS MATERIALIZED (
    SELECT user_id,club_id FROM home UNION SELECT user_id,club_id FROM standalone
  )
  INSERT INTO public.ca_club_tournament_player_daily
    (club_id,tournament_id,user_id,stat_date,updated_at)
  SELECT DISTINCT a.club_id,wt.related_entity_id,wt.user_id,
         (wt.created_at AT TIME ZONE 'UTC')::date,now()
    FROM public.wallet_transactions wt JOIN affiliations a ON a.user_id=wt.user_id
   WHERE wt.created_at>=v_from AND wt.created_at<v_to
     AND wt.category IN ('tournament_buyin','prize','bounty','addon','rebuy','refund','prize_reversal')
     AND wt.related_entity_id IS NOT NULL AND wt.table_id IS NULL;

  SELECT count(*) INTO v_players FROM public.ca_club_player_daily
   WHERE stat_date BETWEEN v_start AND v_end;
  SELECT count(*) INTO v_tournaments FROM public.ca_club_tournament_daily
   WHERE stat_date BETWEEN v_start AND v_end;
  SELECT count(*) INTO v_participants FROM public.ca_club_tournament_player_daily
   WHERE stat_date BETWEEN v_start AND v_end;
  RETURN jsonb_build_object('start',v_start,'end',v_end,'player_facts',v_players,
    'tournament_facts',v_tournaments,'participant_facts',v_participants,
    'refreshed_at',now());
END;
$function$
;
CREATE OR REPLACE FUNCTION public.record_daily_challenge_event(p_user_id uuid, p_event_key text, p_amounts jsonb, p_magnitudes jsonb, p_values jsonb, p_occurred_at timestamp with time zone)
 RETURNS TABLE(id uuid, challenge_id text, progress integer, requirement integer, chip_reward numeric, diamond_reward integer, newly_completed boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_inserted integer;
  v_event public.daily_challenge_progress_events%ROWTYPE;
  v_daily_key text;
  v_weekly_key text;
  v_monthly_key text;
BEGIN
  IF p_user_id IS NULL OR p_event_key IS NULL
     OR length(p_event_key) NOT BETWEEN 1 AND 200 THEN
    RAISE EXCEPTION 'A player and stable event key are required';
  END IF;
  IF p_amounts IS NULL OR jsonb_typeof(p_amounts) <> 'object'
     OR p_magnitudes IS NULL OR jsonb_typeof(p_magnitudes) <> 'object'
     OR p_values IS NULL OR jsonb_typeof(p_values) <> 'object' THEN
    RAISE EXCEPTION 'Challenge event amounts, magnitudes, and values must be JSON objects';
  END IF;
  IF p_occurred_at < now() - interval '35 days'
     OR p_occurred_at > now() + interval '1 minute' THEN
    RAISE EXCEPTION 'Daily Missions events must be recorded at their authoritative occurrence time';
  END IF;

  IF EXISTS (
    SELECT 1
    FROM jsonb_object_keys(p_amounts) key
    WHERE key NOT IN (
      'hands_played',
      'hands_won',
      'showdowns',
      'showdowns_won',
      'hands_won_no_showdown',
      'big_pots',
      'strong_hands',
      'chips_won',
      'tournaments_played',
      'friends_added'
    )
  ) THEN
    RAISE EXCEPTION 'Unknown Daily Missions event type';
  END IF;
  IF EXISTS (
    SELECT 1
    FROM jsonb_each_text(p_amounts) item
    WHERE CASE
      WHEN item.value ~ '^\d+$' THEN
        item.value::numeric < 0
        OR (item.key = 'chips_won' AND item.value::numeric > 1000000000)
        OR (item.key <> 'chips_won' AND item.value::numeric > 2500)
      ELSE true
    END
  )
  OR EXISTS (
    SELECT 1
    FROM jsonb_each_text(p_magnitudes) item
    WHERE CASE
      WHEN item.value ~ '^\d+(\.\d+)?$' THEN
        item.value::numeric < 0 OR item.value::numeric > 1000000000
      ELSE true
    END
  ) THEN
    RAISE EXCEPTION 'Daily Missions event values are outside their server contract';
  END IF;

  -- Only catalog types with per-occurrence thresholds may carry value arrays.
  IF EXISTS (
    SELECT 1
    FROM jsonb_each(p_values) item
    WHERE item.key NOT IN ('big_pots', 'strong_hands')
       OR jsonb_typeof(item.value) <> 'array'
  ) THEN
    RAISE EXCEPTION 'Daily Missions exact values have an invalid category or shape';
  END IF;
  IF EXISTS (
    SELECT 1
    FROM jsonb_each(p_values) item
    WHERE jsonb_array_length(item.value) > 2500
  ) THEN
    RAISE EXCEPTION 'Daily Missions exact values exceed the event candidate limit';
  END IF;
  IF EXISTS (
    SELECT 1
    FROM jsonb_each(p_values) item
    WHERE NOT (p_amounts ? item.key)
       OR jsonb_array_length(item.value) <> (p_amounts ->> item.key)::integer
  ) THEN
    RAISE EXCEPTION 'Daily Missions exact values must match their scalar candidate count';
  END IF;
  IF EXISTS (
    SELECT 1
    FROM jsonb_each(p_values) category
    CROSS JOIN LATERAL jsonb_array_elements(category.value) AS candidate(value)
    WHERE CASE
      WHEN jsonb_typeof(candidate.value) = 'number' THEN
        candidate.value::text::numeric < 0
        OR candidate.value::text::numeric > 1000000000
        OR (category.key = 'strong_hands' AND candidate.value::text::numeric > 20)
      ELSE true
    END
  ) THEN
    RAISE EXCEPTION 'Daily Missions exact values must be bounded nonnegative numbers';
  END IF;

  PERFORM public.fn_lock_daily_mission_user(p_user_id);

  v_daily_key := to_char((p_occurred_at AT TIME ZONE 'utc')::date, 'YYYY-MM-DD');
  v_weekly_key := 'W'
    || to_char(date_trunc('week', p_occurred_at AT TIME ZONE 'utc')::date, 'YYYY-MM-DD');
  v_monthly_key := 'M' || to_char(p_occurred_at AT TIME ZONE 'utc', 'YYYY-MM');

  INSERT INTO public.daily_challenge_progress_events (
    user_id,
    event_key,
    amounts,
    magnitudes,
    threshold_values,
    occurred_at
  ) VALUES (
    p_user_id,
    p_event_key,
    p_amounts,
    p_magnitudes,
    p_values,
    p_occurred_at
  )
  ON CONFLICT (user_id, event_key) DO NOTHING;
  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  IF v_inserted = 0 THEN
    SELECT * INTO STRICT v_event
    FROM public.daily_challenge_progress_events
    WHERE user_id = p_user_id
      AND event_key = p_event_key
    FOR UPDATE;

    IF v_event.amounts IS DISTINCT FROM p_amounts
       OR v_event.magnitudes IS DISTINCT FROM p_magnitudes
       OR v_event.threshold_values IS DISTINCT FROM p_values
       OR v_event.occurred_at IS DISTINCT FROM p_occurred_at
    THEN
      RAISE EXCEPTION 'Daily Missions event key is already bound to another payload';
    END IF;

    RETURN;
  END IF;

  PERFORM public.fn_assign_current_challenge_period(
    p_user_id,
    'daily',
    v_daily_key,
    5
  );
  PERFORM public.fn_assign_current_challenge_period(
    p_user_id,
    'weekly',
    v_weekly_key,
    3
  );
  PERFORM public.fn_assign_current_challenge_period(
    p_user_id,
    'monthly',
    v_monthly_key,
    2
  );

  RETURN QUERY
  WITH scalar_bumps AS (
    SELECT key AS challenge_type,
           GREATEST(COALESCE((value #>> '{}')::integer, 0), 0) AS amount
    FROM jsonb_each(p_amounts)
  ), calculated_bumps AS (
    SELECT u.id,
           CASE
             WHEN u.threshold_snapshot IS NULL THEN b.amount
             WHEN p_values ? u.challenge_type_snapshot THEN (
               SELECT count(*)::integer
               FROM jsonb_array_elements(
                 p_values -> u.challenge_type_snapshot
               ) AS candidate(value)
               WHERE candidate.value::text::numeric >= u.threshold_snapshot
             )
             WHEN COALESCE(
               (p_magnitudes -> u.challenge_type_snapshot) #>> '{}',
               '0'
             )::numeric >= u.threshold_snapshot THEN b.amount
             ELSE 0
           END AS amount
    FROM public.user_daily_challenges u
    JOIN scalar_bumps b
      ON b.challenge_type = u.challenge_type_snapshot
    WHERE u.user_id = p_user_id
      AND u.completed = false
      AND u.assigned_date IN (v_daily_key, v_weekly_key, v_monthly_key)
  ), updated AS (
    UPDATE public.user_daily_challenges u
    SET progress = LEAST(
          u.progress + calculated.amount,
          u.requirement_snapshot
        ),
        completed = (u.progress + calculated.amount) >= u.requirement_snapshot,
        completed_at = CASE
          WHEN (u.progress + calculated.amount) >= u.requirement_snapshot
               AND u.completed_at IS NULL THEN now()
          ELSE u.completed_at
        END
    FROM calculated_bumps calculated
    WHERE u.id = calculated.id
      AND calculated.amount > 0
    RETURNING u.id,
              u.challenge_id,
              u.progress,
              u.requirement_snapshot,
              u.chip_reward_snapshot,
              u.diamond_reward_snapshot,
              u.completed
  )
  SELECT updated.id,
         updated.challenge_id,
         updated.progress,
         updated.requirement_snapshot,
         updated.chip_reward_snapshot,
         updated.diamond_reward_snapshot,
         updated.completed
  FROM updated;

  -- DIAMOND-RULINGS 3 (CLAUDE.md 10.5, horses are players): a horse has no browser, so the
  -- engine is its input device and it presses Claim the moment a human would be shown the
  -- and never breaks the progress just recorded.
  --
  -- five-argument serialized body, which nothing in the engine reaches; 733 challenges completed
  -- and 0 were claimed before this was noticed.
  -- The horse claim used to run here, which keyed it to a horse DOING something: a horse that
    -- stopped playing stopped claiming, and 23 quiet horses accumulated 759 rewards worth
    -- 51,380 diamonds. It is now fn_ca_horse_claim_due, keyed to who is OWED, on a minute
    -- tick. Recording an event does not pay anybody (CLAUDE.md 10.5, 10.11).
END;
$function$
;
CREATE OR REPLACE FUNCTION public.record_daily_challenge_event(p_user_id uuid, p_event_key text, p_amounts jsonb, p_magnitudes jsonb DEFAULT '{}'::jsonb, p_occurred_at timestamp with time zone DEFAULT now())
 RETURNS TABLE(id uuid, challenge_id text, progress integer, requirement integer, chip_reward numeric, diamond_reward integer, newly_completed boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_event public.daily_challenge_progress_events%ROWTYPE;
  v_event_found boolean;
BEGIN
  PERFORM public.fn_lock_daily_mission_user(p_user_id);

  SELECT * INTO v_event
  FROM public.daily_challenge_progress_events
  WHERE user_id = p_user_id
    AND event_key = p_event_key
  FOR UPDATE;
  v_event_found := FOUND;

  IF v_event_found
     AND (
       v_event.amounts IS DISTINCT FROM p_amounts
       OR v_event.magnitudes IS DISTINCT FROM p_magnitudes
       OR v_event.threshold_values IS DISTINCT FROM '{}'::jsonb
       OR v_event.occurred_at IS DISTINCT FROM p_occurred_at
     )
  THEN
    RAISE EXCEPTION 'Daily Missions event key is already bound to another payload';
  END IF;

  RETURN QUERY
  SELECT *
  FROM public.record_daily_challenge_event_serialized_body(
    p_user_id,
    p_event_key,
    p_amounts,
    p_magnitudes,
    p_occurred_at
  );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.sp_normalize_cosmetic_token(p_raw text)
 RETURNS text
 LANGUAGE sql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
  SELECT regexp_replace(lower(btrim(coalesce(p_raw, ''))), '[[:space:]-]+', '_', 'g');
$function$
;
CREATE OR REPLACE FUNCTION public.fn_assign_current_challenge_period(p_user_id uuid, p_tier text, p_period_key text, p_count integer)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  PERFORM public.fn_lock_daily_mission_user(p_user_id);
  PERFORM public.fn_assign_current_challenge_period_serialized_body(
    p_user_id,
    p_tier,
    p_period_key,
    p_count
  );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.record_daily_challenge_event_serialized_body(p_user_id uuid, p_event_key text, p_amounts jsonb, p_magnitudes jsonb DEFAULT '{}'::jsonb, p_occurred_at timestamp with time zone DEFAULT now())
 RETURNS TABLE(id uuid, challenge_id text, progress integer, requirement integer, chip_reward numeric, diamond_reward integer, newly_completed boolean)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_inserted integer;
  v_daily_key text;
  v_weekly_key text;
  v_monthly_key text;
BEGIN
  IF p_user_id IS NULL OR p_event_key IS NULL OR length(p_event_key) NOT BETWEEN 1 AND 200 THEN
    RAISE EXCEPTION 'A player and stable event key are required';
  END IF;
  IF p_amounts IS NULL OR jsonb_typeof(p_amounts) <> 'object'
     OR p_magnitudes IS NULL OR jsonb_typeof(p_magnitudes) <> 'object' THEN
    RAISE EXCEPTION 'Challenge event amounts must be JSON objects';
  END IF;
  IF p_occurred_at < now() - interval '35 days' OR p_occurred_at > now() + interval '1 minute' THEN
    RAISE EXCEPTION 'Daily Missions events must be recorded at their authoritative occurrence time';
  END IF;
  IF EXISTS (
    SELECT 1 FROM jsonb_object_keys(p_amounts) key
    WHERE key NOT IN ('hands_played','hands_won','showdowns','showdowns_won',
                      'hands_won_no_showdown','big_pots','strong_hands',
                      'chips_won','tournaments_played','friends_added')
  ) THEN
    RAISE EXCEPTION 'Unknown Daily Missions event type';
  END IF;
  IF EXISTS (
    SELECT 1 FROM jsonb_each_text(p_amounts) item
    WHERE CASE WHEN item.value ~ '^\d+$' THEN
      item.value::numeric < 0
      OR (item.key = 'chips_won' AND item.value::numeric > 1000000000)
      OR (item.key <> 'chips_won' AND item.value::numeric > 2500)
    ELSE true END
  ) OR EXISTS (
    SELECT 1 FROM jsonb_each_text(p_magnitudes) item
    WHERE CASE WHEN item.value ~ '^\d+$' THEN
      item.value::numeric < 0 OR item.value::numeric > 1000000000
    ELSE true END
  ) THEN
    RAISE EXCEPTION 'Daily Missions event values are outside their server contract';
  END IF;

  v_daily_key := to_char((p_occurred_at AT TIME ZONE 'utc')::date, 'YYYY-MM-DD');
  v_weekly_key := 'W' || to_char(date_trunc('week', p_occurred_at AT TIME ZONE 'utc')::date, 'YYYY-MM-DD');
  v_monthly_key := 'M' || to_char(p_occurred_at AT TIME ZONE 'utc', 'YYYY-MM');

  INSERT INTO public.daily_challenge_progress_events (
    user_id, event_key, amounts, magnitudes, occurred_at
  ) VALUES (p_user_id, p_event_key, p_amounts, p_magnitudes, p_occurred_at)
  ON CONFLICT (user_id, event_key) DO NOTHING;
  GET DIAGNOSTICS v_inserted = ROW_COUNT;
  IF v_inserted = 0 THEN RETURN; END IF;

  PERFORM public.fn_assign_current_challenge_period(p_user_id, 'daily', v_daily_key, 5);
  PERFORM public.fn_assign_current_challenge_period(p_user_id, 'weekly', v_weekly_key, 3);
  PERFORM public.fn_assign_current_challenge_period(p_user_id, 'monthly', v_monthly_key, 2);

  RETURN QUERY
  WITH bumps AS (
    SELECT key AS ctype,
           GREATEST(COALESCE((value #>> '{}')::integer, 0), 0) AS amount
    FROM jsonb_each(p_amounts)
  ), updated AS (
    UPDATE public.user_daily_challenges u
       SET progress = LEAST(u.progress + b.amount, u.requirement_snapshot),
           completed = (u.progress + b.amount) >= u.requirement_snapshot,
           completed_at = CASE
             WHEN (u.progress + b.amount) >= u.requirement_snapshot
                  AND u.completed_at IS NULL THEN now()
             ELSE u.completed_at
           END
      FROM bumps b
     WHERE u.user_id = p_user_id
       AND u.challenge_type_snapshot = b.ctype
       AND b.amount > 0
       AND u.completed = false
       AND u.assigned_date IN (v_daily_key, v_weekly_key, v_monthly_key)
       AND (
         u.threshold_snapshot IS NULL
         OR COALESCE((p_magnitudes -> b.ctype) #>> '{}', '0')::numeric >= u.threshold_snapshot
       )
    RETURNING u.id, u.challenge_id, u.progress, u.requirement_snapshot,
              u.chip_reward_snapshot, u.diamond_reward_snapshot, u.completed
  )
  SELECT updated.id, updated.challenge_id, updated.progress,
         updated.requirement_snapshot, updated.chip_reward_snapshot,
         updated.diamond_reward_snapshot, updated.completed
  FROM updated;

  -- DIAMOND-RULINGS 3 (CLAUDE.md 10.5, horses are players): a horse has no browser, so the
  -- engine is its input device, and it presses Claim the moment a human would be shown the
  -- that fails is filed; it never breaks the progress that was just recorded.
  -- The horse claim used to run here, which keyed it to a horse DOING something: a horse that
    -- stopped playing stopped claiming, and 23 quiet horses accumulated 759 rewards worth
    -- 51,380 diamonds. It is now fn_ca_horse_claim_due, keyed to who is OWED, on a minute
    -- tick. Recording an event does not pay anybody (CLAUDE.md 10.5, 10.11).
END;
$function$
;
CREATE OR REPLACE FUNCTION public.fn_assign_current_challenge_period_serialized_body(p_user_id uuid, p_tier text, p_period_key text, p_count integer)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_day_index integer;
  v_existing integer;
BEGIN
  IF p_user_id IS NULL THEN
    RAISE EXCEPTION 'A player is required';
  END IF;
  IF p_tier IS NULL OR p_period_key IS NULL OR p_count IS NULL
     OR (p_tier = 'daily' AND (p_count <> 5 OR p_period_key !~ '^\d{4}-\d{2}-\d{2}$'))
     OR (p_tier = 'weekly' AND (p_count <> 3 OR p_period_key !~ '^W\d{4}-\d{2}-\d{2}$'))
     OR (p_tier = 'monthly' AND (p_count <> 2 OR p_period_key !~ '^M\d{4}-\d{2}$'))
     OR p_tier NOT IN ('daily', 'weekly', 'monthly') THEN
    RAISE EXCEPTION 'Invalid canonical Daily Missions period contract';
  END IF;

  SELECT count(*) INTO v_existing
  FROM public.user_daily_challenges
  WHERE user_id = p_user_id AND assigned_date = p_period_key;

  IF v_existing > p_count OR EXISTS (
    SELECT 1
    FROM public.user_daily_challenges
    WHERE user_id = p_user_id
      AND assigned_date = p_period_key
      AND tier_snapshot IS DISTINCT FROM p_tier
  ) THEN
    RAISE EXCEPTION 'Existing % period is not a canonical Daily Missions contract set', p_tier;
  END IF;
  IF v_existing = p_count THEN
    RETURN;
  END IF;

  IF p_tier = 'daily' THEN
    v_day_index := abs(p_period_key::date - date '1970-01-01');

    -- Five distinct challenge types move through a circular type wheel. Each
    -- selected type advances through its own complete catalog list. This
    -- guarantees bounded exposure for every active Daily contract without
    -- coupling selection eligibility to its reward amount.
    INSERT INTO public.user_daily_challenges (
      user_id, challenge_id, assigned_date, progress, completed
    )
    WITH challenge_types AS (
      SELECT challenge_type,
             row_number() OVER (ORDER BY challenge_type) - 1 AS type_ordinal,
             count(*) OVER () AS type_count
      FROM (
        SELECT DISTINCT challenge_type
        FROM public.daily_challenge_catalog
        WHERE tier = 'daily' AND is_active
      ) types
    ), ranked AS (
      SELECT c.id,
             row_number() OVER (PARTITION BY c.challenge_type ORDER BY c.id) - 1 AS item_ordinal,
             count(*) OVER (PARTITION BY c.challenge_type) AS item_count,
             t.type_ordinal,
             t.type_count,
             mod(
               t.type_ordinal - mod(v_day_index::bigint, t.type_count) + t.type_count,
               t.type_count
             ) AS type_distance
      FROM public.daily_challenge_catalog c
      JOIN challenge_types t USING (challenge_type)
      WHERE c.tier = 'daily' AND c.is_active
    ), selected AS (
      SELECT id, type_ordinal, type_distance
      FROM ranked
      WHERE type_distance < p_count
        AND item_ordinal = mod(
          (v_day_index::bigint / type_count) + type_distance,
          item_count
        )
    )
    SELECT p_user_id, selected.id, p_period_key, 0, false
    FROM selected
    WHERE NOT EXISTS (
      SELECT 1
      FROM public.user_daily_challenges existing
      WHERE existing.user_id = p_user_id
        AND existing.assigned_date = p_period_key
        AND existing.challenge_id = selected.id
    )
    ORDER BY selected.type_distance, selected.type_ordinal, selected.id
    LIMIT (p_count - v_existing)
    ON CONFLICT (user_id, challenge_id, assigned_date) DO NOTHING;
  ELSE
    INSERT INTO public.user_daily_challenges (
      user_id, challenge_id, assigned_date, progress, completed
    )
    WITH one_per_type AS (
      SELECT DISTINCT ON (c.challenge_type)
             c.id,
             c.challenge_type,
             md5(p_period_key || '|' || c.id) AS draw
      FROM public.daily_challenge_catalog c
      WHERE c.tier = p_tier AND c.is_active
      ORDER BY c.challenge_type, md5(p_period_key || '|' || c.id), c.id
    )
    SELECT p_user_id, one_per_type.id, p_period_key, 0, false
    FROM one_per_type
    WHERE NOT EXISTS (
      SELECT 1
      FROM public.user_daily_challenges existing
      WHERE existing.user_id = p_user_id
        AND existing.assigned_date = p_period_key
        AND existing.challenge_id = one_per_type.id
    )
    ORDER BY draw, id
    LIMIT (p_count - v_existing)
    ON CONFLICT (user_id, challenge_id, assigned_date) DO NOTHING;
  END IF;

  IF (
    SELECT count(*)
    FROM public.user_daily_challenges
    WHERE user_id = p_user_id AND assigned_date = p_period_key
  ) <> p_count THEN
    RAISE EXCEPTION 'Catalog cannot supply the canonical % % contracts', p_count, p_tier;
  END IF;
END;
$function$
;