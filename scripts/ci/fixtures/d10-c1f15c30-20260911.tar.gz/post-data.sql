--
-- PostgreSQL database dump
--

\restrict gqQzeOBClGJ3nyXg9XJUx5BdsSaPRa42BalSgtwWfemTDJ7Ive7qIj3fNV5DAYc

-- Dumped from database version 17.11 (Homebrew)
-- Dumped by pg_dump version 17.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: agent_commission_settlements agent_commission_settlements_club_id_user_id_period_start_p_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commission_settlements
    ADD CONSTRAINT agent_commission_settlements_club_id_user_id_period_start_p_key UNIQUE (club_id, user_id, period_start, period_end);


--
-- Name: agent_commission_settlements agent_commission_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commission_settlements
    ADD CONSTRAINT agent_commission_settlements_pkey PRIMARY KEY (id);


--
-- Name: agent_commission_unsettled_rollup agent_commission_unsettled_rollup_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commission_unsettled_rollup
    ADD CONSTRAINT agent_commission_unsettled_rollup_pkey PRIMARY KEY (club_id, user_id);


--
-- Name: agent_commissions agent_commissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_pkey PRIMARY KEY (id);


--
-- Name: agents agents_club_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_club_id_user_id_key UNIQUE (club_id, user_id);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: audit_trail audit_trail_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_pkey PRIMARY KEY (id);


--
-- Name: bbj_hand_evidence_log bbj_hand_evidence_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_hand_evidence_log
    ADD CONSTRAINT bbj_hand_evidence_log_pkey PRIMARY KEY (id);


--
-- Name: bbj_ledger_deletions bbj_ledger_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_ledger_deletions
    ADD CONSTRAINT bbj_ledger_deletions_pkey PRIMARY KEY (id);


--
-- Name: bbj_payouts bbj_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_payouts
    ADD CONSTRAINT bbj_payouts_pkey PRIMARY KEY (id);


--
-- Name: bbj_pools bbj_pools_club_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_pools
    ADD CONSTRAINT bbj_pools_club_id_key UNIQUE (club_id);


--
-- Name: bbj_pools bbj_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_pools
    ADD CONSTRAINT bbj_pools_pkey PRIMARY KEY (id);


--
-- Name: bbj_unclaimed_shares bbj_unclaimed_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_unclaimed_shares
    ADD CONSTRAINT bbj_unclaimed_shares_pkey PRIMARY KEY (id);


--
-- Name: bomb_pot_award_units bomb_pot_award_units_idem; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bomb_pot_award_units
    ADD CONSTRAINT bomb_pot_award_units_idem UNIQUE (hand_history_id, pot_index, board, side, user_id);


--
-- Name: bomb_pot_award_units bomb_pot_award_units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bomb_pot_award_units
    ADD CONSTRAINT bomb_pot_award_units_pkey PRIMARY KEY (id);


--
-- Name: ca_arena_settings ca_arena_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_arena_settings
    ADD CONSTRAINT ca_arena_settings_pkey PRIMARY KEY (id);


--
-- Name: ca_cert_accounts ca_cert_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_cert_accounts
    ADD CONSTRAINT ca_cert_accounts_pkey PRIMARY KEY (user_id);


--
-- Name: ca_club_commission_daily ca_club_commission_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_club_commission_daily
    ADD CONSTRAINT ca_club_commission_daily_pkey PRIMARY KEY (club_id, stat_date);


--
-- Name: ca_club_player_daily ca_club_player_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_club_player_daily
    ADD CONSTRAINT ca_club_player_daily_pkey PRIMARY KEY (club_id, user_id, stat_date);


--
-- Name: ca_club_rake_daily ca_club_rake_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_club_rake_daily
    ADD CONSTRAINT ca_club_rake_daily_pkey PRIMARY KEY (club_id, stat_date);


--
-- Name: ca_club_tournament_daily ca_club_tournament_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_club_tournament_daily
    ADD CONSTRAINT ca_club_tournament_daily_pkey PRIMARY KEY (club_id, tournament_id, stat_date);


--
-- Name: ca_club_tournament_player_daily ca_club_tournament_player_daily_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_club_tournament_player_daily
    ADD CONSTRAINT ca_club_tournament_player_daily_pkey PRIMARY KEY (club_id, tournament_id, user_id, stat_date);


--
-- Name: ca_detector_registry ca_detector_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_detector_registry
    ADD CONSTRAINT ca_detector_registry_pkey PRIMARY KEY (source);


--
-- Name: ca_diamond_balance_audit ca_diamond_balance_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_balance_audit
    ADD CONSTRAINT ca_diamond_balance_audit_pkey PRIMARY KEY (id);


--
-- Name: ca_diamond_engine_spend ca_diamond_engine_spend_journal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_engine_spend
    ADD CONSTRAINT ca_diamond_engine_spend_journal_id_key UNIQUE (journal_id);


--
-- Name: ca_diamond_engine_spend ca_diamond_engine_spend_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_engine_spend
    ADD CONSTRAINT ca_diamond_engine_spend_pkey PRIMARY KEY (id);


--
-- Name: ca_diamond_house ca_diamond_house_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_house
    ADD CONSTRAINT ca_diamond_house_pkey PRIMARY KEY (id);


--
-- Name: ca_diamond_incidents ca_diamond_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_incidents
    ADD CONSTRAINT ca_diamond_incidents_pkey PRIMARY KEY (id);


--
-- Name: ca_diamond_journal_archive ca_diamond_journal_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_journal_archive
    ADD CONSTRAINT ca_diamond_journal_archive_pkey PRIMARY KEY (id);


--
-- Name: ca_diamond_rule_modes ca_diamond_rule_modes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_rule_modes
    ADD CONSTRAINT ca_diamond_rule_modes_pkey PRIMARY KEY (rule);


--
-- Name: ca_drift_incidents ca_drift_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_drift_incidents
    ADD CONSTRAINT ca_drift_incidents_pkey PRIMARY KEY (id);


--
-- Name: ca_financial_epochs ca_financial_epochs_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_financial_epochs
    ADD CONSTRAINT ca_financial_epochs_name_key UNIQUE (name);


--
-- Name: ca_financial_epochs ca_financial_epochs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_financial_epochs
    ADD CONSTRAINT ca_financial_epochs_pkey PRIMARY KEY (id);


--
-- Name: ca_freeroll_free_buy_log ca_freeroll_free_buy_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_freeroll_free_buy_log
    ADD CONSTRAINT ca_freeroll_free_buy_log_pkey PRIMARY KEY (id);


--
-- Name: ca_frozen_pool_deletions ca_frozen_pool_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_frozen_pool_deletions
    ADD CONSTRAINT ca_frozen_pool_deletions_pkey PRIMARY KEY (id);


--
-- Name: ca_hand_financial_facts ca_hand_financial_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_hand_financial_facts
    ADD CONSTRAINT ca_hand_financial_facts_pkey PRIMARY KEY (hand_id);


--
-- Name: ca_hand_player_idx ca_hand_player_idx_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_hand_player_idx
    ADD CONSTRAINT ca_hand_player_idx_pkey PRIMARY KEY (user_id, hand_id);


--
-- Name: ca_hand_player_stat ca_hand_player_stat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_hand_player_stat
    ADD CONSTRAINT ca_hand_player_stat_pkey PRIMARY KEY (user_id, hand_id);


--
-- Name: ca_incident_events ca_incident_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_incident_events
    ADD CONSTRAINT ca_incident_events_pkey PRIMARY KEY (id);


--
-- Name: ca_incident_file_failures ca_incident_file_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_incident_file_failures
    ADD CONSTRAINT ca_incident_file_failures_pkey PRIMARY KEY (id);


--
-- Name: ca_incident_notify_ledger ca_incident_notify_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_incident_notify_ledger
    ADD CONSTRAINT ca_incident_notify_ledger_pkey PRIMARY KEY (recipient_id, finding_key);


--
-- Name: ca_incident_recipients ca_incident_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_incident_recipients
    ADD CONSTRAINT ca_incident_recipients_pkey PRIMARY KEY (id);


--
-- Name: ca_incident_recipients ca_incident_recipients_scope_scope_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_incident_recipients
    ADD CONSTRAINT ca_incident_recipients_scope_scope_id_user_id_key UNIQUE (scope, scope_id, user_id);


--
-- Name: ca_ledger_day_manifest_restatements ca_ledger_day_manifest_restatements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_ledger_day_manifest_restatements
    ADD CONSTRAINT ca_ledger_day_manifest_restatements_pkey PRIMARY KEY (id);


--
-- Name: ca_ledger_day_manifests ca_ledger_day_manifests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_ledger_day_manifests
    ADD CONSTRAINT ca_ledger_day_manifests_pkey PRIMARY KEY (day);


--
-- Name: ca_ledger_maintenance_kinds ca_ledger_maintenance_kinds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_ledger_maintenance_kinds
    ADD CONSTRAINT ca_ledger_maintenance_kinds_pkey PRIMARY KEY (kind);


--
-- Name: ca_ledger_mutation_log ca_ledger_mutation_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_ledger_mutation_log
    ADD CONSTRAINT ca_ledger_mutation_log_pkey PRIMARY KEY (id);


--
-- Name: ca_ledger_write_failures ca_ledger_write_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_ledger_write_failures
    ADD CONSTRAINT ca_ledger_write_failures_pkey PRIMARY KEY (id);


--
-- Name: ca_manual_adjustments ca_manual_adjustments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_manual_adjustments
    ADD CONSTRAINT ca_manual_adjustments_pkey PRIMARY KEY (id);


--
-- Name: ca_mint_ledger ca_mint_ledger_op_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_mint_ledger
    ADD CONSTRAINT ca_mint_ledger_op_id_key UNIQUE (op_id);


--
-- Name: ca_mint_ledger ca_mint_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_mint_ledger
    ADD CONSTRAINT ca_mint_ledger_pkey PRIMARY KEY (id);


--
-- Name: ca_mint_policy ca_mint_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_mint_policy
    ADD CONSTRAINT ca_mint_policy_pkey PRIMARY KEY (id);


--
-- Name: ca_money_path_enforcement ca_money_path_enforcement_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_money_path_enforcement
    ADD CONSTRAINT ca_money_path_enforcement_pkey PRIMARY KEY (only_row);


--
-- Name: ca_money_path_violations ca_money_path_violations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_money_path_violations
    ADD CONSTRAINT ca_money_path_violations_pkey PRIMARY KEY (id);


--
-- Name: ca_op_claims ca_op_claims_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_op_claims
    ADD CONSTRAINT ca_op_claims_pkey PRIMARY KEY (op_id, fn_name);


--
-- Name: ca_operator_policy ca_operator_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_operator_policy
    ADD CONSTRAINT ca_operator_policy_pkey PRIMARY KEY (id);


--
-- Name: ca_payout_freeze ca_payout_freeze_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_payout_freeze
    ADD CONSTRAINT ca_payout_freeze_pkey PRIMARY KEY (id);


--
-- Name: ca_player_restrictions ca_player_restrictions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_player_restrictions
    ADD CONSTRAINT ca_player_restrictions_pkey PRIMARY KEY (id);


--
-- Name: ca_profile_deletions ca_profile_deletions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_profile_deletions
    ADD CONSTRAINT ca_profile_deletions_pkey PRIMARY KEY (id);


--
-- Name: ca_restriction_observations ca_restriction_observations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_restriction_observations
    ADD CONSTRAINT ca_restriction_observations_pkey PRIMARY KEY (id);


--
-- Name: ca_seat_stack_exits ca_seat_stack_exits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_seat_stack_exits
    ADD CONSTRAINT ca_seat_stack_exits_pkey PRIMARY KEY (id);


--
-- Name: ca_settle_sources ca_settle_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_settle_sources
    ADD CONSTRAINT ca_settle_sources_pkey PRIMARY KEY (source);


--
-- Name: ca_treasury_baseline ca_treasury_baseline_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_treasury_baseline
    ADD CONSTRAINT ca_treasury_baseline_pkey PRIMARY KEY (club_id);


--
-- Name: cash_cluster_events cash_cluster_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_cluster_events
    ADD CONSTRAINT cash_cluster_events_pkey PRIMARY KEY (id);


--
-- Name: cash_game_roster cash_game_roster_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_game_roster
    ADD CONSTRAINT cash_game_roster_pkey PRIMARY KEY (id);


--
-- Name: cash_games cash_games_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_games
    ADD CONSTRAINT cash_games_pkey PRIMARY KEY (id);


--
-- Name: cash_player_session cash_player_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_player_session
    ADD CONSTRAINT cash_player_session_pkey PRIMARY KEY (id);


--
-- Name: cash_seat_change_requests cash_seat_change_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_change_requests
    ADD CONSTRAINT cash_seat_change_requests_pkey PRIMARY KEY (id);


--
-- Name: cash_seat_moves cash_seat_moves_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_moves
    ADD CONSTRAINT cash_seat_moves_pkey PRIMARY KEY (id);


--
-- Name: cashout_requests cashout_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashout_requests
    ADD CONSTRAINT cashout_requests_pkey PRIMARY KEY (id);


--
-- Name: chip_ledger chip_ledger_category_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.chip_ledger
    ADD CONSTRAINT chip_ledger_category_check CHECK ((category = ANY (ARRAY['buyin'::text, 'cashout'::text, 'rake'::text, 'commission'::text, 'transfer'::text, 'player_funding'::text, 'agent_funding'::text, 'mint'::text, 'burn'::text, 'legacy_seed_reconcile'::text, 'rakeback'::text, 'settlement'::text, 'tournament_buyin'::text, 'tournament_prize'::text, 'bounty'::text, 'adjustment'::text, 'refund'::text, 'addon'::text, 'rebuy'::text, 'table_cashout'::text, 'tournament_refund'::text, 'bbj_contribution'::text, 'bbj_payout'::text, 'promo'::text, 'promo_release'::text, 'promo_send'::text, 'credit_draw'::text, 'credit_repayment'::text, 'insurance'::text, 'spin_entry'::text, 'spin_prize'::text, 'overlay'::text, 'correction'::text, 'reversal'::text, 'escrow_hold'::text, 'escrow_release'::text, 'treasury_transfer'::text, 'horse_funding'::text, 'fee'::text, 'eco'::text, 'pnl_settlement'::text, 'union_send'::text, 'cashier_send'::text, 'cashier_claim_back'::text, 'ticket_issue'::text, 'ticket_redeem'::text, 'club_opening_allocation'::text, 'leaderboard_payout'::text, 'club_bank_send'::text, 'club_bank_claim'::text, 'agent_send'::text, 'agent_claim'::text, 'union_settlement'::text, 'wheel_prize'::text, 'plinko_prize'::text, 'crash_prize'::text]))) NOT VALID;


--
-- Name: chip_ledger chip_ledger_exact_scale; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.chip_ledger
    ADD CONSTRAINT chip_ledger_exact_scale CHECK ((amount = round(amount, 2))) NOT VALID;


--
-- Name: chip_ledger chip_ledger_from_type_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.chip_ledger
    ADD CONSTRAINT chip_ledger_from_type_check CHECK ((from_type = ANY (ARRAY['player_wallet'::text, 'club_treasury'::text, 'union_bank'::text, 'agent_wallet'::text, 'system_mint'::text, 'system_burn'::text, 'table_stack'::text, 'promo_wallet'::text, 'club_wallet'::text, 'union_wallet'::text, 'bbj_pool'::text, 'spin_reserve'::text, 'insurance_bank'::text, 'escrow'::text, 'prize_liability'::text, 'bounty_liability'::text, 'rakeback_payable'::text, 'refund_payable'::text, 'settlement_suspense'::text, 'issuance_reserve'::text, 'chip_retirement'::text, 'credit_facility'::text, 'credit_receivable'::text, 'opening_setup'::text, 'leaderboard_round'::text]))) NOT VALID;


--
-- Name: chip_ledger_idem chip_ledger_idem_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chip_ledger_idem
    ADD CONSTRAINT chip_ledger_idem_pkey PRIMARY KEY (idempotency_key);


--
-- Name: chip_ledger chip_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chip_ledger
    ADD CONSTRAINT chip_ledger_pkey PRIMARY KEY (id);


--
-- Name: chip_ledger chip_ledger_to_type_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.chip_ledger
    ADD CONSTRAINT chip_ledger_to_type_check CHECK ((to_type = ANY (ARRAY['player_wallet'::text, 'club_treasury'::text, 'union_bank'::text, 'agent_wallet'::text, 'system_mint'::text, 'system_burn'::text, 'table_stack'::text, 'promo_wallet'::text, 'club_wallet'::text, 'union_wallet'::text, 'bbj_pool'::text, 'spin_reserve'::text, 'insurance_bank'::text, 'escrow'::text, 'prize_liability'::text, 'bounty_liability'::text, 'rakeback_payable'::text, 'refund_payable'::text, 'settlement_suspense'::text, 'issuance_reserve'::text, 'chip_retirement'::text, 'credit_facility'::text, 'credit_receivable'::text, 'opening_setup'::text, 'leaderboard_round'::text]))) NOT VALID;


--
-- Name: chip_transactions chip_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chip_transactions
    ADD CONSTRAINT chip_transactions_pkey PRIMARY KEY (id);


--
-- Name: wallet_transactions chk_balance_after_is_two_decimal_places; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.wallet_transactions
    ADD CONSTRAINT chk_balance_after_is_two_decimal_places CHECK (((balance_after IS NULL) OR (balance_after = round(balance_after, 2)))) NOT VALID;


--
-- Name: CONSTRAINT chk_balance_after_is_two_decimal_places ON wallet_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT chk_balance_after_is_two_decimal_places ON public.wallet_transactions IS 'NOT VALID deliberately. 243 of 2,899,837 rows written 2026-04-17..2026-07-21 carry sub-cent values; their fractions cancel exactly (sum 0.000000 chips), so nothing is owed to anyone. Found only by attempting the validation - a three-day sample of this column read clean, which is why the probe runs before the migration. None since 07-21. The constraint still refuses every NEW sub-cent value.';


--
-- Name: agent_commissions ck_whole_cents; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.agent_commissions
    ADD CONSTRAINT ck_whole_cents CHECK (((created_at < '2026-09-07 17:00:00-05'::timestamp with time zone) OR (amount = round(amount, 2)))) NOT VALID;


--
-- Name: chip_ledger ck_whole_cents; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.chip_ledger
    ADD CONSTRAINT ck_whole_cents CHECK (((created_at < '2026-09-07 17:00:00-05'::timestamp with time zone) OR (amount = round(amount, 2)))) NOT VALID;


--
-- Name: rake_records ck_whole_cents; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.rake_records
    ADD CONSTRAINT ck_whole_cents CHECK (((created_at < '2026-09-07 17:00:00-05'::timestamp with time zone) OR ((rake_amount = round(rake_amount, 2)) AND (bbj_contribution = round(bbj_contribution, 2))))) NOT VALID;


--
-- Name: union_wallet_transactions ck_whole_cents; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.union_wallet_transactions
    ADD CONSTRAINT ck_whole_cents CHECK (((created_at < '2026-09-07 17:00:00-05'::timestamp with time zone) OR (amount = round(amount, 2)))) NOT VALID;


--
-- Name: club_hand_daily_shard club_hand_daily_shard_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_hand_daily_shard
    ADD CONSTRAINT club_hand_daily_shard_pkey PRIMARY KEY (club_id, stat_date, shard);


--
-- Name: club_level_thresholds club_level_thresholds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_level_thresholds
    ADD CONSTRAINT club_level_thresholds_pkey PRIMARY KEY (level);


--
-- Name: club_member_daily_stats club_member_daily_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_member_daily_stats
    ADD CONSTRAINT club_member_daily_stats_pkey PRIMARY KEY (club_id, table_id, user_id, stat_date);


--
-- Name: club_member_table_state club_member_table_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_member_table_state
    ADD CONSTRAINT club_member_table_state_pkey PRIMARY KEY (table_id, user_id);


--
-- Name: club_members club_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_members
    ADD CONSTRAINT club_members_pkey PRIMARY KEY (club_id, user_id);


--
-- Name: club_wallets club_wallets_club_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_wallets
    ADD CONSTRAINT club_wallets_club_id_key UNIQUE (club_id);


--
-- Name: club_wallets club_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_wallets
    ADD CONSTRAINT club_wallets_pkey PRIMARY KEY (id);


--
-- Name: clubs clubs_club_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_club_id_key UNIQUE (club_id);


--
-- Name: clubs clubs_default_rake_percent_range; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.clubs
    ADD CONSTRAINT clubs_default_rake_percent_range CHECK (((default_rake_percent IS NULL) OR (default_rake_percent = ('-1'::integer)::numeric) OR ((default_rake_percent >= (0)::numeric) AND (default_rake_percent <= (10)::numeric)))) NOT VALID;


--
-- Name: clubs clubs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_pkey PRIMARY KEY (id);


--
-- Name: clubs clubs_rake_cap_range; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.clubs
    ADD CONSTRAINT clubs_rake_cap_range CHECK (((rake_cap IS NULL) OR (rake_cap = ('-1'::integer)::numeric) OR ((rake_cap >= (0)::numeric) AND (rake_cap <= (10)::numeric)))) NOT VALID;


--
-- Name: content_authors content_authors_alias_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_authors
    ADD CONSTRAINT content_authors_alias_key UNIQUE (alias);


--
-- Name: content_authors content_authors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_authors
    ADD CONSTRAINT content_authors_pkey PRIMARY KEY (id);


--
-- Name: daily_challenge_dashboard_revisions daily_challenge_dashboard_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenge_dashboard_revisions
    ADD CONSTRAINT daily_challenge_dashboard_revisions_pkey PRIMARY KEY (user_id);


--
-- Name: daily_challenge_event_outbox daily_challenge_event_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenge_event_outbox
    ADD CONSTRAINT daily_challenge_event_outbox_pkey PRIMARY KEY (user_id, event_key);


--
-- Name: deep_stack_delete_attempts deep_stack_delete_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deep_stack_delete_attempts
    ADD CONSTRAINT deep_stack_delete_attempts_pkey PRIMARY KEY (id);


--
-- Name: diamond_engine_daily_caps diamond_engine_daily_caps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_engine_daily_caps
    ADD CONSTRAINT diamond_engine_daily_caps_pkey PRIMARY KEY (engine);


--
-- Name: diamond_reward_budgets diamond_reward_budgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_reward_budgets
    ADD CONSTRAINT diamond_reward_budgets_pkey PRIMARY KEY (period, engine);


--
-- Name: diamond_reward_catalog diamond_reward_catalog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_reward_catalog
    ADD CONSTRAINT diamond_reward_catalog_pkey PRIMARY KEY (action_key);


--
-- Name: diamond_transactions diamond_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_transactions
    ADD CONSTRAINT diamond_transactions_pkey PRIMARY KEY (id);


--
-- Name: diamond_user_daily_awards diamond_user_daily_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_user_daily_awards
    ADD CONSTRAINT diamond_user_daily_awards_pkey PRIMARY KEY (user_id, engine, day);


--
-- Name: diamond_wallets diamond_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_wallets
    ADD CONSTRAINT diamond_wallets_pkey PRIMARY KEY (id);


--
-- Name: diamond_wallets diamond_wallets_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_wallets
    ADD CONSTRAINT diamond_wallets_user_id_key UNIQUE (user_id);


--
-- Name: engine_maintenance_break engine_maintenance_break_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engine_maintenance_break
    ADD CONSTRAINT engine_maintenance_break_pkey PRIMARY KEY (id);


--
-- Name: engine_maintenance_thaws engine_maintenance_thaws_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engine_maintenance_thaws
    ADD CONSTRAINT engine_maintenance_thaws_pkey PRIMARY KEY (freeze_started_at);


--
-- Name: engine_recovery_events engine_recovery_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engine_recovery_events
    ADD CONSTRAINT engine_recovery_events_pkey PRIMARY KEY (id);


--
-- Name: engine_tournament_leases engine_tournament_leases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engine_tournament_leases
    ADD CONSTRAINT engine_tournament_leases_pkey PRIMARY KEY (tournament_id);


--
-- Name: financial_alerts financial_alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_alerts
    ADD CONSTRAINT financial_alerts_pkey PRIMARY KEY (id);


--
-- Name: friendships friendships_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_pkey PRIMARY KEY (id);


--
-- Name: friendships friendships_user_id_friend_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_user_id_friend_id_key UNIQUE (user_id, friend_id);


--
-- Name: game_management_events game_management_events_event_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_management_events
    ADD CONSTRAINT game_management_events_event_id_key UNIQUE (event_id);


--
-- Name: game_management_events game_management_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_management_events
    ADD CONSTRAINT game_management_events_pkey PRIMARY KEY (sequence);


--
-- Name: hand_atomic_commits hand_atomic_commits_hand_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hand_atomic_commits
    ADD CONSTRAINT hand_atomic_commits_hand_id_key UNIQUE (hand_id);


--
-- Name: hand_atomic_commits hand_atomic_commits_hand_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hand_atomic_commits
    ADD CONSTRAINT hand_atomic_commits_hand_number_key UNIQUE (hand_number);


--
-- Name: hand_atomic_commits hand_atomic_commits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hand_atomic_commits
    ADD CONSTRAINT hand_atomic_commits_pkey PRIMARY KEY (table_id, hand_number);


--
-- Name: hand_history hand_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hand_history
    ADD CONSTRAINT hand_history_pkey PRIMARY KEY (id);


--
-- Name: managed_game_contract_versions managed_game_contract_versions_game_kind_game_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_game_contract_versions
    ADD CONSTRAINT managed_game_contract_versions_game_kind_game_id_version_key UNIQUE (game_kind, game_id, version);


--
-- Name: managed_game_contract_versions managed_game_contract_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_game_contract_versions
    ADD CONSTRAINT managed_game_contract_versions_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: table_seats one_committed_seat_per_game_player; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_seats
    ADD CONSTRAINT one_committed_seat_per_game_player UNIQUE (user_id, active_game_scope) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: player_position_stats player_position_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_position_stats
    ADD CONSTRAINT player_position_stats_pkey PRIMARY KEY (user_id, "position");


--
-- Name: player_stats player_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_pkey PRIMARY KEY (id);


--
-- Name: player_stats player_stats_user_id_club_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_user_id_club_id_key UNIQUE (user_id, club_id);


--
-- Name: poker_diamond_custody poker_diamond_custody_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poker_diamond_custody
    ADD CONSTRAINT poker_diamond_custody_pkey PRIMARY KEY (id);


--
-- Name: poker_diamond_custody poker_diamond_custody_user_id_purpose_target_id_entry_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poker_diamond_custody
    ADD CONSTRAINT poker_diamond_custody_user_id_purpose_target_id_entry_key_key UNIQUE (user_id, purpose, target_id, entry_key);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: push_outbox push_outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_outbox
    ADD CONSTRAINT push_outbox_pkey PRIMARY KEY (id);


--
-- Name: rake_records rake_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rake_records
    ADD CONSTRAINT rake_records_pkey PRIMARY KEY (id);


--
-- Name: rakeback_stats_applied rakeback_stats_applied_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rakeback_stats_applied
    ADD CONSTRAINT rakeback_stats_applied_pkey PRIMARY KEY (rake_record_id, user_id);


--
-- Name: settlement_idempotency_keys settlement_idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settlement_idempotency_keys
    ADD CONSTRAINT settlement_idempotency_keys_pkey PRIMARY KEY (table_id, hand_id);


--
-- Name: signup_errors signup_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signup_errors
    ADD CONSTRAINT signup_errors_pkey PRIMARY KEY (id);


--
-- Name: social_follows social_follows_follower_id_following_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_follows
    ADD CONSTRAINT social_follows_follower_id_following_id_key UNIQUE (follower_id, following_id);


--
-- Name: social_follows social_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_follows
    ADD CONSTRAINT social_follows_pkey PRIMARY KEY (id);


--
-- Name: social_pages social_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_pages
    ADD CONSTRAINT social_pages_pkey PRIMARY KEY (id);


--
-- Name: social_pages social_pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_pages
    ADD CONSTRAINT social_pages_slug_key UNIQUE (slug);


--
-- Name: spin_bonus_pools spin_bonus_pools_club_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spin_bonus_pools
    ADD CONSTRAINT spin_bonus_pools_club_id_key UNIQUE (club_id);


--
-- Name: spin_bonus_pools spin_bonus_pools_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spin_bonus_pools
    ADD CONSTRAINT spin_bonus_pools_pkey PRIMARY KEY (id);


--
-- Name: spin_draw_receipts spin_draw_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spin_draw_receipts
    ADD CONSTRAINT spin_draw_receipts_pkey PRIMARY KEY (tournament_id);


--
-- Name: spin_payout_ladder spin_payout_ladder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spin_payout_ladder
    ADD CONSTRAINT spin_payout_ladder_pkey PRIMARY KEY (multiplier);


--
-- Name: spin_reserve_ledger spin_reserve_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spin_reserve_ledger
    ADD CONSTRAINT spin_reserve_ledger_pkey PRIMARY KEY (id);


--
-- Name: tables table_game_scope_parent_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT table_game_scope_parent_key UNIQUE (id, seat_game_scope);


--
-- Name: tables table_seat_admission_parent_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT table_seat_admission_parent_key UNIQUE (id, seat_admission_key);


--
-- Name: table_seats table_seats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_seats
    ADD CONSTRAINT table_seats_pkey PRIMARY KEY (id);


--
-- Name: table_seats table_seats_table_id_seat_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_seats
    ADD CONSTRAINT table_seats_table_id_seat_number_key UNIQUE (table_id, seat_number);


--
-- Name: table_waitlist table_waitlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_waitlist
    ADD CONSTRAINT table_waitlist_pkey PRIMARY KEY (id);


--
-- Name: tables tables_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_pkey PRIMARY KEY (id);


--
-- Name: tables tables_rake_cap_bb_range; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tables
    ADD CONSTRAINT tables_rake_cap_bb_range CHECK (((rake_cap_bb IS NULL) OR (rake_cap_bb = ('-1'::integer)::numeric) OR ((rake_cap_bb >= (0)::numeric) AND (rake_cap_bb <= (10)::numeric)))) NOT VALID;


--
-- Name: tables tables_rake_percent_range; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tables
    ADD CONSTRAINT tables_rake_percent_range CHECK (((rake_percent IS NULL) OR (rake_percent = ('-1'::integer)::numeric) OR ((rake_percent >= (0)::numeric) AND (rake_percent <= (10)::numeric)))) NOT VALID;


--
-- Name: tournament_bounties tournament_bounties_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounties
    ADD CONSTRAINT tournament_bounties_pkey PRIMARY KEY (id);


--
-- Name: tournament_bounty_award_recipients tournament_bounty_award_recipients_award_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_award_recipients
    ADD CONSTRAINT tournament_bounty_award_recipients_award_id_user_id_key UNIQUE (award_id, user_id);


--
-- Name: tournament_bounty_award_recipients tournament_bounty_award_recipients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_award_recipients
    ADD CONSTRAINT tournament_bounty_award_recipients_pkey PRIMARY KEY (id);


--
-- Name: tournament_bounty_awards tournament_bounty_awards_op_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_awards
    ADD CONSTRAINT tournament_bounty_awards_op_id_key UNIQUE (op_id);


--
-- Name: tournament_bounty_awards tournament_bounty_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_awards
    ADD CONSTRAINT tournament_bounty_awards_pkey PRIMARY KEY (id);


--
-- Name: tournament_bounty_chests tournament_bounty_chests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_chests
    ADD CONSTRAINT tournament_bounty_chests_pkey PRIMARY KEY (id);


--
-- Name: tournament_bounty_chests tournament_bounty_chests_tournament_id_seq_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_chests
    ADD CONSTRAINT tournament_bounty_chests_tournament_id_seq_key UNIQUE (tournament_id, seq);


--
-- Name: tournament_bounty_completion_receipts tournament_bounty_completion_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_completion_receipts
    ADD CONSTRAINT tournament_bounty_completion_receipts_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_bounty_obligations tournament_bounty_obligations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_obligations
    ADD CONSTRAINT tournament_bounty_obligations_pkey PRIMARY KEY (id);


--
-- Name: tournament_bounty_obligations tournament_bounty_obligations_tournament_id_eliminated_user_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_obligations
    ADD CONSTRAINT tournament_bounty_obligations_tournament_id_eliminated_user_key UNIQUE (tournament_id, eliminated_user_id, seat_joined_at);


--
-- Name: tournament_bounty_obligations tournament_bounty_obligations_tournament_id_hand_number_eli_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_obligations
    ADD CONSTRAINT tournament_bounty_obligations_tournament_id_hand_number_eli_key UNIQUE (tournament_id, hand_number, eliminated_user_id);


--
-- Name: tournament_cancellation_receipts tournament_cancellation_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_cancellation_receipts
    ADD CONSTRAINT tournament_cancellation_receipts_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_cancellation_receipts tournament_cancellation_receipts_spin_unwind_tournament_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_cancellation_receipts
    ADD CONSTRAINT tournament_cancellation_receipts_spin_unwind_tournament_id_key UNIQUE (spin_unwind_tournament_id);


--
-- Name: tournament_capacity_table_receipts tournament_capacity_table_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_capacity_table_receipts
    ADD CONSTRAINT tournament_capacity_table_receipts_pkey PRIMARY KEY (table_id);


--
-- Name: tournament_deal_votes tournament_deal_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_deal_votes
    ADD CONSTRAINT tournament_deal_votes_pkey PRIMARY KEY (tournament_id, user_id);


--
-- Name: tournament_escrow tournament_escrow_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_escrow
    ADD CONSTRAINT tournament_escrow_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_final_table_deal_batches tournament_final_table_deal_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_final_table_deal_batches
    ADD CONSTRAINT tournament_final_table_deal_batches_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_finish_receipts tournament_finish_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_finish_receipts
    ADD CONSTRAINT tournament_finish_receipts_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_guarantee_overlays tournament_guarantee_overlays_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_guarantee_overlays
    ADD CONSTRAINT tournament_guarantee_overlays_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_knockout_candidates tournament_knockout_candidate_tournament_id_eliminated_user_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_knockout_candidates
    ADD CONSTRAINT tournament_knockout_candidate_tournament_id_eliminated_user_key UNIQUE (tournament_id, eliminated_user_id, seat_joined_at);


--
-- Name: tournament_knockout_candidates tournament_knockout_candidate_tournament_id_hand_number_eli_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_knockout_candidates
    ADD CONSTRAINT tournament_knockout_candidate_tournament_id_hand_number_eli_key UNIQUE (tournament_id, hand_number, eliminated_user_id);


--
-- Name: tournament_knockout_candidates tournament_knockout_candidates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_knockout_candidates
    ADD CONSTRAINT tournament_knockout_candidates_pkey PRIMARY KEY (id);


--
-- Name: tournament_launch_receipts tournament_launch_receipts_launch_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_launch_receipts
    ADD CONSTRAINT tournament_launch_receipts_launch_id_key UNIQUE (launch_id);


--
-- Name: tournament_launch_receipts tournament_launch_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_launch_receipts
    ADD CONSTRAINT tournament_launch_receipts_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_manager_wakes tournament_manager_wakes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_manager_wakes
    ADD CONSTRAINT tournament_manager_wakes_pkey PRIMARY KEY (id);


--
-- Name: tournament_mystery_activation_receipts tournament_mystery_activation_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_mystery_activation_receipts
    ADD CONSTRAINT tournament_mystery_activation_receipts_pkey PRIMARY KEY (tournament_id, activation_generation);


--
-- Name: tournament_obligations tournament_obligations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_obligations
    ADD CONSTRAINT tournament_obligations_pkey PRIMARY KEY (id);


--
-- Name: tournament_payouts tournament_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_payouts
    ADD CONSTRAINT tournament_payouts_pkey PRIMARY KEY (id);


--
-- Name: tournament_place_settlement_batches tournament_place_settlement_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_place_settlement_batches
    ADD CONSTRAINT tournament_place_settlement_batches_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_players tournament_players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_players
    ADD CONSTRAINT tournament_players_pkey PRIMARY KEY (id);


--
-- Name: tournament_players tournament_players_tournament_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_players
    ADD CONSTRAINT tournament_players_tournament_id_user_id_key UNIQUE (tournament_id, user_id);

ALTER TABLE ONLY public.tournament_players REPLICA IDENTITY USING INDEX tournament_players_tournament_id_user_id_key;


--
-- Name: tournament_rake_settlements tournament_rake_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_rake_settlements
    ADD CONSTRAINT tournament_rake_settlements_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_refund_authorizations tournament_refund_authorizations_entitlement_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_authorizations
    ADD CONSTRAINT tournament_refund_authorizations_entitlement_id_key UNIQUE (entitlement_id);


--
-- Name: tournament_refund_authorizations tournament_refund_authorizations_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_authorizations
    ADD CONSTRAINT tournament_refund_authorizations_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: tournament_refund_authorizations tournament_refund_authorizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_authorizations
    ADD CONSTRAINT tournament_refund_authorizations_pkey PRIMARY KEY (token);


--
-- Name: tournament_refund_entitlements tournament_refund_entitlement_tournament_id_user_id_entitle_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlement_tournament_id_user_id_entitle_key UNIQUE (tournament_id, user_id, entitlement_kind, source_ledger_id);


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlements_pkey PRIMARY KEY (id);


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_source_ledger_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlements_source_ledger_id_key UNIQUE (source_ledger_id);


--
-- Name: tournament_refund_tranches tournament_refund_tranches_credit_ledger_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_credit_ledger_id_key UNIQUE (credit_ledger_id);


--
-- Name: tournament_refund_tranches tournament_refund_tranches_entitlement_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_entitlement_id_key UNIQUE (entitlement_id);


--
-- Name: tournament_refund_tranches tournament_refund_tranches_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: tournament_refund_tranches tournament_refund_tranches_obligation_id_amount_paid_before_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_obligation_id_amount_paid_before_key UNIQUE (obligation_id, amount_paid_before);


--
-- Name: tournament_refund_tranches tournament_refund_tranches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_pkey PRIMARY KEY (wallet_transaction_id);


--
-- Name: tournament_reminder_receipts tournament_reminder_receipts_outbox_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_reminder_receipts
    ADD CONSTRAINT tournament_reminder_receipts_outbox_id_key UNIQUE (outbox_id);


--
-- Name: tournament_reminder_receipts tournament_reminder_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_reminder_receipts
    ADD CONSTRAINT tournament_reminder_receipts_pkey PRIMARY KEY (tournament_id, recipient_user_id, scheduled_start_at, stage);


--
-- Name: tournament_satellite_awards tournament_satellite_awards_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: tournament_satellite_awards tournament_satellite_awards_payout_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_payout_id_key UNIQUE (payout_id);


--
-- Name: tournament_satellite_awards tournament_satellite_awards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_pkey PRIMARY KEY (tournament_id, place);


--
-- Name: tournament_satellite_awards tournament_satellite_awards_registration_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_registration_id_key UNIQUE (registration_id);


--
-- Name: tournament_satellite_awards tournament_satellite_awards_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_ticket_id_key UNIQUE (ticket_id);


--
-- Name: tournament_satellite_awards tournament_satellite_awards_tournament_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_tournament_id_user_id_key UNIQUE (tournament_id, user_id);


--
-- Name: tournament_satellite_economic_snapshots tournament_satellite_economic_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_economic_snapshots
    ADD CONSTRAINT tournament_satellite_economic_snapshots_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_satellite_entitlements tournament_satellite_entitlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_entitlements
    ADD CONSTRAINT tournament_satellite_entitlements_pkey PRIMARY KEY (tournament_id, "position");


--
-- Name: tournament_satellite_settlement_batches tournament_satellite_settlement_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_settlement_batches
    ADD CONSTRAINT tournament_satellite_settlement_batches_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_satellite_settlements tournament_satellite_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_settlements
    ADD CONSTRAINT tournament_satellite_settlements_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_seat_exit_authorizations tournament_seat_exit_authoriz_token_tournament_id_user_id_s_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_seat_exit_authorizations
    ADD CONSTRAINT tournament_seat_exit_authoriz_token_tournament_id_user_id_s_key UNIQUE (token, tournament_id, user_id, seat_id, operation);


--
-- Name: tournament_seat_exit_authorizations tournament_seat_exit_authorizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_seat_exit_authorizations
    ADD CONSTRAINT tournament_seat_exit_authorizations_pkey PRIMARY KEY (token, seat_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation__contribution_reversal_journal_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation__contribution_reversal_journal_key UNIQUE (contribution_reversal_journal_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwi_original_entry_journal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwi_original_entry_journal_id_key UNIQUE (original_entry_journal_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwin_contribution_reversal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwin_contribution_reversal_id_key UNIQUE (contribution_reversal_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwin_draw_reversal_journal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwin_draw_reversal_journal_id_key UNIQUE (draw_reversal_journal_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwin_original_contribution_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwin_original_contribution_id_key UNIQUE (original_contribution_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwin_original_draw_journal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwin_original_draw_journal_id_key UNIQUE (original_draw_journal_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_draw_reversal_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwinds_draw_reversal_id_key UNIQUE (draw_reversal_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_original_draw_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwinds_original_draw_id_key UNIQUE (original_draw_id);


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwinds_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_table_origins tournament_table_origins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_table_origins
    ADD CONSTRAINT tournament_table_origins_pkey PRIMARY KEY (table_id);


--
-- Name: tournament_terminal_settlements tournament_terminal_settlements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_terminal_settlements
    ADD CONSTRAINT tournament_terminal_settlements_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_ticket_admission_authorizations tournament_ticket_admission_authorizations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_ticket_admission_authorizations
    ADD CONSTRAINT tournament_ticket_admission_authorizations_pkey PRIMARY KEY (token);


--
-- Name: tournament_ticket_admission_authorizations tournament_ticket_admission_authorizations_registration_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_ticket_admission_authorizations
    ADD CONSTRAINT tournament_ticket_admission_authorizations_registration_id_key UNIQUE (registration_id);


--
-- Name: tournament_ticket_admission_authorizations tournament_ticket_admission_authorizations_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_ticket_admission_authorizations
    ADD CONSTRAINT tournament_ticket_admission_authorizations_ticket_id_key UNIQUE (ticket_id);


--
-- Name: tournament_tickets tournament_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_tickets
    ADD CONSTRAINT tournament_tickets_pkey PRIMARY KEY (id);


--
-- Name: tournament_unregistration_receipts tournament_unregistration_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_unregistration_receipts
    ADD CONSTRAINT tournament_unregistration_receipts_pkey PRIMARY KEY (registration_id);


--
-- Name: tournament_unregistration_receipts tournament_unregistration_receipts_request_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_unregistration_receipts
    ADD CONSTRAINT tournament_unregistration_receipts_request_id_key UNIQUE (request_id);


--
-- Name: tournaments tournaments_heads_up_rake_within_5_pct; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tournaments
    ADD CONSTRAINT tournaments_heads_up_rake_within_5_pct CHECK (((max_players IS NULL) OR (max_players > 2) OR (COALESCE(buy_in_fee, (0)::numeric) <= (round(((COALESCE(buy_in_amount, (0)::numeric) + COALESCE(buy_in_fee, (0)::numeric)) * 0.05), 2) + 0.005)))) NOT VALID;


--
-- Name: CONSTRAINT tournaments_heads_up_rake_within_5_pct ON tournaments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT tournaments_heads_up_rake_within_5_pct ON public.tournaments IS 'A two-seat tournament charges at most 5% of what the player pays (headsUpSpec.HEADS_UP_RAKE_RATE). NOT VALID: rows written before 2026-08-26 carry 6.67-10% and are left as the honest record of what was charged.';


--
-- Name: tournaments tournaments_payout_percent_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tournaments
    ADD CONSTRAINT tournaments_payout_percent_check CHECK ((payout_percent = ANY (ARRAY[10, 15, 20]))) NOT VALID;


--
-- Name: tournaments tournaments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT tournaments_pkey PRIMARY KEY (id);


--
-- Name: tournaments tournaments_rake_within_10_pct; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tournaments
    ADD CONSTRAINT tournaments_rake_within_10_pct CHECK ((COALESCE(buy_in_fee, (0)::numeric) <= (((COALESCE(buy_in_amount, (0)::numeric) + COALESCE(buy_in_fee, (0)::numeric)) * 0.1) + 0.000000001))) NOT VALID;


--
-- Name: tournaments tournaments_spin_has_no_fee; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tournaments
    ADD CONSTRAINT tournaments_spin_has_no_fee CHECK (((created_at < '2026-08-20 19:00:00-05'::timestamp with time zone) OR (((lower(COALESCE(variant, ''::text)) <> 'spin'::text) AND (upper(COALESCE(tournament_type, ''::text)) <> 'SPIN'::text)) OR (COALESCE(buy_in_fee, (0)::numeric) = (0)::numeric)))) NOT VALID;


--
-- Name: CONSTRAINT tournaments_spin_has_no_fee ON tournaments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT tournaments_spin_has_no_fee ON public.tournaments IS 'Spins carry no separate fee. Rows created before 2026-08-21 are grandfathered: 7,120 legacy rows predate the rule and must stay UPDATE-able for remediation.';


--
-- Name: tournaments tournaments_spin_no_extra_rake; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tournaments
    ADD CONSTRAINT tournaments_spin_no_extra_rake CHECK (((created_at < '2026-08-20 19:00:00-05'::timestamp with time zone) OR ((variant IS DISTINCT FROM 'spin'::text) AND (upper(COALESCE(tournament_type, ''::text)) <> 'SPIN'::text)) OR (COALESCE(buy_in_fee, (0)::numeric) = (0)::numeric))) NOT VALID;


--
-- Name: union_admins union_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_admins
    ADD CONSTRAINT union_admins_pkey PRIMARY KEY (id);


--
-- Name: union_admins union_admins_union_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_admins
    ADD CONSTRAINT union_admins_union_id_user_id_key UNIQUE (union_id, user_id);


--
-- Name: union_clubs union_clubs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_clubs
    ADD CONSTRAINT union_clubs_pkey PRIMARY KEY (id);


--
-- Name: union_clubs union_clubs_union_id_club_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_clubs
    ADD CONSTRAINT union_clubs_union_id_club_id_key UNIQUE (union_id, club_id);


--
-- Name: union_creators union_creators_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_creators
    ADD CONSTRAINT union_creators_pkey PRIMARY KEY (user_id);


--
-- Name: union_rake_weekly union_rake_weekly_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_rake_weekly
    ADD CONSTRAINT union_rake_weekly_key UNIQUE NULLS NOT DISTINCT (union_id, club_id, week_start);


--
-- Name: union_rake_weekly union_rake_weekly_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_rake_weekly
    ADD CONSTRAINT union_rake_weekly_pkey PRIMARY KEY (union_id, club_id, week_start);


--
-- Name: union_wallet_transactions union_wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_wallet_transactions
    ADD CONSTRAINT union_wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: union_wallets union_wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_wallets
    ADD CONSTRAINT union_wallets_pkey PRIMARY KEY (id);


--
-- Name: union_wallets union_wallets_union_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_wallets
    ADD CONSTRAINT union_wallets_union_id_key UNIQUE (union_id);


--
-- Name: unions unions_code_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unions
    ADD CONSTRAINT unions_code_unique UNIQUE (code);


--
-- Name: unions unions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unions
    ADD CONSTRAINT unions_pkey PRIMARY KEY (id);


--
-- Name: user_daily_streaks user_daily_streaks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_daily_streaks
    ADD CONSTRAINT user_daily_streaks_pkey PRIMARY KEY (user_id);


--
-- Name: user_diamond_balance user_diamond_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_diamond_balance
    ADD CONSTRAINT user_diamond_balance_pkey PRIMARY KEY (user_id);


--
-- Name: user_diamonds user_diamonds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_diamonds
    ADD CONSTRAINT user_diamonds_pkey PRIMARY KEY (user_id);


--
-- Name: user_mfa_factors user_mfa_factors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_mfa_factors
    ADD CONSTRAINT user_mfa_factors_pkey PRIMARY KEY (id);


--
-- Name: user_mfa_factors user_mfa_factors_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_mfa_factors
    ADD CONSTRAINT user_mfa_factors_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: vip_points_carry vip_points_carry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vip_points_carry
    ADD CONSTRAINT vip_points_carry_pkey PRIMARY KEY (user_id);


--
-- Name: vip_points_ledger vip_points_ledger_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vip_points_ledger
    ADD CONSTRAINT vip_points_ledger_pkey PRIMARY KEY (id);


--
-- Name: vip_points_ledger vip_points_ledger_user_id_source_type_source_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vip_points_ledger
    ADD CONSTRAINT vip_points_ledger_user_id_source_type_source_id_key UNIQUE (user_id, source_type, source_id);


--
-- Name: vip_points vip_points_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.vip_points
    ADD CONSTRAINT vip_points_pkey PRIMARY KEY (user_id);


--
-- Name: wallet_credit_idempotency wallet_credit_idempotency_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_credit_idempotency
    ADD CONSTRAINT wallet_credit_idempotency_pkey PRIMARY KEY (key);


--
-- Name: wallet_transactions wallet_transactions_amount_non_negative; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_amount_non_negative CHECK ((amount >= (0)::numeric)) NOT VALID;


--
-- Name: CONSTRAINT wallet_transactions_amount_non_negative ON wallet_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT wallet_transactions_amount_non_negative ON public.wallet_transactions IS 'Direction is carried by `type`, never by the sign of `amount`. NOT VALID so 5 pre-existing anomalous rows (rake x3, prize, transfer) are preserved for investigation; it still enforces on all new writes.';


--
-- Name: wallet_transactions wallet_transactions_category_check; Type: CHECK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_category_check CHECK ((category = ANY (ARRAY['buyin'::text, 'cashout'::text, 'promo'::text, 'rake'::text, 'transfer'::text, 'tournament_buyin'::text, 'tournament_winnings'::text, 'tournament_cashout'::text, 'horse_refill'::text, 'deposit'::text, 'withdrawal'::text, 'refund'::text, 'bbj'::text, 'bonus'::text, 'mint'::text, 'settlement'::text, 'commission'::text, 'INSURANCE'::text, 'prize'::text, 'rebuy'::text, 'addon'::text, 'funding'::text, 'promotion'::text, 'rakeback'::text, 'bounty'::text, 'addon_refund'::text, 'bounty_own'::text, 'prize_reversal'::text, 'leaderboard_payout'::text]))) NOT VALID;


--
-- Name: wallet_transactions wallet_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_pkey PRIMARY KEY (id);


--
-- Name: wallets wallets_user_id_wallet_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_wallet_type_key UNIQUE (user_id, wallet_type);


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- Name: agent_commission_settlements_pair_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commission_settlements_pair_idx ON public.agent_commission_settlements USING btree (club_id, user_id, period_start, period_end);


--
-- Name: agent_commissions_open_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commissions_open_idx ON public.agent_commissions USING btree (club_id, user_id, created_at) INCLUDE (amount, id) WHERE (settled_at IS NULL);


--
-- Name: agent_commissions_unsettled_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commissions_unsettled_idx ON public.agent_commissions USING btree (club_id, user_id) INCLUDE (amount, created_at) WHERE (settled_at IS NULL);


--
-- Name: agent_commissions_user_recent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX agent_commissions_user_recent_idx ON public.agent_commissions USING btree (user_id, created_at DESC);


--
-- Name: bbj_payouts_pool_table_hand_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX bbj_payouts_pool_table_hand_uidx ON public.bbj_payouts USING btree (pool_id, table_id, hand_number);


--
-- Name: ca_clubs_one_platform_club; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ca_clubs_one_platform_club ON public.clubs USING btree (is_platform) WHERE is_platform;


--
-- Name: INDEX ca_clubs_one_platform_club; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.ca_clubs_one_platform_club IS 'Ruling 16 and standard 3.2 both say ONE platform club. This is what makes that true rather than hoped: a second is_platform row cannot be inserted.';


--
-- Name: ca_diamond_balance_audit_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_diamond_balance_audit_at_idx ON public.ca_diamond_balance_audit USING btree (occurred_at DESC);


--
-- Name: ca_diamond_balance_audit_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_diamond_balance_audit_user_idx ON public.ca_diamond_balance_audit USING btree (user_id, occurred_at DESC);


--
-- Name: ca_diamond_engine_spend_period_engine; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_diamond_engine_spend_period_engine ON public.ca_diamond_engine_spend USING btree (period, engine);


--
-- Name: ca_diamond_incidents_open_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_diamond_incidents_open_idx ON public.ca_diamond_incidents USING btree (occurred_at DESC) WHERE (resolved_at IS NULL);


--
-- Name: ca_diamond_incidents_rule_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_diamond_incidents_rule_idx ON public.ca_diamond_incidents USING btree (rule, occurred_at DESC);


--
-- Name: ca_drift_incidents_alert_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_drift_incidents_alert_id_idx ON public.ca_drift_incidents USING btree (((metadata ->> 'alert_id'::text))) WHERE (metadata ? 'alert_id'::text);


--
-- Name: ca_drift_incidents_alert_uuid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_drift_incidents_alert_uuid_idx ON public.ca_drift_incidents USING btree ((((metadata ->> 'alert_id'::text))::uuid)) WHERE ((metadata ->> 'alert_id'::text) ~ '^[0-9a-fA-F-]{36}$'::text);


--
-- Name: ca_manual_adjustments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_manual_adjustments_status_idx ON public.ca_manual_adjustments USING btree (status, created_at DESC);


--
-- Name: ca_mint_ledger_asset_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_mint_ledger_asset_idx ON public.ca_mint_ledger USING btree (asset, action, created_at DESC);


--
-- Name: ca_mint_ledger_chip_ledger_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ca_mint_ledger_chip_ledger_id_key ON public.ca_mint_ledger USING btree (chip_ledger_id) WHERE (chip_ledger_id IS NOT NULL);


--
-- Name: ca_mint_ledger_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_mint_ledger_created_idx ON public.ca_mint_ledger USING btree (created_at DESC);


--
-- Name: ca_mint_ledger_diamond_tx_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ca_mint_ledger_diamond_tx_id_key ON public.ca_mint_ledger USING btree (diamond_tx_id) WHERE (diamond_tx_id IS NOT NULL);


--
-- Name: ca_mint_ledger_holder_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_mint_ledger_holder_idx ON public.ca_mint_ledger USING btree (holder_type, holder_id, created_at DESC);


--
-- Name: ca_mint_ledger_origin_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_mint_ledger_origin_idx ON public.ca_mint_ledger USING btree (origin, created_at DESC);


--
-- Name: ca_money_path_violations_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_money_path_violations_at_idx ON public.ca_money_path_violations USING btree (at DESC);


--
-- Name: ca_payout_freeze_one_open_per_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ca_payout_freeze_one_open_per_scope ON public.ca_payout_freeze USING btree (scope) WHERE (cleared_at IS NULL);


--
-- Name: ca_player_restrictions_active_by_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_player_restrictions_active_by_user ON public.ca_player_restrictions USING btree (user_id) WHERE (status = 'active'::text);


--
-- Name: ca_player_restrictions_one_active_per_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ca_player_restrictions_one_active_per_scope ON public.ca_player_restrictions USING btree (user_id, scope) WHERE (status = 'active'::text);


--
-- Name: ca_restriction_observations_by_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_restriction_observations_by_user ON public.ca_restriction_observations USING btree (user_id, observed_at DESC);


--
-- Name: ca_restriction_observations_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_restriction_observations_recent ON public.ca_restriction_observations USING btree (observed_at DESC);


--
-- Name: ca_seat_stack_exits_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_seat_stack_exits_at_idx ON public.ca_seat_stack_exits USING btree (occurred_at DESC);


--
-- Name: ca_seat_stack_exits_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ca_seat_stack_exits_user_idx ON public.ca_seat_stack_exits USING btree (user_id, occurred_at DESC);


--
-- Name: cash_cluster_events_by_game; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_cluster_events_by_game ON public.cash_cluster_events USING btree (game_id, at DESC);


--
-- Name: cash_games_one_per_band_action_madness; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cash_games_one_per_band_action_madness ON public.cash_games USING btree (club_id, template_name, variant, public.fn_cash_stake_band(bb)) WHERE (enabled AND (template_name = ANY (ARRAY['action'::text, 'madness'::text])));


--
-- Name: INDEX cash_games_one_per_band_action_madness; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.cash_games_one_per_band_action_madness IS 'Dan 2026-09-05: one Action game and one Madness game per blind category per game type. Classic is deliberately not covered.';


--
-- Name: cash_games_one_per_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cash_games_one_per_key ON public.cash_games USING btree (club_id, variant, sb, bb, template_name) WHERE (enabled AND must_move);


--
-- Name: cash_player_session_one_open; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cash_player_session_one_open ON public.cash_player_session USING btree (player_id, scope_type, scope_id) WHERE (closed_at IS NULL);


--
-- Name: cash_player_session_open_by_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_player_session_open_by_scope ON public.cash_player_session USING btree (scope_id) WHERE (closed_at IS NULL);


--
-- Name: cash_player_session_open_by_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_player_session_open_by_table ON public.cash_player_session USING btree (table_id) WHERE (closed_at IS NULL);


--
-- Name: cash_seat_moves_one_pending_per_player; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cash_seat_moves_one_pending_per_player ON public.cash_seat_moves USING btree (player_id) WHERE (state = 'pending'::text);


--
-- Name: cash_seat_moves_pending_by_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cash_seat_moves_pending_by_from ON public.cash_seat_moves USING btree (from_table_id) WHERE (state = 'pending'::text);


--
-- Name: cashout_requests_one_pending_per_player_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cashout_requests_one_pending_per_player_uidx ON public.cashout_requests USING btree (club_id, player_id) WHERE (status = 'pending'::text);


--
-- Name: chip_ledger_chain_seq_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_ledger_chain_seq_key ON public.chip_ledger USING btree (chain_seq);


--
-- Name: chip_transactions_agent_wallet_op_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_transactions_agent_wallet_op_id_uidx ON public.chip_transactions USING btree (club_id, ((metadata ->> 'op_id'::text))) WHERE ((transaction_type = ANY (ARRAY['agent_wallet_send'::text, 'agent_wallet_claim_back'::text, 'cashout_request_escrow'::text, 'cashout_approved'::text, 'cashout_denied'::text, 'cashout_cancelled'::text])) AND (metadata ? 'op_id'::text));


--
-- Name: chip_transactions_agent_wallet_reversible_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chip_transactions_agent_wallet_reversible_idx ON public.chip_transactions USING btree (from_user_id, reversible_until) WHERE (transaction_type = 'agent_wallet_send'::text);


--
-- Name: chip_transactions_club_bank_op_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_transactions_club_bank_op_id_uidx ON public.chip_transactions USING btree (club_id, ((metadata ->> 'op_id'::text))) WHERE ((transaction_type = ANY (ARRAY['club_bank_send'::text, 'club_bank_reversal'::text])) AND (metadata ? 'op_id'::text));


--
-- Name: chip_transactions_club_from_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chip_transactions_club_from_created_idx ON public.chip_transactions USING btree (club_id, from_user_id, created_at DESC) INCLUDE (amount, transaction_type, to_user_id, notes);


--
-- Name: chip_transactions_club_to_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chip_transactions_club_to_created_idx ON public.chip_transactions USING btree (club_id, to_user_id, created_at DESC) INCLUDE (amount, transaction_type, from_user_id, notes);


--
-- Name: chip_transactions_commission_claim_op_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_transactions_commission_claim_op_id_uidx ON public.chip_transactions USING btree (club_id, ((metadata ->> 'op_id'::text))) WHERE ((transaction_type = 'commission_claim'::text) AND (metadata ? 'op_id'::text));


--
-- Name: chip_transactions_staff_ops_op_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_transactions_staff_ops_op_id_uidx ON public.chip_transactions USING btree (club_id, ((metadata ->> 'op_id'::text))) WHERE ((transaction_type = ANY (ARRAY['admin_removal'::text, 'mint'::text, 'cashout_expired_refund'::text])) AND (metadata ? 'op_id'::text));


--
-- Name: chip_transactions_ticket_cancel_receipt_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_transactions_ticket_cancel_receipt_uidx ON public.chip_transactions USING btree (((metadata ->> 'ticket_id'::text))) WHERE (transaction_type = 'tournament_ticket_cancel'::text);


--
-- Name: chip_transactions_ticket_redeem_receipt_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_transactions_ticket_redeem_receipt_uidx ON public.chip_transactions USING btree (((metadata ->> 'ticket_id'::text))) WHERE (transaction_type = 'tournament_ticket_redeem'::text);


--
-- Name: chip_transactions_wallet_ops_op_id_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX chip_transactions_wallet_ops_op_id_uidx ON public.chip_transactions USING btree (club_id, ((metadata ->> 'op_id'::text))) WHERE ((transaction_type = ANY (ARRAY['club_bank_claim'::text, 'promo_wallet_send'::text])) AND (metadata ? 'op_id'::text));


--
-- Name: club_members_cashier_tree_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX club_members_cashier_tree_idx ON public.club_members USING btree (club_id, agent_id, user_id) INCLUDE (role, status, chip_balance) WHERE (COALESCE(status, 'active'::text) = ANY (ARRAY['active'::text, 'approved'::text]));


--
-- Name: content_authors_profile_id_uniq; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX content_authors_profile_id_uniq ON public.content_authors USING btree (profile_id) WHERE (profile_id IS NOT NULL);


--
-- Name: diamond_transactions_user_reference_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX diamond_transactions_user_reference_uidx ON public.diamond_transactions USING btree (user_id, reference_id) WHERE (reference_id IS NOT NULL);


--
-- Name: financial_alerts_incident_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_alerts_incident_id_idx ON public.financial_alerts USING btree (((context ->> 'incident_id'::text))) WHERE (context ? 'incident_id'::text);


--
-- Name: financial_alerts_incident_uuid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_alerts_incident_uuid_idx ON public.financial_alerts USING btree ((((context ->> 'incident_id'::text))::uuid)) WHERE ((context ->> 'incident_id'::text) ~ '^[0-9a-fA-F-]{36}$'::text);


--
-- Name: financial_alerts_unresolved_source_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_alerts_unresolved_source_idx ON public.financial_alerts USING btree (source) WHERE (NOT resolved);


--
-- Name: idx_agent_commissions_club_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_commissions_club_created ON public.agent_commissions USING btree (club_id, created_at) INCLUDE (user_id, amount, settled_at);


--
-- Name: idx_agent_commissions_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_commissions_club_id ON public.agent_commissions USING btree (club_id);


--
-- Name: idx_agent_commissions_source_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_commissions_source_lookup ON public.agent_commissions USING btree (source_id, source_type, club_id) WHERE (source_id IS NOT NULL);


--
-- Name: idx_agent_commissions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_commissions_user ON public.agent_commissions USING btree (user_id);


--
-- Name: idx_agents_club; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agents_club ON public.agents USING btree (club_id);


--
-- Name: idx_agents_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agents_parent ON public.agents USING btree (parent_agent_id);


--
-- Name: idx_agents_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agents_user ON public.agents USING btree (user_id);


--
-- Name: idx_audit_trail_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_trail_actor ON public.audit_trail USING btree (actor_id, created_at DESC);


--
-- Name: idx_audit_trail_club_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_trail_club_action ON public.audit_trail USING btree (club_id, action, created_at DESC);


--
-- Name: idx_bbj_payouts_table_hand; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bbj_payouts_table_hand ON public.bbj_payouts USING btree (table_id, hand_number);


--
-- Name: idx_bbj_pools_union; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bbj_pools_union ON public.bbj_pools USING btree (union_id) WHERE (union_id IS NOT NULL);


--
-- Name: idx_bbj_unclaimed_shares_payout_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bbj_unclaimed_shares_payout_id_fk ON public.bbj_unclaimed_shares USING btree (payout_id);


--
-- Name: idx_bbj_unclaimed_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bbj_unclaimed_user ON public.bbj_unclaimed_shares USING btree (user_id) WHERE (paid_at IS NULL);


--
-- Name: idx_bounty_awards_table_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounty_awards_table_open ON public.tournament_bounty_awards USING btree (tournament_id, table_id, reserved_at) WHERE (status = ANY (ARRAY['reserved'::text, 'revealed'::text]));


--
-- Name: idx_bounty_awards_tournament; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounty_awards_tournament ON public.tournament_bounty_awards USING btree (tournament_id, reserved_at);


--
-- Name: idx_bounty_chests_next_available; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounty_chests_next_available ON public.tournament_bounty_chests USING btree (tournament_id, seq) WHERE (status = 'available'::text);


--
-- Name: idx_bounty_recipients_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bounty_recipients_user ON public.tournament_bounty_award_recipients USING btree (user_id);


--
-- Name: idx_ca_arena_settings_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_arena_settings_club_id_fk ON public.ca_arena_settings USING btree (club_id);


--
-- Name: idx_ca_club_player_daily_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_club_player_daily_range ON public.ca_club_player_daily USING btree (club_id, stat_date, user_id);


--
-- Name: idx_ca_club_tournament_daily_range; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_club_tournament_daily_range ON public.ca_club_tournament_daily USING btree (club_id, stat_date, tournament_id);


--
-- Name: idx_ca_diamond_journal_archive_archived_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_diamond_journal_archive_archived_at ON public.ca_diamond_journal_archive USING btree (archived_at DESC);


--
-- Name: idx_ca_diamond_journal_archive_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_diamond_journal_archive_user ON public.ca_diamond_journal_archive USING btree (user_id, created_at DESC);


--
-- Name: idx_ca_hand_player_idx_hand_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_hand_player_idx_hand_id ON public.ca_hand_player_idx USING btree (hand_id);


--
-- Name: idx_ca_hand_player_idx_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_hand_player_idx_user_time ON public.ca_hand_player_idx USING btree (user_id, created_at DESC);


--
-- Name: idx_ca_hand_player_stat_hand_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_hand_player_stat_hand_id ON public.ca_hand_player_stat USING btree (hand_id);


--
-- Name: idx_ca_hand_player_stat_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_hand_player_stat_user_time ON public.ca_hand_player_stat USING btree (user_id, created_at DESC);


--
-- Name: idx_ca_ledger_day_manifest_restatements_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ca_ledger_day_manifest_restatements_day ON public.ca_ledger_day_manifest_restatements USING btree (day, restated_at DESC);


--
-- Name: idx_cash_game_roster_game_joined; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cash_game_roster_game_joined ON public.cash_game_roster USING btree (game_id, joined_at) WHERE (left_at IS NULL);


--
-- Name: idx_cash_game_roster_open; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cash_game_roster_open ON public.cash_game_roster USING btree (game_id, user_id) WHERE (left_at IS NULL);


--
-- Name: idx_cash_seat_change_requests_game_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cash_seat_change_requests_game_created ON public.cash_seat_change_requests USING btree (game_id, created_at) WHERE (status = 'requested'::text);


--
-- Name: idx_cash_seat_change_requests_open; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_cash_seat_change_requests_open ON public.cash_seat_change_requests USING btree (game_id, user_id) WHERE (status = 'requested'::text);


--
-- Name: idx_cash_seat_moves_cancelled_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cash_seat_moves_cancelled_player ON public.cash_seat_moves USING btree (player_id, created_at) WHERE (state = 'cancelled'::text);


--
-- Name: idx_cashout_requests_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cashout_requests_club_id_fk ON public.cashout_requests USING btree (club_id);


--
-- Name: idx_chip_ledger_club_created_desc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_club_created_desc ON public.chip_ledger USING btree (club_id, created_at DESC);


--
-- Name: idx_chip_ledger_club_from_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_club_from_created ON public.chip_ledger USING btree (club_id, from_entity_id, created_at);


--
-- Name: idx_chip_ledger_club_to_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_club_to_created ON public.chip_ledger USING btree (club_id, to_entity_id, created_at);


--
-- Name: idx_chip_ledger_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_created_at ON public.chip_ledger USING btree (created_at);


--
-- Name: idx_chip_ledger_from_entity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_from_entity_created ON public.chip_ledger USING btree (from_entity_id, created_at DESC);


--
-- Name: idx_chip_ledger_overlay_by_tournament; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_overlay_by_tournament ON public.chip_ledger USING btree (tournament_id) INCLUDE (amount) WHERE ((tournament_id IS NOT NULL) AND (category = 'overlay'::text) AND (to_type = 'prize_liability'::text));


--
-- Name: INDEX idx_chip_ledger_overlay_by_tournament; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_chip_ledger_overlay_by_tournament IS 'Serves fn_tournament_conservation_delta''s funded_overlay term. Narrow on purpose: overlay legs into prize_liability only.';


--
-- Name: idx_chip_ledger_performed_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_performed_by ON public.chip_ledger USING btree (performed_by);


--
-- Name: idx_chip_ledger_promo_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_promo_from ON public.chip_ledger USING btree (from_entity_id, created_at DESC) WHERE (from_type = 'promo_wallet'::text);


--
-- Name: idx_chip_ledger_promo_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_promo_to ON public.chip_ledger USING btree (to_entity_id, created_at DESC) WHERE (to_type = 'promo_wallet'::text);


--
-- Name: idx_chip_ledger_to_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_to_entity ON public.chip_ledger USING btree (to_entity_id);


--
-- Name: idx_chip_ledger_to_entity_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_ledger_to_entity_created ON public.chip_ledger USING btree (to_entity_id, created_at DESC);


--
-- Name: idx_chip_transactions_reversible_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_transactions_reversible_open ON public.chip_transactions USING btree (reversible_until) WHERE (reversible_until IS NOT NULL);


--
-- Name: idx_chip_tx_club_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_tx_club_created ON public.chip_transactions USING btree (club_id, created_at DESC);


--
-- Name: idx_chip_tx_from; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_tx_from ON public.chip_transactions USING btree (from_user_id) WHERE (from_user_id IS NOT NULL);


--
-- Name: idx_chip_tx_from_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_tx_from_user ON public.chip_transactions USING btree (from_user_id, created_at DESC) WHERE (from_user_id IS NOT NULL);


--
-- Name: idx_chip_tx_table_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_tx_table_id ON public.chip_transactions USING btree (table_id, created_at) WHERE (table_id IS NOT NULL);


--
-- Name: idx_chip_tx_to_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_tx_to_user ON public.chip_transactions USING btree (to_user_id, created_at DESC) WHERE (to_user_id IS NOT NULL);


--
-- Name: idx_chip_tx_type_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chip_tx_type_user_created ON public.chip_transactions USING btree (transaction_type, to_user_id, created_at);


--
-- Name: idx_club_members_active_lifecycle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_club_members_active_lifecycle ON public.club_members USING btree (club_id, user_id) WHERE (membership_lifecycle_status = 'active'::text);


--
-- Name: idx_club_members_agent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_club_members_agent_id ON public.club_members USING btree (agent_id);


--
-- Name: idx_club_members_club_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_club_members_club_status ON public.club_members USING btree (club_id, status);


--
-- Name: idx_club_members_search_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_club_members_search_scope ON public.club_members USING btree (club_id, user_id) WHERE (status = ANY (ARRAY['active'::text, 'approved'::text]));


--
-- Name: idx_club_members_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_club_members_user ON public.club_members USING btree (user_id);


--
-- Name: idx_club_members_user_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_club_members_user_active ON public.club_members USING btree (user_id, club_id) WHERE (status = ANY (ARRAY['active'::text, 'approved'::text]));


--
-- Name: idx_clubs_active_lifecycle; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clubs_active_lifecycle ON public.clubs USING btree (id) WHERE (lifecycle_status = 'active'::text);


--
-- Name: idx_clubs_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_clubs_code ON public.clubs USING btree (code);


--
-- Name: idx_clubs_name_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_clubs_name_lower ON public.clubs USING btree (lower(name));


--
-- Name: idx_clubs_one_platform; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_clubs_one_platform ON public.clubs USING btree (is_platform) WHERE is_platform;


--
-- Name: idx_clubs_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clubs_owner ON public.clubs USING btree (owner_id);


--
-- Name: idx_clubs_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_clubs_slug ON public.clubs USING btree (slug) WHERE (slug IS NOT NULL);


--
-- Name: idx_clubs_union_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clubs_union_id ON public.clubs USING btree (union_id);


--
-- Name: idx_cm_club_role_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cm_club_role_status ON public.club_members USING btree (club_id, role, status);


--
-- Name: idx_cmds_club_date_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cmds_club_date_user ON public.club_member_daily_stats USING btree (club_id, stat_date) INCLUDE (user_id, hands_played);


--
-- Name: INDEX idx_cmds_club_date_user; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_cmds_club_date_user IS 'Serves the (club_id, stat_date) range every club report reads: ca_club_player_page, ca_club_player_breakdown and ca_club_revenue.by_table. Neither existing index leads with that pair, so a cold ca_club_player_page took 8.6s and was killed by the 8s timeout while a warm one took 384ms.';


--
-- Name: idx_cmds_club_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cmds_club_user ON public.club_member_daily_stats USING btree (club_id, user_id);


--
-- Name: idx_cmds_stat_date_table_club; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cmds_stat_date_table_club ON public.club_member_daily_stats USING btree (stat_date, table_id, club_id);


--
-- Name: idx_content_authors_profile_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_content_authors_profile_id ON public.content_authors USING btree (profile_id);


--
-- Name: idx_daily_challenge_event_outbox_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_challenge_event_outbox_due ON public.daily_challenge_event_outbox USING btree (next_attempt_at, created_at);


--
-- Name: idx_daily_challenge_event_outbox_shard_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_daily_challenge_event_outbox_shard_due ON public.daily_challenge_event_outbox USING btree ((((hashtext((user_id)::text) & 2147483647) % 4)), user_id, created_at) WHERE (dead_lettered_at IS NULL);


--
-- Name: idx_diamond_transactions_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_diamond_transactions_created_at ON public.diamond_transactions USING btree (created_at DESC);


--
-- Name: idx_diamond_transactions_reference_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_diamond_transactions_reference_id ON public.diamond_transactions USING btree (reference_id) WHERE (reference_id IS NOT NULL);


--
-- Name: idx_diamond_transactions_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_diamond_transactions_user_created ON public.diamond_transactions USING btree (user_id, created_at DESC);


--
-- Name: idx_diamond_transactions_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_diamond_transactions_user_id ON public.diamond_transactions USING btree (user_id);


--
-- Name: idx_diamond_transactions_user_type_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_diamond_transactions_user_type_created ON public.diamond_transactions USING btree (user_id, transaction_type, created_at DESC);


--
-- Name: idx_engine_recovery_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_engine_recovery_events_created ON public.engine_recovery_events USING btree (created_at DESC);


--
-- Name: idx_engine_recovery_events_real_kills_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_engine_recovery_events_real_kills_created ON public.engine_recovery_events USING btree (created_at DESC) WHERE ((event = 'watchdog_kill_rebuild'::text) AND (event_class = 'automatic_recovery'::text));


--
-- Name: idx_engine_tournament_leases_heartbeat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_engine_tournament_leases_heartbeat ON public.engine_tournament_leases USING btree (heartbeat_at);


--
-- Name: idx_financial_alerts_reported_by_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_alerts_reported_by_created ON public.financial_alerts USING btree (((context ->> 'reported_by'::text)), created_at DESC);


--
-- Name: idx_financial_alerts_resolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_alerts_resolved ON public.financial_alerts USING btree (resolved) WHERE (resolved = false);


--
-- Name: idx_financial_alerts_resolved_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_alerts_resolved_by ON public.financial_alerts USING btree (resolved_by);


--
-- Name: idx_financial_alerts_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_alerts_severity ON public.financial_alerts USING btree (severity);


--
-- Name: idx_financial_alerts_source_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_alerts_source_created ON public.financial_alerts USING btree (source, created_at DESC);


--
-- Name: idx_friendships_friend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_friendships_friend ON public.friendships USING btree (friend_id);


--
-- Name: idx_friendships_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_friendships_status ON public.friendships USING btree (status);


--
-- Name: idx_friendships_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_friendships_user ON public.friendships USING btree (user_id);


--
-- Name: idx_game_management_events_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_game_management_events_club_id ON public.game_management_events USING btree (club_id);


--
-- Name: INDEX idx_game_management_events_club_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_game_management_events_club_id IS 'Foreign key support for game_management_events_club_id_fkey, and the index the retirement function''s own DELETE ... WHERE club_id = $1 needs. 867,780 rows.';


--
-- Name: idx_game_management_events_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_game_management_events_created ON public.game_management_events USING btree (created_at DESC);


--
-- Name: idx_game_management_events_recipient; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_game_management_events_recipient ON public.game_management_events USING btree (recipient_id, sequence DESC) WHERE (recipient_id IS NOT NULL);


--
-- Name: idx_game_management_events_scope; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_game_management_events_scope ON public.game_management_events USING btree (scope_id, sequence DESC);


--
-- Name: idx_game_management_events_scope_created_cover; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_game_management_events_scope_created_cover ON public.game_management_events USING btree (scope_kind, scope_id, created_at DESC) INCLUDE (sequence, event_type) WHERE ((scope_kind IS NOT NULL) AND (scope_id IS NOT NULL));


--
-- Name: idx_hand_atomic_commits_post_commit_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_atomic_commits_post_commit_pending ON public.hand_atomic_commits USING btree (table_id, hand_number) WHERE ((post_commit_payload IS NOT NULL) AND (post_commit_completed_at IS NULL));


--
-- Name: idx_hand_history_bomb_pot_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_bomb_pot_created ON public.hand_history USING btree (created_at) WHERE (bomb_pot IS NOT NULL);


--
-- Name: INDEX idx_hand_history_bomb_pot_created; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_hand_history_bomb_pot_created IS 'Serves fn_club_bomb_pot_report. Bomb pot hands are ~0.7% of hand_history (19,078 in 30 days of 2.7M rows); without this the report sequentially scans 7.2 GB for 46 seconds and is killed by the 8s PostgREST timeout, which is why the page had never rendered.';


--
-- Name: idx_hand_history_cash_rake_unbanked; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_cash_rake_unbanked ON public.hand_history USING btree (created_at) WHERE ((tournament_id IS NULL) AND (rake_amount > (0)::numeric));


--
-- Name: idx_hand_history_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_created ON public.hand_history USING btree (created_at DESC);


--
-- Name: idx_hand_history_hand_number_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_hand_number_lookup ON public.hand_history USING btree (hand_number);


--
-- Name: idx_hand_history_human_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_human_created ON public.hand_history USING btree (created_at) WHERE has_human;


--
-- Name: idx_hand_history_players_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_players_gin ON public.hand_history USING gin (players jsonb_path_ops) WITH (fastupdate='on', gin_pending_list_limit='32768');


--
-- Name: idx_hand_history_table_created_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_table_created_id ON public.hand_history USING btree (table_id, created_at, id);


--
-- Name: idx_hand_history_table_handnum; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_table_handnum ON public.hand_history USING btree (table_id, hand_number DESC);


--
-- Name: idx_hand_history_tournament_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_hand_history_tournament_created ON public.hand_history USING btree (tournament_id, created_at DESC) WHERE (tournament_id IS NOT NULL);


--
-- Name: idx_managed_game_contract_versions_game; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_game_contract_versions_game ON public.managed_game_contract_versions USING btree (game_kind, game_id, version DESC);


--
-- Name: idx_managed_game_contract_versions_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_managed_game_contract_versions_hash ON public.managed_game_contract_versions USING btree (game_kind, game_id, contract_hash);


--
-- Name: idx_notif_dedup_friend_request; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_notif_dedup_friend_request ON public.notifications USING btree (user_id, type, ((data ->> 'sender_id'::text))) WHERE (type = 'friend_request'::text);


--
-- Name: idx_notif_dedup_group_friend; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_notif_dedup_group_friend ON public.notifications USING btree (user_id, type, ((data ->> 'group_id'::text)), ((data ->> 'friend_id'::text))) WHERE (type = 'home_group_friend_joined'::text);


--
-- Name: idx_notifications_actor_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_actor_id ON public.notifications USING btree (actor_id);


--
-- Name: idx_notifications_user_all; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_all ON public.notifications USING btree (user_id, created_at DESC);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_notifications_user_id_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_id_id ON public.notifications USING btree (user_id, id);


--
-- Name: idx_notifications_user_type_read; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_type_read ON public.notifications USING btree (user_id, type, read, created_at DESC);


--
-- Name: idx_notifications_user_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_unread ON public.notifications USING btree (user_id, read, created_at DESC) WHERE (read = false);


--
-- Name: idx_player_stats_club; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_stats_club ON public.player_stats USING btree (club_id);


--
-- Name: idx_player_stats_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_stats_user ON public.player_stats USING btree (user_id);


--
-- Name: idx_profiles_alias_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_alias_trgm ON public.profiles USING gin (lower(alias) public.gin_trgm_ops);


--
-- Name: idx_profiles_display_name_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_display_name_trgm ON public.profiles USING gin (lower(display_name) public.gin_trgm_ops);


--
-- Name: idx_profiles_farming_flagged; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_farming_flagged ON public.profiles USING btree (is_farming_flagged);


--
-- Name: idx_profiles_kyc_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_kyc_status ON public.profiles USING btree (kyc_status) WHERE (kyc_status = ANY (ARRAY['PENDING'::text, 'APPROVED'::text, 'REJECTED'::text]));


--
-- Name: idx_profiles_referral_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_referral_code ON public.profiles USING btree (referral_code) WHERE (referral_code IS NOT NULL);


--
-- Name: idx_profiles_username_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_profiles_username_lower ON public.profiles USING btree (lower(username)) WHERE (username IS NOT NULL);


--
-- Name: idx_profiles_username_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_profiles_username_trgm ON public.profiles USING gin (lower(username) public.gin_trgm_ops);


--
-- Name: idx_rake_records_club_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_club_created ON public.rake_records USING btree (club_id, created_at) WHERE (rake_amount > (0)::numeric);


--
-- Name: idx_rake_records_club_data_tournament_window; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_club_data_tournament_window ON public.rake_records USING btree (created_at, tournament_id) INCLUDE (rake_amount, metadata) WHERE (is_tournament AND (rake_amount <> (0)::numeric) AND (tournament_id IS NOT NULL));


--
-- Name: idx_rake_records_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_club_id_fk ON public.rake_records USING btree (club_id);


--
-- Name: INDEX idx_rake_records_club_id_fk; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_rake_records_club_id_fk IS 'Foreign key support for rake_records_club_id_fkey. idx_rake_records_club_created leads on club_id but is partial (WHERE rake_amount > 0), and a partial index cannot answer a foreign key check. Without this one, deleting a club sequentially scans 1.8M rows and takes 1.3 seconds of the request budget.';


--
-- Name: idx_rake_records_contribs_gin; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_contribs_gin ON public.rake_records USING gin (player_contributions);


--
-- Name: idx_rake_records_created_at_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_created_at_id ON public.rake_records USING btree (created_at, id);


--
-- Name: idx_rake_records_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_date ON public.rake_records USING btree (created_at);


--
-- Name: idx_rake_records_relink; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_relink ON public.rake_records USING btree (table_id, ((metadata ->> 'hand_number'::text))) WHERE (hand_id IS NULL);


--
-- Name: idx_rake_records_table_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_table_id ON public.rake_records USING btree (table_id);


--
-- Name: idx_rake_records_tournament; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_records_tournament ON public.rake_records USING btree (tournament_id) WHERE (tournament_id IS NOT NULL);


--
-- Name: idx_rake_settlements_unattributed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_settlements_unattributed ON public.tournament_rake_settlements USING btree (settled_at) WHERE (attributed_at IS NULL);


--
-- Name: idx_rake_settlements_unmeasured; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rake_settlements_unmeasured ON public.tournament_rake_settlements USING btree (settled_at) WHERE ((attributed_users IS NULL) AND (amount > (0)::numeric));


--
-- Name: idx_settlement_idem_status_age; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_settlement_idem_status_age ON public.settlement_idempotency_keys USING btree (status, last_attempt_at DESC) WHERE (status = 'in_flight'::text);


--
-- Name: idx_settlement_idem_table_completed_succeeded; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_settlement_idem_table_completed_succeeded ON public.settlement_idempotency_keys USING btree (table_id, completed_at DESC) WHERE (status = 'succeeded'::text);


--
-- Name: INDEX idx_settlement_idem_table_completed_succeeded; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_settlement_idem_table_completed_succeeded IS 'Bounty-evidence lookup: (table_id, completed_at DESC) WHERE status = succeeded. Took loadPersistedBountyEvidence from 8,523 ms - past the 8s service_role statement timeout, so it errored rather than returned - to 88.5 ms. 2026-09-09.';


--
-- Name: idx_social_follows_following_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_follows_following_id ON public.social_follows USING btree (following_id);


--
-- Name: idx_social_pages_home_games; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_pages_home_games ON public.social_pages USING btree (page_type, is_public, location_state, location_city) WHERE (page_type = 'home_game'::text);


--
-- Name: idx_social_pages_linked_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_pages_linked_entity ON public.social_pages USING btree (linked_entity_type, linked_entity_id) WHERE (linked_entity_type IS NOT NULL);


--
-- Name: idx_social_pages_linked_home_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_pages_linked_home_group ON public.social_pages USING btree (linked_entity_id) WHERE (linked_entity_type = 'home_group'::text);


--
-- Name: idx_social_pages_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_pages_owner ON public.social_pages USING btree (owner_id);


--
-- Name: idx_social_pages_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_pages_type ON public.social_pages USING btree (page_type);


--
-- Name: idx_social_pages_venue; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_social_pages_venue ON public.social_pages USING btree (linked_venue_id);


--
-- Name: idx_spin_reserve_ledger_draws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_spin_reserve_ledger_draws ON public.spin_reserve_ledger USING btree (tournament_id) INCLUDE (amount, created_at) WHERE ((kind = 'jackpot_draw'::text) AND (tournament_id IS NOT NULL));


--
-- Name: idx_table_seats_club_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_club_active ON public.table_seats USING btree (club_id, table_id) WHERE (left_at IS NULL);


--
-- Name: idx_table_seats_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_club_id_fk ON public.table_seats USING btree (club_id);


--
-- Name: INDEX idx_table_seats_club_id_fk; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_table_seats_club_id_fk IS 'Foreign key support for table_seats_club_id_fkey. idx_table_seats_club_active is partial (WHERE left_at IS NULL) and cannot answer the check.';


--
-- Name: idx_table_seats_horse_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_horse_id ON public.table_seats USING btree (horse_id) WHERE (horse_id IS NOT NULL);


--
-- Name: idx_table_seats_live_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_live_user ON public.table_seats USING btree (user_id, table_id) WHERE (left_at IS NULL);


--
-- Name: idx_table_seats_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_status ON public.table_seats USING btree (status) WHERE (left_at IS NULL);


--
-- Name: idx_table_seats_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_table ON public.table_seats USING btree (table_id);


--
-- Name: idx_table_seats_unstamped_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_unstamped_active ON public.table_seats USING btree (table_id) WHERE ((left_at IS NULL) AND (club_id IS NULL));


--
-- Name: idx_table_seats_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_user ON public.table_seats USING btree (user_id);


--
-- Name: idx_table_seats_user_live; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_seats_user_live ON public.table_seats USING btree (user_id) WHERE (left_at IS NULL);


--
-- Name: idx_table_waitlist_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_table_waitlist_user_id ON public.table_waitlist USING btree (user_id);


--
-- Name: idx_tables_bomb_pot_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_bomb_pot_due ON public.tables USING btree (bomb_pot_next_due_at) WHERE (bomb_pot_next_due_at IS NOT NULL);


--
-- Name: idx_tables_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_club_id ON public.tables USING btree (club_id);


--
-- Name: idx_tables_club_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_club_open ON public.tables USING btree (club_id, created_at DESC) WHERE ((is_deleted = false) AND (status <> 'closed'::text));


--
-- Name: idx_tables_cluster_closed_status_drift; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_cluster_closed_status_drift ON public.tables USING btree (cluster_id) WHERE ((lifecycle = 'closed'::text) AND (status <> 'closed'::text));


--
-- Name: idx_tables_cluster_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_cluster_open ON public.tables USING btree (cluster_id, role, main_index, created_at) WHERE (lifecycle <> 'closed'::text);


--
-- Name: idx_tables_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_created_by ON public.tables USING btree (created_by);


--
-- Name: idx_tables_live_by_club; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_live_by_club ON public.tables USING btree (club_id) WHERE ((tournament_id IS NULL) AND (is_deleted IS NOT TRUE) AND (status <> ALL (ARRAY['closed'::text, 'deleted'::text])));


--
-- Name: INDEX idx_tables_live_by_club; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_tables_live_by_club IS 'Serves fn_live_table_count. Predicate must stay character-identical to that function''s WHERE clause or the planner falls back to a seq scan of 58k rows. Added 2026-08-20.';


--
-- Name: idx_tables_live_by_union; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_live_by_union ON public.tables USING btree (union_id) WHERE ((tournament_id IS NULL) AND (is_deleted IS NOT TRUE) AND (status <> ALL (ARRAY['closed'::text, 'deleted'::text])));


--
-- Name: INDEX idx_tables_live_by_union; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_tables_live_by_union IS 'Serves fn_live_table_count. Predicate must stay character-identical to that function''s WHERE clause or the planner falls back to a seq scan of 58k rows. Added 2026-08-20.';


--
-- Name: idx_tables_management_club_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_management_club_page ON public.tables USING btree (club_id, created_at, id) WHERE ((tournament_id IS NULL) AND (NOT COALESCE(is_deleted, false)) AND (union_id IS NULL));


--
-- Name: idx_tables_management_scope_club_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_management_scope_club_page ON public.tables USING btree (club_id, created_at, id) WHERE ((tournament_id IS NULL) AND (NOT COALESCE(is_deleted, false)));


--
-- Name: idx_tables_open_by_club; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_open_by_club ON public.tables USING btree (club_id, tournament_id) WHERE ((status <> 'closed'::text) AND (is_deleted IS NOT TRUE));


--
-- Name: idx_tables_platform_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_platform_open ON public.tables USING btree (current_players DESC) WHERE ((is_deleted = false) AND (status <> 'closed'::text) AND (tournament_id IS NULL));


--
-- Name: idx_tables_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_status ON public.tables USING btree (status);


--
-- Name: idx_tables_tournament_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_tournament_id ON public.tables USING btree (tournament_id) WHERE (tournament_id IS NOT NULL);


--
-- Name: idx_tables_union_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tables_union_id ON public.tables USING btree (union_id);


--
-- Name: idx_tourn_players_tourn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tourn_players_tourn ON public.tournament_players USING btree (tournament_id);


--
-- Name: idx_tourn_players_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tourn_players_user ON public.tournament_players USING btree (user_id);


--
-- Name: idx_tournament_bounty_awards_chest_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_bounty_awards_chest_id ON public.tournament_bounty_awards USING btree (chest_id);


--
-- Name: idx_tournament_bounty_obligations_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_bounty_obligations_pending ON public.tournament_bounty_obligations USING btree (next_attempt_at, created_at) WHERE (state = 'pending'::text);


--
-- Name: idx_tournament_bounty_obligations_user_hand; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_bounty_obligations_user_hand ON public.tournament_bounty_obligations USING btree (tournament_id, eliminated_user_id, hand_number DESC);


--
-- Name: idx_tournament_capacity_table_receipts_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_capacity_table_receipts_pending ON public.tournament_capacity_table_receipts USING btree (tournament_id, created_at, table_id) WHERE (manager_admitted_at IS NULL);


--
-- Name: idx_tournament_guarantee_overlays_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_guarantee_overlays_club_id ON public.tournament_guarantee_overlays USING btree (club_id);


--
-- Name: idx_tournament_knockout_candidates_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_knockout_candidates_pending ON public.tournament_knockout_candidates USING btree (tournament_id, hand_number, eliminated_user_id) WHERE (state = 'pending'::text);


--
-- Name: idx_tournament_knockout_candidates_user_hand; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_knockout_candidates_user_hand ON public.tournament_knockout_candidates USING btree (tournament_id, eliminated_user_id, hand_number DESC, id DESC);


--
-- Name: idx_tournament_manager_wakes_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_manager_wakes_pending ON public.tournament_manager_wakes USING btree (created_at, id) WHERE (consumed_at IS NULL);


--
-- Name: idx_tournament_payouts_satellite_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_payouts_satellite_target ON public.tournament_payouts USING btree (((metadata ->> 'satellite_target_id'::text))) WHERE (source = 'satellite_seat'::text);


--
-- Name: INDEX idx_tournament_payouts_satellite_target; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_tournament_payouts_satellite_target IS 'Serves fn_tournament_conservation_delta''s seat_income term. Without it the delta scanned all of tournament_payouts on every call.';


--
-- Name: idx_tournament_payouts_tournament; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_payouts_tournament ON public.tournament_payouts USING btree (tournament_id);


--
-- Name: idx_tournament_payouts_tournament_position; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_payouts_tournament_position ON public.tournament_payouts USING btree (tournament_id, "position");


--
-- Name: idx_tournament_players_basis; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_basis ON public.tournament_players USING btree (tournament_id) INCLUDE (club_id, rebuys, add_on);


--
-- Name: idx_tournament_players_chips; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_chips ON public.tournament_players USING btree (tournament_id, status, chips);


--
-- Name: idx_tournament_players_club; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_club ON public.tournament_players USING btree (club_id, tournament_id);


--
-- Name: idx_tournament_players_live_user_table; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_live_user_table ON public.tournament_players USING btree (user_id, table_id) WHERE ((status = 'playing'::text) AND (table_id IS NOT NULL));


--
-- Name: idx_tournament_players_rebuy_prompt_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_rebuy_prompt_open ON public.tournament_players USING btree (tournament_id, rebuy_prompt_until) WHERE (rebuy_prompt_until IS NOT NULL);


--
-- Name: idx_tournament_players_registered_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_registered_at ON public.tournament_players USING btree (registered_at);


--
-- Name: idx_tournament_players_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_status ON public.tournament_players USING btree (tournament_id, status);


--
-- Name: idx_tournament_players_user_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_players_user_open ON public.tournament_players USING btree (user_id) WHERE (status = ANY (ARRAY['registered'::text, 'playing'::text]));


--
-- Name: idx_tournament_rake_settlements_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_rake_settlements_club_id ON public.tournament_rake_settlements USING btree (club_id);


--
-- Name: idx_tournament_refund_authorizations_source_wallet_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_refund_authorizations_source_wallet_club_id_fk ON public.tournament_refund_authorizations USING btree (source_wallet_club_id);


--
-- Name: idx_tournament_refund_entitlements_refund_wallet_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_refund_entitlements_refund_wallet_club_id_fk ON public.tournament_refund_entitlements USING btree (refund_wallet_club_id);


--
-- Name: idx_tournament_refund_tranches_source_wallet_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_refund_tranches_source_wallet_club_id_fk ON public.tournament_refund_tranches USING btree (source_wallet_club_id);


--
-- Name: idx_tournament_table_origins_tournament; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_table_origins_tournament ON public.tournament_table_origins USING btree (tournament_id, origin_kind, table_id);


--
-- Name: idx_tournament_tickets_club_id_fk; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_tickets_club_id_fk ON public.tournament_tickets USING btree (club_id);


--
-- Name: idx_tournaments_addon_period_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_addon_period_open ON public.tournaments USING btree (addon_period_ends_at) WHERE (addon_period_ends_at IS NOT NULL);


--
-- Name: idx_tournaments_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_club_id ON public.tournaments USING btree (club_id);


--
-- Name: idx_tournaments_completed_ended_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_completed_ended_at ON public.tournaments USING btree (ended_at DESC) WHERE (status = 'COMPLETED'::text);


--
-- Name: idx_tournaments_live_unfinalized_guarantee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_live_unfinalized_guarantee ON public.tournaments USING btree (club_id) INCLUDE (guaranteed_prize, prize_pool) WHERE ((NOT COALESCE(prize_pool_finalized, false)) AND (upper(status) = ANY (ARRAY['ANNOUNCED'::text, 'REGISTERING'::text, 'RUNNING'::text])));


--
-- Name: idx_tournaments_management_club_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_management_club_page ON public.tournaments USING btree (club_id, start_time, id) WHERE (union_id IS NULL);


--
-- Name: idx_tournaments_management_scope_club_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_management_scope_club_page ON public.tournaments USING btree (club_id, start_time, id);


--
-- Name: idx_tournaments_management_union_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_management_union_page ON public.tournaments USING btree (union_id, start_time, id) WHERE (union_id IS NOT NULL);


--
-- Name: idx_tournaments_pinned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_pinned ON public.tournaments USING btree (is_pinned) WHERE (is_pinned = true);


--
-- Name: idx_tournaments_satellite_target_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_satellite_target_id ON public.tournaments USING btree (satellite_target_id);


--
-- Name: idx_tournaments_spin_draws; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_spin_draws ON public.tournaments USING btree (created_at DESC) INCLUDE (spin_multiplier, spin_locked_tiers) WHERE ((variant = 'spin'::text) AND (spin_multiplier IS NOT NULL));


--
-- Name: idx_tournaments_spin_ended; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_spin_ended ON public.tournaments USING btree (ended_at DESC) WHERE ((variant = 'spin'::text) AND (spin_multiplier IS NOT NULL) AND (ended_at IS NOT NULL));


--
-- Name: idx_tournaments_spin_reveal_lag; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_spin_reveal_lag ON public.tournaments USING btree (started_at DESC) INCLUDE (spin_reveal_lag_ms) WHERE (spin_reveal_lag_ms IS NOT NULL);


--
-- Name: idx_tournaments_spin_unbooked_scan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_spin_unbooked_scan ON public.tournaments USING btree (started_at) WHERE ((variant = 'spin'::text) AND (status = ANY (ARRAY['RUNNING'::text, 'COMPLETED'::text])));


--
-- Name: INDEX idx_tournaments_spin_unbooked_scan; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_tournaments_spin_unbooked_scan IS 'Serves the unbooked-spin anti-join in fn_spin_metrics and fn_spin_sweep_unbooked. Before it, both did a full read of every spin ever played (877ms and 1244ms measured). Ascending: the sweep drains oldest-first.';


--
-- Name: idx_tournaments_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_start_time ON public.tournaments USING btree (start_time);


--
-- Name: idx_tournaments_status_start_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_status_start_time ON public.tournaments USING btree (status, start_time);


--
-- Name: idx_tournaments_tournament_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_tournament_type ON public.tournaments USING btree (tournament_type);


--
-- Name: idx_tournaments_union_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_union_id ON public.tournaments USING btree (union_id) WHERE (union_id IS NOT NULL);


--
-- Name: idx_tournaments_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_updated_at ON public.tournaments USING btree (updated_at DESC);


--
-- Name: idx_tournaments_variant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournaments_variant ON public.tournaments USING btree (variant);


--
-- Name: idx_tourney_bounties_eliminated; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tourney_bounties_eliminated ON public.tournament_bounties USING btree (eliminated_player_id);


--
-- Name: idx_union_clubs_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_union_clubs_club_id ON public.union_clubs USING btree (club_id);


--
-- Name: idx_union_wallet_transactions_club_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_union_wallet_transactions_club_id ON public.union_wallet_transactions USING btree (club_id);


--
-- Name: idx_union_wallet_transactions_created_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_union_wallet_transactions_created_by ON public.union_wallet_transactions USING btree (created_by);


--
-- Name: idx_unions_owner_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_unions_owner_id ON public.unions USING btree (owner_id);


--
-- Name: idx_unions_union_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_unions_union_code ON public.unions USING btree (union_code) WHERE (union_code IS NOT NULL);


--
-- Name: idx_unique_active_user_per_table; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_unique_active_user_per_table ON public.table_seats USING btree (table_id, user_id) WHERE (left_at IS NULL);


--
-- Name: idx_uwt_bbj_flows; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uwt_bbj_flows ON public.union_wallet_transactions USING btree (tx_type) INCLUDE (amount) WHERE (tx_type = ANY (ARRAY['bbj_fund'::text, 'bbj_promo_sweep'::text]));


--
-- Name: idx_uwt_rake_credit_basis; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uwt_rake_credit_basis ON public.union_wallet_transactions USING btree (union_id, created_at) WHERE ((wallet = 'rake_wallet'::text) AND (direction = 'credit'::text) AND (tx_type = 'rake'::text));


--
-- Name: idx_uwt_rake_credit_club_sum; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uwt_rake_credit_club_sum ON public.union_wallet_transactions USING btree (union_id, club_id, created_at) INCLUDE (amount) WHERE ((wallet = 'rake_wallet'::text) AND (direction = 'credit'::text) AND (tx_type = 'rake'::text));


--
-- Name: idx_uwt_rake_credit_sum; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uwt_rake_credit_sum ON public.union_wallet_transactions USING btree (union_id, created_at) INCLUDE (amount, club_id) WHERE ((wallet = 'rake_wallet'::text) AND (direction = 'credit'::text) AND (tx_type = 'rake'::text));


--
-- Name: idx_uwt_rake_wallet_recon; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uwt_rake_wallet_recon ON public.union_wallet_transactions USING btree (union_id, created_at) INCLUDE (amount, direction) WHERE (wallet = 'rake_wallet'::text);


--
-- Name: idx_uwt_union_wallet_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_uwt_union_wallet_created ON public.union_wallet_transactions USING btree (union_id, wallet, created_at DESC) INCLUDE (amount, direction);


--
-- Name: idx_waitlist_table_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_waitlist_table_status ON public.table_waitlist USING btree (table_id, status);


--
-- Name: idx_wallet_credit_idempotency_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_credit_idempotency_user_id ON public.wallet_credit_idempotency USING btree (user_id);


--
-- Name: INDEX idx_wallet_credit_idempotency_user_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_wallet_credit_idempotency_user_id IS 'Bounds player-scoped receipt audit and account-lifecycle cleanup; added after a production statement timeout in Daily Missions certification.';


--
-- Name: idx_wallet_transactions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_transactions_user ON public.wallet_transactions USING btree (user_id);


--
-- Name: idx_wallet_transactions_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_transactions_user_created ON public.wallet_transactions USING btree (user_id, created_at DESC);


--
-- Name: idx_wallet_tx_club_data_cash_user_window; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_club_data_cash_user_window ON public.wallet_transactions USING btree (user_id, created_at) INCLUDE (type, amount, table_id) WHERE ((category = ANY (ARRAY['buyin'::text, 'cashout'::text])) AND (table_id IS NOT NULL));


--
-- Name: idx_wallet_tx_club_data_player_window; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_club_data_player_window ON public.wallet_transactions USING btree (user_id, created_at) INCLUDE (category, type, amount, table_id, related_entity_id) WHERE (((category = ANY (ARRAY['buyin'::text, 'cashout'::text])) AND (table_id IS NOT NULL)) OR ((category = ANY (ARRAY['tournament_buyin'::text, 'prize'::text, 'bounty'::text])) AND (related_entity_id IS NOT NULL)));


--
-- Name: idx_wallet_tx_club_data_tournament_user_window; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_club_data_tournament_user_window ON public.wallet_transactions USING btree (user_id, created_at) INCLUDE (category, amount, related_entity_id) WHERE ((category = ANY (ARRAY['tournament_buyin'::text, 'prize'::text, 'bounty'::text])) AND (related_entity_id IS NOT NULL));


--
-- Name: idx_wallet_tx_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_created_at ON public.wallet_transactions USING btree (created_at);


--
-- Name: idx_wallet_tx_entity_cat_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_entity_cat_created ON public.wallet_transactions USING btree (related_entity_id, category, created_at) WHERE (related_entity_id IS NOT NULL);


--
-- Name: idx_wallet_tx_prize_credits_by_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_prize_credits_by_entity ON public.wallet_transactions USING btree (related_entity_id) INCLUDE (amount) WHERE ((type = 'credit'::text) AND (category = 'prize'::text) AND (related_entity_id IS NOT NULL));


--
-- Name: INDEX idx_wallet_tx_prize_credits_by_entity; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_wallet_tx_prize_credits_by_entity IS 'Per-tournament prize-credit totals without scanning 2.5M wallet rows. v_spin_unpaid_settlements measured 10.5s without it, and fn_backpay_spin_unpaid_winners - a money repair the engine runs every 10 minutes under an 8s statement timeout - measured 8.18s end to end. It was 0.2s from silently never running again.';


--
-- Name: idx_wallet_tx_table_cat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_table_cat ON public.wallet_transactions USING btree (table_id, category) WHERE (table_id IS NOT NULL);


--
-- Name: idx_wallet_tx_table_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_table_created ON public.wallet_transactions USING btree (table_id, created_at) WHERE (table_id IS NOT NULL);


--
-- Name: idx_wallet_tx_user_diamond; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_user_diamond ON public.wallet_transactions USING btree (user_id) INCLUDE (amount) WHERE ((type = 'credit'::text) AND (category = ANY (ARRAY['diamond_purchase'::text, 'diamond_reward'::text, 'diamond_refund'::text])));


--
-- Name: INDEX idx_wallet_tx_user_diamond; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_wallet_tx_user_diamond IS 'DiamondService lifetime-earned. Without it: parallel seq scan of the 2.1M row ledger, 8s, on every lobby load.';


--
-- Name: idx_wallet_tx_user_diamond_spend; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallet_tx_user_diamond_spend ON public.wallet_transactions USING btree (user_id) INCLUDE (amount) WHERE ((type = 'debit'::text) AND (category = ANY (ARRAY['diamond_deduction'::text, 'vip_purchase'::text, 'mint'::text])));


--
-- Name: INDEX idx_wallet_tx_user_diamond_spend; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_wallet_tx_user_diamond_spend IS 'DiamondService lifetime-spent. Same full-scan shape as the earned lookup without it.';


--
-- Name: idx_wallets_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wallets_user ON public.wallets USING btree (user_id);


--
-- Name: idx_wt_bbj_promo_payout; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_wt_bbj_promo_payout ON public.wallet_transactions USING btree (category) INCLUDE (amount) WHERE ((category = 'promotion'::text) AND (description = 'BBJ promo pool payout'::text));


--
-- Name: ix_ca_drift_incidents_club; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ca_drift_incidents_club ON public.ca_drift_incidents USING btree (club_id, detected_at DESC);


--
-- Name: ix_ca_drift_incidents_open; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ca_drift_incidents_open ON public.ca_drift_incidents USING btree (status, detected_at DESC) WHERE (status <> 'resolved'::text);


--
-- Name: ix_ca_incident_events_incident; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_ca_incident_events_incident ON public.ca_incident_events USING btree (incident_id, at);


--
-- Name: ix_chip_ledger_settlement; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chip_ledger_settlement ON public.chip_ledger USING btree (settlement_id) WHERE (settlement_id IS NOT NULL);


--
-- Name: ix_tournament_obligations_tournament; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tournament_obligations_tournament ON public.tournament_obligations USING btree (tournament_id);


--
-- Name: ix_tournament_obligations_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tournament_obligations_user_created ON public.tournament_obligations USING btree (user_id, created_at DESC, id DESC) WHERE (user_id IS NOT NULL);


--
-- Name: notifications_daily_mission_cycle_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notifications_daily_mission_cycle_unique ON public.notifications USING btree (user_id, ((data ->> 'cycle_date'::text))) WHERE ((type = 'daily_challenge'::text) AND ((data ->> 'source'::text) = 'club_arena_daily_missions'::text));


--
-- Name: notifications_pa_leak_audit_job_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX notifications_pa_leak_audit_job_unique ON public.notifications USING btree (((data ->> 'paAuditJobId'::text))) WHERE ((type = 'personal_assistant_audit_complete'::text) AND (data ? 'paAuditJobId'::text));


--
-- Name: one_god_account_only; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX one_god_account_only ON public.profiles USING btree (role) WHERE (role = 'god'::text);


--
-- Name: INDEX one_god_account_only; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.one_god_account_only IS 'Dan 2026-09-02: there is exactly one god account. A second INSERT/UPDATE to role=god is refused by the database rather than relying on every writer to remember.';


--
-- Name: poker_arena_one_diamond_identity; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX poker_arena_one_diamond_identity ON public.clubs USING btree (asset) WHERE (asset = 'diamonds'::text);


--
-- Name: poker_diamond_custody_arena; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poker_diamond_custody_arena ON public.poker_diamond_custody USING btree (arena_id);


--
-- Name: poker_diamond_custody_occupancy; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX poker_diamond_custody_occupancy ON public.poker_diamond_custody USING btree (occupancy_id) WHERE (occupancy_id IS NOT NULL);


--
-- Name: poker_diamond_custody_seat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poker_diamond_custody_seat ON public.poker_diamond_custody USING btree (seat_id) WHERE (seat_id IS NOT NULL);


--
-- Name: poker_diamond_custody_user_state; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX poker_diamond_custody_user_state ON public.poker_diamond_custody USING btree (user_id, state);


--
-- Name: poker_diamond_one_open_entry; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX poker_diamond_one_open_entry ON public.poker_diamond_custody USING btree (user_id, purpose, target_id) WHERE (state <> 'released'::text);


--
-- Name: profiles_username_lower_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX profiles_username_lower_key ON public.profiles USING btree (lower(username)) WHERE ((username IS NOT NULL) AND (username <> ''::text));


--
-- Name: INDEX profiles_username_lower_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.profiles_username_lower_key IS 'Case-insensitive uniqueness for profiles.username. Replaces the old case-sensitive profiles_username_key. Allows NULL/empty values (the legacy signup fallback writes empty strings into a few legacy rows).';


--
-- Name: push_outbox_event_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_outbox_event_idx ON public.push_outbox USING btree (event, created_at DESC);


--
-- Name: push_outbox_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_outbox_pending_idx ON public.push_outbox USING btree (status, created_at) WHERE (status = 'pending'::text);


--
-- Name: push_outbox_processing_claimed_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_outbox_processing_claimed_idx ON public.push_outbox USING btree (claimed_at) WHERE (status = 'processing'::text);


--
-- Name: push_outbox_recipient_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_outbox_recipient_idx ON public.push_outbox USING btree (recipient_user_id, created_at DESC);


--
-- Name: push_outbox_recipient_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_outbox_recipient_pending_idx ON public.push_outbox USING btree (recipient_user_id) WHERE (status = ANY (ARRAY['pending'::text, 'processing'::text]));


--
-- Name: push_outbox_recipient_sent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_outbox_recipient_sent_idx ON public.push_outbox USING btree (recipient_user_id, sent_at DESC) WHERE (status = 'sent'::text);


--
-- Name: signup_errors_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX signup_errors_occurred_at_idx ON public.signup_errors USING btree (occurred_at DESC);


--
-- Name: signup_errors_pending_forward_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX signup_errors_pending_forward_idx ON public.signup_errors USING btree (occurred_at) WHERE (forwarded_to_sentry IS NULL);


--
-- Name: spin_reserve_ledger_club_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spin_reserve_ledger_club_time ON public.spin_reserve_ledger USING btree (club_id, created_at DESC);


--
-- Name: spin_reserve_ledger_tournament; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX spin_reserve_ledger_tournament ON public.spin_reserve_ledger USING btree (tournament_id) WHERE (tournament_id IS NOT NULL);


--
-- Name: table_seats_occupancy_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX table_seats_occupancy_id_unique ON public.table_seats USING btree (occupancy_id);


--
-- Name: table_waitlist_one_active_per_player_uidx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX table_waitlist_one_active_per_player_uidx ON public.table_waitlist USING btree (table_id, user_id) WHERE (status = ANY (ARRAY['waiting'::text, 'notified'::text]));


--
-- Name: tables_cluster_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tables_cluster_id_idx ON public.tables USING btree (cluster_id) WHERE (cluster_id IS NOT NULL);


--
-- Name: tournament_players_one_elimination_sequence; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tournament_players_one_elimination_sequence ON public.tournament_players USING btree (tournament_id, elimination_sequence) WHERE (elimination_sequence IS NOT NULL);


--
-- Name: tournament_players_one_finish_position; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tournament_players_one_finish_position ON public.tournament_players USING btree (tournament_id, "position") WHERE ("position" IS NOT NULL);


--
-- Name: tournament_refund_entitlement_one_source_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tournament_refund_entitlement_one_source_ticket ON public.tournament_refund_entitlements USING btree (source_ticket_id) WHERE (source_ticket_id IS NOT NULL);


--
-- Name: tournament_refund_entitlements_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tournament_refund_entitlements_player ON public.tournament_refund_entitlements USING btree (tournament_id, user_id, id);


--
-- Name: tournament_ticket_entry_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tournament_ticket_entry_lookup ON public.tournament_tickets USING btree (holder_id, status, redemption_mode, created_at, id) WHERE ((status = 'issued'::text) AND (redemption_mode = 'tournament_entry_only'::text));


--
-- Name: tournament_ticket_one_direct_satellite_award; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tournament_ticket_one_direct_satellite_award ON public.tournament_tickets USING btree (source_satellite_id, source_satellite_award_place) WHERE (source_satellite_award_place IS NOT NULL);


--
-- Name: tournament_ticket_one_satellite_entitlement; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX tournament_ticket_one_satellite_entitlement ON public.tournament_tickets USING btree (source_refund_entitlement_id) WHERE (source_refund_entitlement_id IS NOT NULL);


--
-- Name: tournament_unregistration_receipt_fee_reversals; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tournament_unregistration_receipt_fee_reversals ON public.tournament_unregistration_receipts USING gin (fee_reversal_ids);


--
-- Name: tournament_unregistration_receipt_fee_sources; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tournament_unregistration_receipt_fee_sources ON public.tournament_unregistration_receipts USING gin (fee_source_rake_record_ids);


--
-- Name: tournament_unregistration_receipt_replay; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tournament_unregistration_receipt_replay ON public.tournament_unregistration_receipts USING btree (tournament_id, user_id, source_table_id, settled_at DESC, registration_id);


--
-- Name: unions_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX unions_slug_key ON public.unions USING btree (slug);


--
-- Name: uniq_profiles_verified_phone; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uniq_profiles_verified_phone ON public.profiles USING btree (phone) WHERE ((phone_verified = true) AND (phone IS NOT NULL) AND (phone <> ''::text));


--
-- Name: uq_agent_commissions_source; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_agent_commissions_source ON public.agent_commissions USING btree (user_id, source_id, source_type) WHERE (source_id IS NOT NULL);


--
-- Name: uq_bbj_pools_club_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_bbj_pools_club_active ON public.bbj_pools USING btree (club_id) WHERE ((club_id IS NOT NULL) AND (status = 'active'::text));


--
-- Name: uq_bbj_pools_union_active; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_bbj_pools_union_active ON public.bbj_pools USING btree (union_id) WHERE ((club_id IS NULL) AND (union_id IS NOT NULL) AND (status = 'active'::text));


--
-- Name: uq_bbj_unclaimed_open; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_bbj_unclaimed_open ON public.bbj_unclaimed_shares USING btree (payout_id, user_id) WHERE (paid_at IS NULL);


--
-- Name: uq_hand_history_global_hand_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_hand_history_global_hand_number ON public.hand_history USING btree (hand_number) WHERE (hand_number >= 1000000);


--
-- Name: uq_profiles_player_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_profiles_player_number ON public.profiles USING btree (player_number) WHERE (player_number IS NOT NULL);


--
-- Name: uq_rake_records_hand_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_rake_records_hand_id ON public.rake_records USING btree (hand_id) WHERE (hand_id IS NOT NULL);


--
-- Name: uq_scheduled_tournament_one_live_per_occurrence; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_scheduled_tournament_one_live_per_occurrence ON public.tournaments USING btree (club_id, tournament_type, name, start_time) WHERE ((status = ANY (ARRAY['ANNOUNCED'::text, 'REGISTERING'::text])) AND (tournament_type = ANY (ARRAY['MTT'::text, 'XMTT'::text])));


--
-- Name: uq_spin_ledger_one_booking_per_game; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_spin_ledger_one_booking_per_game ON public.spin_reserve_ledger USING btree (tournament_id, kind) WHERE ((tournament_id IS NOT NULL) AND (kind = ANY (ARRAY['contribution'::text, 'jackpot_draw'::text])));


--
-- Name: uq_spin_one_contribution_reversal_per_game; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_spin_one_contribution_reversal_per_game ON public.spin_reserve_ledger USING btree (tournament_id) WHERE (kind = 'contribution_reversal'::text);


--
-- Name: uq_spin_one_draw_reversal_per_game; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_spin_one_draw_reversal_per_game ON public.spin_reserve_ledger USING btree (tournament_id) WHERE (kind = 'draw_reversal'::text);


--
-- Name: uq_tournament_bounty_award_generation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tournament_bounty_award_generation ON public.tournament_bounty_awards USING btree (bounty_obligation_id) WHERE (bounty_obligation_id IS NOT NULL);


--
-- Name: uq_tournament_bounty_award_legacy; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tournament_bounty_award_legacy ON public.tournament_bounty_awards USING btree (tournament_id, eliminated_user_id) WHERE (bounty_obligation_id IS NULL);


--
-- Name: uq_tournament_manager_wakes_pending_by_reason; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tournament_manager_wakes_pending_by_reason ON public.tournament_manager_wakes USING btree (tournament_id, reason) WHERE (consumed_at IS NULL);


--
-- Name: uq_tournament_payouts_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tournament_payouts_idempotency_key ON public.tournament_payouts USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: uq_tourney_bounty_ko_generation; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tourney_bounty_ko_generation ON public.tournament_bounties USING btree (bounty_obligation_id, collector_player_id) WHERE (bounty_obligation_id IS NOT NULL);


--
-- Name: uq_tourney_bounty_ko_legacy; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_tourney_bounty_ko_legacy ON public.tournament_bounties USING btree (tournament_id, eliminated_player_id, collector_player_id) WHERE (bounty_obligation_id IS NULL);


--
-- Name: uq_union_wallet_tx_op; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_union_wallet_tx_op ON public.union_wallet_transactions USING btree (union_id, tx_type, period_id) WHERE (period_id IS NOT NULL);


--
-- Name: INDEX uq_union_wallet_tx_op; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.uq_union_wallet_tx_op IS 'Idempotency key for union money RPCs: op_id -> period_id, retry -> unique violation -> the function answers duplicate. Deliberately NOT restricted to a list of tx_types — it was until 2026-08-24, and every new money path silently shipped without idempotency until someone remembered to edit it.';


--
-- Name: ux_ca_drift_incidents_open_dedupe; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_ca_drift_incidents_open_dedupe ON public.ca_drift_incidents USING btree (dedupe_key) WHERE (status <> 'resolved'::text);


--
-- Name: ux_ca_financial_epochs_current; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_ca_financial_epochs_current ON public.ca_financial_epochs USING btree (is_current) WHERE is_current;


--
-- Name: ux_chip_ledger_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_chip_ledger_idempotency_key ON public.chip_ledger USING btree (idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: ux_chip_transactions_idempotency_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_chip_transactions_idempotency_key ON public.chip_transactions USING btree (((metadata ->> 'idempotency_key'::text))) WHERE (metadata ? 'idempotency_key'::text);


--
-- Name: ux_tournament_obligations_place; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_tournament_obligations_place ON public.tournament_obligations USING btree (tournament_id, kind, place) WHERE (place IS NOT NULL);


--
-- Name: ux_tournament_obligations_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ux_tournament_obligations_user ON public.tournament_obligations USING btree (tournament_id, kind, user_id) WHERE (place IS NULL);


--
-- Name: users on_auth_user_created; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();


--
-- Name: users on_auth_user_created_diamonds; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created_diamonds AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.initialize_user_diamonds();


--
-- Name: users on_auth_user_created_wallet; Type: TRIGGER; Schema: auth; Owner: -
--

CREATE TRIGGER on_auth_user_created_wallet AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_v2_create_wallet();


--
-- Name: table_seats a0_tournament_live_seat_root_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER a0_tournament_live_seat_root_guard BEFORE INSERT OR UPDATE OF table_id, user_id, seat_number, left_at ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_tournament_live_seat_acquisition_requires_authority();


--
-- Name: chip_ledger aa_ca_capture_tournament_charge_entitlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_ca_capture_tournament_charge_entitlement AFTER INSERT ON public.chip_ledger FOR EACH ROW WHEN (((new.tournament_id IS NOT NULL) AND (new.from_type = 'player_wallet'::text) AND (new.to_type = 'prize_liability'::text))) EXECUTE FUNCTION public.fn_ca_capture_tournament_charge_entitlement();


--
-- Name: diamond_transactions aa_ca_diamond_journal_classifier; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_ca_diamond_journal_classifier BEFORE INSERT ON public.diamond_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_diamond_journal_classifier();


--
-- Name: tournaments aa_guard_tournament_completing_claim; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_guard_tournament_completing_claim BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_guard_tournament_completing_claim();

ALTER TABLE public.tournaments DISABLE TRIGGER aa_guard_tournament_completing_claim;


--
-- Name: engine_maintenance_break aa_serialize_maintenance_break_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_serialize_maintenance_break_write BEFORE INSERT OR DELETE OR UPDATE OR TRUNCATE ON public.engine_maintenance_break FOR EACH STATEMENT EXECUTE FUNCTION public.fn_serialize_engine_maintenance_break_write();


--
-- Name: tournament_players aa_serialize_tournament_player_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_serialize_tournament_player_insert BEFORE INSERT ON public.tournament_players FOR EACH STATEMENT EXECUTE FUNCTION public.fn_serialize_entry_statement();


--
-- Name: table_seats aa_tournament_live_seat_proof_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_tournament_live_seat_proof_lock BEFORE INSERT OR DELETE OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.trg_lock_and_validate_tournament_live_seat();


--
-- Name: tournament_players aa_tournament_player_launch_proof_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_tournament_player_launch_proof_lock BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.trg_lock_tournament_player_launch_proof();


--
-- Name: tables aa_tournament_table_launch_proof_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aa_tournament_table_launch_proof_lock BEFORE INSERT OR DELETE OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.trg_lock_and_classify_tournament_table();


--
-- Name: tournaments aaa_guard_atomic_satellite_completion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aaa_guard_atomic_satellite_completion BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.trg_guard_atomic_satellite_completion();

ALTER TABLE public.tournaments DISABLE TRIGGER aaa_guard_atomic_satellite_completion;


--
-- Name: table_seats ab_refuse_live_seat_on_closed_tournament_table; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ab_refuse_live_seat_on_closed_tournament_table BEFORE INSERT OR UPDATE OF table_id, user_id, left_at ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.trg_refuse_live_seat_on_closed_tournament_table();


--
-- Name: tables ab_tournament_table_close_requires_empty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ab_tournament_table_close_requires_empty BEFORE UPDATE OF status, is_deleted ON public.tables FOR EACH ROW EXECUTE FUNCTION public.trg_tournament_table_close_requires_empty();


--
-- Name: wallet_transactions ca_legacy_round3_wallet_receipt; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_legacy_round3_wallet_receipt BEFORE INSERT ON public.wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_legacy_round3_wallet_receipt();


--
-- Name: rake_records ca_reporting_rake_change_del; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_reporting_rake_change_del AFTER DELETE ON public.rake_records REFERENCING OLD TABLE AS old_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_ca_reporting_repair_changed_days();


--
-- Name: rake_records ca_reporting_rake_change_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_reporting_rake_change_upd AFTER UPDATE ON public.rake_records REFERENCING OLD TABLE AS old_rows NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_ca_reporting_repair_changed_days();


--
-- Name: rake_records ca_reporting_rake_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_reporting_rake_insert AFTER INSERT ON public.rake_records FOR EACH ROW EXECUTE FUNCTION public.trg_ca_reporting_rake_insert();


--
-- Name: wallet_transactions ca_reporting_wallet_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_reporting_wallet_change AFTER DELETE OR UPDATE OF user_id, amount, type, category, table_id, related_entity_id, created_at ON public.wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.trg_ca_reporting_follows_a_changed_fact();


--
-- Name: TRIGGER ca_reporting_wallet_change ON wallet_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER ca_reporting_wallet_change ON public.wallet_transactions IS 'Rebuilds the Club Data rollups for a changed day. Fires on DELETE and on UPDATE of a fact column only; a marker stamp (terminal_closed_at) never rebuilds a day.';


--
-- Name: wallet_transactions ca_reporting_wallet_change_del; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_reporting_wallet_change_del AFTER DELETE ON public.wallet_transactions REFERENCING OLD TABLE AS old_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_ca_reporting_repair_changed_days();


--
-- Name: wallet_transactions ca_reporting_wallet_change_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_reporting_wallet_change_upd AFTER UPDATE ON public.wallet_transactions REFERENCING OLD TABLE AS old_rows NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_ca_reporting_repair_changed_days();


--
-- Name: wallet_transactions ca_reporting_wallet_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER ca_reporting_wallet_insert AFTER INSERT ON public.wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.trg_ca_reporting_wallet_insert();


--
-- Name: chip_ledger cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: rake_records cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.rake_records FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: spin_reserve_ledger cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.spin_reserve_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tables cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_escrow cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_escrow FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_guarantee_overlays cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_guarantee_overlays FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_obligations cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_obligations FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_payouts cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_payouts FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_players cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_rake_settlements cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_rake_settlements FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_refund_entitlements cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_refund_entitlements FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_refund_tranches cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_refund_tranches FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournament_spin_cancellation_unwinds cancelled_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_spin_cancellation_unwinds FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_evidence_is_immutable();


--
-- Name: tournaments cancelled_tournament_parent_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_parent_is_immutable BEFORE DELETE OR UPDATE OF status, variant, tournament_type, satellite_target_id, satellite_target, satellite_seats, prize_pool, prize_pool_finalized, bounty_pool, bounty_pool_paid, is_bounty, is_pko, is_mystery_bounty, mystery_bounty_stage, mystery_bounty_pool_cents, club_id, ended_at, total_rake, current_players, on_break, break_started_at, break_ends_at ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_parent_is_immutable();


--
-- Name: table_seats cancelled_tournament_seat_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_seat_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_seat_is_immutable();


--
-- Name: wallet_transactions cancelled_tournament_wallet_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cancelled_tournament_wallet_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_cancelled_tournament_wallet_is_immutable();


--
-- Name: push_outbox claim_tournament_reminder_before_enqueue; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER claim_tournament_reminder_before_enqueue BEFORE INSERT ON public.push_outbox FOR EACH ROW WHEN ((new.event = ANY (ARRAY['tournament_reminder_15m'::text, 'tournament_reminder_2m'::text]))) EXECUTE FUNCTION public.trg_claim_tournament_reminder();


--
-- Name: engine_recovery_events classify_engine_recovery_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER classify_engine_recovery_event BEFORE INSERT ON public.engine_recovery_events FOR EACH ROW EXECUTE FUNCTION public.fn_classify_engine_recovery_event();


--
-- Name: club_members club_members_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER club_members_updated_at BEFORE UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: clubs clubs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER clubs_updated_at BEFORE UPDATE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: agents guard_agent_wallet_direct_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER guard_agent_wallet_direct_update BEFORE INSERT OR UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.guard_agent_wallet_direct_update();


--
-- Name: hand_history hand_history_club_member_stats; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER hand_history_club_member_stats AFTER INSERT ON public.hand_history FOR EACH ROW EXECUTE FUNCTION public.trg_hand_history_club_member_stats();


--
-- Name: hand_history hand_history_fold_stats; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER hand_history_fold_stats AFTER INSERT ON public.hand_history FOR EACH ROW EXECUTE FUNCTION public.fn_fold_hand_winnings();


--
-- Name: hand_history hand_history_position_stats; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER hand_history_position_stats AFTER INSERT ON public.hand_history FOR EACH ROW EXECUTE FUNCTION public.trg_hand_history_position_stats();


--
-- Name: club_members lock_cashier_hierarchy_insert_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER lock_cashier_hierarchy_insert_delete BEFORE INSERT OR DELETE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.lock_club_cashier_hierarchy_mutation();


--
-- Name: club_members lock_cashier_hierarchy_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER lock_cashier_hierarchy_update BEFORE UPDATE OF club_id, agent_id, role, status ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.lock_club_cashier_hierarchy_mutation();


--
-- Name: tournaments non_satellite_completed_requires_terminal_receipt; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER non_satellite_completed_requires_terminal_receipt AFTER INSERT OR UPDATE OF status ON public.tournaments DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.fn_non_satellite_completed_requires_terminal_receipt();


--
-- Name: table_seats poker_arena_chip_seat_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_chip_seat_guard BEFORE INSERT OR UPDATE OF table_id ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_poker_guard_chip_seat();


--
-- Name: clubs poker_arena_identity_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_identity_guard BEFORE INSERT OR UPDATE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_poker_guard_arena_structure();


--
-- Name: club_members poker_arena_membership_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_membership_guard BEFORE INSERT OR UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_poker_guard_arena_structure();


--
-- Name: agent_commission_settlements poker_arena_no_hierarchy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_no_hierarchy BEFORE INSERT OR UPDATE ON public.agent_commission_settlements FOR EACH ROW EXECUTE FUNCTION public.fn_poker_reject_diamond_hierarchy();


--
-- Name: agent_commissions poker_arena_no_hierarchy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_no_hierarchy BEFORE INSERT OR UPDATE ON public.agent_commissions FOR EACH ROW EXECUTE FUNCTION public.fn_poker_reject_diamond_hierarchy();


--
-- Name: agents poker_arena_no_hierarchy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_no_hierarchy BEFORE INSERT OR UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.fn_poker_reject_diamond_hierarchy();


--
-- Name: ca_club_commission_daily poker_arena_no_hierarchy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_no_hierarchy BEFORE INSERT OR UPDATE ON public.ca_club_commission_daily FOR EACH ROW EXECUTE FUNCTION public.fn_poker_reject_diamond_hierarchy();


--
-- Name: tables poker_arena_table_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_table_guard BEFORE INSERT OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_poker_guard_arena_structure();


--
-- Name: tournaments poker_arena_tournament_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_tournament_guard BEFORE INSERT OR UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_poker_guard_arena_structure();


--
-- Name: union_clubs poker_arena_union_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_arena_union_guard BEFORE INSERT OR UPDATE ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_poker_guard_arena_structure();


--
-- Name: table_seats poker_bind_diamond_seat; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER poker_bind_diamond_seat AFTER INSERT ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_poker_bind_diamond_seat();


--
-- Name: tournaments receipted_tournament_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER receipted_tournament_is_immutable BEFORE DELETE OR UPDATE OF status, variant, tournament_type, satellite_target_id, satellite_target, satellite_seats, prize_pool, prize_pool_finalized, bounty_pool, bounty_pool_paid, is_bounty, is_pko, is_mystery_bounty, mystery_bounty_stage, mystery_bounty_pool_cents, club_id, ended_at, current_players, on_break, break_started_at, break_ends_at ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_receipted_tournament_is_immutable();


--
-- Name: tournaments satellite_target_contract_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER satellite_target_contract_is_immutable BEFORE UPDATE OF buy_in_amount, buy_in_fee, bounty_amount, rebuy_cost, addon_cost, is_bounty, is_pko, is_mystery_bounty, is_premium_spin, variant, tournament_type, club_id, entry_contract_locked ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_target_contract_is_immutable();


--
-- Name: tournament_players satellite_target_player_provenance_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER satellite_target_player_provenance_is_immutable BEFORE INSERT OR DELETE OR UPDATE OF id, tournament_id, user_id, is_satellite_qualifier, source_satellite_id ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_target_player_provenance_is_immutable();


--
-- Name: rake_records satellite_target_rake_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER satellite_target_rake_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.rake_records FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_target_rake_is_immutable();


--
-- Name: chip_ledger satellite_transfer_ledger_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER satellite_transfer_ledger_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_transfer_ledger_is_immutable();


--
-- Name: tournament_players seed_bounty_head; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER seed_bounty_head AFTER INSERT ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.trg_seed_bounty_head();


--
-- Name: spin_draw_receipts spin_draw_receipt_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER spin_draw_receipt_is_immutable BEFORE DELETE OR UPDATE ON public.spin_draw_receipts FOR EACH ROW EXECUTE FUNCTION public.trg_spin_draw_receipt_is_immutable();


--
-- Name: spin_reserve_ledger spin_reserve_receipt_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER spin_reserve_receipt_is_immutable BEFORE DELETE OR UPDATE ON public.spin_reserve_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_spin_reserve_receipt_is_immutable();


--
-- Name: spin_reserve_ledger spin_reserve_row_requires_exact_journal; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER spin_reserve_row_requires_exact_journal BEFORE INSERT ON public.spin_reserve_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_spin_reserve_row_requires_exact_journal();


--
-- Name: tournaments spin_tournament_contract_is_draw; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER spin_tournament_contract_is_draw BEFORE UPDATE OF spin_multiplier, prize_pool, spin_locked_tiers ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_spin_tournament_contract_is_draw();


--
-- Name: tournaments stamp_tournament_terminal_evidence_markers; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stamp_tournament_terminal_evidence_markers AFTER INSERT OR UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_tournament_terminal_evidence_markers();


--
-- Name: tables tables_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tables_updated_at BEFORE UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tournament_bounty_award_recipients terminal_bounty_recipient_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_bounty_recipient_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_bounty_award_recipients FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_bounty_recipient_is_immutable();


--
-- Name: wallet_credit_idempotency terminal_credit_key_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_credit_key_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.wallet_credit_idempotency FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_credit_key_is_immutable();


--
-- Name: tournament_escrow terminal_tournament_escrow_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_escrow_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_escrow FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_escrow_is_immutable();


--
-- Name: chip_ledger terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: rake_records terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.rake_records FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: spin_reserve_ledger terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.spin_reserve_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_bounty_awards terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_bounty_awards FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_bounty_chests terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_bounty_chests FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_guarantee_overlays terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_guarantee_overlays FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_obligations terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_obligations FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_payouts terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_payouts FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_players terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_rake_settlements terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_rake_settlements FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_refund_entitlements terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_refund_entitlements FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_refund_tranches terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_refund_tranches FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_satellite_awards terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_satellite_awards FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_spin_cancellation_unwinds terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_spin_cancellation_unwinds FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: table_seats terminal_tournament_seat_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_seat_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_seat_is_immutable();


--
-- Name: wallet_transactions terminal_wallet_transaction_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_wallet_transaction_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_wallet_transaction_is_immutable();


--
-- Name: tournament_cancellation_receipts tournament_cancellation_receipts_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_cancellation_receipts_append_only BEFORE DELETE OR UPDATE ON public.tournament_cancellation_receipts FOR EACH ROW EXECUTE FUNCTION public.fn_tournament_cancellation_receipts_append_only();


--
-- Name: tournaments tournament_completed_stats; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_completed_stats AFTER UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.trg_tournament_completed_stats();


--
-- Name: tournament_players tournament_elimination_has_a_place; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournament_elimination_has_a_place AFTER INSERT OR UPDATE OF status, "position" ON public.tournament_players DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.fn_tournament_elimination_has_a_place();


--
-- Name: tournament_launch_receipts tournament_launch_receipt_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_launch_receipt_is_immutable BEFORE DELETE OR UPDATE ON public.tournament_launch_receipts FOR EACH ROW EXECUTE FUNCTION public.trg_tournament_launch_receipt_is_immutable();


--
-- Name: table_seats tournament_live_seat_has_active_roster; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournament_live_seat_has_active_roster AFTER INSERT ON public.table_seats DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.trg_assert_live_tournament_seat_has_roster();


--
-- Name: table_seats tournament_live_seat_update_has_active_roster; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournament_live_seat_update_has_active_roster AFTER UPDATE OF table_id, user_id, left_at ON public.table_seats DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.trg_assert_live_tournament_seat_has_roster();


--
-- Name: tournament_players tournament_place_collision_watch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_place_collision_watch BEFORE INSERT OR UPDATE OF "position" ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.trg_tournament_place_collision();


--
-- Name: tournament_players tournament_player_name; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_player_name BEFORE INSERT ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.trg_tournament_player_name();


--
-- Name: tournament_refund_entitlements tournament_refund_entitlement_commit_valid; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournament_refund_entitlement_commit_valid AFTER INSERT ON public.tournament_refund_entitlements DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.fn_ca_refund_entitlement_commit_valid();


--
-- Name: tournament_refund_entitlements tournament_refund_entitlement_locks_parent_contract; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_refund_entitlement_locks_parent_contract AFTER INSERT ON public.tournament_refund_entitlements FOR EACH ROW EXECUTE FUNCTION public.fn_ca_lock_tournament_contract_from_entitlement();


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_refund_entitlements_append_only BEFORE DELETE OR UPDATE ON public.tournament_refund_entitlements FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_settlement_receipts_are_append_only();


--
-- Name: tournament_refund_tranches tournament_refund_tranches_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_refund_tranches_append_only BEFORE DELETE OR UPDATE ON public.tournament_refund_tranches FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_settlement_receipts_are_append_only();


--
-- Name: tournament_players tournament_roster_cannot_orphan_live_seat; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournament_roster_cannot_orphan_live_seat AFTER DELETE ON public.tournament_players DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.trg_assert_live_tournament_seat_has_roster();


--
-- Name: tournament_players tournament_roster_update_cannot_orphan_live_seat; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournament_roster_update_cannot_orphan_live_seat AFTER UPDATE OF tournament_id, user_id, status ON public.tournament_players DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.trg_assert_live_tournament_seat_has_roster();


--
-- Name: tournament_satellite_awards tournament_satellite_award_captures_refund_entitlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_satellite_award_captures_refund_entitlement AFTER INSERT ON public.tournament_satellite_awards FOR EACH ROW WHEN ((new.delivery_kind = 'seat'::text)) EXECUTE FUNCTION public.fn_ca_capture_satellite_seat_entitlement();


--
-- Name: tournament_satellite_awards tournament_satellite_awards_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_satellite_awards_append_only BEFORE DELETE OR UPDATE ON public.tournament_satellite_awards FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_settlement_receipts_are_append_only();


--
-- Name: tournament_tickets tournament_satellite_entry_ticket_is_guarded; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_satellite_entry_ticket_is_guarded BEFORE DELETE OR UPDATE ON public.tournament_tickets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_satellite_entry_ticket_is_guarded();


--
-- Name: tournament_satellite_settlements tournament_satellite_settlements_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_satellite_settlements_append_only BEFORE DELETE OR UPDATE ON public.tournament_satellite_settlements FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_settlement_receipts_are_append_only();


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_spin_cancellation_unwinds_append_only BEFORE DELETE OR UPDATE ON public.tournament_spin_cancellation_unwinds FOR EACH ROW EXECUTE FUNCTION public.fn_tournament_cancellation_receipts_append_only();


--
-- Name: tournaments tournament_start_time_locked_during_launch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_start_time_locked_during_launch BEFORE UPDATE OF start_time ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.trg_lock_tournament_start_time_during_launch();


--
-- Name: tournament_table_origins tournament_table_origin_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_table_origin_is_immutable BEFORE UPDATE ON public.tournament_table_origins FOR EACH ROW EXECUTE FUNCTION public.trg_tournament_table_origin_is_immutable();


--
-- Name: tournament_table_origins tournament_table_origin_is_proven; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournament_table_origin_is_proven AFTER INSERT ON public.tournament_table_origins DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.trg_validate_tournament_table_origin();


--
-- Name: tables tournament_table_terminal_close_is_irreversible; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_table_terminal_close_is_irreversible BEFORE INSERT OR DELETE OR UPDATE OF id, tournament_id, status, current_players, lifecycle, terminal_closed_at ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_tournament_table_terminal_close_is_irreversible();


--
-- Name: tournament_terminal_settlements tournament_terminal_settlements_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_terminal_settlements_append_only BEFORE DELETE OR UPDATE ON public.tournament_terminal_settlements FOR EACH ROW EXECUTE FUNCTION public.fn_tournament_terminal_receipts_are_append_only();


--
-- Name: rake_records tournament_unregistration_rake_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_unregistration_rake_evidence_is_immutable BEFORE DELETE OR UPDATE ON public.rake_records FOR EACH ROW EXECUTE FUNCTION public.fn_ca_unregistration_rake_evidence_is_immutable();


--
-- Name: tournament_unregistration_receipts tournament_unregistration_receipts_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_unregistration_receipts_append_only BEFORE DELETE OR UPDATE ON public.tournament_unregistration_receipts FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_settlement_receipts_are_append_only();


--
-- Name: tournaments tournaments_cancel_must_refund; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER tournaments_cancel_must_refund AFTER UPDATE ON public.tournaments DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((upper(COALESCE(new.status, ''::text)) = ANY (ARRAY['CANCELLED'::text, 'CANCELED'::text])) AND (upper(COALESCE(old.status, ''::text)) IS DISTINCT FROM upper(COALESCE(new.status, ''::text))))) EXECUTE FUNCTION public.trg_tournaments_cancel_must_refund();


--
-- Name: tournaments tournaments_creation_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournaments_creation_guard BEFORE INSERT ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_tournaments_creation_guard();


--
-- Name: tournaments tournaments_guarantee_affordable_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournaments_guarantee_affordable_ins BEFORE INSERT ON public.tournaments FOR EACH ROW WHEN ((COALESCE(new.guaranteed_prize, (0)::numeric) > (0)::numeric)) EXECUTE FUNCTION public.trg_tournaments_guarantee_affordable();


--
-- Name: tournaments tournaments_guarantee_affordable_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournaments_guarantee_affordable_upd BEFORE UPDATE ON public.tournaments FOR EACH ROW WHEN (((COALESCE(new.guaranteed_prize, (0)::numeric) > (0)::numeric) AND (new.guaranteed_prize IS DISTINCT FROM old.guaranteed_prize))) EXECUTE FUNCTION public.trg_tournaments_guarantee_affordable();


--
-- Name: tournaments tournaments_rank_before_complete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournaments_rank_before_complete BEFORE UPDATE ON public.tournaments FOR EACH ROW WHEN (((new.status = 'COMPLETED'::text) AND (old.status IS DISTINCT FROM 'COMPLETED'::text))) EXECUTE FUNCTION public.trg_tournaments_rank_before_complete();


--
-- Name: tournaments tournaments_short_formats_never_break; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournaments_short_formats_never_break BEFORE INSERT OR UPDATE OF tournament_type, variant, synchronized_breaks ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_short_formats_never_break();


--
-- Name: tournaments tournaments_spin_completed_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournaments_spin_completed_guard BEFORE UPDATE ON public.tournaments FOR EACH ROW WHEN (((new.status = 'COMPLETED'::text) AND (old.status IS DISTINCT FROM 'COMPLETED'::text))) EXECUTE FUNCTION public.trg_spin_completed_guard();


--
-- Name: profiles tr_generate_referral_code; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tr_generate_referral_code BEFORE INSERT ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.generate_referral_code();


--
-- Name: cashout_requests tr_notify_agent_on_cashout; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tr_notify_agent_on_cashout AFTER INSERT ON public.cashout_requests FOR EACH ROW WHEN ((new.status = 'pending'::text)) EXECUTE FUNCTION public.fn_notify_agent_on_cashout();


--
-- Name: profiles trg_a_benched_horse_stays_benched; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_a_benched_horse_stays_benched BEFORE UPDATE OF horse_status ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_a_benched_horse_stays_benched();


--
-- Name: profiles trg_aa_diamond_balance_mirrors_canonical; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_aa_diamond_balance_mirrors_canonical BEFORE INSERT OR UPDATE OF diamonds, diamond_balance ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_diamond_balance_mirrors_canonical();


--
-- Name: tournament_bounty_awards trg_ack_bounty_obligation_from_award; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ack_bounty_obligation_from_award AFTER INSERT OR UPDATE OF status ON public.tournament_bounty_awards FOR EACH ROW EXECUTE FUNCTION public.fn_ack_bounty_obligation_from_award();


--
-- Name: tournament_bounties trg_ack_bounty_obligation_from_ledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ack_bounty_obligation_from_ledger AFTER INSERT ON public.tournament_bounties FOR EACH ROW EXECUTE FUNCTION public.fn_ack_bounty_obligation_from_ledger();


--
-- Name: club_members trg_admin_holds_no_player_wallet; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_admin_holds_no_player_wallet BEFORE INSERT OR UPDATE OF role, chip_balance ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_admin_holds_no_player_wallet();


--
-- Name: agent_commissions trg_agent_commission_rollup_del; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_agent_commission_rollup_del AFTER DELETE ON public.agent_commissions REFERENCING OLD TABLE AS old_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_agent_commission_rollup_change();


--
-- Name: agent_commissions trg_agent_commission_rollup_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_agent_commission_rollup_ins AFTER INSERT ON public.agent_commissions REFERENCING NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_agent_commission_rollup_insert();


--
-- Name: agent_commissions trg_agent_commission_rollup_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_agent_commission_rollup_upd AFTER UPDATE ON public.agent_commissions REFERENCING OLD TABLE AS old_rows NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_agent_commission_rollup_change();


--
-- Name: agents trg_agents_commission_bounds; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_agents_commission_bounds BEFORE INSERT OR UPDATE OF commission_rate ON public.agents FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_agent_commission_bounds();


--
-- Name: agents trg_agents_human_user_club_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_agents_human_user_club_only BEFORE INSERT OR UPDATE OF club_id, user_id ON public.agents FOR EACH ROW EXECUTE FUNCTION public.fn_ca_reject_automated_user_club_row();


--
-- Name: agents trg_agents_staff_earn_no_rakeback; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_agents_staff_earn_no_rakeback BEFORE INSERT OR UPDATE OF role, commission_rate, player_rakeback_rate ON public.agents FOR EACH ROW WHEN (((COALESCE(new.commission_rate, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.player_rakeback_rate, (0)::numeric) <> (0)::numeric))) EXECUTE FUNCTION public.fn_agents_staff_earn_no_rakeback();


--
-- Name: club_members trg_approval_gate_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_approval_gate_ins BEFORE INSERT ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_membership_approval_gate();


--
-- Name: club_members trg_approval_gate_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_approval_gate_upd BEFORE UPDATE OF status ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_membership_approval_gate();


--
-- Name: tournament_bounty_awards trg_attach_bounty_award_obligation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_attach_bounty_award_obligation BEFORE INSERT ON public.tournament_bounty_awards FOR EACH ROW EXECUTE FUNCTION public.fn_attach_bounty_award_obligation();


--
-- Name: tournament_bounties trg_attach_bounty_ledger_obligation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_attach_bounty_ledger_obligation BEFORE INSERT ON public.tournament_bounties FOR EACH ROW EXECUTE FUNCTION public.fn_attach_bounty_ledger_obligation();


--
-- Name: clubs trg_audit_club_created; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_club_created AFTER INSERT ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_audit_club_entry_mutation();


--
-- Name: clubs trg_audit_club_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_club_delete BEFORE DELETE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_audit_club_delete();


--
-- Name: club_members trg_audit_club_join; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_club_join AFTER INSERT OR UPDATE OF status ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_audit_club_entry_mutation();


--
-- Name: club_members trg_audit_club_member_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_club_member_delete AFTER DELETE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_audit_club_member_change();


--
-- Name: club_members trg_audit_club_member_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_club_member_update AFTER UPDATE OF role, status ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_audit_club_member_change();


--
-- Name: clubs trg_audit_club_settings; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_audit_club_settings AFTER UPDATE ON public.clubs FOR EACH ROW WHEN (((old.name IS DISTINCT FROM new.name) OR (old.description IS DISTINCT FROM new.description) OR (old.is_public IS DISTINCT FROM new.is_public) OR (old.requires_approval IS DISTINCT FROM new.requires_approval) OR (old.default_rake_percent IS DISTINCT FROM new.default_rake_percent) OR (old.rake_cap IS DISTINCT FROM new.rake_cap) OR (old.allow_straddle IS DISTINCT FROM new.allow_straddle) OR (old.allow_run_it_twice IS DISTINCT FROM new.allow_run_it_twice) OR (old.allow_rabbit_hunt IS DISTINCT FROM new.allow_rabbit_hunt) OR (old.min_buyin_bb IS DISTINCT FROM new.min_buyin_bb) OR (old.max_buyin_bb IS DISTINCT FROM new.max_buyin_bb) OR (old.logo_url IS DISTINCT FROM new.logo_url) OR (old.bbj_rake_enabled IS DISTINCT FROM new.bbj_rake_enabled) OR (old.spins_enabled IS DISTINCT FROM new.spins_enabled) OR (old.spins_preseed_amount IS DISTINCT FROM new.spins_preseed_amount) OR (old.spins_wallet_funding IS DISTINCT FROM new.spins_wallet_funding))) EXECUTE FUNCTION public.fn_audit_club_settings_change();


--
-- Name: profiles trg_auto_connect_dan; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_auto_connect_dan AFTER INSERT ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.auto_connect_to_dan_bekavac();


--
-- Name: clubs trg_autocreate_club_social_page; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_autocreate_club_social_page AFTER INSERT ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.trg_fn_autocreate_club_social_page();


--
-- Name: social_follows trg_award_follow; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_award_follow AFTER INSERT ON public.social_follows FOR EACH ROW EXECUTE FUNCTION public.trgfn_award_follow();


--
-- Name: rake_records trg_award_vip_points_from_rake; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_award_vip_points_from_rake AFTER INSERT ON public.rake_records FOR EACH ROW EXECUTE FUNCTION public.fn_award_vip_points_from_rake();


--
-- Name: bbj_payouts trg_bbj_payouts_delete_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_bbj_payouts_delete_guard BEFORE DELETE ON public.bbj_payouts FOR EACH ROW EXECUTE FUNCTION public.fn_bbj_ledger_delete_guard();


--
-- Name: club_members trg_block_browser_balance_inserts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_block_browser_balance_inserts BEFORE INSERT ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_block_browser_balance_inserts();


--
-- Name: club_members trg_block_browser_balance_writes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_block_browser_balance_writes BEFORE UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_block_browser_balance_writes();


--
-- Name: clubs trg_block_browser_treasury_writes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_block_browser_treasury_writes BEFORE UPDATE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_block_browser_balance_writes();


--
-- Name: tournament_bounty_awards trg_bounty_award_has_recipients; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER trg_bounty_award_has_recipients AFTER INSERT ON public.tournament_bounty_awards DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.fn_assert_bounty_award_has_recipients();


--
-- Name: agent_commissions trg_ca_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_append_only BEFORE DELETE OR UPDATE ON public.agent_commissions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_append_only();


--
-- Name: chip_ledger trg_ca_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_append_only BEFORE DELETE OR UPDATE ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_append_only();


--
-- Name: chip_transactions trg_ca_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_append_only BEFORE DELETE OR UPDATE ON public.chip_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_append_only();


--
-- Name: diamond_transactions trg_ca_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_append_only BEFORE DELETE OR UPDATE ON public.diamond_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_append_only();


--
-- Name: union_wallet_transactions trg_ca_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_append_only BEFORE DELETE OR UPDATE ON public.union_wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_append_only();


--
-- Name: vip_points_ledger trg_ca_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_append_only BEFORE DELETE OR UPDATE ON public.vip_points_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_append_only();


--
-- Name: wallet_transactions trg_ca_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_append_only BEFORE DELETE OR UPDATE ON public.wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_append_only();


--
-- Name: table_seats trg_ca_arena_seat_is_same_asset; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_arena_seat_is_same_asset AFTER INSERT ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_ca_arena_seat_is_same_asset();


--
-- Name: agents trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER UPDATE OF agent_wallet_balance, promo_wallet_balance ON public.agents FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('agent_wallet_balance=agent_wallet', 'promo_wallet_balance=promo_wallet');


--
-- Name: bbj_pools trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER INSERT OR UPDATE OF main_balance, backup_balance, promo_balance ON public.bbj_pools FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('main_balance=bbj_pool', 'backup_balance=bbj_pool', 'promo_balance=bbj_pool');


--
-- Name: club_members trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER UPDATE OF promo_balance ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('promo_balance=promo_wallet');


--
-- Name: club_wallets trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER INSERT OR UPDATE OF chip_balance, insurance_balance ON public.club_wallets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('chip_balance=club_wallet', 'insurance_balance=insurance_bank');


--
-- Name: clubs trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER INSERT OR UPDATE OF chip_treasury, chip_pool, promo_balance, insurance_balance ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('chip_treasury=club_treasury', 'chip_pool=club_treasury', 'promo_balance=promo_wallet', 'insurance_balance=insurance_bank');


--
-- Name: spin_bonus_pools trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER INSERT OR UPDATE OF balance ON public.spin_bonus_pools FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('balance=spin_reserve');


--
-- Name: union_wallets trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER INSERT OR UPDATE OF chip_balance, rake_wallet, bbj_wallet, promo_wallet, insurance_wallet, spin_reserve_wallet ON public.union_wallets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('chip_balance=union_bank', 'rake_wallet=union_wallet', 'bbj_wallet=union_wallet', 'promo_wallet=union_wallet', 'insurance_wallet=union_wallet', 'spin_reserve_wallet=union_wallet');


--
-- Name: unions trg_ca_autoledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger AFTER UPDATE OF chip_balance, rake_wallet, main_bbj_balance, backup_bbj_balance, promo_fund_balance, insurance_balance ON public.unions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger('chip_balance=union_bank', 'rake_wallet=union_wallet', 'main_bbj_balance=bbj_pool', 'backup_bbj_balance=bbj_pool', 'promo_fund_balance=promo_wallet', 'insurance_balance=insurance_bank');


--
-- Name: agents trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('agent_wallet_balance=agent_wallet', 'promo_wallet_balance=promo_wallet');


--
-- Name: bbj_pools trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.bbj_pools FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('main_balance=bbj_pool', 'backup_balance=bbj_pool', 'promo_balance=bbj_pool');


--
-- Name: club_members trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('chip_balance=player_wallet', 'promo_balance=promo_wallet');


--
-- Name: club_wallets trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.club_wallets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('chip_balance=club_wallet', 'insurance_balance=insurance_bank');


--
-- Name: clubs trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('chip_treasury=club_treasury', 'chip_pool=club_treasury', 'promo_balance=promo_wallet', 'insurance_balance=insurance_bank');


--
-- Name: spin_bonus_pools trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.spin_bonus_pools FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('balance=spin_reserve');


--
-- Name: union_wallets trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.union_wallets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('chip_balance=union_bank', 'rake_wallet=union_wallet', 'bbj_wallet=union_wallet', 'promo_wallet=union_wallet', 'insurance_wallet=union_wallet', 'spin_reserve_wallet=union_wallet');


--
-- Name: unions trg_ca_autoledger_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_delete BEFORE DELETE ON public.unions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_autoledger_delete('chip_balance=union_bank', 'rake_wallet=union_wallet', 'main_bbj_balance=bbj_pool', 'backup_bbj_balance=bbj_pool', 'promo_fund_balance=promo_wallet', 'insurance_balance=insurance_bank');


--
-- Name: agents trg_ca_autoledger_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_insert AFTER INSERT ON public.agents FOR EACH ROW WHEN (((COALESCE(new.agent_wallet_balance, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.promo_wallet_balance, (0)::numeric) <> (0)::numeric))) EXECUTE FUNCTION public.fn_ca_autoledger('agent_wallet_balance=agent_wallet', 'promo_wallet_balance=promo_wallet');


--
-- Name: club_members trg_ca_autoledger_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_insert AFTER INSERT ON public.club_members FOR EACH ROW WHEN (((COALESCE(new.chip_balance, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.promo_balance, (0)::numeric) <> (0)::numeric))) EXECUTE FUNCTION public.fn_ca_autoledger('chip_balance=player_wallet', 'promo_balance=promo_wallet');


--
-- Name: unions trg_ca_autoledger_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_autoledger_insert AFTER INSERT ON public.unions FOR EACH ROW WHEN (((COALESCE(new.chip_balance, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.rake_wallet, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.main_bbj_balance, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.backup_bbj_balance, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.promo_fund_balance, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.insurance_balance, (0)::numeric) <> (0)::numeric))) EXECUTE FUNCTION public.fn_ca_autoledger('chip_balance=union_bank', 'rake_wallet=union_wallet', 'main_bbj_balance=bbj_pool', 'backup_bbj_balance=bbj_pool', 'promo_fund_balance=promo_wallet', 'insurance_balance=insurance_bank');


--
-- Name: bbj_pools trg_ca_block_browser; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_block_browser BEFORE INSERT OR DELETE OR UPDATE ON public.bbj_pools FOR EACH ROW EXECUTE FUNCTION public.fn_ca_block_browser_money_table();


--
-- Name: club_wallets trg_ca_block_browser; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_block_browser BEFORE INSERT OR DELETE OR UPDATE ON public.club_wallets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_block_browser_money_table();


--
-- Name: spin_bonus_pools trg_ca_block_browser; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_block_browser BEFORE INSERT OR DELETE OR UPDATE ON public.spin_bonus_pools FOR EACH ROW EXECUTE FUNCTION public.fn_ca_block_browser_money_table();


--
-- Name: union_wallets trg_ca_block_browser; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_block_browser BEFORE INSERT OR DELETE OR UPDATE ON public.union_wallets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_block_browser_money_table();


--
-- Name: hand_history trg_ca_capture_hand_facts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_capture_hand_facts BEFORE DELETE ON public.hand_history FOR EACH ROW EXECUTE FUNCTION public.fn_ca_capture_hand_facts();


--
-- Name: chip_ledger trg_ca_chip_ledger_enrich; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_chip_ledger_enrich BEFORE INSERT ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_ca_chip_ledger_enrich();


--
-- Name: clubs trg_ca_club_gets_a_baseline; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_club_gets_a_baseline AFTER INSERT ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_ca_club_gets_a_baseline();


--
-- Name: rake_records trg_ca_club_rake_daily_del; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_club_rake_daily_del AFTER DELETE ON public.rake_records REFERENCING OLD TABLE AS old_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_ca_club_rake_daily_change();


--
-- Name: rake_records trg_ca_club_rake_daily_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_club_rake_daily_ins AFTER INSERT ON public.rake_records REFERENCING NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_ca_club_rake_daily_insert();


--
-- Name: rake_records trg_ca_club_rake_daily_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_club_rake_daily_upd AFTER UPDATE ON public.rake_records REFERENCING OLD TABLE AS old_rows NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION public.trg_ca_club_rake_daily_change();


--
-- Name: diamond_transactions trg_ca_diamond_earn_ledger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_diamond_earn_ledger AFTER INSERT ON public.diamond_transactions FOR EACH ROW WHEN ((new.amount > 0)) EXECUTE FUNCTION public.fn_ca_diamond_earn_ledger();


--
-- Name: diamond_transactions trg_ca_diamond_register_follows_journal; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_diamond_register_follows_journal AFTER INSERT ON public.diamond_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_ca_diamond_register_follows_journal();


--
-- Name: diamond_reward_catalog trg_ca_diamond_reward_catalog_history; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_diamond_reward_catalog_history AFTER INSERT OR DELETE OR UPDATE ON public.diamond_reward_catalog FOR EACH ROW EXECUTE FUNCTION public.fn_ca_diamond_catalog_history();


--
-- Name: financial_alerts trg_ca_financial_alert_incident; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_financial_alert_incident AFTER INSERT ON public.financial_alerts FOR EACH ROW EXECUTE FUNCTION public.fn_ca_financial_alert_to_incident();


--
-- Name: table_seats trg_ca_guard_seat_creation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_guard_seat_creation BEFORE INSERT OR UPDATE OF left_at ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_ca_guard_seat_creation();


--
-- Name: ca_incident_events trg_ca_incident_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_incident_events_append_only BEFORE DELETE OR UPDATE ON public.ca_incident_events FOR EACH ROW EXECUTE FUNCTION public.fn_ca_incident_events_append_only();


--
-- Name: ca_drift_incidents trg_ca_incidents_stay_in_midway; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_incidents_stay_in_midway BEFORE INSERT ON public.ca_drift_incidents FOR EACH ROW EXECUTE FUNCTION public.fn_ca_incidents_stay_in_midway();


--
-- Name: ca_mint_ledger trg_ca_mint_register_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_mint_register_append_only BEFORE DELETE OR UPDATE ON public.ca_mint_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_ca_mint_register_append_only();


--
-- Name: wallet_transactions trg_ca_money_path_log; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_money_path_log AFTER INSERT ON public.wallet_transactions FOR EACH ROW WHEN (((new.type = 'credit'::text) AND ((lower(COALESCE(new.category, ''::text)) = ANY (ARRAY['prize'::text, 'bounty'::text, 'refund'::text, 'tournament_prize'::text, 'tournament_refund'::text])) OR (lower(COALESCE(new.category, ''::text)) ~~ 'tourney%'::text)))) EXECUTE FUNCTION public.fn_ca_money_path_log();


--
-- Name: TRIGGER trg_ca_money_path_log ON wallet_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER trg_ca_money_path_log ON public.wallet_transactions IS 'R3 LOG-ONLY (Lane A3, 2026-09-02): records tournament-category credits made outside fn_settle_tournament_obligation in ca_money_path_violations. Never refuses. Enforcement is a separate, Dan-gated step.';


--
-- Name: profiles trg_ca_profile_deletion_journal; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_profile_deletion_journal BEFORE DELETE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_ca_journal_profile_deletion();


--
-- Name: ca_drift_incidents trg_ca_resolution_needs_a_cause; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_resolution_needs_a_cause BEFORE UPDATE ON public.ca_drift_incidents FOR EACH ROW EXECUTE FUNCTION public.fn_ca_resolution_needs_a_cause();


--
-- Name: hand_history trg_ca_stats_live_from_hand; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_stats_live_from_hand AFTER INSERT ON public.hand_history FOR EACH ROW EXECUTE FUNCTION public.trg_ca_stats_live_from_hand();


--
-- Name: tournament_players trg_ca_tournament_entry_gate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_ca_tournament_entry_gate BEFORE INSERT ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_ca_tournament_entry_gate();


--
-- Name: table_seats trg_cash_game_roster_track; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_cash_game_roster_track AFTER INSERT OR UPDATE OF left_at, user_id ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_cash_game_roster_track();


--
-- Name: chip_ledger trg_chip_ledger_performed_by; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_chip_ledger_performed_by BEFORE INSERT ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.enforce_chip_ledger_performed_by();


--
-- Name: tournaments trg_clear_seats_on_game_end; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_clear_seats_on_game_end AFTER UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_clear_seats_on_game_end();


--
-- Name: table_seats trg_clear_sitout_on_turnover; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_clear_sitout_on_turnover BEFORE UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_clear_sitout_on_turnover();


--
-- Name: union_clubs trg_club_enters_a_union_empty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_enters_a_union_empty BEFORE INSERT ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_club_enters_union_empty();


--
-- Name: clubs trg_club_identity_emit_management_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_identity_emit_management_event AFTER UPDATE OF tagline, lobby_message, description ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_emit_management_content_event();


--
-- Name: club_members trg_club_member_notes_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_member_notes_guard BEFORE UPDATE OF nickname, notes ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_club_member_notes_guard();


--
-- Name: club_members trg_club_members_audit_chip_movement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_audit_chip_movement AFTER UPDATE OF chip_balance ON public.club_members FOR EACH ROW WHEN ((old.chip_balance IS DISTINCT FROM new.chip_balance)) EXECUTE FUNCTION public.fn_club_members_ledger_writer();


--
-- Name: club_members trg_club_members_bot_follows_horse; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_bot_follows_horse BEFORE INSERT OR UPDATE OF user_id, is_bot ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_club_members_bot_follows_horse();


--
-- Name: club_members trg_club_members_emit_management_access; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_emit_management_access AFTER INSERT OR DELETE OR UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_emit_management_access_event();


--
-- Name: club_members trg_club_members_guard_lifecycle_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_guard_lifecycle_write BEFORE UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_guard_membership_lifecycle_write();


--
-- Name: club_members trg_club_members_human_user_club_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_human_user_club_only BEFORE INSERT OR UPDATE OF club_id, user_id, is_bot ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_ca_reject_automated_user_club_row();


--
-- Name: club_members trg_club_members_level_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_level_sync AFTER INSERT OR DELETE OR UPDATE OF role, status ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.trg_auto_recompute_club_level();


--
-- Name: club_members trg_club_members_no_agent_cycle_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_no_agent_cycle_ins BEFORE INSERT ON public.club_members FOR EACH ROW WHEN ((new.agent_id IS NOT NULL)) EXECUTE FUNCTION public.fn_club_members_no_agent_cycle();


--
-- Name: club_members trg_club_members_no_agent_cycle_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_no_agent_cycle_upd BEFORE UPDATE OF agent_id ON public.club_members FOR EACH ROW WHEN (((new.agent_id IS NOT NULL) AND (new.agent_id IS DISTINCT FROM old.agent_id))) EXECUTE FUNCTION public.fn_club_members_no_agent_cycle();


--
-- Name: club_members trg_club_members_require_explicit_join; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_require_explicit_join BEFORE INSERT ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_require_explicit_club_membership_source();


--
-- Name: club_members trg_club_members_role_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_role_guard BEFORE UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_club_members_role_guard();


--
-- Name: club_members trg_club_members_staff_earn_no_rakeback; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_members_staff_earn_no_rakeback BEFORE INSERT OR UPDATE ON public.club_members FOR EACH ROW WHEN (((new.role = ANY (ARRAY['co_owner'::text, 'admin'::text])) AND ((COALESCE(new.player_rakeback_pct, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.rakeback_rate, (0)::numeric) <> (0)::numeric) OR (COALESCE(new.commission_rate, (0)::numeric) <> (0)::numeric)))) EXECUTE FUNCTION public.fn_club_members_staff_earn_no_rakeback();


--
-- Name: clubs trg_club_owner_emit_management_access; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_owner_emit_management_access AFTER UPDATE OF owner_id ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_emit_club_union_access_event();


--
-- Name: clubs trg_club_owner_has_a_player_wallet; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER trg_club_owner_has_a_player_wallet AFTER INSERT OR UPDATE ON public.clubs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.fn_club_owner_has_a_player_wallet();


--
-- Name: clubs trg_club_union_emit_management_access; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_union_emit_management_access AFTER UPDATE OF union_id ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_emit_club_union_access_event();


--
-- Name: club_wallets trg_club_wallets_updated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_club_wallets_updated BEFORE UPDATE ON public.club_wallets FOR EACH ROW EXECUTE FUNCTION public.touch_club_wallets();


--
-- Name: clubs trg_clubs_guard_lifecycle_write; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_clubs_guard_lifecycle_write BEFORE DELETE OR UPDATE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_guard_club_lifecycle_write();


--
-- Name: clubs trg_clubs_lobby_message_keeps_its_own_books; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_clubs_lobby_message_keeps_its_own_books BEFORE INSERT OR UPDATE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_clubs_lobby_message_keeps_its_own_books();


--
-- Name: clubs trg_clubs_protect_level_columns; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_clubs_protect_level_columns BEFORE UPDATE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.trg_protect_club_level_columns();


--
-- Name: profiles trg_daily_challenge_revision_from_diamonds; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_daily_challenge_revision_from_diamonds AFTER UPDATE OF diamonds ON public.profiles FOR EACH ROW WHEN ((old.diamonds IS DISTINCT FROM new.diamonds)) EXECUTE FUNCTION public.bump_daily_challenge_dashboard_revision();


--
-- Name: friendships trg_daily_missions_friend_accepted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_daily_missions_friend_accepted AFTER INSERT OR UPDATE OF status ON public.friendships FOR EACH ROW EXECUTE FUNCTION public.fn_daily_missions_friend_accepted();


--
-- Name: tournament_players trg_daily_missions_tournament_registered; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_daily_missions_tournament_registered AFTER UPDATE ON public.tournament_players REFERENCING OLD TABLE AS previous_rows NEW TABLE AS updated_rows FOR EACH STATEMENT EXECUTE FUNCTION public.fn_daily_missions_tournament_registered_updated();


--
-- Name: tournament_players trg_daily_missions_tournament_registered_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_daily_missions_tournament_registered_insert AFTER INSERT ON public.tournament_players REFERENCING NEW TABLE AS inserted_rows FOR EACH STATEMENT EXECUTE FUNCTION public.fn_daily_missions_tournament_registered_inserted();


--
-- Name: agents trg_deep_stack_agents_are_protected; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_deep_stack_agents_are_protected BEFORE DELETE ON public.agents FOR EACH ROW WHEN ((old.club_id = '2a1132b9-5ba2-42e6-9f01-30a7fcffebe3'::uuid)) EXECUTE FUNCTION public.fn_deep_stack_society_cannot_be_deleted_by_accident();


--
-- Name: club_members trg_deep_stack_members_are_protected; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_deep_stack_members_are_protected BEFORE DELETE ON public.club_members FOR EACH ROW WHEN ((old.club_id = '2a1132b9-5ba2-42e6-9f01-30a7fcffebe3'::uuid)) EXECUTE FUNCTION public.fn_deep_stack_society_cannot_be_deleted_by_accident();


--
-- Name: clubs trg_delete_club_social_page; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_delete_club_social_page AFTER DELETE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.trg_fn_delete_club_social_page();


--
-- Name: profiles trg_diamond_side_tables_follow_profiles; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_diamond_side_tables_follow_profiles AFTER INSERT OR UPDATE OF diamonds ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_diamond_side_tables_follow_profiles();


--
-- Name: tournament_bounty_obligations trg_emit_manager_wake_for_settled_bounty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_emit_manager_wake_for_settled_bounty AFTER UPDATE OF state ON public.tournament_bounty_obligations FOR EACH ROW EXECUTE FUNCTION public.fn_emit_manager_wake_for_settled_bounty();


--
-- Name: diamond_transactions trg_enforce_anti_farming_caps; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_enforce_anti_farming_caps BEFORE INSERT ON public.diamond_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_anti_farming_caps();


--
-- Name: tournament_players trg_enforce_booking_game_cap; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_enforce_booking_game_cap BEFORE INSERT OR UPDATE OF status ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_booking_game_cap();


--
-- Name: table_seats trg_enforce_four_table_limit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_enforce_four_table_limit BEFORE INSERT OR UPDATE OF left_at ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_four_table_limit();


--
-- Name: tournament_players trg_enforce_tournament_capacity; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_enforce_tournament_capacity BEFORE INSERT ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_tournament_capacity();


--
-- Name: hand_history trg_enqueue_hand_daily_missions; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_enqueue_hand_daily_missions AFTER INSERT ON public.hand_history FOR EACH ROW EXECUTE FUNCTION public.fn_enqueue_hand_daily_missions();


--
-- Name: club_members trg_four_club_limit_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_four_club_limit_ins BEFORE INSERT ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_four_club_limit();


--
-- Name: club_members trg_four_club_limit_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_four_club_limit_upd BEFORE UPDATE OF status ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_four_club_limit();


--
-- Name: game_management_events trg_game_management_events_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_game_management_events_append_only BEFORE DELETE OR UPDATE ON public.game_management_events FOR EACH ROW EXECUTE FUNCTION public.fn_guard_game_management_event();


--
-- Name: clubs trg_guard_clubs_chip_pool_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_clubs_chip_pool_ins BEFORE INSERT ON public.clubs FOR EACH ROW WHEN (((new.chip_pool IS NOT NULL) AND (new.chip_pool <> (0)::numeric))) EXECUTE FUNCTION public.guard_wallet_balance_write();


--
-- Name: clubs trg_guard_clubs_chip_pool_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_clubs_chip_pool_upd BEFORE UPDATE OF chip_pool ON public.clubs FOR EACH ROW WHEN ((new.chip_pool IS DISTINCT FROM old.chip_pool)) EXECUTE FUNCTION public.guard_wallet_balance_write();


--
-- Name: profiles trg_guard_horse_avatar; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_horse_avatar BEFORE UPDATE OF avatar_url ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_guard_horse_avatar();


--
-- Name: profiles trg_guard_profile_privileged_columns; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_profile_privileged_columns BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_guard_profile_privileged_columns();


--
-- Name: rake_records trg_guard_rake_belongs_to_club; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_rake_belongs_to_club BEFORE INSERT OR UPDATE ON public.rake_records FOR EACH ROW EXECUTE FUNCTION public.fn_guard_rake_belongs_to_club();


--
-- Name: agents trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: bbj_pools trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.bbj_pools FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: cashout_requests trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.cashout_requests FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: club_members trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: club_wallets trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.club_wallets FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: spin_bonus_pools trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.spin_bonus_pools FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: table_seats trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: tables trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: tournament_escrow trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_escrow FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: tournament_players trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: tournament_tickets trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_tickets FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: tournaments trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: union_clubs trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: unions trg_guard_retired_club_mutation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_retired_club_mutation BEFORE INSERT OR DELETE OR UPDATE ON public.unions FOR EACH ROW EXECUTE FUNCTION public.fn_guard_retired_club_mutation();


--
-- Name: wallets trg_guard_wallets_balance_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_wallets_balance_ins BEFORE INSERT ON public.wallets FOR EACH ROW WHEN (((new.balance IS NOT NULL) AND (new.balance <> (0)::numeric))) EXECUTE FUNCTION public.guard_wallet_balance_write();


--
-- Name: wallets trg_guard_wallets_balance_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_guard_wallets_balance_upd BEFORE UPDATE OF balance ON public.wallets FOR EACH ROW WHEN ((new.balance IS DISTINCT FROM old.balance)) EXECUTE FUNCTION public.guard_wallet_balance_write();


--
-- Name: hand_history trg_log_jackpot_hand_deleted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_log_jackpot_hand_deleted BEFORE DELETE ON public.hand_history FOR EACH ROW EXECUTE FUNCTION public.fn_log_jackpot_hand_deleted();


--
-- Name: bbj_payouts trg_log_jackpot_payout_without_hand; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_log_jackpot_payout_without_hand AFTER INSERT ON public.bbj_payouts FOR EACH ROW EXECUTE FUNCTION public.fn_log_jackpot_payout_without_hand();


--
-- Name: table_seats trg_log_seat_stack_exit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_log_seat_stack_exit BEFORE DELETE OR UPDATE OF left_at ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_log_seat_stack_exit();


--
-- Name: managed_game_contract_versions trg_managed_game_contract_version_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_managed_game_contract_version_immutable BEFORE DELETE OR UPDATE ON public.managed_game_contract_versions FOR EACH ROW EXECUTE FUNCTION public.fn_guard_managed_game_contract_version();


--
-- Name: clubs trg_mark_new_club_opening_checklist; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_mark_new_club_opening_checklist BEFORE INSERT ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_mark_new_club_opening_checklist();


--
-- Name: club_members trg_membership_starts_with_zero_chips; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_membership_starts_with_zero_chips BEFORE INSERT ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_membership_starts_with_zero_chips();


--
-- Name: notifications trg_mirror_notification_to_push_outbox; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_mirror_notification_to_push_outbox AFTER INSERT ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.fn_mirror_notification_to_push_outbox();


--
-- Name: profiles trg_mirror_profile_into_legacy_users; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_mirror_profile_into_legacy_users AFTER INSERT ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_mirror_profile_into_legacy_users();


--
-- Name: clubs trg_new_club_gets_the_ladder; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_new_club_gets_the_ladder AFTER INSERT ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_new_club_gets_the_ladder();


--
-- Name: table_seats trg_new_seat_clear_sitout; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_new_seat_clear_sitout BEFORE INSERT ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_new_seat_clear_sitout();


--
-- Name: unions trg_new_union_gets_the_ladder; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_new_union_gets_the_ladder AFTER INSERT ON public.unions FOR EACH ROW EXECUTE FUNCTION public.fn_new_union_gets_the_ladder();


--
-- Name: table_seats trg_no_live_seat_on_finished_game; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_no_live_seat_on_finished_game BEFORE INSERT OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_no_live_seat_on_finished_game();


--
-- Name: profiles trg_normalize_username; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_normalize_username BEFORE INSERT OR UPDATE OF username ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_normalize_username();


--
-- Name: notifications trg_notification_fill_action_url; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_notification_fill_action_url BEFORE INSERT ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.fn_notification_fill_action_url();


--
-- Name: table_seats trg_notify_blinding_off; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_notify_blinding_off AFTER UPDATE OF is_sitting_out, is_away ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_notify_blinding_off();


--
-- Name: friendships trg_notify_friend_request; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_notify_friend_request AFTER INSERT ON public.friendships FOR EACH ROW EXECUTE FUNCTION public.fn_notify_friend_request();


--
-- Name: tables trg_on_table_status_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_on_table_status_change AFTER UPDATE OF status ON public.tables FOR EACH ROW WHEN ((old.status IS DISTINCT FROM new.status)) EXECUTE FUNCTION public.fn_on_table_status_change();


--
-- Name: table_seats trg_one_live_seat_per_tournament; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_one_live_seat_per_tournament BEFORE INSERT OR UPDATE OF user_id, left_at, table_id ON public.table_seats FOR EACH ROW WHEN ((new.left_at IS NULL)) EXECUTE FUNCTION public.fn_guard_one_live_tournament_seat();


--
-- Name: profiles trg_profiles_assign_player_number; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_assign_player_number BEFORE INSERT OR UPDATE OF player_number ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.trg_profiles_assign_player_number();


--
-- Name: profiles trg_profiles_cosmetics_ownership; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_cosmetics_ownership BEFORE INSERT OR UPDATE OF equipped_frame, equipped_aura ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.sp_guard_avatar_cosmetics();


--
-- Name: profiles trg_profiles_horse_is_born_social; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_profiles_horse_is_born_social AFTER INSERT OR UPDATE OF is_horse ON public.profiles FOR EACH ROW WHEN ((new.is_horse IS TRUE)) EXECUTE FUNCTION public.trg_fn_horse_is_born_social();


--
-- Name: profiles trg_protect_profile_username_and_gate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_protect_profile_username_and_gate BEFORE INSERT OR UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_protect_profile_username_and_gate();


--
-- Name: tournaments trg_receipt_mystery_activation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_receipt_mystery_activation AFTER UPDATE OF mystery_bounty_stage ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_receipt_mystery_activation();


--
-- Name: club_members trg_recompute_club_level_on_member_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_recompute_club_level_on_member_change AFTER INSERT OR DELETE OR UPDATE OF role, status ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_recompute_club_level_on_member_change();


--
-- Name: union_clubs trg_recompute_union_level_on_club_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_recompute_union_level_on_club_change AFTER INSERT OR DELETE OR UPDATE OF union_id, club_id ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_recompute_union_level_on_club_change();


--
-- Name: clubs trg_record_new_club_opening_bank; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_record_new_club_opening_bank AFTER INSERT ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_record_new_club_opening_bank();


--
-- Name: tournaments trg_refuse_completed_with_pending_bounties; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_refuse_completed_with_pending_bounties BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_completed_with_pending_bounties();


--
-- Name: tournaments trg_refuse_mystery_activation_with_pending_heads; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_refuse_mystery_activation_with_pending_heads BEFORE UPDATE OF mystery_bounty_stage, mystery_bounty_activation_generation ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_mystery_activation_with_pending_heads();


--
-- Name: tournament_players trg_refuse_reentry_with_pending_bounty; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_refuse_reentry_with_pending_bounty BEFORE UPDATE OF status ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_reentry_with_pending_bounty();


--
-- Name: table_seats trg_refuse_seat_on_closed_cluster_table; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_refuse_seat_on_closed_cluster_table BEFORE INSERT ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_seat_on_closed_cluster_table();


--
-- Name: table_seats trg_refuse_seat_revive_on_closed_cluster_table; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_refuse_seat_revive_on_closed_cluster_table BEFORE UPDATE OF user_id, left_at, table_id ON public.table_seats FOR EACH ROW WHEN (((new.left_at IS NULL) AND ((old.left_at IS NOT NULL) OR (old.user_id IS DISTINCT FROM new.user_id) OR (old.table_id IS DISTINCT FROM new.table_id)))) EXECUTE FUNCTION public.fn_refuse_seat_on_closed_cluster_table();


--
-- Name: tournament_players trg_refuse_zero_chip_field_elimination; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_refuse_zero_chip_field_elimination BEFORE UPDATE ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_zero_chip_field_elimination();


--
-- Name: profiles trg_reject_horse_name_on_human; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_reject_horse_name_on_human BEFORE INSERT OR UPDATE OF display_name, is_horse ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_reject_horse_name_on_human();


--
-- Name: tournaments trg_release_seats_on_tournament_finish; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_release_seats_on_tournament_finish AFTER UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_release_seats_on_tournament_finish();


--
-- Name: tournaments trg_retire_manager_wakes_after_terminal_status; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_retire_manager_wakes_after_terminal_status AFTER UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_retire_manager_wakes_after_terminal_status();


--
-- Name: table_seats trg_seat_change_syncs_seat_first_count; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_seat_change_syncs_seat_first_count AFTER INSERT OR DELETE OR UPDATE OF left_at ON public.table_seats FOR EACH ROW WHEN ((pg_trigger_depth() < 2)) EXECUTE FUNCTION public.fn_seat_change_syncs_seat_first_count();


--
-- Name: table_seats trg_seat_insert_cancel_waitlist; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_seat_insert_cancel_waitlist AFTER INSERT ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_seat_insert_cancel_waitlist();


--
-- Name: clubs trg_seed_new_club_opening_bank; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_seed_new_club_opening_bank BEFORE INSERT ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_seed_new_club_opening_bank();


--
-- Name: clubs trg_spin_pool_follows_union_membership; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_spin_pool_follows_union_membership AFTER UPDATE OF union_id ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_spin_pool_follows_union_membership();


--
-- Name: table_seats trg_stamp_seat_horse_id; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_stamp_seat_horse_id BEFORE INSERT OR UPDATE OF user_id ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_seat_horse_id();


--
-- Name: table_seats trg_stamp_sit_out_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_stamp_sit_out_at BEFORE INSERT OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_sit_out_at();


--
-- Name: club_members trg_sync_agent_player_counts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_agent_player_counts AFTER INSERT OR DELETE OR UPDATE OF agent_id, club_id, is_active ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_sync_agent_player_counts();


--
-- Name: agents trg_sync_agent_wallets; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_agent_wallets BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.sync_agent_wallet_columns();


--
-- Name: club_members trg_sync_club_member_count; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_club_member_count AFTER INSERT OR DELETE OR UPDATE OF status, club_id, role ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_sync_club_member_count();


--
-- Name: clubs trg_sync_mfa_required_on_club_owner; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_mfa_required_on_club_owner AFTER INSERT OR UPDATE OF owner_id ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_sync_mfa_required_on_club_owner();


--
-- Name: club_members trg_sync_mfa_required_on_club_role; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_mfa_required_on_club_role AFTER INSERT OR UPDATE OF role, user_id ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_sync_mfa_required_on_club_role();


--
-- Name: profiles trg_sync_mfa_required_on_role_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_mfa_required_on_role_change BEFORE INSERT OR UPDATE OF role, is_vip ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_sync_mfa_required_on_role_change();


--
-- Name: notifications trg_sync_notification_read_state; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_notification_read_state BEFORE INSERT OR UPDATE ON public.notifications FOR EACH ROW EXECUTE FUNCTION public.sync_notification_read_state();


--
-- Name: player_stats trg_sync_profile_total_hands; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_profile_total_hands AFTER INSERT OR DELETE OR UPDATE OF hands_played ON public.player_stats FOR EACH ROW EXECUTE FUNCTION public.fn_sync_profile_total_hands();


--
-- Name: tournament_players trg_sync_tournament_current_players; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_sync_tournament_current_players AFTER INSERT OR DELETE OR UPDATE OF status, tournament_id ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_sync_tournament_current_players();


--
-- Name: table_seats trg_table_seats_human_user_club_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_table_seats_human_user_club_only BEFORE INSERT OR UPDATE OF table_id, user_id, left_at ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_ca_reject_automated_user_club_row();


--
-- Name: table_seats trg_table_seats_stamp_club; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_table_seats_stamp_club BEFORE INSERT OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_seat_club();


--
-- Name: tables trg_tables_auto_cashout_on_close; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_auto_cashout_on_close AFTER UPDATE OF status ON public.tables FOR EACH ROW WHEN (((new.status IS DISTINCT FROM old.status) AND (lower(COALESCE(new.status, ''::text)) = ANY (ARRAY['closed'::text, 'completed'::text, 'cancelled'::text, 'finished'::text])))) EXECUTE FUNCTION public.trg_auto_cashout_on_table_close();


--
-- Name: tables trg_tables_autostart_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_autostart_guard BEFORE INSERT OR UPDATE OF auto_start_players, max_players ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_tables_autostart_guard();


--
-- Name: tables trg_tables_block_deleted_revival; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_block_deleted_revival BEFORE UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_block_deleted_table_revival();


--
-- Name: tables trg_tables_capture_management_contract; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_capture_management_contract AFTER INSERT OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_capture_managed_game_contract();


--
-- Name: tables trg_tables_closed_main_releases_index; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_closed_main_releases_index BEFORE INSERT OR UPDATE OF lifecycle, is_deleted, main_index, cluster_id ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_closed_cluster_main_releases_index();


--
-- Name: TRIGGER trg_tables_closed_main_releases_index ON tables; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TRIGGER trg_tables_closed_main_releases_index ON public.tables IS 'A closed or deleted cluster table owns no main_index. Watches main_index and cluster_id as well as lifecycle and is_deleted: a renumber writes only main_index, and the narrower list let 2,935 rows through on 2026-09-05.';


--
-- Name: tables trg_tables_cluster_table_ceiling; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_cluster_table_ceiling BEFORE INSERT ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_cluster_table_ceiling();


--
-- Name: tables trg_tables_creation_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_creation_guard BEFORE INSERT ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_tables_creation_guard();


--
-- Name: tables trg_tables_emit_game_management_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_emit_game_management_event AFTER INSERT OR DELETE OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_emit_managed_game_row_event();


--
-- Name: tables trg_tables_managed_delete_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_managed_delete_guard BEFORE DELETE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_guard_managed_game_delete();


--
-- Name: tables trg_tables_managed_lifecycle_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_managed_lifecycle_guard BEFORE UPDATE OF status, is_deleted ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_guard_managed_game_lifecycle();


--
-- Name: tables trg_tables_sync_club_counts_del; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_sync_club_counts_del AFTER DELETE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_sync_club_table_counts();


--
-- Name: tables trg_tables_sync_club_counts_ins; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_sync_club_counts_ins AFTER INSERT ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_sync_club_table_counts();


--
-- Name: tables trg_tables_sync_club_counts_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_sync_club_counts_upd AFTER UPDATE OF status, is_deleted, club_id, union_id, tournament_id ON public.tables FOR EACH ROW WHEN (((new.status IS DISTINCT FROM old.status) OR (new.is_deleted IS DISTINCT FROM old.is_deleted) OR (new.club_id IS DISTINCT FROM old.club_id) OR (new.union_id IS DISTINCT FROM old.union_id) OR (new.tournament_id IS DISTINCT FROM old.tournament_id))) EXECUTE FUNCTION public.fn_sync_club_table_counts();


--
-- Name: tables trg_tables_sync_rit; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_sync_rit BEFORE INSERT OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_tables_sync_rit();


--
-- Name: tables trg_tables_union_ownership; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_union_ownership BEFORE INSERT ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_table_union_ownership();


--
-- Name: tables trg_tables_union_ownership_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tables_union_ownership_upd BEFORE UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_table_union_ownership_update();


--
-- Name: rake_records trg_tournament_fee_names_its_player; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournament_fee_names_its_player BEFORE INSERT ON public.rake_records FOR EACH ROW WHEN (((new.is_tournament IS TRUE) AND (new.player_contributions IS NULL) AND (new.rake_amount > (0)::numeric))) EXECUTE FUNCTION public.fn_tournament_fee_names_its_player();


--
-- Name: tournament_payouts trg_tournament_payouts_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournament_payouts_append_only BEFORE DELETE OR UPDATE ON public.tournament_payouts FOR EACH ROW EXECUTE FUNCTION public.fn_tournament_payouts_are_append_only();


--
-- Name: tournament_players trg_tournament_players_human_user_club_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournament_players_human_user_club_only BEFORE INSERT OR UPDATE OF tournament_id, user_id ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_ca_reject_automated_user_club_row();


--
-- Name: tournament_players trg_tournament_players_stamp_club; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournament_players_stamp_club BEFORE INSERT OR UPDATE ON public.tournament_players FOR EACH ROW WHEN ((new.club_id IS NULL)) EXECUTE FUNCTION public.fn_stamp_entry_club();


--
-- Name: tournaments trg_tournaments_capture_management_contract; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_capture_management_contract AFTER INSERT OR UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_capture_managed_game_contract();


--
-- Name: tournaments trg_tournaments_emit_game_management_event; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_emit_game_management_event AFTER INSERT OR DELETE OR UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_emit_managed_game_row_event();


--
-- Name: tournaments trg_tournaments_managed_delete_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_managed_delete_guard BEFORE DELETE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_guard_managed_game_delete();


--
-- Name: tournaments trg_tournaments_managed_lifecycle_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_managed_lifecycle_guard BEFORE UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_guard_managed_game_lifecycle();


--
-- Name: tournaments trg_tournaments_publish_readiness; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_publish_readiness AFTER INSERT OR UPDATE OF guaranteed_prize, club_id, union_id, is_private, variant, tournament_type, satellite_target_id, satellite_target, satellite_seats ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_guard_tournament_publish_readiness();


--
-- Name: tournaments trg_tournaments_refuse_unbuilt_multi_day; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_refuse_unbuilt_multi_day BEFORE INSERT OR UPDATE OF is_multi_day, total_days, day_number, parent_tournament_id, survivors_advance_to, flight_number, flight_end_chips_snapshot ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_tournaments_refuse_unbuilt_multi_day();


--
-- Name: tournaments trg_tournaments_registered_contract_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_registered_contract_lock BEFORE UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_guard_registered_tournament_contract();


--
-- Name: tournaments trg_tournaments_start_readiness; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_start_readiness BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_guard_tournament_start_readiness();


--
-- Name: tournaments trg_tournaments_union_ownership; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_union_ownership BEFORE INSERT ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_tournament_union_ownership();


--
-- Name: tournaments trg_tournaments_union_ownership_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_tournaments_union_ownership_upd BEFORE UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_tournament_union_ownership_update();


--
-- Name: union_admins trg_union_admins_emit_management_access; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_admins_emit_management_access AFTER INSERT OR DELETE OR UPDATE ON public.union_admins FOR EACH ROW EXECUTE FUNCTION public.fn_emit_management_access_event();


--
-- Name: union_clubs trg_union_clubs_emit_management_access; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_clubs_emit_management_access AFTER INSERT OR DELETE ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_emit_management_access_event();


--
-- Name: union_clubs trg_union_clubs_reassignment_management_access; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_clubs_reassignment_management_access AFTER UPDATE OF union_id, club_id ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_emit_management_access_event();


--
-- Name: union_clubs trg_union_clubs_sync_mirror; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_clubs_sync_mirror AFTER INSERT OR DELETE ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_sync_club_union_mirror();


--
-- Name: union_clubs trg_union_clubs_sync_table_counts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_clubs_sync_table_counts AFTER INSERT OR DELETE OR UPDATE ON public.union_clubs FOR EACH ROW EXECUTE FUNCTION public.fn_sync_union_membership_table_counts();


--
-- Name: unions trg_union_creation_is_allowlisted; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_creation_is_allowlisted BEFORE INSERT ON public.unions FOR EACH ROW EXECUTE FUNCTION public.fn_guard_union_creation();


--
-- Name: unions trg_union_owner_emit_management_access; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_owner_emit_management_access AFTER UPDATE OF owner_id ON public.unions FOR EACH ROW EXECUTE FUNCTION public.fn_emit_union_owner_access_event();


--
-- Name: clubs trg_union_totals_follow_club_counts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_union_totals_follow_club_counts AFTER UPDATE ON public.clubs REFERENCING OLD TABLE AS oldrows NEW TABLE AS newrows FOR EACH STATEMENT EXECUTE FUNCTION public.fn_union_totals_follow_club_counts();


--
-- Name: unions trg_unions_set_slug; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_unions_set_slug BEFORE INSERT OR UPDATE OF slug, name ON public.unions FOR EACH ROW EXECUTE FUNCTION public.fn_unions_set_slug();


--
-- Name: profiles trg_validate_home_url_fields; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_validate_home_url_fields BEFORE INSERT OR UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_validate_home_url_fields();


--
-- Name: tournaments trg_whole_dollar_buyin; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_whole_dollar_buyin BEFORE INSERT OR UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_enforce_whole_dollar_buyin();


--
-- Name: union_wallet_transactions union_rake_weekly_maintain; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER union_rake_weekly_maintain AFTER INSERT ON public.union_wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.trg_union_rake_weekly();


--
-- Name: tournament_payouts zz_a_payout_row_carries_its_key; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_a_payout_row_carries_its_key BEFORE INSERT ON public.tournament_payouts FOR EACH ROW EXECUTE FUNCTION public.zz_a_payout_row_carries_its_key();


--
-- Name: financial_alerts zz_ca_alert_resolution_reaches_the_incident; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_alert_resolution_reaches_the_incident AFTER UPDATE OF resolved ON public.financial_alerts FOR EACH ROW EXECUTE FUNCTION public.fn_ca_alert_resolution_reaches_the_incident();


--
-- Name: chip_ledger zz_ca_attested_day_is_restated_del; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_attested_day_is_restated_del AFTER DELETE ON public.chip_ledger REFERENCING OLD TABLE AS old_rows FOR EACH STATEMENT EXECUTE FUNCTION public.fn_ca_attested_day_is_restated();


--
-- Name: chip_ledger zz_ca_attested_day_is_restated_upd; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_attested_day_is_restated_upd AFTER UPDATE ON public.chip_ledger REFERENCING OLD TABLE AS old_rows NEW TABLE AS new_rows FOR EACH STATEMENT EXECUTE FUNCTION public.fn_ca_attested_day_is_restated();


--
-- Name: profiles zz_ca_audit_diamond_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_audit_diamond_change AFTER INSERT OR UPDATE OF diamonds ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.fn_ca_audit_diamond_change();


--
-- Name: hand_history zz_ca_bomb_hand_keeps_its_award_units; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER zz_ca_bomb_hand_keeps_its_award_units AFTER INSERT ON public.hand_history DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.bomb_pot IS NOT NULL)) EXECUTE FUNCTION public.fn_ca_bomb_hand_keeps_its_award_units();


--
-- Name: profiles zz_ca_diamond_born_with_balance; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_diamond_born_with_balance AFTER INSERT ON public.profiles FOR EACH ROW WHEN (((new.diamonds IS NOT NULL) AND (new.diamonds <> 0))) EXECUTE FUNCTION public.fn_ca_diamond_born_with_balance();


--
-- Name: chip_ledger zz_ca_escrow_overlay_leg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_escrow_overlay_leg AFTER INSERT ON public.chip_ledger FOR EACH ROW WHEN (((new.to_type = 'prize_liability'::text) AND ((new.category = 'overlay'::text) OR ((new.category = 'correction'::text) AND (new.from_type = ANY (ARRAY['union_bank'::text, 'club_treasury'::text])))))) EXECUTE FUNCTION public.fn_ca_escrow_on_overlay_leg();


--
-- Name: rake_records zz_ca_escrow_rake_record; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_escrow_rake_record AFTER INSERT ON public.rake_records FOR EACH ROW WHEN (((new.is_tournament IS TRUE) AND (new.tournament_id IS NOT NULL))) EXECUTE FUNCTION public.fn_ca_escrow_on_rake_record();


--
-- Name: tournament_rake_settlements zz_ca_escrow_rake_settlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_escrow_rake_settlement AFTER INSERT OR UPDATE OF settled_at ON public.tournament_rake_settlements FOR EACH ROW EXECUTE FUNCTION public.fn_ca_escrow_on_rake_settlement();


--
-- Name: chip_ledger zz_ca_escrow_reserve_leg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_escrow_reserve_leg AFTER INSERT ON public.chip_ledger FOR EACH ROW WHEN ((new.category = ANY (ARRAY['spin_entry'::text, 'spin_prize'::text]))) EXECUTE FUNCTION public.fn_ca_escrow_on_reserve_leg();


--
-- Name: tournament_payouts zz_ca_escrow_seat_payout; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_escrow_seat_payout AFTER INSERT ON public.tournament_payouts FOR EACH ROW WHEN ((new.source = 'satellite_seat'::text)) EXECUTE FUNCTION public.fn_ca_escrow_on_seat_payout();


--
-- Name: chip_ledger zz_ca_escrow_seat_transfer_leg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_escrow_seat_transfer_leg AFTER INSERT ON public.chip_ledger FOR EACH ROW WHEN (((new.to_type = 'prize_liability'::text) AND (new.idempotency_key ~~ 'tourney:%:seat:%:pool_transfer'::text))) EXECUTE FUNCTION public.fn_ca_escrow_on_seat_transfer_leg();


--
-- Name: wallet_transactions zz_ca_escrow_wallet_tx; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_escrow_wallet_tx AFTER INSERT ON public.wallet_transactions FOR EACH ROW WHEN ((new.related_entity_id IS NOT NULL)) EXECUTE FUNCTION public.fn_ca_escrow_on_wallet_tx();


--
-- Name: tournaments zz_ca_fund_overlay_on_lock; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_fund_overlay_on_lock BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_ca_fund_overlay_on_lock();


--
-- Name: ca_drift_incidents zz_ca_incident_resolution_reaches_the_alerts; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_incident_resolution_reaches_the_alerts AFTER UPDATE OF status ON public.ca_drift_incidents FOR EACH ROW EXECUTE FUNCTION public.fn_ca_incident_resolution_reaches_the_alerts();


--
-- Name: chip_ledger zz_ca_issuance_leg_is_registered; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER zz_ca_issuance_leg_is_registered AFTER INSERT ON public.chip_ledger DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN (((new.from_type = ANY (ARRAY['system_mint'::text, 'system_burn'::text, 'issuance_reserve'::text, 'chip_retirement'::text])) OR (new.to_type = ANY (ARRAY['system_mint'::text, 'system_burn'::text, 'issuance_reserve'::text, 'chip_retirement'::text])))) EXECUTE FUNCTION public.fn_ca_issuance_leg_is_registered();


--
-- Name: ca_ledger_day_manifests zz_ca_manifest_is_restated_not_edited; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_manifest_is_restated_not_edited BEFORE DELETE OR UPDATE ON public.ca_ledger_day_manifests FOR EACH ROW EXECUTE FUNCTION public.fn_ca_manifest_is_restated_not_edited();


--
-- Name: wallets zz_ca_record_frozen_pool_deletion; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_record_frozen_pool_deletion BEFORE DELETE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.fn_ca_record_frozen_pool_deletion();


--
-- Name: ca_ledger_day_manifest_restatements zz_ca_restatement_is_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_ca_restatement_is_append_only BEFORE DELETE OR UPDATE ON public.ca_ledger_day_manifest_restatements FOR EACH ROW EXECUTE FUNCTION public.fn_ca_restatement_is_append_only();


--
-- Name: tables zz_cancel_cash_seat_moves_on_table_close; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_cancel_cash_seat_moves_on_table_close AFTER UPDATE OF status, seat_admission_key ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_cancel_cash_seat_moves_on_table_close();


--
-- Name: cash_games zz_cash_game_floor_from_template; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_cash_game_floor_from_template BEFORE INSERT OR UPDATE OF ruleset_snapshot, template_name, variant ON public.cash_games FOR EACH ROW EXECUTE FUNCTION public.fn_cash_game_floor_from_template();


--
-- Name: cash_seat_moves zz_cash_seat_move_window; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_cash_seat_move_window BEFORE INSERT ON public.cash_seat_moves FOR EACH ROW EXECUTE FUNCTION public.fn_cash_seat_move_set_window();


--
-- Name: chip_ledger zz_chip_ledger_key_is_claimed_once; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_chip_ledger_key_is_claimed_once BEFORE INSERT ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.zz_chip_ledger_key_is_claimed_once();


--
-- Name: table_seats zz_close_session_when_seat_vacated; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER zz_close_session_when_seat_vacated AFTER UPDATE OF left_at ON public.table_seats DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.trg_fn_close_session_when_seat_vacated();


--
-- Name: tables zz_close_sessions_when_table_closes; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_close_sessions_when_table_closes AFTER UPDATE OF status, is_deleted ON public.tables FOR EACH ROW EXECUTE FUNCTION public.trg_fn_close_sessions_when_table_closes();


--
-- Name: ca_diamond_engine_spend zz_engine_spend_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_engine_spend_append_only BEFORE DELETE OR UPDATE ON public.ca_diamond_engine_spend FOR EACH ROW EXECUTE FUNCTION public.fn_ca_engine_spend_append_only();


--
-- Name: ca_diamond_engine_spend zz_engine_spend_no_truncate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_engine_spend_no_truncate BEFORE TRUNCATE ON public.ca_diamond_engine_spend FOR EACH STATEMENT EXECUTE FUNCTION public.fn_ca_engine_spend_append_only();


--
-- Name: tournaments zz_freerolls_are_free_buy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freerolls_are_free_buy BEFORE INSERT OR UPDATE OF buy_in_amount, buy_in_fee, tournament_type, variant, is_rebuy, add_on_available, rebuy_cost, addon_cost, rebuy_chips, addon_chips, rebuy_levels, addon_levels, max_rebuys ON public.tournaments FOR EACH ROW WHEN ((COALESCE(new.buy_in_amount, (0)::numeric) = (0)::numeric)) EXECUTE FUNCTION public.fn_freerolls_are_free_buy();


--
-- Name: table_seats zz_freeze_entry_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_entry_guard BEFORE INSERT OR UPDATE OF left_at, user_id ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_new_entries_while_frozen();


--
-- Name: tournament_players zz_freeze_entry_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_entry_guard BEFORE INSERT ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_new_entries_while_frozen();


--
-- Name: chip_ledger zz_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_guard BEFORE INSERT OR DELETE OR UPDATE ON public.chip_ledger FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_while_frozen();


--
-- Name: chip_transactions zz_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_guard BEFORE INSERT OR DELETE OR UPDATE ON public.chip_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_while_frozen();


--
-- Name: club_members zz_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_guard BEFORE INSERT OR DELETE OR UPDATE ON public.club_members FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_while_frozen('chip_balance');


--
-- Name: clubs zz_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_guard BEFORE UPDATE ON public.clubs FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_while_frozen('chip_pool', 'total_rake');


--
-- Name: table_seats zz_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_guard BEFORE INSERT OR DELETE OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_while_frozen('stack', 'left_at', 'sit_out_at');


--
-- Name: wallet_transactions zz_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_guard BEFORE INSERT OR DELETE OR UPDATE ON public.wallet_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_while_frozen();


--
-- Name: wallets zz_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_guard BEFORE INSERT OR DELETE OR UPDATE ON public.wallets FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_while_frozen('balance');


--
-- Name: tournaments zz_freeze_launch_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_freeze_launch_guard BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW WHEN (((new.status = 'RUNNING'::text) AND (old.status IS DISTINCT FROM new.status))) EXECUTE FUNCTION public.fn_refuse_new_entries_while_frozen();


--
-- Name: cash_games zz_one_game_per_blind_category; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_one_game_per_blind_category BEFORE INSERT OR UPDATE OF enabled, template_name, variant, bb, club_id ON public.cash_games FOR EACH ROW EXECUTE FUNCTION public.fn_guard_one_game_per_blind_category();


--
-- Name: table_seats zz_restriction_seat_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_restriction_seat_guard BEFORE INSERT ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_ca_refuse_restricted_entry('cash');


--
-- Name: table_seats zz_restriction_seat_revive_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_restriction_seat_revive_guard BEFORE UPDATE OF user_id, left_at ON public.table_seats FOR EACH ROW WHEN (((new.left_at IS NULL) AND ((old.left_at IS NOT NULL) OR (old.user_id IS DISTINCT FROM new.user_id)))) EXECUTE FUNCTION public.fn_ca_refuse_restricted_entry('cash');


--
-- Name: tournament_players zz_restriction_tourney_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_restriction_tourney_guard BEFORE INSERT ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_ca_refuse_restricted_entry('tournaments');


--
-- Name: chip_transactions zz_settlement_freeze_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_settlement_freeze_guard BEFORE INSERT ON public.chip_transactions FOR EACH ROW EXECUTE FUNCTION public.fn_refuse_operator_move_while_settling();


--
-- Name: tournament_escrow zz_spin_escrow_is_enforced; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_spin_escrow_is_enforced BEFORE INSERT ON public.tournament_escrow FOR EACH ROW EXECUTE FUNCTION public.fn_spin_escrow_is_enforced();


--
-- Name: spin_reserve_ledger zz_spin_shortfall_funds_escrow; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_spin_shortfall_funds_escrow AFTER INSERT ON public.spin_reserve_ledger FOR EACH ROW WHEN ((new.kind = 'adjustment'::text)) EXECUTE FUNCTION public.fn_spin_shortfall_funds_the_escrow();


--
-- Name: tournament_players zz_stamp_tournament_elimination_sequence; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_stamp_tournament_elimination_sequence BEFORE INSERT OR UPDATE OF status, elimination_sequence ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_tournament_elimination_sequence();


--
-- Name: ca_diamond_rule_modes zz_touch_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_touch_updated_at BEFORE INSERT OR UPDATE ON public.ca_diamond_rule_modes FOR EACH ROW EXECUTE FUNCTION public.fn_ca_touch_updated_at();


--
-- Name: diamond_engine_daily_caps zz_touch_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_touch_updated_at BEFORE INSERT OR UPDATE ON public.diamond_engine_daily_caps FOR EACH ROW EXECUTE FUNCTION public.fn_ca_touch_updated_at();


--
-- Name: vip_points zz_vip_points_move_only_with_a_leg; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zz_vip_points_move_only_with_a_leg BEFORE INSERT OR UPDATE ON public.vip_points FOR EACH ROW EXECUTE FUNCTION public.fn_vip_points_move_only_with_a_leg();


--
-- Name: cash_seat_moves zzz_bind_cash_seat_move_occupancy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzz_bind_cash_seat_move_occupancy BEFORE INSERT OR UPDATE ON public.cash_seat_moves FOR EACH ROW EXECUTE FUNCTION public.fn_bind_cash_seat_move_occupancy();


--
-- Name: table_seats zzz_diamond_seat_keeps_custody; Type: TRIGGER; Schema: public; Owner: -
--

CREATE CONSTRAINT TRIGGER zzz_diamond_seat_keeps_custody AFTER INSERT OR DELETE OR UPDATE ON public.table_seats DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.fn_poker_diamond_seat_keeps_custody();


--
-- Name: tournaments zzz_spin_ladder_is_the_drawn_one; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzz_spin_ladder_is_the_drawn_one BEFORE INSERT OR UPDATE ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.fn_spin_ladder_is_the_drawn_one();


--
-- Name: table_seats zzz_stamp_seat_occupancy; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzz_stamp_seat_occupancy BEFORE INSERT OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_seat_occupancy();


--
-- Name: tournaments zzzy_lock_atomic_place_tournament_status; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzy_lock_atomic_place_tournament_status BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW WHEN ((new.status IS DISTINCT FROM old.status)) EXECUTE FUNCTION public.trg_lock_atomic_place_tournament_status();


--
-- Name: tournaments zzzz_capture_satellite_economics_on_start; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_capture_satellite_economics_on_start BEFORE INSERT OR UPDATE OF status ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.trg_capture_satellite_economics_on_start();


--
-- Name: tournament_obligations zzzz_freeze_batched_tournament_place; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_batched_tournament_place BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_obligations FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_batched_tournament_place();


--
-- Name: tournament_players zzzz_freeze_batched_tournament_result; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_batched_tournament_result BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_batched_tournament_result();


--
-- Name: tournament_final_table_deal_batches zzzz_freeze_canonical_final_deal_batch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_canonical_final_deal_batch BEFORE DELETE OR UPDATE ON public.tournament_final_table_deal_batches FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_canonical_final_deal_batch();


--
-- Name: tournaments zzzz_freeze_finalized_tournament_prize_pool; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_finalized_tournament_prize_pool BEFORE UPDATE OF prize_pool, guaranteed_prize, prize_pool_finalized, payout_structure, spin_multiplier ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_finalized_tournament_prize_pool();

ALTER TABLE public.tournaments DISABLE TRIGGER zzzz_freeze_finalized_tournament_prize_pool;


--
-- Name: tournaments zzzz_freeze_registered_tournament_settlement_contract; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_registered_tournament_settlement_contract BEFORE UPDATE OF variant, tournament_type, satellite_target_id, bubble_protection, buy_in_amount, guaranteed_prize ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_registered_tournament_settlement_contract();


--
-- Name: tournament_satellite_economic_snapshots zzzz_freeze_satellite_economic_snapshot; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_satellite_economic_snapshot BEFORE DELETE OR UPDATE ON public.tournament_satellite_economic_snapshots FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_satellite_economic_snapshot();


--
-- Name: tournament_satellite_entitlements zzzz_freeze_satellite_entitlement; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_satellite_entitlement BEFORE DELETE OR UPDATE ON public.tournament_satellite_entitlements FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_satellite_entitlement();


--
-- Name: tournament_satellite_settlement_batches zzzz_freeze_satellite_settlement_batch; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_freeze_satellite_settlement_batch BEFORE DELETE OR UPDATE ON public.tournament_satellite_settlement_batches FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_satellite_settlement_batch();


--
-- Name: tournament_players zzzz_refuse_finalized_tournament_entry; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_refuse_finalized_tournament_entry BEFORE INSERT ON public.tournament_players FOR EACH ROW EXECUTE FUNCTION public.trg_refuse_finalized_tournament_entry();


--
-- Name: tournaments zzzz_refuse_normal_tournament_completed_insert; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_refuse_normal_tournament_completed_insert BEFORE INSERT ON public.tournaments FOR EACH ROW WHEN ((new.status = 'COMPLETED'::text)) EXECUTE FUNCTION public.trg_refuse_normal_tournament_completed_insert();


--
-- Name: table_seats zzzz_stamp_active_seat_game_scope; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_stamp_active_seat_game_scope BEFORE INSERT OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_active_seat_game_scope();


--
-- Name: tables zzzz_stamp_table_game_scope; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_stamp_table_game_scope BEFORE INSERT OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_table_game_scope();


--
-- Name: tables zzzz_stamp_table_seat_admission; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_stamp_table_seat_admission BEFORE INSERT OR UPDATE ON public.tables FOR EACH ROW EXECUTE FUNCTION public.fn_stamp_table_seat_admission();


--
-- Name: tournaments zzzz_tournament_pool_finalization_window_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_tournament_pool_finalization_window_guard BEFORE UPDATE OF prize_pool_finalized ON public.tournaments FOR EACH ROW EXECUTE FUNCTION public.trg_tournament_pool_finalization_window_guard();

ALTER TABLE public.tournaments DISABLE TRIGGER zzzz_tournament_pool_finalization_window_guard;


--
-- Name: tournaments zzzz_tournaments_atomic_place_completion_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzz_tournaments_atomic_place_completion_guard BEFORE UPDATE ON public.tournaments FOR EACH ROW WHEN (((new.status = 'COMPLETED'::text) AND (old.status IS DISTINCT FROM 'COMPLETED'::text))) EXECUTE FUNCTION public.trg_tournament_atomic_place_completion_guard();

ALTER TABLE public.tournaments DISABLE TRIGGER zzzz_tournaments_atomic_place_completion_guard;


--
-- Name: tournaments zzzzy_lock_atomic_final_table_deal_status; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzy_lock_atomic_final_table_deal_status BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW WHEN ((new.status IS DISTINCT FROM old.status)) EXECUTE FUNCTION public.trg_lock_atomic_final_table_deal_status();


--
-- Name: tournament_obligations zzzzz_freeze_atomic_final_table_deal_obligation; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzz_freeze_atomic_final_table_deal_obligation BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_obligations FOR EACH ROW EXECUTE FUNCTION public.trg_freeze_atomic_final_table_deal_obligation();


--
-- Name: table_seats zzzzz_require_live_seat_parent; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzz_require_live_seat_parent BEFORE INSERT OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.fn_require_live_seat_parent();


--
-- Name: table_seats zzzzz_seat_parent_keys_match; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzz_seat_parent_keys_match BEFORE INSERT OR UPDATE ON public.table_seats FOR EACH ROW EXECUTE FUNCTION public.trg_seat_parent_keys_match();


--
-- Name: tables zzzzz_table_parent_keys_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzz_table_parent_keys_guard BEFORE UPDATE ON public.tables FOR EACH ROW WHEN ((old.seat_admission_key IS DISTINCT FROM new.seat_admission_key)) EXECUTE FUNCTION public.trg_table_parent_keys_guard();


--
-- Name: tables zzzzz_table_scope_cascade; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzz_table_scope_cascade AFTER UPDATE ON public.tables FOR EACH ROW WHEN ((old.seat_game_scope IS DISTINCT FROM new.seat_game_scope)) EXECUTE FUNCTION public.trg_table_scope_cascade();


--
-- Name: tournaments zzzzz_tournaments_atomic_final_table_deal_completion_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzz_tournaments_atomic_final_table_deal_completion_guard BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW WHEN (((new.status = 'COMPLETED'::text) AND (old.status IS DISTINCT FROM 'COMPLETED'::text))) EXECUTE FUNCTION public.trg_atomic_final_table_deal_completion_guard();

ALTER TABLE public.tournaments DISABLE TRIGGER zzzzz_tournaments_atomic_final_table_deal_completion_guard;


--
-- Name: tournaments zzzzzz_tournaments_financial_certificate; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER zzzzzz_tournaments_financial_certificate BEFORE UPDATE OF status ON public.tournaments FOR EACH ROW WHEN (((new.status = 'COMPLETED'::text) AND (old.status IS DISTINCT FROM 'COMPLETED'::text))) EXECUTE FUNCTION public.fn_guard_tournament_completed_certificate();

ALTER TABLE public.tournaments DISABLE TRIGGER zzzzzz_tournaments_financial_certificate;


--
-- Name: agent_commission_settlements agent_commission_settlements_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commission_settlements
    ADD CONSTRAINT agent_commission_settlements_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: agent_commissions agent_commissions_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: agent_commissions agent_commissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_commissions
    ADD CONSTRAINT agent_commissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: agents agents_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: audit_trail audit_trail_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES auth.users(id) ON DELETE RESTRICT;


--
-- Name: audit_trail audit_trail_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_trail
    ADD CONSTRAINT audit_trail_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE SET NULL;


--
-- Name: bbj_payouts bbj_payouts_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_payouts
    ADD CONSTRAINT bbj_payouts_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.bbj_pools(id) ON DELETE RESTRICT;


--
-- Name: bbj_unclaimed_shares bbj_unclaimed_shares_payout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_unclaimed_shares
    ADD CONSTRAINT bbj_unclaimed_shares_payout_id_fkey FOREIGN KEY (payout_id) REFERENCES public.bbj_payouts(id) ON DELETE CASCADE;


--
-- Name: ca_arena_settings ca_arena_settings_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_arena_settings
    ADD CONSTRAINT ca_arena_settings_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE RESTRICT;


--
-- Name: ca_incident_events ca_incident_events_incident_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_incident_events
    ADD CONSTRAINT ca_incident_events_incident_id_fkey FOREIGN KEY (incident_id) REFERENCES public.ca_drift_incidents(id);


--
-- Name: ca_mint_ledger ca_mint_ledger_chip_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_mint_ledger
    ADD CONSTRAINT ca_mint_ledger_chip_ledger_id_fkey FOREIGN KEY (chip_ledger_id) REFERENCES public.chip_ledger(id) ON DELETE RESTRICT;


--
-- Name: ca_treasury_baseline ca_treasury_baseline_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_treasury_baseline
    ADD CONSTRAINT ca_treasury_baseline_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: cash_game_roster cash_game_roster_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_game_roster
    ADD CONSTRAINT cash_game_roster_game_id_fkey FOREIGN KEY (game_id) REFERENCES public.cash_games(id) ON DELETE CASCADE;


--
-- Name: cash_seat_change_requests cash_seat_change_requests_from_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_change_requests
    ADD CONSTRAINT cash_seat_change_requests_from_table_id_fkey FOREIGN KEY (from_table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: cash_seat_change_requests cash_seat_change_requests_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_change_requests
    ADD CONSTRAINT cash_seat_change_requests_game_id_fkey FOREIGN KEY (game_id) REFERENCES public.cash_games(id) ON DELETE CASCADE;


--
-- Name: cash_seat_change_requests cash_seat_change_requests_to_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_change_requests
    ADD CONSTRAINT cash_seat_change_requests_to_table_id_fkey FOREIGN KEY (to_table_id) REFERENCES public.tables(id) ON DELETE SET NULL;


--
-- Name: cash_seat_moves cash_seat_moves_from_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_moves
    ADD CONSTRAINT cash_seat_moves_from_table_id_fkey FOREIGN KEY (from_table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: cash_seat_moves cash_seat_moves_game_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_moves
    ADD CONSTRAINT cash_seat_moves_game_id_fkey FOREIGN KEY (game_id) REFERENCES public.cash_games(id) ON DELETE CASCADE;


--
-- Name: cash_seat_moves cash_seat_moves_to_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_seat_moves
    ADD CONSTRAINT cash_seat_moves_to_table_id_fkey FOREIGN KEY (to_table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: cashout_requests cashout_requests_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashout_requests
    ADD CONSTRAINT cashout_requests_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: cashout_requests cashout_requests_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashout_requests
    ADD CONSTRAINT cashout_requests_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: cashout_requests cashout_requests_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashout_requests
    ADD CONSTRAINT cashout_requests_player_id_fkey FOREIGN KEY (player_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: chip_ledger chip_ledger_performed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chip_ledger
    ADD CONSTRAINT chip_ledger_performed_by_fkey FOREIGN KEY (performed_by) REFERENCES auth.users(id);


--
-- Name: club_members club_members_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_members
    ADD CONSTRAINT club_members_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.profiles(id) ON DELETE SET NULL;


--
-- Name: club_members club_members_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_members
    ADD CONSTRAINT club_members_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: club_members club_members_profiles_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_members
    ADD CONSTRAINT club_members_profiles_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: club_wallets club_wallets_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.club_wallets
    ADD CONSTRAINT club_wallets_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: clubs clubs_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.profiles(id);


--
-- Name: clubs clubs_retired_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_retired_by_fkey FOREIGN KEY (retired_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: clubs clubs_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clubs
    ADD CONSTRAINT clubs_union_id_fkey FOREIGN KEY (union_id) REFERENCES public.unions(id);


--
-- Name: daily_challenge_dashboard_revisions daily_challenge_dashboard_revisions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenge_dashboard_revisions
    ADD CONSTRAINT daily_challenge_dashboard_revisions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: daily_challenge_event_outbox daily_challenge_event_outbox_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_challenge_event_outbox
    ADD CONSTRAINT daily_challenge_event_outbox_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: diamond_transactions diamond_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_transactions
    ADD CONSTRAINT diamond_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: diamond_user_daily_awards diamond_user_daily_awards_user_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_user_daily_awards
    ADD CONSTRAINT diamond_user_daily_awards_user_fk FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: engine_tournament_leases engine_tournament_leases_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.engine_tournament_leases
    ADD CONSTRAINT engine_tournament_leases_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: financial_alerts financial_alerts_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_alerts
    ADD CONSTRAINT financial_alerts_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES auth.users(id);


--
-- Name: agents fk_agents_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_parent FOREIGN KEY (parent_agent_id) REFERENCES public.agents(id);


--
-- Name: agents fk_agents_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT fk_agents_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: cashout_requests fk_cashout_requests_agent_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashout_requests
    ADD CONSTRAINT fk_cashout_requests_agent_id_profiles FOREIGN KEY (agent_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: cashout_requests fk_cashout_requests_player_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cashout_requests
    ADD CONSTRAINT fk_cashout_requests_player_id_profiles FOREIGN KEY (player_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: chip_transactions fk_chip_transactions_club_id_clubs; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chip_transactions
    ADD CONSTRAINT fk_chip_transactions_club_id_clubs FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE SET NULL NOT VALID;


--
-- Name: chip_transactions fk_chip_transactions_from_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chip_transactions
    ADD CONSTRAINT fk_chip_transactions_from_user_id_profiles FOREIGN KEY (from_user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: chip_transactions fk_chip_transactions_to_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chip_transactions
    ADD CONSTRAINT fk_chip_transactions_to_user_id_profiles FOREIGN KEY (to_user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: content_authors fk_content_authors_profile_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_authors
    ADD CONSTRAINT fk_content_authors_profile_id_profiles FOREIGN KEY (profile_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: diamond_transactions fk_diamond_transactions_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_transactions
    ADD CONSTRAINT fk_diamond_transactions_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: diamond_wallets fk_diamond_wallets_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.diamond_wallets
    ADD CONSTRAINT fk_diamond_wallets_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: friendships fk_friendships_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT fk_friendships_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: notifications fk_notifications_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT fk_notifications_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: player_stats fk_player_stats_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT fk_player_stats_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: social_pages fk_social_pages_owner_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_pages
    ADD CONSTRAINT fk_social_pages_owner_id_profiles FOREIGN KEY (owner_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: social_pages fk_social_pages_owner_profile; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_pages
    ADD CONSTRAINT fk_social_pages_owner_profile FOREIGN KEY (owner_id) REFERENCES public.profiles(id) ON DELETE SET NULL;


--
-- Name: table_seats fk_table_seats_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_seats
    ADD CONSTRAINT fk_table_seats_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: table_waitlist fk_table_waitlist_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_waitlist
    ADD CONSTRAINT fk_table_waitlist_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: tables fk_tables_club_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT fk_tables_club_id FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: tournament_players fk_tournament_players_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_players
    ADD CONSTRAINT fk_tournament_players_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: union_admins fk_union_admins_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_admins
    ADD CONSTRAINT fk_union_admins_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: unions fk_unions_owner_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unions
    ADD CONSTRAINT fk_unions_owner_id_profiles FOREIGN KEY (owner_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_daily_streaks fk_user_daily_streaks_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_daily_streaks
    ADD CONSTRAINT fk_user_daily_streaks_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_diamond_balance fk_user_diamond_balance_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_diamond_balance
    ADD CONSTRAINT fk_user_diamond_balance_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_diamonds fk_user_diamonds_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_diamonds
    ADD CONSTRAINT fk_user_diamonds_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: user_mfa_factors fk_user_mfa_factors_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_mfa_factors
    ADD CONSTRAINT fk_user_mfa_factors_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: wallet_transactions fk_wallet_transactions_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT fk_wallet_transactions_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: wallets fk_wallets_user_id_profiles; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT fk_wallets_user_id_profiles FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: friendships friendships_friend_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_friend_id_fkey FOREIGN KEY (friend_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: friendships friendships_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.friendships
    ADD CONSTRAINT friendships_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: CONSTRAINT friendships_user_id_fkey ON friendships; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT friendships_user_id_fkey ON public.friendships IS 'Added 2026-09-05. Without it, deleting an account left its friendship edges behind; 3,990 such rows had accumulated and rendered as "Player Profile Unavailable" on /friends.';


--
-- Name: game_management_events game_management_events_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_management_events
    ADD CONSTRAINT game_management_events_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: game_management_events game_management_events_recipient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_management_events
    ADD CONSTRAINT game_management_events_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: game_management_events game_management_events_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_management_events
    ADD CONSTRAINT game_management_events_union_id_fkey FOREIGN KEY (union_id) REFERENCES public.unions(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_actor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_actor_id_fkey FOREIGN KEY (actor_id) REFERENCES public.profiles(id);


--
-- Name: poker_diamond_custody poker_diamond_custody_arena_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poker_diamond_custody
    ADD CONSTRAINT poker_diamond_custody_arena_id_fkey FOREIGN KEY (arena_id) REFERENCES public.clubs(id) ON DELETE RESTRICT;


--
-- Name: poker_diamond_custody poker_diamond_custody_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.poker_diamond_custody
    ADD CONSTRAINT poker_diamond_custody_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE RESTRICT;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: push_outbox push_outbox_recipient_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_outbox
    ADD CONSTRAINT push_outbox_recipient_user_id_fkey FOREIGN KEY (recipient_user_id) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: rake_records rake_records_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rake_records
    ADD CONSTRAINT rake_records_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE SET NULL;


--
-- Name: rake_records rake_records_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rake_records
    ADD CONSTRAINT rake_records_table_id_fkey FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE SET NULL;


--
-- Name: rake_records rake_records_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rake_records
    ADD CONSTRAINT rake_records_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE SET NULL;


--
-- Name: social_follows social_follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_follows
    ADD CONSTRAINT social_follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: social_follows social_follows_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_follows
    ADD CONSTRAINT social_follows_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: social_pages social_pages_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_pages
    ADD CONSTRAINT social_pages_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: table_seats table_seats_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_seats
    ADD CONSTRAINT table_seats_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id);


--
-- Name: table_seats table_seats_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_seats
    ADD CONSTRAINT table_seats_table_id_fkey FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: CONSTRAINT table_seats_table_id_fkey ON table_seats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT table_seats_table_id_fkey ON public.table_seats IS 'Declares the seat->table relationship. Also what lets PostgREST embed tables:table_id(...); without it those selects return PGRST200 / 400.';


--
-- Name: table_waitlist table_waitlist_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_waitlist
    ADD CONSTRAINT table_waitlist_table_id_fkey FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: table_waitlist table_waitlist_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.table_waitlist
    ADD CONSTRAINT table_waitlist_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id);


--
-- Name: tables tables_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES public.cash_games(id);


--
-- Name: tables tables_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id);


--
-- Name: tables tables_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id);


--
-- Name: tables tables_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tables
    ADD CONSTRAINT tables_union_id_fkey FOREIGN KEY (union_id) REFERENCES public.unions(id) ON DELETE CASCADE;


--
-- Name: tournament_bounties tournament_bounties_bounty_obligation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounties
    ADD CONSTRAINT tournament_bounties_bounty_obligation_id_fkey FOREIGN KEY (bounty_obligation_id) REFERENCES public.tournament_bounty_obligations(id) ON DELETE RESTRICT;


--
-- Name: tournament_bounties tournament_bounties_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounties
    ADD CONSTRAINT tournament_bounties_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_bounty_award_recipients tournament_bounty_award_recipients_award_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_award_recipients
    ADD CONSTRAINT tournament_bounty_award_recipients_award_id_fkey FOREIGN KEY (award_id) REFERENCES public.tournament_bounty_awards(id) ON DELETE CASCADE;


--
-- Name: tournament_bounty_awards tournament_bounty_awards_bounty_obligation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_awards
    ADD CONSTRAINT tournament_bounty_awards_bounty_obligation_id_fkey FOREIGN KEY (bounty_obligation_id) REFERENCES public.tournament_bounty_obligations(id) ON DELETE RESTRICT;


--
-- Name: tournament_bounty_awards tournament_bounty_awards_chest_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_awards
    ADD CONSTRAINT tournament_bounty_awards_chest_id_fkey FOREIGN KEY (chest_id) REFERENCES public.tournament_bounty_chests(id);


--
-- Name: tournament_bounty_awards tournament_bounty_awards_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_awards
    ADD CONSTRAINT tournament_bounty_awards_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_bounty_chests tournament_bounty_chests_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_chests
    ADD CONSTRAINT tournament_bounty_chests_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_bounty_completion_receipts tournament_bounty_completion_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_completion_receipts
    ADD CONSTRAINT tournament_bounty_completion_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_bounty_obligations tournament_bounty_obligations_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_bounty_obligations
    ADD CONSTRAINT tournament_bounty_obligations_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_cancellation_receipts tournament_cancellation_receipts_spin_unwind_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_cancellation_receipts
    ADD CONSTRAINT tournament_cancellation_receipts_spin_unwind_tournament_id_fkey FOREIGN KEY (spin_unwind_tournament_id) REFERENCES public.tournament_spin_cancellation_unwinds(tournament_id) ON DELETE RESTRICT;


--
-- Name: tournament_cancellation_receipts tournament_cancellation_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_cancellation_receipts
    ADD CONSTRAINT tournament_cancellation_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_capacity_table_receipts tournament_capacity_table_receipts_manager_wake_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_capacity_table_receipts
    ADD CONSTRAINT tournament_capacity_table_receipts_manager_wake_id_fkey FOREIGN KEY (manager_wake_id) REFERENCES public.tournament_manager_wakes(id) ON DELETE RESTRICT;


--
-- Name: tournament_capacity_table_receipts tournament_capacity_table_receipts_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_capacity_table_receipts
    ADD CONSTRAINT tournament_capacity_table_receipts_table_id_fkey FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE;


--
-- Name: tournament_capacity_table_receipts tournament_capacity_table_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_capacity_table_receipts
    ADD CONSTRAINT tournament_capacity_table_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_deal_votes tournament_deal_votes_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_deal_votes
    ADD CONSTRAINT tournament_deal_votes_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_final_table_deal_batches tournament_final_table_deal_batches_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_final_table_deal_batches
    ADD CONSTRAINT tournament_final_table_deal_batches_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_finish_receipts tournament_finish_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_finish_receipts
    ADD CONSTRAINT tournament_finish_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_guarantee_overlays tournament_guarantee_overlays_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_guarantee_overlays
    ADD CONSTRAINT tournament_guarantee_overlays_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE SET NULL;


--
-- Name: tournament_guarantee_overlays tournament_guarantee_overlays_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_guarantee_overlays
    ADD CONSTRAINT tournament_guarantee_overlays_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_launch_receipts tournament_launch_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_launch_receipts
    ADD CONSTRAINT tournament_launch_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_manager_wakes tournament_manager_wakes_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_manager_wakes
    ADD CONSTRAINT tournament_manager_wakes_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_mystery_activation_receipts tournament_mystery_activation_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_mystery_activation_receipts
    ADD CONSTRAINT tournament_mystery_activation_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_obligations tournament_obligations_adjustment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_obligations
    ADD CONSTRAINT tournament_obligations_adjustment_id_fkey FOREIGN KEY (adjustment_id) REFERENCES public.ca_manual_adjustments(id);


--
-- Name: tournament_obligations tournament_obligations_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_obligations
    ADD CONSTRAINT tournament_obligations_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_payouts tournament_payouts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_payouts
    ADD CONSTRAINT tournament_payouts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_place_settlement_batches tournament_place_settlement_batches_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_place_settlement_batches
    ADD CONSTRAINT tournament_place_settlement_batches_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_players tournament_players_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_players
    ADD CONSTRAINT tournament_players_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id);


--
-- Name: tournament_players tournament_players_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_players
    ADD CONSTRAINT tournament_players_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_rake_settlements tournament_rake_settlements_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_rake_settlements
    ADD CONSTRAINT tournament_rake_settlements_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE SET NULL;


--
-- Name: tournament_rake_settlements tournament_rake_settlements_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_rake_settlements
    ADD CONSTRAINT tournament_rake_settlements_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_refund_authorizations tournament_refund_authorizations_entitlement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_authorizations
    ADD CONSTRAINT tournament_refund_authorizations_entitlement_id_fkey FOREIGN KEY (entitlement_id) REFERENCES public.tournament_refund_entitlements(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_authorizations tournament_refund_authorizations_source_wallet_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_authorizations
    ADD CONSTRAINT tournament_refund_authorizations_source_wallet_club_id_fkey FOREIGN KEY (source_wallet_club_id) REFERENCES public.clubs(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_refund_wallet_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlements_refund_wallet_club_id_fkey FOREIGN KEY (refund_wallet_club_id) REFERENCES public.clubs(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_source_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlements_source_ledger_id_fkey FOREIGN KEY (source_ledger_id) REFERENCES public.chip_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_source_satellite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlements_source_satellite_id_fkey FOREIGN KEY (source_satellite_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_source_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlements_source_ticket_id_fkey FOREIGN KEY (source_ticket_id) REFERENCES public.tournament_tickets(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_entitlements tournament_refund_entitlements_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_entitlements
    ADD CONSTRAINT tournament_refund_entitlements_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_tranches tournament_refund_tranches_credit_ledger_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_credit_ledger_id_fkey FOREIGN KEY (credit_ledger_id) REFERENCES public.chip_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_tranches tournament_refund_tranches_entitlement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_entitlement_id_fkey FOREIGN KEY (entitlement_id) REFERENCES public.tournament_refund_entitlements(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_tranches tournament_refund_tranches_idempotency_key_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_idempotency_key_fkey FOREIGN KEY (idempotency_key) REFERENCES public.wallet_credit_idempotency(key) ON DELETE RESTRICT;


--
-- Name: tournament_refund_tranches tournament_refund_tranches_obligation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_obligation_id_fkey FOREIGN KEY (obligation_id) REFERENCES public.tournament_obligations(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_tranches tournament_refund_tranches_source_wallet_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_source_wallet_club_id_fkey FOREIGN KEY (source_wallet_club_id) REFERENCES public.clubs(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_tranches tournament_refund_tranches_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_refund_tranches tournament_refund_tranches_wallet_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_refund_tranches
    ADD CONSTRAINT tournament_refund_tranches_wallet_transaction_id_fkey FOREIGN KEY (wallet_transaction_id) REFERENCES public.wallet_transactions(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_awards tournament_satellite_awards_obligation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_obligation_id_fkey FOREIGN KEY (obligation_id) REFERENCES public.tournament_obligations(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_awards tournament_satellite_awards_payout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_payout_id_fkey FOREIGN KEY (payout_id) REFERENCES public.tournament_payouts(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_awards tournament_satellite_awards_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tournament_tickets(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_awards tournament_satellite_awards_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_awards
    ADD CONSTRAINT tournament_satellite_awards_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournament_satellite_settlements(tournament_id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_economic_snapshots tournament_satellite_economic_snapsho_target_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_economic_snapshots
    ADD CONSTRAINT tournament_satellite_economic_snapsho_target_tournament_id_fkey FOREIGN KEY (target_tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_economic_snapshots tournament_satellite_economic_snapshots_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_economic_snapshots
    ADD CONSTRAINT tournament_satellite_economic_snapshots_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_entitlements tournament_satellite_entitlements_target_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_entitlements
    ADD CONSTRAINT tournament_satellite_entitlements_target_tournament_id_fkey FOREIGN KEY (target_tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_entitlements tournament_satellite_entitlements_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_entitlements
    ADD CONSTRAINT tournament_satellite_entitlements_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_settlement_batches tournament_satellite_settlement_batch_target_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_settlement_batches
    ADD CONSTRAINT tournament_satellite_settlement_batch_target_tournament_id_fkey FOREIGN KEY (target_tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_settlement_batches tournament_satellite_settlement_batches_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_settlement_batches
    ADD CONSTRAINT tournament_satellite_settlement_batches_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_settlements tournament_satellite_settlements_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_settlements
    ADD CONSTRAINT tournament_satellite_settlements_target_id_fkey FOREIGN KEY (target_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_settlements tournament_satellite_settlements_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_settlements
    ADD CONSTRAINT tournament_satellite_settlements_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_seat_exit_authorizations tournament_seat_exit_authorizations_seat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_seat_exit_authorizations
    ADD CONSTRAINT tournament_seat_exit_authorizations_seat_id_fkey FOREIGN KEY (seat_id) REFERENCES public.table_seats(id) ON DELETE RESTRICT;


--
-- Name: tournament_seat_exit_authorizations tournament_seat_exit_authorizations_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_seat_exit_authorizations
    ADD CONSTRAINT tournament_seat_exit_authorizations_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation__contribution_reversal_journa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation__contribution_reversal_journa_fkey FOREIGN KEY (contribution_reversal_journal_id) REFERENCES public.chip_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unw_original_entry_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unw_original_entry_journal_id_fkey FOREIGN KEY (original_entry_journal_id) REFERENCES public.chip_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwi_contribution_reversal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwi_contribution_reversal_id_fkey FOREIGN KEY (contribution_reversal_id) REFERENCES public.spin_reserve_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwi_draw_reversal_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwi_draw_reversal_journal_id_fkey FOREIGN KEY (draw_reversal_journal_id) REFERENCES public.chip_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwi_original_contribution_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwi_original_contribution_id_fkey FOREIGN KEY (original_contribution_id) REFERENCES public.spin_reserve_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwi_original_draw_journal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwi_original_draw_journal_id_fkey FOREIGN KEY (original_draw_journal_id) REFERENCES public.chip_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_draw_reversal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwinds_draw_reversal_id_fkey FOREIGN KEY (draw_reversal_id) REFERENCES public.spin_reserve_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_original_draw_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwinds_original_draw_id_fkey FOREIGN KEY (original_draw_id) REFERENCES public.spin_reserve_ledger(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_pool_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwinds_pool_id_fkey FOREIGN KEY (pool_id) REFERENCES public.spin_bonus_pools(id) ON DELETE RESTRICT;


--
-- Name: tournament_spin_cancellation_unwinds tournament_spin_cancellation_unwinds_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_spin_cancellation_unwinds
    ADD CONSTRAINT tournament_spin_cancellation_unwinds_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_table_origins tournament_table_origins_launch_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_table_origins
    ADD CONSTRAINT tournament_table_origins_launch_fk FOREIGN KEY (launch_id) REFERENCES public.tournament_launch_receipts(launch_id) ON DELETE RESTRICT;


--
-- Name: tournament_table_origins tournament_table_origins_table_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_table_origins
    ADD CONSTRAINT tournament_table_origins_table_fk FOREIGN KEY (table_id) REFERENCES public.tables(id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tournament_table_origins tournament_table_origins_tournament_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_table_origins
    ADD CONSTRAINT tournament_table_origins_tournament_fk FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE CASCADE;


--
-- Name: tournament_terminal_settlements tournament_terminal_settlements_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_terminal_settlements
    ADD CONSTRAINT tournament_terminal_settlements_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_ticket_admission_authorizations tournament_ticket_admission_authorizations_registration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_ticket_admission_authorizations
    ADD CONSTRAINT tournament_ticket_admission_authorizations_registration_id_fkey FOREIGN KEY (registration_id) REFERENCES public.tournament_players(id) ON DELETE RESTRICT;


--
-- Name: tournament_ticket_admission_authorizations tournament_ticket_admission_authorizations_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_ticket_admission_authorizations
    ADD CONSTRAINT tournament_ticket_admission_authorizations_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tournament_tickets(id) ON DELETE RESTRICT;


--
-- Name: tournament_ticket_admission_authorizations tournament_ticket_admission_authorizations_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_ticket_admission_authorizations
    ADD CONSTRAINT tournament_ticket_admission_authorizations_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_ticket_admission_authorizations tournament_ticket_admission_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_ticket_admission_authorizations
    ADD CONSTRAINT tournament_ticket_admission_authorizations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE RESTRICT;


--
-- Name: tournament_tickets tournament_tickets_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_tickets
    ADD CONSTRAINT tournament_tickets_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: tournament_tickets tournament_tickets_direct_satellite_award_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_tickets
    ADD CONSTRAINT tournament_tickets_direct_satellite_award_fkey FOREIGN KEY (source_satellite_id, source_satellite_award_place) REFERENCES public.tournament_satellite_awards(tournament_id, place) ON DELETE RESTRICT DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tournament_tickets tournament_tickets_source_refund_entitlement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_tickets
    ADD CONSTRAINT tournament_tickets_source_refund_entitlement_id_fkey FOREIGN KEY (source_refund_entitlement_id) REFERENCES public.tournament_refund_entitlements(id) ON DELETE RESTRICT;


--
-- Name: tournament_tickets tournament_tickets_source_satellite_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_tickets
    ADD CONSTRAINT tournament_tickets_source_satellite_id_fkey FOREIGN KEY (source_satellite_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_tickets tournament_tickets_source_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_tickets
    ADD CONSTRAINT tournament_tickets_source_tournament_id_fkey FOREIGN KEY (source_tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_unregistration_receipts tournament_unregistration_receipts_source_table_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_unregistration_receipts
    ADD CONSTRAINT tournament_unregistration_receipts_source_table_id_fkey FOREIGN KEY (source_table_id) REFERENCES public.tables(id) ON DELETE RESTRICT;


--
-- Name: tournament_unregistration_receipts tournament_unregistration_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_unregistration_receipts
    ADD CONSTRAINT tournament_unregistration_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_unregistration_receipts tournament_unregistration_receipts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_unregistration_receipts
    ADD CONSTRAINT tournament_unregistration_receipts_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE RESTRICT;


--
-- Name: tournaments tournaments_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT tournaments_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: tournaments tournaments_satellite_target_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournaments
    ADD CONSTRAINT tournaments_satellite_target_id_fkey FOREIGN KEY (satellite_target_id) REFERENCES public.tournaments(id);


--
-- Name: union_admins union_admins_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_admins
    ADD CONSTRAINT union_admins_union_id_fkey FOREIGN KEY (union_id) REFERENCES public.unions(id) ON DELETE CASCADE;


--
-- Name: union_admins union_admins_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_admins
    ADD CONSTRAINT union_admins_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: union_clubs union_clubs_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_clubs
    ADD CONSTRAINT union_clubs_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE CASCADE;


--
-- Name: union_clubs union_clubs_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_clubs
    ADD CONSTRAINT union_clubs_union_id_fkey FOREIGN KEY (union_id) REFERENCES public.unions(id) ON DELETE CASCADE;


--
-- Name: union_creators union_creators_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_creators
    ADD CONSTRAINT union_creators_added_by_fkey FOREIGN KEY (added_by) REFERENCES auth.users(id);


--
-- Name: union_creators union_creators_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_creators
    ADD CONSTRAINT union_creators_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: union_wallet_transactions union_wallet_transactions_club_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_wallet_transactions
    ADD CONSTRAINT union_wallet_transactions_club_id_fkey FOREIGN KEY (club_id) REFERENCES public.clubs(id) ON DELETE SET NULL;


--
-- Name: union_wallet_transactions union_wallet_transactions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_wallet_transactions
    ADD CONSTRAINT union_wallet_transactions_created_by_fkey FOREIGN KEY (created_by) REFERENCES auth.users(id) ON DELETE SET NULL;


--
-- Name: union_wallet_transactions union_wallet_transactions_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_wallet_transactions
    ADD CONSTRAINT union_wallet_transactions_union_id_fkey FOREIGN KEY (union_id) REFERENCES public.unions(id) ON DELETE CASCADE;


--
-- Name: union_wallets union_wallets_union_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.union_wallets
    ADD CONSTRAINT union_wallets_union_id_fkey FOREIGN KEY (union_id) REFERENCES public.unions(id) ON DELETE CASCADE;


--
-- Name: unions unions_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.unions
    ADD CONSTRAINT unions_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES auth.users(id);


--
-- Name: user_daily_streaks user_daily_streaks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_daily_streaks
    ADD CONSTRAINT user_daily_streaks_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_diamond_balance user_diamond_balance_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_diamond_balance
    ADD CONSTRAINT user_diamond_balance_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_diamonds user_diamonds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_diamonds
    ADD CONSTRAINT user_diamonds_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_mfa_factors user_mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_mfa_factors
    ADD CONSTRAINT user_mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: wallet_transactions wallet_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallet_transactions
    ADD CONSTRAINT wallet_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: wallets wallets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.wallets
    ADD CONSTRAINT wallets_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- Name: content_authors Admins manage authors; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins manage authors" ON public.content_authors TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = ( SELECT auth.uid() AS uid)) AND (profiles.is_admin = true))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM public.profiles
  WHERE ((profiles.id = ( SELECT auth.uid() AS uid)) AND (profiles.is_admin = true)))));


--
-- Name: spin_bonus_pools Anon read access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anon read access" ON public.spin_bonus_pools FOR SELECT USING (true);


--
-- Name: clubs Anyone can view clubs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view clubs" ON public.clubs FOR SELECT USING (true);


--
-- Name: clubs Authenticated users can create clubs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can create clubs" ON public.clubs FOR INSERT TO authenticated WITH CHECK ((owner_id = ( SELECT auth.uid() AS uid)));


--
-- Name: club_members Club staff can read club rosters; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Club staff can read club rosters" ON public.club_members FOR SELECT TO authenticated USING ((public.is_club_admin(club_id, ( SELECT auth.uid() AS uid)) OR (EXISTS ( SELECT 1
   FROM public.clubs c
  WHERE ((c.id = club_members.club_id) AND (c.owner_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: club_members Members can read own club memberships; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Members can read own club memberships" ON public.club_members FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: clubs Owners can update clubs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Owners can update clubs" ON public.clubs FOR UPDATE TO authenticated USING ((owner_id = ( SELECT auth.uid() AS uid))) WITH CHECK ((owner_id = ( SELECT auth.uid() AS uid)));


--
-- Name: player_stats Player stats are public; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Player stats are public" ON public.player_stats FOR SELECT USING (true);


--
-- Name: content_authors Public can read authors; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Public can read authors" ON public.content_authors FOR SELECT USING (true);


--
-- Name: table_seats Public read access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Public read access" ON public.table_seats FOR SELECT USING (true);


--
-- Name: wallets Service role full access wallets; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role full access wallets" ON public.wallets TO service_role USING (true) WITH CHECK (true);


--
-- Name: notifications Service role inserts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role inserts" ON public.notifications FOR INSERT TO service_role WITH CHECK (true);


--
-- Name: club_members Service role manages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role manages" ON public.club_members TO service_role USING (true);


--
-- Name: hand_history Service role manages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role manages" ON public.hand_history TO service_role USING (true);


--
-- Name: table_seats Service role manages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role manages" ON public.table_seats TO service_role USING (true);


--
-- Name: tournaments Service role manages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Service role manages" ON public.tournaments TO service_role USING (true);


--
-- Name: notifications Users can delete own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete own notifications" ON public.notifications FOR DELETE USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: wallets Users can insert own wallets; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert own wallets" ON public.wallets FOR INSERT WITH CHECK ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: club_members Users can join clubs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can join clubs" ON public.club_members FOR INSERT WITH CHECK (((user_id = ( SELECT auth.uid() AS uid)) AND (COALESCE(credit_limit, (0)::numeric) = (0)::numeric) AND (COALESCE(credit_used, (0)::numeric) = (0)::numeric) AND (agent_id IS NULL) AND (parent_agent_id IS NULL) AND ((role = ANY (ARRAY['member'::text, 'player'::text])) OR public.is_club_admin(club_id, ( SELECT auth.uid() AS uid)))));


--
-- Name: wallets Users can read own wallets; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can read own wallets" ON public.wallets FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: users Users can update own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own data" ON public.users FOR UPDATE USING ((id = ( SELECT auth.uid() AS uid)));


--
-- Name: notifications Users can update own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update own notifications" ON public.notifications FOR UPDATE USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: users Users can view own data; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own data" ON public.users FOR SELECT USING ((id = ( SELECT auth.uid() AS uid)));


--
-- Name: user_diamonds Users can view own diamonds; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own diamonds" ON public.user_diamonds FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: notifications Users can view own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own notifications" ON public.notifications FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: user_daily_streaks Users can view own streaks; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view own streaks" ON public.user_daily_streaks FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: chip_ledger Users can view their own transactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own transactions" ON public.chip_ledger FOR SELECT USING (((( SELECT auth.uid() AS uid) = performed_by) OR (( SELECT auth.uid() AS uid) = from_entity_id) OR (( SELECT auth.uid() AS uid) = to_entity_id)));


--
-- Name: user_diamond_balance Users view own balance; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users view own balance" ON public.user_diamond_balance FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: wallet_transactions Users view own transactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users view own transactions" ON public.wallet_transactions FOR SELECT USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: agent_commission_settlements acs_agent_reads_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY acs_agent_reads_own ON public.agent_commission_settlements FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: agent_commission_settlements acs_service_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY acs_service_only ON public.agent_commission_settlements TO service_role USING ((( SELECT auth.role() AS role) = 'service_role'::text));


--
-- Name: agent_commission_settlements acs_union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY acs_union_overseer_read ON public.agent_commission_settlements FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: push_outbox admin reads push outbox; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "admin reads push outbox" ON public.push_outbox FOR SELECT USING (public.is_admin());


--
-- Name: agent_commission_settlements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_commission_settlements ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_commission_unsettled_rollup; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_commission_unsettled_rollup ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_commissions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_commissions ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_commissions agent_commissions_service_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_commissions_service_only ON public.agent_commissions TO service_role USING ((( SELECT auth.role() AS role) = 'service_role'::text));


--
-- Name: agent_commissions agent_reads_own_commissions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_reads_own_commissions ON public.agent_commissions FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: agents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;

--
-- Name: agents agents_cashier_scoped_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agents_cashier_scoped_read ON public.agents FOR SELECT TO authenticated USING (((user_id = ( SELECT auth.uid() AS uid)) OR (public.fn_club_cashier_scope(club_id, ( SELECT auth.uid() AS uid)) = 'all'::text) OR ((public.fn_club_cashier_scope(club_id, ( SELECT auth.uid() AS uid)) = 'downline'::text) AND public.fn_club_cashier_can_transact(club_id, ( SELECT auth.uid() AS uid), user_id))));


--
-- Name: agents agents_svc; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agents_svc ON public.agents TO service_role USING (true);


--
-- Name: audit_trail; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_trail ENABLE ROW LEVEL SECURITY;

--
-- Name: bbj_hand_evidence_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bbj_hand_evidence_log ENABLE ROW LEVEL SECURITY;

--
-- Name: bbj_ledger_deletions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bbj_ledger_deletions ENABLE ROW LEVEL SECURITY;

--
-- Name: bbj_payouts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bbj_payouts ENABLE ROW LEVEL SECURITY;

--
-- Name: bbj_payouts bbj_payouts_admin_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bbj_payouts_admin_only ON public.bbj_payouts FOR SELECT TO authenticated USING (public.fn_is_platform_admin());


--
-- Name: bbj_pools; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bbj_pools ENABLE ROW LEVEL SECURITY;

--
-- Name: bbj_pools bbj_pools_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bbj_pools_select ON public.bbj_pools FOR SELECT USING (true);


--
-- Name: bbj_unclaimed_shares bbj_unclaimed_self_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bbj_unclaimed_self_select ON public.bbj_unclaimed_shares FOR SELECT TO authenticated USING (((user_id = ( SELECT auth.uid() AS uid)) OR public.fn_is_platform_admin()));


--
-- Name: bbj_unclaimed_shares; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bbj_unclaimed_shares ENABLE ROW LEVEL SECURITY;

--
-- Name: bomb_pot_award_units; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bomb_pot_award_units ENABLE ROW LEVEL SECURITY;

--
-- Name: bomb_pot_award_units bomb_pot_award_units_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY bomb_pot_award_units_read ON public.bomb_pot_award_units FOR SELECT TO authenticated USING (((user_id = ( SELECT auth.uid() AS uid)) OR (EXISTS ( SELECT 1
   FROM (public.tables t
     JOIN public.club_members cm ON ((cm.club_id = t.club_id)))
  WHERE ((t.id = bomb_pot_award_units.table_id) AND (cm.user_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: ca_arena_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_arena_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_cert_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_cert_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_club_commission_daily; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_club_commission_daily ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_club_player_daily; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_club_player_daily ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_club_rake_daily; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_club_rake_daily ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_club_tournament_daily; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_club_tournament_daily ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_club_tournament_player_daily; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_club_tournament_player_daily ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_detector_registry; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_detector_registry ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_diamond_balance_audit; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_diamond_balance_audit ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_diamond_engine_spend; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_diamond_engine_spend ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_diamond_house; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_diamond_house ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_diamond_incidents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_diamond_incidents ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_diamond_journal_archive; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_diamond_journal_archive ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_diamond_journal_archive ca_diamond_journal_archive_service_role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ca_diamond_journal_archive_service_role ON public.ca_diamond_journal_archive TO service_role USING (true) WITH CHECK (true);


--
-- Name: ca_diamond_rule_modes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_diamond_rule_modes ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_drift_incidents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_drift_incidents ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_financial_epochs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_financial_epochs ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_freeroll_free_buy_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_freeroll_free_buy_log ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_frozen_pool_deletions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_frozen_pool_deletions ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_hand_financial_facts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_hand_financial_facts ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_hand_player_idx; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_hand_player_idx ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_hand_player_idx ca_hand_player_idx_owner_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ca_hand_player_idx_owner_read ON public.ca_hand_player_idx FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: ca_hand_player_stat; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_hand_player_stat ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_incident_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_incident_events ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_incident_file_failures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_incident_file_failures ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_incident_notify_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_incident_notify_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_incident_recipients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_incident_recipients ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_ledger_day_manifest_restatements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_ledger_day_manifest_restatements ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_ledger_day_manifests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_ledger_day_manifests ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_ledger_maintenance_kinds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_ledger_maintenance_kinds ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_ledger_mutation_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_ledger_mutation_log ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_ledger_write_failures; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_ledger_write_failures ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_manual_adjustments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_manual_adjustments ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_mint_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_mint_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_mint_ledger ca_mint_ledger_admin_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ca_mint_ledger_admin_read ON public.ca_mint_ledger FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.id = ( SELECT auth.uid() AS uid)) AND (p.role = ANY (ARRAY['admin'::text, 'god'::text, 'superadmin'::text]))))));


--
-- Name: ca_mint_policy; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_mint_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_mint_policy ca_mint_policy_admin_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ca_mint_policy_admin_read ON public.ca_mint_policy FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.profiles p
  WHERE ((p.id = ( SELECT auth.uid() AS uid)) AND (p.role = ANY (ARRAY['admin'::text, 'god'::text, 'superadmin'::text]))))));


--
-- Name: ca_money_path_enforcement; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_money_path_enforcement ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_money_path_violations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_money_path_violations ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_op_claims; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_op_claims ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_operator_policy; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_operator_policy ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_payout_freeze; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_payout_freeze ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_player_restrictions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_player_restrictions ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_profile_deletions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_profile_deletions ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_restriction_observations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_restriction_observations ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_seat_stack_exits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_seat_stack_exits ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_settle_sources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_settle_sources ENABLE ROW LEVEL SECURITY;

--
-- Name: ca_treasury_baseline; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ca_treasury_baseline ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_cluster_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cash_cluster_events ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_game_roster; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cash_game_roster ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_games; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cash_games ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_games cash_games_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cash_games_read ON public.cash_games FOR SELECT TO authenticated USING (((NOT COALESCE((((ruleset_snapshot -> 'options'::text) ->> 'is_private'::text))::boolean, false)) OR (EXISTS ( SELECT 1
   FROM public.club_members cm
  WHERE ((cm.club_id = cash_games.club_id) AND (cm.user_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: cash_player_session; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cash_player_session ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_seat_change_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cash_seat_change_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_seat_moves; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cash_seat_moves ENABLE ROW LEVEL SECURITY;

--
-- Name: cash_seat_moves cash_seat_moves_read_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cash_seat_moves_read_own ON public.cash_seat_moves FOR SELECT TO authenticated USING ((player_id = ( SELECT auth.uid() AS uid)));


--
-- Name: club_members cashier_downline_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cashier_downline_read ON public.club_members FOR SELECT TO authenticated USING (((public.fn_club_cashier_scope(club_id, ( SELECT auth.uid() AS uid)) = 'downline'::text) AND public.fn_club_cashier_can_transact(club_id, ( SELECT auth.uid() AS uid), user_id)));


--
-- Name: tournament_tickets cashier_tournament_tickets_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cashier_tournament_tickets_read ON public.tournament_tickets FOR SELECT TO authenticated USING (((issued_by = ( SELECT auth.uid() AS uid)) OR (holder_id = ( SELECT auth.uid() AS uid)) OR (public.fn_club_cashier_scope(club_id, ( SELECT auth.uid() AS uid)) = 'all'::text)));


--
-- Name: cashout_requests cashout_no_client_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cashout_no_client_delete ON public.cashout_requests AS RESTRICTIVE FOR DELETE TO anon, authenticated USING (false);


--
-- Name: cashout_requests cashout_no_client_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cashout_no_client_insert ON public.cashout_requests AS RESTRICTIVE FOR INSERT TO anon, authenticated WITH CHECK (false);


--
-- Name: cashout_requests cashout_no_client_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cashout_no_client_update ON public.cashout_requests AS RESTRICTIVE FOR UPDATE TO anon, authenticated USING (false) WITH CHECK (false);


--
-- Name: cashout_requests cashout_read_scoped; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cashout_read_scoped ON public.cashout_requests FOR SELECT TO authenticated USING (((player_id = ( SELECT auth.uid() AS uid)) OR (agent_id = ( SELECT auth.uid() AS uid)) OR (public.fn_club_bank_role(club_id) = ANY (ARRAY['owner'::text, 'co_owner'::text, 'admin'::text])) OR public.fn_club_is_in_downline(club_id, ( SELECT auth.uid() AS uid), player_id)));


--
-- Name: cashout_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cashout_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: cashout_requests cashout_svc; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cashout_svc ON public.cashout_requests TO service_role USING (true);


--
-- Name: chip_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chip_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: chip_ledger_idem; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chip_ledger_idem ENABLE ROW LEVEL SECURITY;

--
-- Name: chip_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chip_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: chip_transactions chip_transactions_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY chip_transactions_select_own ON public.chip_transactions FOR SELECT TO authenticated USING (((( SELECT auth.uid() AS uid) = from_user_id) OR (( SELECT auth.uid() AS uid) = to_user_id)));


--
-- Name: audit_trail club admins read own club rows; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "club admins read own club rows" ON public.audit_trail FOR SELECT TO authenticated USING (((club_id IS NOT NULL) AND public.is_club_admin(club_id)));


--
-- Name: audit_trail club owners read own club rows; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "club owners read own club rows" ON public.audit_trail FOR SELECT TO authenticated USING ((club_id IN ( SELECT c.id
   FROM public.clubs c
  WHERE (c.owner_id = ( SELECT auth.uid() AS uid)))));


--
-- Name: club_wallets club owners read own club wallet; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "club owners read own club wallet" ON public.club_wallets FOR SELECT TO authenticated USING ((club_id IN ( SELECT c.id
   FROM public.clubs c
  WHERE (c.owner_id = ( SELECT auth.uid() AS uid)))));


--
-- Name: club_hand_daily_shard; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.club_hand_daily_shard ENABLE ROW LEVEL SECURITY;

--
-- Name: club_level_thresholds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.club_level_thresholds ENABLE ROW LEVEL SECURITY;

--
-- Name: club_level_thresholds club_level_thresholds_readable; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY club_level_thresholds_readable ON public.club_level_thresholds FOR SELECT TO anon, authenticated USING (true);


--
-- Name: club_member_daily_stats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.club_member_daily_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: club_member_table_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.club_member_table_state ENABLE ROW LEVEL SECURITY;

--
-- Name: club_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.club_members ENABLE ROW LEVEL SECURITY;

--
-- Name: club_members club_members_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY club_members_update ON public.club_members FOR UPDATE USING (((user_id = ( SELECT auth.uid() AS uid)) OR public.is_club_admin(club_id, ( SELECT auth.uid() AS uid)))) WITH CHECK ((public.is_club_admin(club_id, ( SELECT auth.uid() AS uid)) OR ((user_id = ( SELECT auth.uid() AS uid)) AND (role = ANY (ARRAY['member'::text, 'player'::text])) AND (COALESCE(credit_limit, (0)::numeric) = (0)::numeric) AND (COALESCE(credit_used, (0)::numeric) = (0)::numeric) AND (agent_id IS NULL) AND (parent_agent_id IS NULL))));


--
-- Name: club_wallets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.club_wallets ENABLE ROW LEVEL SECURITY;

--
-- Name: clubs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clubs ENABLE ROW LEVEL SECURITY;

--
-- Name: content_authors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.content_authors ENABLE ROW LEVEL SECURITY;

--
-- Name: daily_challenge_dashboard_revisions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.daily_challenge_dashboard_revisions ENABLE ROW LEVEL SECURITY;

--
-- Name: daily_challenge_event_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.daily_challenge_event_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: deep_stack_delete_attempts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.deep_stack_delete_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: diamond_engine_daily_caps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.diamond_engine_daily_caps ENABLE ROW LEVEL SECURITY;

--
-- Name: diamond_reward_budgets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.diamond_reward_budgets ENABLE ROW LEVEL SECURITY;

--
-- Name: diamond_reward_catalog; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.diamond_reward_catalog ENABLE ROW LEVEL SECURITY;

--
-- Name: diamond_reward_catalog diamond_reward_catalog_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY diamond_reward_catalog_read ON public.diamond_reward_catalog FOR SELECT USING (true);


--
-- Name: diamond_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.diamond_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: diamond_transactions diamond_transactions_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY diamond_transactions_select_own ON public.diamond_transactions FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: diamond_transactions diamond_transactions_service_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY diamond_transactions_service_only ON public.diamond_transactions TO service_role USING (true) WITH CHECK (true);


--
-- Name: diamond_user_daily_awards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.diamond_user_daily_awards ENABLE ROW LEVEL SECURITY;

--
-- Name: diamond_wallets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.diamond_wallets ENABLE ROW LEVEL SECURITY;

--
-- Name: diamond_wallets diamond_wallets_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY diamond_wallets_select_own ON public.diamond_wallets FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: engine_maintenance_break; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.engine_maintenance_break ENABLE ROW LEVEL SECURITY;

--
-- Name: engine_maintenance_thaws; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.engine_maintenance_thaws ENABLE ROW LEVEL SECURITY;

--
-- Name: engine_recovery_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.engine_recovery_events ENABLE ROW LEVEL SECURITY;

--
-- Name: engine_tournament_leases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.engine_tournament_leases ENABLE ROW LEVEL SECURITY;

--
-- Name: financial_alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.financial_alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: financial_alerts financial_alerts_service_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY financial_alerts_service_only ON public.financial_alerts TO service_role USING (true) WITH CHECK (true);


--
-- Name: friendships; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.friendships ENABLE ROW LEVEL SECURITY;

--
-- Name: friendships friendships_delete_participant; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY friendships_delete_participant ON public.friendships FOR DELETE TO authenticated USING (((( SELECT auth.uid() AS uid) = user_id) OR (( SELECT auth.uid() AS uid) = friend_id)));


--
-- Name: friendships friendships_insert_pending_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY friendships_insert_pending_self ON public.friendships FOR INSERT TO authenticated WITH CHECK (((( SELECT auth.uid() AS uid) = user_id) AND (friend_id <> user_id) AND (status = 'pending'::text)));


--
-- Name: friendships friendships_select_participant; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY friendships_select_participant ON public.friendships FOR SELECT TO authenticated USING (((( SELECT auth.uid() AS uid) = user_id) OR (( SELECT auth.uid() AS uid) = friend_id)));


--
-- Name: game_management_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.game_management_events ENABLE ROW LEVEL SECURITY;

--
-- Name: game_management_events game_management_events_authorized_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY game_management_events_authorized_read ON public.game_management_events FOR SELECT TO authenticated USING (((recipient_id = ( SELECT auth.uid() AS uid)) OR ((scope_kind = 'club'::text) AND public.fn_can_create_games(scope_id, ( SELECT auth.uid() AS uid))) OR ((scope_kind = 'union'::text) AND public.fn_is_union_operator(scope_id, ( SELECT auth.uid() AS uid)))));


--
-- Name: hand_atomic_commits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hand_atomic_commits ENABLE ROW LEVEL SECURITY;

--
-- Name: hand_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hand_history ENABLE ROW LEVEL SECURITY;

--
-- Name: hand_history hand_history_authenticated_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY hand_history_authenticated_select ON public.hand_history FOR SELECT TO authenticated USING ((players @> jsonb_build_array(jsonb_build_object('userId', (( SELECT auth.uid() AS uid))::text))));


--
-- Name: engine_maintenance_break maintenance_break_is_public; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY maintenance_break_is_public ON public.engine_maintenance_break FOR SELECT TO anon, authenticated USING (true);


--
-- Name: managed_game_contract_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.managed_game_contract_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: poker_diamond_custody own_custody; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY own_custody ON public.poker_diamond_custody FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: player_position_stats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.player_position_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: player_stats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.player_stats ENABLE ROW LEVEL SECURITY;

--
-- Name: player_stats player_stats_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY player_stats_self ON public.player_stats TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id)) WITH CHECK ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: tables poker_arena_diamond_tables; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY poker_arena_diamond_tables ON public.tables FOR SELECT TO authenticated USING (((EXISTS ( SELECT 1
   FROM public.clubs c
  WHERE ((c.id = tables.club_id) AND (c.asset = 'diamonds'::text)))) AND public.fn_poker_can_read_games(club_id)));


--
-- Name: tournaments poker_arena_diamond_tournaments; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY poker_arena_diamond_tournaments ON public.tournaments FOR SELECT TO authenticated USING (((EXISTS ( SELECT 1
   FROM public.clubs c
  WHERE ((c.id = tournaments.club_id) AND (c.asset = 'diamonds'::text)))) AND public.fn_poker_can_read_games(club_id)));


--
-- Name: tables poker_arena_table_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY poker_arena_table_access ON public.tables AS RESTRICTIVE FOR SELECT TO authenticated USING ((((club_id IS NULL) AND (union_id IS NULL)) OR (COALESCE(union_id, club_id) IN ( SELECT c.id
   FROM public.clubs c
  WHERE public.fn_poker_can_read_games(c.id)))));


--
-- Name: tables poker_arena_table_guest_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY poker_arena_table_guest_access ON public.tables AS RESTRICTIVE FOR SELECT TO anon USING (((club_id IS NULL) AND (union_id IS NULL)));


--
-- Name: tournaments poker_arena_tournament_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY poker_arena_tournament_access ON public.tournaments AS RESTRICTIVE FOR SELECT TO authenticated USING ((((club_id IS NULL) AND (union_id IS NULL)) OR (COALESCE(union_id, club_id) IN ( SELECT c.id
   FROM public.clubs c
  WHERE public.fn_poker_can_read_games(c.id)))));


--
-- Name: tournaments poker_arena_tournament_guest_access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY poker_arena_tournament_guest_access ON public.tournaments AS RESTRICTIVE FOR SELECT TO anon USING (((club_id IS NULL) AND (union_id IS NULL)));


--
-- Name: poker_diamond_custody; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.poker_diamond_custody ENABLE ROW LEVEL SECURITY;

--
-- Name: player_position_stats pps_select_authenticated; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY pps_select_authenticated ON public.player_position_stats FOR SELECT TO authenticated USING (true);


--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles profiles_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_delete ON public.profiles FOR DELETE USING ((( SELECT auth.uid() AS uid) = id));


--
-- Name: profiles profiles_insert_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_insert_self ON public.profiles FOR INSERT TO authenticated WITH CHECK ((( SELECT auth.uid() AS uid) = id));


--
-- Name: profiles profiles_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_select ON public.profiles FOR SELECT TO authenticated USING (true);


--
-- Name: profiles profiles_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY profiles_update ON public.profiles FOR UPDATE USING ((( SELECT auth.uid() AS uid) = id)) WITH CHECK ((( SELECT auth.uid() AS uid) = id));


--
-- Name: push_outbox; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.push_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: rake_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rake_records ENABLE ROW LEVEL SECURITY;

--
-- Name: rake_records rake_records_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rake_records_read ON public.rake_records FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.club_members cm
  WHERE ((cm.club_id = rake_records.club_id) AND (cm.user_id = ( SELECT auth.uid() AS uid)) AND (cm.role = ANY (ARRAY['owner'::text, 'co_owner'::text, 'admin'::text, 'agent'::text]))))));


--
-- Name: rake_records rake_records_svc; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rake_records_svc ON public.rake_records TO service_role USING (true);


--
-- Name: rakeback_stats_applied; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rakeback_stats_applied ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_trail service_role full access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "service_role full access" ON public.audit_trail TO service_role USING (true) WITH CHECK (true);


--
-- Name: club_wallets service_role full access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "service_role full access" ON public.club_wallets TO service_role USING (true) WITH CHECK (true);


--
-- Name: settlement_idempotency_keys service_role full access; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "service_role full access" ON public.settlement_idempotency_keys TO service_role USING (true) WITH CHECK (true);


--
-- Name: settlement_idempotency_keys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.settlement_idempotency_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: social_follows sf_del; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sf_del ON public.social_follows FOR DELETE USING ((( SELECT auth.uid() AS uid) = follower_id));


--
-- Name: social_follows sf_ins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sf_ins ON public.social_follows FOR INSERT WITH CHECK ((( SELECT auth.uid() AS uid) = follower_id));


--
-- Name: social_follows sf_sel; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sf_sel ON public.social_follows FOR SELECT USING (true);


--
-- Name: signup_errors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.signup_errors ENABLE ROW LEVEL SECURITY;

--
-- Name: signup_errors signup_errors_service_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY signup_errors_service_only ON public.signup_errors TO service_role USING (true) WITH CHECK (true);


--
-- Name: social_follows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.social_follows ENABLE ROW LEVEL SECURITY;

--
-- Name: social_pages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.social_pages ENABLE ROW LEVEL SECURITY;

--
-- Name: social_pages social_pages_owner_write; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY social_pages_owner_write ON public.social_pages TO authenticated USING ((( SELECT auth.uid() AS uid) = owner_id)) WITH CHECK ((( SELECT auth.uid() AS uid) = owner_id));


--
-- Name: social_pages social_pages_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY social_pages_read ON public.social_pages FOR SELECT USING (((COALESCE(is_public, false) = true) OR (owner_id = ( SELECT auth.uid() AS uid))));


--
-- Name: spin_bonus_pools; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.spin_bonus_pools ENABLE ROW LEVEL SECURITY;

--
-- Name: spin_bonus_pools spin_bonus_pools_service; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY spin_bonus_pools_service ON public.spin_bonus_pools TO service_role USING (true) WITH CHECK (true);


--
-- Name: spin_draw_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.spin_draw_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: spin_payout_ladder; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.spin_payout_ladder ENABLE ROW LEVEL SECURITY;

--
-- Name: spin_reserve_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.spin_reserve_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: spin_reserve_ledger spin_reserve_ledger_service; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY spin_reserve_ledger_service ON public.spin_reserve_ledger TO service_role USING (true) WITH CHECK (true);


--
-- Name: table_seats; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.table_seats ENABLE ROW LEVEL SECURITY;

--
-- Name: table_waitlist; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.table_waitlist ENABLE ROW LEVEL SECURITY;

--
-- Name: tables; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tables ENABLE ROW LEVEL SECURITY;

--
-- Name: tables tables_insert_owner_or_admin; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tables_insert_owner_or_admin ON public.tables FOR INSERT TO authenticated WITH CHECK (public.fn_can_create_games(club_id, ( SELECT auth.uid() AS uid)));


--
-- Name: tables tables_select_scoped; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tables_select_scoped ON public.tables FOR SELECT USING (((COALESCE(is_private, false) = false) OR (club_id IS NULL) OR public.is_club_member(club_id, ( SELECT auth.uid() AS uid)) OR (EXISTS ( SELECT 1
   FROM public.clubs c
  WHERE ((c.id = tables.club_id) AND (c.owner_id = ( SELECT auth.uid() AS uid))))) OR public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: tournament_deal_votes tdv_insert_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tdv_insert_own ON public.tournament_deal_votes FOR INSERT TO authenticated WITH CHECK (((user_id = ( SELECT auth.uid() AS uid)) AND (EXISTS ( SELECT 1
   FROM public.tournament_players tp
  WHERE ((tp.tournament_id = tournament_deal_votes.tournament_id) AND (tp.user_id = ( SELECT auth.uid() AS uid)) AND (tp.status = ANY (ARRAY['registered'::text, 'playing'::text])) AND (tp.eliminated_at IS NULL)))) AND (EXISTS ( SELECT 1
   FROM public.tournaments t
  WHERE ((t.id = tournament_deal_votes.tournament_id) AND COALESCE(t.final_table_deal_enabled, false) AND (t.status = 'RUNNING'::text))))));


--
-- Name: tournament_deal_votes tdv_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tdv_read ON public.tournament_deal_votes FOR SELECT TO authenticated USING (true);


--
-- Name: tournament_deal_votes tdv_service_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tdv_service_all ON public.tournament_deal_votes TO service_role USING (true) WITH CHECK (true);


--
-- Name: tournament_bounties; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_bounties ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_bounties tournament_bounties_public_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tournament_bounties_public_read ON public.tournament_bounties FOR SELECT USING (true);


--
-- Name: tournament_bounty_award_recipients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_bounty_award_recipients ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_bounty_awards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_bounty_awards ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_bounty_chests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_bounty_chests ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_bounty_completion_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_bounty_completion_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_bounty_obligations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_bounty_obligations ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_cancellation_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_cancellation_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_capacity_table_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_capacity_table_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_deal_votes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_deal_votes ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_escrow; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_escrow ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_final_table_deal_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_final_table_deal_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_finish_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_finish_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_guarantee_overlays; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_guarantee_overlays ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_knockout_candidates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_knockout_candidates ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_launch_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_launch_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_manager_wakes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_manager_wakes ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_mystery_activation_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_mystery_activation_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_obligations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_obligations ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_payouts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_payouts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_place_settlement_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_place_settlement_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_players; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_players ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_players tournament_players_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tournament_players_select ON public.tournament_players FOR SELECT USING (true);


--
-- Name: tournament_rake_settlements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_rake_settlements ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_refund_authorizations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_refund_authorizations ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_refund_entitlements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_refund_entitlements ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_refund_tranches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_refund_tranches ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_reminder_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_reminder_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_satellite_awards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_satellite_awards ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_satellite_economic_snapshots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_satellite_economic_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_satellite_entitlements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_satellite_entitlements ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_satellite_settlement_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_satellite_settlement_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_satellite_settlements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_satellite_settlements ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_seat_exit_authorizations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_seat_exit_authorizations ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_spin_cancellation_unwinds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_spin_cancellation_unwinds ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_table_origins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_table_origins ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_terminal_settlements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_terminal_settlements ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_ticket_admission_authorizations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_ticket_admission_authorizations ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_tickets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_tickets ENABLE ROW LEVEL SECURITY;

--
-- Name: tournament_unregistration_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_unregistration_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: tournaments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournaments ENABLE ROW LEVEL SECURITY;

--
-- Name: tournaments tournaments_select_scoped; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tournaments_select_scoped ON public.tournaments FOR SELECT USING (((COALESCE(is_private, false) = false) OR (club_id IS NULL) OR public.is_club_member(club_id, ( SELECT auth.uid() AS uid)) OR (EXISTS ( SELECT 1
   FROM public.clubs c
  WHERE ((c.id = tournaments.club_id) AND (c.owner_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: tournament_payouts tpay_read_self_field_or_staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tpay_read_self_field_or_staff ON public.tournament_payouts FOR SELECT TO authenticated USING (((user_id = ( SELECT auth.uid() AS uid)) OR (EXISTS ( SELECT 1
   FROM public.tournament_players tp
  WHERE ((tp.tournament_id = tournament_payouts.tournament_id) AND (tp.user_id = ( SELECT auth.uid() AS uid))))) OR (EXISTS ( SELECT 1
   FROM public.tournaments t
  WHERE ((t.id = tournament_payouts.tournament_id) AND (t.club_id IS NOT NULL) AND public.fn_is_club_admin_uid(t.club_id))))));


--
-- Name: tournament_payouts tpay_service_all; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tpay_service_all ON public.tournament_payouts TO service_role USING (true) WITH CHECK (true);


--
-- Name: union_wallet_transactions union_admin_view_wallet_txns; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_admin_view_wallet_txns ON public.union_wallet_transactions FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.union_admins
  WHERE ((union_admins.union_id = union_wallet_transactions.union_id) AND (union_admins.user_id = ( SELECT auth.uid() AS uid))))));


--
-- Name: union_admins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.union_admins ENABLE ROW LEVEL SECURITY;

--
-- Name: union_admins union_admins_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_admins_read ON public.union_admins FOR SELECT USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: union_admins union_admins_svc; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_admins_svc ON public.union_admins TO service_role USING (true);


--
-- Name: union_clubs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.union_clubs ENABLE ROW LEVEL SECURITY;

--
-- Name: union_clubs union_clubs_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_clubs_read ON public.union_clubs FOR SELECT USING (((EXISTS ( SELECT 1
   FROM public.union_admins ua
  WHERE ((ua.union_id = union_clubs.union_id) AND (ua.user_id = ( SELECT auth.uid() AS uid))))) OR (EXISTS ( SELECT 1
   FROM public.clubs c
  WHERE ((c.id = union_clubs.club_id) AND (c.owner_id = ( SELECT auth.uid() AS uid))))) OR (EXISTS ( SELECT 1
   FROM public.club_members cm
  WHERE ((cm.club_id = union_clubs.club_id) AND (cm.user_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: union_clubs union_clubs_svc; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_clubs_svc ON public.union_clubs TO service_role USING (true);


--
-- Name: union_creators; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.union_creators ENABLE ROW LEVEL SECURITY;

--
-- Name: union_creators union_creators_read_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_creators_read_self ON public.union_creators FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: union_creators union_creators_svc; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_creators_svc ON public.union_creators TO service_role USING (true) WITH CHECK (true);


--
-- Name: agent_commissions union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.agent_commissions FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: agents union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.agents FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: chip_transactions union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.chip_transactions FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: club_member_daily_stats union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.club_member_daily_stats FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: club_members union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.club_members FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: club_wallets union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.club_wallets FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: rake_records union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.rake_records FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND public.fn_union_oversees_club(club_id, ( SELECT auth.uid() AS uid))));


--
-- Name: table_seats union_overseer_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_overseer_read ON public.table_seats FOR SELECT TO authenticated USING ((( SELECT public.fn_is_any_union_overseer(( SELECT auth.uid() AS uid)) AS fn_is_any_union_overseer) AND (EXISTS ( SELECT 1
   FROM public.tables t
  WHERE ((t.id = table_seats.table_id) AND public.fn_is_union_overseer(t.union_id, ( SELECT auth.uid() AS uid)))))));


--
-- Name: union_rake_weekly; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.union_rake_weekly ENABLE ROW LEVEL SECURITY;

--
-- Name: union_wallet_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.union_wallet_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: union_wallets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.union_wallets ENABLE ROW LEVEL SECURITY;

--
-- Name: union_wallets union_wallets_admin_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_wallets_admin_read ON public.union_wallets FOR SELECT TO authenticated USING (((EXISTS ( SELECT 1
   FROM public.union_admins ua
  WHERE ((ua.union_id = union_wallets.union_id) AND (ua.user_id = ( SELECT auth.uid() AS uid))))) OR (EXISTS ( SELECT 1
   FROM public.unions u
  WHERE ((u.id = union_wallets.union_id) AND (u.owner_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: union_wallets union_wallets_service_only; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY union_wallets_service_only ON public.union_wallets TO service_role USING (true) WITH CHECK (true);


--
-- Name: unions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.unions ENABLE ROW LEVEL SECURITY;

--
-- Name: unions unions_public_browse; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY unions_public_browse ON public.unions FOR SELECT TO authenticated USING ((is_public IS NOT FALSE));


--
-- Name: unions unions_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY unions_read ON public.unions FOR SELECT USING (((owner_id = ( SELECT auth.uid() AS uid)) OR (EXISTS ( SELECT 1
   FROM public.union_admins ua
  WHERE ((ua.union_id = unions.id) AND (ua.user_id = ( SELECT auth.uid() AS uid)))))));


--
-- Name: unions unions_svc; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY unions_svc ON public.unions TO service_role USING (true);


--
-- Name: user_daily_streaks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_daily_streaks ENABLE ROW LEVEL SECURITY;

--
-- Name: user_diamond_balance; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_diamond_balance ENABLE ROW LEVEL SECURITY;

--
-- Name: user_diamonds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_diamonds ENABLE ROW LEVEL SECURITY;

--
-- Name: user_mfa_factors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: daily_challenge_dashboard_revisions users read own daily challenge revision; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "users read own daily challenge revision" ON public.daily_challenge_dashboard_revisions FOR SELECT TO authenticated USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: user_mfa_factors users_delete_own_mfa; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_delete_own_mfa ON public.user_mfa_factors FOR DELETE USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: user_mfa_factors users_insert_own_mfa; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_insert_own_mfa ON public.user_mfa_factors FOR INSERT WITH CHECK ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: user_mfa_factors users_read_own_mfa; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_read_own_mfa ON public.user_mfa_factors FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: user_mfa_factors users_update_own_mfa; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_update_own_mfa ON public.user_mfa_factors FOR UPDATE USING ((( SELECT auth.uid() AS uid) = user_id)) WITH CHECK ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: vip_points; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vip_points ENABLE ROW LEVEL SECURITY;

--
-- Name: vip_points_carry; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vip_points_carry ENABLE ROW LEVEL SECURITY;

--
-- Name: vip_points_carry vip_points_carry_read_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vip_points_carry_read_own ON public.vip_points_carry FOR SELECT USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: vip_points_ledger; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.vip_points_ledger ENABLE ROW LEVEL SECURITY;

--
-- Name: vip_points_ledger vip_points_ledger_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vip_points_ledger_select_own ON public.vip_points_ledger FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: vip_points vip_points_select_own; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY vip_points_select_own ON public.vip_points FOR SELECT USING ((( SELECT auth.uid() AS uid) = user_id));


--
-- Name: table_waitlist waitlist_admin_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY waitlist_admin_read ON public.table_waitlist FOR SELECT TO authenticated USING ((EXISTS ( SELECT 1
   FROM (public.tables pt
     JOIN public.club_members cm ON (((cm.club_id = pt.club_id) AND (cm.user_id = ( SELECT auth.uid() AS uid)))))
  WHERE ((pt.id = table_waitlist.table_id) AND (cm.role = ANY (ARRAY['owner'::text, 'co_owner'::text, 'admin'::text, 'super_agent'::text]))))));


--
-- Name: table_waitlist waitlist_public_queue_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY waitlist_public_queue_read ON public.table_waitlist FOR SELECT TO authenticated USING ((status = ANY (ARRAY['waiting'::text, 'notified'::text])));


--
-- Name: table_waitlist waitlist_user_own_read; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY waitlist_user_own_read ON public.table_waitlist FOR SELECT TO authenticated USING ((user_id = ( SELECT auth.uid() AS uid)));


--
-- Name: wallet_credit_idempotency; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.wallet_credit_idempotency ENABLE ROW LEVEL SECURITY;

--
-- Name: wallet_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.wallet_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: wallets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.wallets ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict gqQzeOBClGJ3nyXg9XJUx5BdsSaPRa42BalSgtwWfemTDJ7Ive7qIj3fNV5DAYc

