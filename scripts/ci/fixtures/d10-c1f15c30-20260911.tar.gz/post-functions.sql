SET check_function_bodies=false;
CREATE OR REPLACE FUNCTION auth.role()
 RETURNS text
 LANGUAGE sql
 STABLE
AS $function$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$function$
;
CREATE OR REPLACE FUNCTION auth.uid()
 RETURNS uuid
 LANGUAGE sql
 STABLE
AS $function$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$function$
;
CREATE OR REPLACE FUNCTION public.fn_can_create_games(p_club_id uuid, p_user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_own    uuid;
  v_member uuid;
BEGIN
  IF EXISTS (SELECT 1 FROM public.clubs WHERE id=p_club_id AND asset='diamonds') THEN RETURN false; END IF;
  IF p_club_id IS NULL OR p_user_id IS NULL THEN
    RETURN false;
  END IF;

  IF NOT EXISTS (SELECT 1 FROM clubs c WHERE c.id = p_club_id) THEN
    RETURN false;
  END IF;

  SELECT own_union_id, member_union_id INTO v_own, v_member
    FROM fn_club_union_context(p_club_id);

  IF v_own IS NOT NULL THEN
    RETURN EXISTS (SELECT 1 FROM unions u
                    WHERE u.id = v_own AND u.owner_id = p_user_id)
        OR EXISTS (SELECT 1 FROM union_admins a
                    WHERE a.union_id = v_own AND a.user_id = p_user_id)
        OR EXISTS (SELECT 1 FROM clubs c
                    WHERE c.id = p_club_id AND c.owner_id = p_user_id)
        OR EXISTS (SELECT 1 FROM club_members m
                    WHERE m.club_id = p_club_id AND m.user_id = p_user_id
                      AND m.role IN ('owner', 'co_owner', 'admin')
                      AND m.status IN ('active', 'approved'));
  END IF;

  IF v_member IS NOT NULL THEN
    RETURN EXISTS (SELECT 1 FROM unions u
                    WHERE u.id = v_member AND u.owner_id = p_user_id)
        OR EXISTS (SELECT 1 FROM union_admins a
                    WHERE a.union_id = v_member AND a.user_id = p_user_id);
  END IF;

  RETURN EXISTS (SELECT 1 FROM clubs c
                  WHERE c.id = p_club_id AND c.owner_id = p_user_id)
      OR EXISTS (SELECT 1 FROM club_members m
                  WHERE m.club_id = p_club_id
                    AND m.user_id = p_user_id
                    AND m.role IN ('owner', 'co_owner', 'admin')
                    AND m.status IN ('active', 'approved'));
END;
$function$
;
CREATE OR REPLACE FUNCTION public.fn_club_bank_role(p_club_id uuid, p_user_id uuid DEFAULT NULL::uuid)
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  select case
    when p_club_id is null then null
    when exists (select 1 from public.clubs c
                  where c.id = p_club_id
                    and c.owner_id = coalesce(p_user_id, auth.uid())) then 'owner'
    else (select cm.role from public.club_members cm
           where cm.club_id = p_club_id
             and cm.user_id = coalesce(p_user_id, auth.uid())
             and coalesce(cm.status, 'active') in ('active', 'approved')
           limit 1)
  end;
$function$
;
CREATE OR REPLACE FUNCTION public.fn_club_cashier_can_transact(p_club_id uuid, p_actor uuid, p_target uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  SELECT CASE
    WHEN p_club_id IS NULL OR p_actor IS NULL OR p_target IS NULL THEN false
    ELSE (
      SELECT CASE s.scope
        WHEN 'all'      THEN true
        WHEN 'downline' THEN public.fn_club_is_in_downline(p_club_id, p_actor, p_target)
        ELSE false
      END
      FROM (SELECT public.fn_club_cashier_scope(p_club_id, p_actor) AS scope) s
    )
  END;
$function$
;
CREATE OR REPLACE FUNCTION public.fn_club_cashier_scope(p_club_id uuid, p_user_id uuid DEFAULT NULL::uuid)
 RETURNS text
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  select case public.fn_club_bank_role(p_club_id, coalesce(p_user_id, auth.uid()))
    when 'owner'       then 'all'
    when 'co_owner'    then 'all'
    when 'admin'       then 'all'
    when 'super_agent' then 'downline'
    when 'agent'       then 'downline'
    when 'sub_agent'   then 'downline'
    else 'none'
  end;
$function$
;
CREATE OR REPLACE FUNCTION public.fn_is_any_union_overseer(p_user_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT p_user_id IS NOT NULL AND (
       EXISTS (SELECT 1 FROM unions u WHERE u.owner_id = p_user_id)
    OR EXISTS (SELECT 1 FROM union_admins a WHERE a.user_id = p_user_id)
    OR EXISTS (SELECT 1 FROM clubs c
                WHERE COALESCE(c.is_union, false) AND c.owner_id = p_user_id)
    OR EXISTS (SELECT 1 FROM club_members m
                JOIN clubs c2 ON c2.id = m.club_id AND COALESCE(c2.is_union, false)
               WHERE m.user_id = p_user_id AND m.role IN ('owner','co_owner','admin')
                 AND m.status IN ('active','approved'))
  );
$function$
;
CREATE OR REPLACE FUNCTION public.fn_is_club_admin_uid(p_club_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT EXISTS (
    SELECT 1 FROM public.club_members cm
    WHERE cm.club_id = p_club_id
      AND cm.user_id = auth.uid()
      AND cm.role IN ('owner','co_owner','admin','manager')
      AND COALESCE(cm.status, 'active') = 'active'
  );
$function$
;
CREATE OR REPLACE FUNCTION public.fn_is_union_operator(p_union_id uuid, p_user_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT p_union_id IS NOT NULL AND p_user_id IS NOT NULL AND (
    EXISTS (SELECT 1 FROM public.unions u WHERE u.id=p_union_id AND u.owner_id=p_user_id)
    OR EXISTS (SELECT 1 FROM public.union_admins a WHERE a.union_id=p_union_id AND a.user_id=p_user_id)
  )
$function$
;
CREATE OR REPLACE FUNCTION public.fn_is_union_overseer(p_union_id uuid, p_user_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT p_union_id IS NOT NULL AND p_user_id IS NOT NULL AND (
       EXISTS (SELECT 1 FROM public.unions u WHERE u.id = p_union_id AND u.owner_id = p_user_id)
    OR EXISTS (SELECT 1 FROM public.union_admins a WHERE a.union_id = p_union_id AND a.user_id = p_user_id)
    OR EXISTS (SELECT 1 FROM public.clubs c
                WHERE c.id = p_union_id AND COALESCE(c.is_union, false) AND c.owner_id = p_user_id)
    OR EXISTS (SELECT 1 FROM public.club_members m
                WHERE m.club_id = p_union_id AND m.user_id = p_user_id
                  AND m.role IN ('owner','co_owner','admin')
                  AND m.status IN ('active','approved'))
  );
$function$
;
CREATE OR REPLACE FUNCTION public.fn_poker_can_read_games(p_club_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE v_uid uuid := auth.uid(); v_club public.clubs%ROWTYPE;
BEGIN
  IF v_uid IS NULL THEN RETURN false; END IF;
  SELECT * INTO v_club FROM public.clubs WHERE id=p_club_id;
  IF NOT FOUND OR v_club.lifecycle_status = 'retired' THEN RETURN false; END IF;
  IF v_club.asset = 'diamonds' THEN
    RETURN v_club.is_platform AND v_club.union_id IS NULL
      AND EXISTS (SELECT 1 FROM public.ca_arena_settings WHERE club_id=v_club.id)
      AND EXISTS (SELECT 1 FROM public.profiles WHERE id=v_uid);
  END IF;
  IF v_club.asset IS DISTINCT FROM 'chips' OR v_club.is_platform THEN RETURN false; END IF;
  RETURN EXISTS (SELECT 1 FROM public.club_members m
    WHERE m.club_id=ANY(public.fn_club_scope_ids(p_club_id))
      AND m.user_id=v_uid AND m.status IN ('active','approved'))
    OR public.fn_union_oversees_club(p_club_id,v_uid);
END $function$
;
CREATE OR REPLACE FUNCTION public.fn_union_oversees_club(p_club_id uuid, p_user_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT p_club_id IS NOT NULL AND p_user_id IS NOT NULL AND public.fn_is_union_overseer(
    COALESCE(
      (SELECT uc.union_id FROM public.union_clubs uc WHERE uc.club_id = p_club_id LIMIT 1),
      (SELECT c.union_id FROM public.clubs c WHERE c.id = p_club_id)
    ),
    p_user_id
  );
$function$
;
CREATE OR REPLACE FUNCTION public.is_admin()
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$ SELECT EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role IN ('admin','god')); $function$
;
CREATE OR REPLACE FUNCTION public.is_club_admin(p_club_id uuid, p_user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public', 'extensions'
AS $function$
BEGIN
  IF EXISTS (SELECT 1 FROM public.clubs WHERE id=p_club_id AND asset='diamonds') THEN RETURN false; END IF;
    RETURN EXISTS (
        SELECT 1 FROM clubs WHERE id = p_club_id AND owner_id = p_user_id
    ) OR EXISTS (
        SELECT 1 FROM club_members
        WHERE club_id = p_club_id
        AND user_id = p_user_id
        AND role IN ('owner', 'co_owner', 'admin')
        AND status = 'active'
    );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.is_club_admin(p_club_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM public.club_members
    WHERE club_id = p_club_id
      AND user_id = auth.uid()
      AND role IN ('owner', 'co_owner', 'admin', 'manager', 'agent')
  );
END;
$function$
;
CREATE OR REPLACE FUNCTION public.is_club_member(p_club_id uuid, p_user_id uuid)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE
 SET search_path TO 'public', 'extensions'
AS $function$
BEGIN
    RETURN EXISTS (
        SELECT 1 FROM club_members
        WHERE club_id = p_club_id
        AND user_id = p_user_id
        AND status = 'active'
    );
END;
$function$
;