--
-- PostgreSQL database dump
--

\restrict uQSNTFTbXhZfmkTNabG3ybUj7oLC0fwfpxjeMhOcHBSb9o3fTNiSwdvzwk1FlHQ

-- Dumped from database version 17.11 (Homebrew)
-- Dumped by pg_dump version 17.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: push_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_outbox (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    recipient_user_id uuid,
    title text NOT NULL,
    body text NOT NULL,
    url text,
    icon_url text,
    badge_url text,
    tag text,
    status text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    failure_reason text,
    related_entity_id uuid,
    event text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    sent_at timestamp with time zone,
    claimed_at timestamp with time zone,
    image_url text,
    CONSTRAINT push_outbox_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'sent'::text, 'failed'::text, 'skipped'::text])))
);


--
-- Name: COLUMN push_outbox.image_url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.push_outbox.image_url IS 'Optional large hero image for the notification (Chrome/Android `image`). Ignored by Safari/iOS/Firefox.';


--
-- Name: ca_drift_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_drift_incidents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    detected_at timestamp with time zone DEFAULT now() NOT NULL,
    deadline_at timestamp with time zone DEFAULT (now() + '00:20:00'::interval) NOT NULL,
    classification text DEFAULT 'unknown'::text NOT NULL,
    severity text DEFAULT 'critical'::text NOT NULL,
    layer text DEFAULT 'unknown'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    source text NOT NULL,
    dedupe_key text NOT NULL,
    union_id uuid,
    club_id uuid,
    entity_type text,
    entity_id uuid,
    table_id uuid,
    tournament_id uuid,
    hand_id uuid,
    settlement_id text,
    wallet_ids uuid[],
    transaction_ids uuid[],
    currency text DEFAULT 'club_chips'::text NOT NULL,
    expected_amount numeric,
    actual_amount numeric,
    discrepancy_amount numeric DEFAULT 0 NOT NULL,
    ledger_balanced boolean,
    suspected_cause text,
    auto_repair_status text DEFAULT 'pending'::text NOT NULL,
    escalation_level integer DEFAULT 0 NOT NULL,
    past_target boolean DEFAULT false NOT NULL,
    occurrences integer DEFAULT 1 NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    acknowledged_by uuid,
    acknowledged_at timestamp with time zone,
    assigned_to uuid,
    root_cause text,
    correction_ref text,
    resolution text,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_drift_incidents_auto_repair_status_check CHECK ((auto_repair_status = ANY (ARRAY['pending'::text, 'running'::text, 'repaired'::text, 'manual_needed'::text, 'not_applicable'::text]))),
    CONSTRAINT ca_drift_incidents_classification_check CHECK ((classification = ANY (ARRAY['ledger_imbalance'::text, 'settlement_error'::text, 'duplicate_payment'::text, 'missing_payment'::text, 'projection_delay'::text, 'cache_mismatch'::text, 'reporting_mismatch'::text, 'delayed_event'::text, 'duplicate_event'::text, 'rounding_error'::text, 'incorrect_rake'::text, 'incorrect_weighted_rake'::text, 'incorrect_rakeback'::text, 'bbj_error'::text, 'treasury_error'::text, 'credit_line_error'::text, 'cross_club_posting'::text, 'cross_union_posting'::text, 'unauthorized_adjustment'::text, 'historical_migration'::text, 'unknown'::text]))),
    CONSTRAINT ca_drift_incidents_layer_check CHECK ((layer = ANY (ARRAY['ledger'::text, 'projection'::text, 'cache'::text, 'reporting'::text, 'settlement'::text, 'unknown'::text]))),
    CONSTRAINT ca_drift_incidents_severity_check CHECK ((severity = ANY (ARRAY['critical'::text, 'warning'::text, 'info'::text]))),
    CONSTRAINT ca_drift_incidents_status_check CHECK ((status = ANY (ARRAY['open'::text, 'acknowledged'::text, 'reconciling'::text, 'resolved'::text])))
);


--
-- Name: ca_player_restrictions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_player_restrictions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    scope text NOT NULL,
    reason_code text NOT NULL,
    reason_note text,
    status text DEFAULT 'active'::text NOT NULL,
    applied_by uuid,
    applied_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone,
    approval_id uuid,
    lifted_by uuid,
    lifted_at timestamp with time zone,
    lift_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_player_restrictions_expiry_after_start CHECK (((expires_at IS NULL) OR (expires_at > applied_at))),
    CONSTRAINT ca_player_restrictions_lift_is_attributed CHECK (((status <> 'lifted'::text) OR ((lifted_at IS NOT NULL) AND (lifted_by IS NOT NULL)))),
    CONSTRAINT ca_player_restrictions_other_needs_a_note CHECK (((reason_code <> 'other'::text) OR (COALESCE(btrim(reason_note), ''::text) <> ''::text))),
    CONSTRAINT ca_player_restrictions_reason_known CHECK ((reason_code = ANY (ARRAY['collusion_suspected'::text, 'chip_dumping_suspected'::text, 'multi_accounting'::text, 'bot_or_rta_suspected'::text, 'abuse_or_harassment'::text, 'payment_dispute'::text, 'kyc_incomplete'::text, 'responsible_gaming'::text, 'self_requested'::text, 'security_compromise'::text, 'terms_violation'::text, 'other'::text]))),
    CONSTRAINT ca_player_restrictions_scope_known CHECK ((scope = ANY (ARRAY['account'::text, 'cash'::text, 'tournaments'::text, 'transfers'::text, 'social'::text]))),
    CONSTRAINT ca_player_restrictions_status_known CHECK ((status = ANY (ARRAY['active'::text, 'lifted'::text, 'expired'::text])))
);


--
-- Name: TABLE ca_player_restrictions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_player_restrictions IS 'Operator restrictions on a player account. One active row per scope per player. Horses and humans alike. Nothing here refuses anything until ca_operator_policy.restrictions_enforced is true.';


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    full_name text,
    display_name text,
    first_name text,
    last_name text,
    username text,
    email text,
    phone text,
    bio text,
    city text,
    state text,
    alias text,
    avatar_url text,
    role text DEFAULT 'user'::text,
    status text DEFAULT 'active'::text,
    is_vip boolean DEFAULT false,
    is_horse boolean DEFAULT false,
    is_admin boolean DEFAULT false,
    is_online boolean DEFAULT false,
    player_number text,
    diamonds integer DEFAULT 0 NOT NULL,
    diamond_balance integer DEFAULT 0,
    diamond_multiplier numeric(3,2) DEFAULT 1.00,
    level integer DEFAULT 1,
    tier text DEFAULT 'Newcomer'::text,
    skill_tier text DEFAULT 'Newcomer'::text,
    login_streak integer DEFAULT 0,
    streak_days integer DEFAULT 0,
    settings jsonb DEFAULT '{}'::jsonb,
    preferences jsonb DEFAULT '{}'::jsonb,
    social_page_id uuid,
    favorite_venue uuid,
    home_poker_club uuid,
    referred_by uuid,
    friends_count integer DEFAULT 0,
    hendon_total_cashes integer DEFAULT 0,
    hendon_total_earnings numeric DEFAULT 0,
    email_verified boolean DEFAULT false,
    phone_verified boolean DEFAULT false,
    onboarding_complete boolean DEFAULT false,
    last_login timestamp with time zone DEFAULT now(),
    last_login_date date DEFAULT CURRENT_DATE,
    last_seen timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    training_view_mode text DEFAULT 'grid'::text,
    last_trivia_date date,
    trivia_streak integer DEFAULT 0,
    trivia_high_score integer DEFAULT 0,
    total_hands_played integer DEFAULT 0,
    notification_token text,
    referral_code text,
    horse_status character varying DEFAULT 'available'::character varying,
    horse_profile jsonb DEFAULT '{}'::jsonb,
    sounds_enabled boolean DEFAULT true,
    vibrations_enabled boolean DEFAULT true,
    show_stack_bb boolean DEFAULT false,
    birth_year integer,
    favorite_hand_type text DEFAULT 'holdem'::text,
    card_back_preference text DEFAULT 'white'::text,
    country text,
    website text,
    twitter text,
    instagram text,
    hendon_url text,
    favorite_game text,
    favorite_hand text,
    home_casino text,
    cover_photo_url text,
    favorite_hand_plo text,
    app_settings jsonb DEFAULT '{}'::jsonb,
    display_name_preference text DEFAULT 'full_name'::text,
    cover_photo_position text DEFAULT '50% 50%'::text,
    tiktok text,
    telegram text,
    birthday date,
    hendon_biggest_cash numeric,
    use_real_name boolean DEFAULT false,
    streak_count integer DEFAULT 0,
    access_tier text DEFAULT 'Full_Access'::text,
    vip_tier text,
    vip_expires_at timestamp with time zone,
    last_active timestamp with time zone DEFAULT now(),
    poker_near_me_preferences jsonb DEFAULT '{"geofenceAlerts": true, "locationEnabled": true, "showNewcomerFriendly": true}'::jsonb,
    can_review boolean DEFAULT true,
    deleted_reviews_count integer DEFAULT 0,
    kyc_status text DEFAULT 'NONE'::text NOT NULL,
    kyc_provider text,
    kyc_inquiry_id text,
    kyc_completed_at timestamp with time zone,
    kyc_rejection_reason text,
    age_verified boolean DEFAULT false NOT NULL,
    age_verified_at timestamp with time zone,
    jurisdiction_country text,
    mfa_required boolean DEFAULT false NOT NULL,
    hub_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    friend_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    store_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    messenger_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    reels_preferences jsonb DEFAULT '{}'::jsonb NOT NULL,
    over_18_attested_at timestamp with time zone,
    jurisdiction_region text,
    jurisdiction_acknowledged_at timestamp with time zone,
    home_games_onboarded_at timestamp with time zone,
    social_profile_completed boolean DEFAULT false NOT NULL,
    is_farming_flagged boolean DEFAULT false,
    stripe_customer_id text,
    club_arena_tos_accepted_at timestamp with time zone,
    bankroll_preferences jsonb,
    diamond_arena_preferences jsonb,
    memory_games_preferences jsonb,
    news_preferences jsonb,
    video_library_preferences jsonb,
    memory_elo integer,
    arena_avatar_url text,
    equipped_frame text,
    equipped_aura text,
    use_avatar_as_profile_pic boolean DEFAULT false,
    status_text text,
    player_tags text[] DEFAULT '{}'::text[],
    CONSTRAINT profiles_diamonds_nonnegative CHECK ((diamonds >= 0)),
    CONSTRAINT profiles_kyc_provider_check CHECK (((kyc_provider IS NULL) OR (kyc_provider = ANY (ARRAY['persona'::text, 'veriff'::text, 'jumio'::text, 'onfido'::text, 'stub'::text])))),
    CONSTRAINT profiles_kyc_status_check CHECK ((kyc_status = ANY (ARRAY['NONE'::text, 'PENDING'::text, 'APPROVED'::text, 'REJECTED'::text, 'EXPIRED'::text])))
)
WITH (autovacuum_vacuum_scale_factor='0.02', autovacuum_analyze_scale_factor='0.01', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: COLUMN profiles.tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.tier IS 'RANK LABEL, NOT A VIP COLUMN. The literal ''Newcomer'' on 1,313 of 1,313 rows as of 2026-09-05: AuthPage writes it at signup and nothing updates it. NEVER gate an entitlement on it - it is a constant, so every comparison against it is decided at signup. It has already caused two live defects (the VIP ring that never rendered, and the VIP avatar gate that stood open for every account). VIP is is_vip + vip_tier + vip_expires_at.';


--
-- Name: COLUMN profiles.skill_tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.skill_tier IS 'REAL, unlike tier and access_tier: 7 distinct values as of 2026-09-05.';


--
-- Name: COLUMN profiles.login_streak; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.login_streak IS 'LIVE. Consecutive-day login count. Maintained by AchievementTriggerService.onLogin, which claims the day against last_login_date BEFORE writing, so a page reload cannot advance it. This is the streak column - not streak_days.';


--
-- Name: COLUMN profiles.streak_days; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.streak_days IS 'DEAD as of 2026-08-29. Zero across all 1,023 profiles and never written by any code in this estate. DO NOT WIRE ANYTHING TO IT: BonusPage once read it and rendered a hardcoded day*10 chips ladder that disagreed with both BonusService and the claim RPC. The live streak is profiles.login_streak.';


--
-- Name: COLUMN profiles.last_login; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.last_login IS 'LIVE. Full timestamptz of the last sign-in, written by AuthPage. Used for dormancy display on the club roster. For streak arithmetic use last_login_date, which is the UTC DAY and is what onLogin compares against.';


--
-- Name: COLUMN profiles.last_login_date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.last_login_date IS 'LIVE. The UTC DAY of the last sign-in. The day guard for login_streak: onLogin returns immediately when this already equals today, so the streak advances at most once per day no matter how many auth events fire.';


--
-- Name: COLUMN profiles.total_hands_played; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.total_hands_played IS 'Maintained rollup of SUM(player_stats.hands_played) for this player, kept current by trg_sync_profile_total_hands. Held 6 across the entire platform until 2026-09-05 because nothing ever wrote it, which made every profile read 0 hands and made the hands leaderboard an ORDER BY on a constant. player_stats, keyed (user_id, club_id), remains the source of truth.';


--
-- Name: COLUMN profiles.app_settings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.app_settings IS 'User app settings (notifications, privacy, appearance, gameplay, display/sound). All settings save here for cross-device persistence.';


--
-- Name: COLUMN profiles.use_real_name; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.use_real_name IS 'When true, display real name (display_name) instead of poker alias (username) at the table';


--
-- Name: COLUMN profiles.access_tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.access_tier IS 'One distinct value across all 1,313 rows as of 2026-09-05, and no reader in the Club Arena client. Treat as unused until something sets it; do not gate on it.';


--
-- Name: COLUMN profiles.vip_tier; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.vip_tier IS 'REAL. ''lifetime'' | ''monthly'' | NULL - a membership KIND, not a ladder rung. Resolved with is_vip and vip_expires_at by src/utils/vipStatus.ts.';


--
-- Name: COLUMN profiles.kyc_status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.kyc_status IS 'Phase 7.1.4: NONE|PENDING|APPROVED|REJECTED|EXPIRED. Required APPROVED for real-money deposits.';


--
-- Name: COLUMN profiles.age_verified; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.age_verified IS 'Phase 7.1.4: true after user confirms 18+ (jurisdiction-dependent). Required for play-money launch.';


--
-- Name: COLUMN profiles.jurisdiction_country; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.jurisdiction_country IS 'Phase 7.1.4: ISO 3166-1 alpha-2 country code. Overrides profiles.country for compliance checks; falls back to country if NULL.';


--
-- Name: COLUMN profiles.mfa_required; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.mfa_required IS 'Phase 6.1.21: if true, API gates must refuse requests that arrive without a valid mfa_session cookie. Set automatically for admin + VIP accounts; users may opt in voluntarily.';


--
-- Name: COLUMN profiles.social_profile_completed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.social_profile_completed IS 'TRUE once the user has confirmed their name, chosen a unique @username, and supplied a phone number. Gates first-time entry to /hub/social-media for OAuth signups.';


--
-- Name: COLUMN profiles.arena_avatar_url; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.arena_avatar_url IS 'Club Arena avatar - library art only, never a photograph. Separate from avatar_url, which is the social media profile picture. Club Arena reads this column; the social media surfaces read avatar_url. Added 2026-08-21.';


--
-- Name: COLUMN profiles.equipped_frame; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.equipped_frame IS 'Denormalised from user_avatars so the game engine can read cosmetics without a join';


--
-- Name: COLUMN profiles.equipped_aura; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.equipped_aura IS 'Denormalised from user_avatars so the game engine can read cosmetics without a join';


--
-- Name: COLUMN profiles.status_text; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.profiles.status_text IS 'A player''s own short status line, e.g. "Grinding MTTs". NULL means they have not set one. Distinct from profiles.status, which is the account state and must never be displayed in its place.';


--
-- Name: CONSTRAINT profiles_diamonds_nonnegative ON profiles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT profiles_diamonds_nonnegative ON public.profiles IS 'DR1 / D13. A diamond balance is never negative. A chargeback larger than the balance books the remainder in diamond_debts. Every other subtractor of profiles.diamonds was read at pg_proc on 2026-09-03 and is guarded, either by a WHERE ... AND diamonds >= amount or by a pre-check under FOR UPDATE.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: bomb_pot_award_units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bomb_pot_award_units (
    id bigint NOT NULL,
    hand_history_id uuid NOT NULL,
    table_id uuid NOT NULL,
    hand_number bigint NOT NULL,
    pot_index integer NOT NULL,
    board smallint NOT NULL,
    side text DEFAULT 'high'::text NOT NULL,
    user_id uuid NOT NULL,
    amount numeric(15,2) NOT NULL,
    hand_name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT bomb_pot_award_units_side_check CHECK ((side = ANY (ARRAY['high'::text, 'low'::text])))
);


--
-- Name: hand_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hand_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    winner_name text,
    pot_size numeric(12,2),
    created_at timestamp with time zone DEFAULT now(),
    table_id uuid,
    tournament_id uuid,
    hand_number integer,
    game_variant text DEFAULT 'nlh'::text,
    small_blind numeric(12,2) DEFAULT 0,
    big_blind numeric(12,2) DEFAULT 0,
    rake_amount numeric(12,2) DEFAULT 0,
    community_cards text[],
    winners jsonb,
    players jsonb DEFAULT '[]'::jsonb,
    actions jsonb DEFAULT '[]'::jsonb,
    summary text,
    bbj_amount numeric(12,2) DEFAULT 0 NOT NULL,
    source text DEFAULT 'manual'::text,
    hand_name text,
    seed text,
    version text DEFAULT 'v1'::text,
    started_at timestamp with time zone DEFAULT now(),
    ended_at timestamp with time zone,
    hole_cards jsonb,
    board jsonb,
    reported boolean DEFAULT false NOT NULL,
    reported_at timestamp with time zone,
    button_seat smallint,
    has_human boolean,
    community_cards2 text[],
    pots jsonb,
    showdown jsonb,
    rit_boards jsonb,
    community_cards3 text[],
    bomb_pot jsonb,
    daily_mission_events jsonb,
    winners_by_board jsonb
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='2000', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='2000', autovacuum_vacuum_insert_threshold='10000', autovacuum_vacuum_insert_scale_factor='0.0', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: COLUMN hand_history.hole_cards; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_history.hole_cards IS 'Showdown-revealed holdings only, keyed by user id: {"<uuid>": [{"rank","suit"}]}. Cards that were MUCKED are deliberately never stored -- everything in here was already shown face-up to the whole table, so a hand participant reading this column learns nothing they did not already see.';


--
-- Name: COLUMN hand_history.button_seat; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_history.button_seat IS 'Dealer/button seat for this hand (1-9). Lets analysis derive each seat''s position (UTG/MP/CO/BTN/SB/BB) from players[].seat. Populated by the engine from currentHandDealerSeat at settlement. NULL for hands written before 2026-08-16.';


--
-- Name: COLUMN hand_history.has_human; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_history.has_human IS 'True if at least one seat in this hand belonged to a person rather than a horse. NULL means not classified yet — sp_prune_hand_history fills it lazily once the row is older than the horse retention window, so this costs nothing on the write path. Anything not positively identifiable as a horse counts as human, so the flag can only over-keep. Added 2026-08-20.';


--
-- Name: COLUMN hand_history.pots; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_history.pots IS 'Pot-level settlement for this hand: [{index, amount, eligible[]}] in pot order (0 = main). Written by ServerTableEngineSettlement from the engine''s own calculatePots() snapshot. NULL on rows written before 2026-08-25. Read by attributeKnockout() to credit a knockout to the winner(s) of the pot that held the busted player''s last chips (Dan section 29).';


--
-- Name: COLUMN hand_history.showdown; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_history.showdown IS 'Showdown reveal record: [{user_id, seat, reveal_order, mucked, hand_name?, hand_description?}]. Mucked entries carry no hand identity. NULL = no showdown or predates 2026-08-25.';


--
-- Name: COLUMN hand_history.rit_boards; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_history.rit_boards IS 'Run It Twice boards 2..N in run order (JSONB array of arrays of engine card strings, e.g. [["Ahearts","Kdiamonds",...],[...]]). NULL on single-run hands. Board 1 remains community_cards. Added 2026-08-26; boards 2..N also exist as rit_board_N: pseudo-actions in `actions` for rows that predate this column.';


--
-- Name: COLUMN hand_history.winners_by_board; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_history.winners_by_board IS 'Multi-board hands only (run it twice/three times, double/triple-board bomb pots): [{board, userId, amount, handName}] - who won each board, with what, for what pre-rake share. NULL on single-board hands. The paid totals are in winners.';


--
-- Name: agent_commission_settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_commission_settlements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    user_id uuid NOT NULL,
    union_id uuid,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    amount numeric NOT NULL,
    rows_count integer DEFAULT 0 NOT NULL,
    paid_at timestamp with time zone DEFAULT now() NOT NULL,
    settlement_ref text,
    CONSTRAINT agent_commission_settlements_amount_check CHECK (((amount >= (0)::numeric) AND (amount = round(amount, 2)))),
    CONSTRAINT agent_commission_settlements_check CHECK ((period_end > period_start)),
    CONSTRAINT chk_amount_is_two_decimal_places CHECK (((amount IS NULL) OR (amount = round(amount, 2))))
);


--
-- Name: TABLE agent_commission_settlements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.agent_commission_settlements IS 'Phase 7 (20260908): the periods round 2 has paid per (club, agent). A commission row created inside one of these periods is settled without carrying a settled_at of its own. Read through fn_agent_commission_paid_by_period; never through a row scan.';


--
-- Name: agent_commission_unsettled_rollup; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_commission_unsettled_rollup (
    club_id uuid NOT NULL,
    user_id uuid NOT NULL,
    owed numeric DEFAULT 0 NOT NULL,
    rows_behind bigint DEFAULT 0 NOT NULL,
    oldest_unsettled timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE agent_commission_unsettled_rollup; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.agent_commission_unsettled_rollup IS 'Per (club, agent) sum of agent_commissions rows with settled_at IS NULL, maintained by statement-level triggers on agent_commissions. Read by fn_ca_agent_payables. Rebuild with fn_rebuild_agent_commission_rollup().';


--
-- Name: agent_commissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_commissions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    user_id uuid NOT NULL,
    amount numeric DEFAULT 0,
    commission_rate numeric DEFAULT 0.1,
    source_type text DEFAULT 'rake'::text,
    source_id uuid,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    settled_at timestamp with time zone,
    CONSTRAINT chk_amount_is_two_decimal_places CHECK (((amount IS NULL) OR (amount = round(amount, 2))))
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='1000', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='1000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: COLUMN agent_commissions.settled_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.agent_commissions.settled_at IS 'Set by fn_settle_round2_club_to_agents when this commission has been paid out to the agent. NULL means still owed. Makes Round 2 idempotent.';


--
-- Name: agents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    club_id uuid NOT NULL,
    membership_id uuid,
    role text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    parent_agent_id uuid,
    commission_rate numeric(5,4) NOT NULL,
    player_rakeback_rate numeric(5,4) NOT NULL,
    credit_limit numeric(15,2) DEFAULT 0 NOT NULL,
    credit_used numeric(15,2) DEFAULT 0 NOT NULL,
    is_prepaid boolean DEFAULT false NOT NULL,
    business_balance numeric(15,2) DEFAULT 0 NOT NULL,
    player_balance numeric(15,2) DEFAULT 0 NOT NULL,
    promo_balance numeric(15,2) DEFAULT 0 NOT NULL,
    total_players integer DEFAULT 0 NOT NULL,
    active_player_count integer DEFAULT 0 NOT NULL,
    sub_agent_count integer DEFAULT 0 NOT NULL,
    weekly_rake_generated numeric(15,2) DEFAULT 0 NOT NULL,
    lifetime_earnings numeric(15,2) DEFAULT 0 NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    last_active_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    auto_rakeback_enabled boolean DEFAULT true,
    rakeback_percentage numeric(5,4) DEFAULT 0.0000,
    agent_wallet_balance numeric(18,2) DEFAULT 0,
    player_wallet_balance numeric(18,4) DEFAULT 0,
    promo_wallet_balance numeric(18,2) DEFAULT 0,
    lifetime_rake_generated numeric(18,4) DEFAULT 0,
    CONSTRAINT agents_agent_wallet_balance_nonneg CHECK ((agent_wallet_balance >= (0)::numeric)),
    CONSTRAINT agents_commission_rate_check CHECK (((commission_rate >= (0)::numeric) AND (commission_rate <= 0.70))),
    CONSTRAINT agents_credit_used_check CHECK ((credit_used >= (0)::numeric)),
    CONSTRAINT agents_player_rakeback_rate_check CHECK (((player_rakeback_rate >= (0)::numeric) AND (player_rakeback_rate <= 0.50))),
    CONSTRAINT agents_promo_wallet_balance_nonneg CHECK ((promo_wallet_balance >= (0)::numeric)),
    CONSTRAINT agents_role_check CHECK ((role = ANY (ARRAY['super_agent'::text, 'agent'::text, 'sub_agent'::text]))),
    CONSTRAINT agents_status_check CHECK ((status = ANY (ARRAY['active'::text, 'suspended'::text, 'frozen'::text]))),
    CONSTRAINT check_credit CHECK (((credit_used <= credit_limit) OR (is_prepaid = true))),
    CONSTRAINT chk_player_wallet_balance_is_two_decimal_places CHECK (((player_wallet_balance IS NULL) OR (player_wallet_balance = round(player_wallet_balance, 2))))
);


--
-- Name: COLUMN agents.promo_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.agents.promo_balance IS 'DEPRECATED 2026-08-15. Agent promo lives on club_members.promo_balance. Zero on every row.';


--
-- Name: COLUMN agents.promo_wallet_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.agents.promo_wallet_balance IS 'DEPRECATED 2026-08-15. Agent promo lives on club_members.promo_balance. Zero on every row.';


--
-- Name: audit_trail; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_trail (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor_id uuid NOT NULL,
    actor_role text NOT NULL,
    action text NOT NULL,
    target_type text NOT NULL,
    target_id uuid,
    club_id uuid,
    agent_id uuid,
    amount numeric(20,4),
    currency text DEFAULT 'CHIPS'::text,
    before_state jsonb,
    after_state jsonb,
    reason text,
    ip_address inet,
    user_agent text,
    request_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT audit_trail_actor_role_check CHECK ((actor_role = ANY (ARRAY['owner'::text, 'co_owner'::text, 'admin'::text, 'super_agent'::text, 'agent'::text, 'sub_agent'::text, 'player'::text, 'host'::text, 'union_admin'::text, 'platform_admin'::text, 'system'::text]))),
    CONSTRAINT chk_amount_is_two_decimal_places CHECK (((amount IS NULL) OR (amount = round(amount, 2))))
);


--
-- Name: TABLE audit_trail; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.audit_trail IS 'Append-only privileged-action log. Closes P0-G1/F1/F2.';


--
-- Name: signup_errors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.signup_errors (
    id bigint NOT NULL,
    user_id uuid,
    email text,
    trigger_name text NOT NULL,
    error_code text,
    error_msg text,
    raw_meta jsonb,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    forwarded_to_sentry timestamp with time zone
);


--
-- Name: TABLE signup_errors; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.signup_errors IS 'Append-only trail of trigger errors during auth.users INSERT. Triggers swallow exceptions to keep signup unblocked, but log here for forensics. Drained by /api/health/signup-errors and queried by the health-monitor cron.';


--
-- Name: COLUMN signup_errors.forwarded_to_sentry; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.signup_errors.forwarded_to_sentry IS 'When this row was pushed to Sentry by /api/cron/sentry-signup-bridge. NULL = pending. Set to NOW() the moment captureMessage succeeds. Indexed (partial) for fast "what is pending?" queries.';


--
-- Name: bbj_hand_evidence_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bbj_hand_evidence_log (
    id bigint NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    kind text NOT NULL,
    payout_id uuid,
    hand_id uuid,
    table_id uuid,
    hand_number bigint,
    db_role text DEFAULT CURRENT_USER NOT NULL,
    application text DEFAULT COALESCE(current_setting('application_name'::text, true), ''::text) NOT NULL,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: TABLE bbj_hand_evidence_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.bbj_hand_evidence_log IS 'Every time the hand behind a jackpot payout is deleted, or a payout is written without one. Append-only; never blocks anything.';


--
-- Name: bbj_hand_evidence_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.bbj_hand_evidence_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bbj_hand_evidence_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.bbj_hand_evidence_log_id_seq OWNED BY public.bbj_hand_evidence_log.id;


--
-- Name: bbj_ledger_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bbj_ledger_deletions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_table text NOT NULL,
    row_data jsonb NOT NULL,
    deleted_by_role text DEFAULT CURRENT_USER NOT NULL,
    application_name text DEFAULT current_setting('application_name'::text, true) NOT NULL,
    deleted_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: bbj_payouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bbj_payouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pool_id uuid NOT NULL,
    hand_id uuid,
    table_id uuid NOT NULL,
    hand_number bigint,
    winner_user_id uuid NOT NULL,
    loser_user_id uuid NOT NULL,
    total_amount numeric(20,2) NOT NULL,
    winner_share numeric(20,2) NOT NULL,
    loser_share numeric(20,2) NOT NULL,
    table_share numeric(20,2) NOT NULL,
    table_player_count integer NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    kind text DEFAULT 'main'::text NOT NULL,
    CONSTRAINT bbj_payouts_kind_check CHECK ((kind = ANY (ARRAY['main'::text, 'mini'::text])))
);


--
-- Name: TABLE bbj_payouts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.bbj_payouts IS 'BUG 014 FIX 2026-04-15 — master BBJ payout record';


--
-- Name: COLUMN bbj_payouts.kind; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bbj_payouts.kind IS 'main = the jackpot itself, paid as a percentage of main_balance. mini = a flat amount out of the backup reserve for a hand that came close but did not meet the main bar. Every existing row is main, which is what the default says.';


--
-- Name: bbj_pools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bbj_pools (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid,
    union_id uuid,
    pool_amount numeric(14,2) DEFAULT 0 NOT NULL,
    hands_contributed bigint DEFAULT 0,
    last_hit_at timestamp with time zone,
    last_hit_amount numeric(14,2) DEFAULT 0,
    last_winner_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    main_balance numeric(14,2) DEFAULT 0 NOT NULL,
    backup_balance numeric(14,2) DEFAULT 0 NOT NULL,
    promo_balance numeric(14,2) DEFAULT 0 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    total_contributed numeric DEFAULT 0,
    total_paid_out numeric(15,2) DEFAULT 0.00 NOT NULL,
    hit_count integer DEFAULT 0 NOT NULL,
    last_loser_id uuid,
    merged_into_pool_id uuid,
    alloc_cum_amount numeric(14,4) DEFAULT 0 NOT NULL,
    mini_reserve_floor numeric(14,2) DEFAULT 5000.00 NOT NULL,
    CONSTRAINT bbj_pools_backup_balance_nonneg CHECK ((backup_balance >= (0)::numeric)),
    CONSTRAINT bbj_pools_main_balance_nonneg CHECK ((main_balance >= (0)::numeric)),
    CONSTRAINT bbj_pools_promo_balance_nonneg CHECK ((promo_balance >= (0)::numeric)),
    CONSTRAINT chk_alloc_cum_amount_is_two_decimal_places CHECK (((alloc_cum_amount IS NULL) OR (alloc_cum_amount = round(alloc_cum_amount, 2))))
);


--
-- Name: COLUMN bbj_pools.pool_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bbj_pools.pool_amount IS 'LEGACY, and NOT a bank. The live banks are main_balance / backup_balance / promo_balance. This column is a pre-split accumulator that four functions can still write (record_rake, fn_union_promo_send, fn_resolve_bbj_pool, fn_complete_club_opening_setup) and that nothing reads: it holds 1,000.00 on one pool and 0.00 on the other four. It is deliberately NOT dropped - it is the only surviving record of that pool''s opening seed, and deleting a settled record to tidy a number is Dan''s call alone (CLAUDE.md 10.9). Do not start reading it as a balance; fn_bbj_conservation_check read it for one hour on 2026-09-07 and stopped, because a figure four writers can move is not a figure a money check can stand on.';


--
-- Name: COLUMN bbj_pools.merged_into_pool_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bbj_pools.merged_into_pool_id IS 'Set when a pool was merged into another (2026-08-19: JAQK club pool -> Midway union pool). Lifetime counters moved to the target; this pool''s bbj_contributions rows deliberately keep their original pool_id so history is not rewritten.';


--
-- Name: COLUMN bbj_pools.alloc_cum_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bbj_pools.alloc_cum_amount IS 'Running total of contributions this pool has allocated. The Triple Bank split rounds against this cumulative figure, not per hand, so the 50/25/25 spec holds to the cent forever instead of drifting toward backup on every unsplittable drop. See 20260823_bbj_split_residual_carry.sql.';


--
-- Name: COLUMN bbj_pools.mini_reserve_floor; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.bbj_pools.mini_reserve_floor IS 'Backup chips the Mini BBJ may never spend below, so the main jackpot always has something to reseed from (fn_bbj_reseed_main_from_backup). 5,000 by default against a 48,917 reserve growing 4,522/day. Raise it per pool if a club wants a deeper cushion.';


--
-- Name: bbj_unclaimed_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bbj_unclaimed_shares (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    payout_id uuid NOT NULL,
    pool_id uuid,
    table_id uuid,
    user_id uuid NOT NULL,
    amount numeric(14,2) NOT NULL,
    reason text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    paid_at timestamp with time zone,
    paid_note text,
    CONSTRAINT bbj_unclaimed_shares_amount_check CHECK ((amount > (0)::numeric))
);


--
-- Name: TABLE bbj_unclaimed_shares; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.bbj_unclaimed_shares IS 'A Bad Beat Jackpot share that could not be delivered because no club wallet resolved for the recipient. The chips were returned to the pool in the same transaction, so nothing is missing; this row is the record that the player is still owed it. BBJ phase 2.3.';


--
-- Name: bomb_pot_award_units_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.bomb_pot_award_units ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.bomb_pot_award_units_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ca_arena_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_arena_settings (
    id smallint DEFAULT 1 NOT NULL,
    club_id uuid,
    settlement_window_days integer DEFAULT 14 NOT NULL,
    note text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cash_games_enabled boolean DEFAULT false NOT NULL,
    CONSTRAINT ca_arena_settings_id_check CHECK ((id = 1)),
    CONSTRAINT ca_arena_settings_settlement_window_days_check CHECK ((settlement_window_days >= 0))
);


--
-- Name: TABLE ca_arena_settings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_arena_settings IS 'The Diamond Arena in one row: which club it is and how long a purchased lot must settle before it can be deposited (ruling 14). Dan owns the window.';


--
-- Name: COLUMN ca_arena_settings.cash_games_enabled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_arena_settings.cash_games_enabled IS 'Public Diamond cash release switch. Platform operations may enable only after complete gameplay certification and seven consecutive clean accounting days, zero suspense and no open critical Diamond incident.';


--
-- Name: ca_cert_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_cert_accounts (
    user_id uuid NOT NULL,
    reason text NOT NULL,
    tagged_at timestamp with time zone DEFAULT now() NOT NULL,
    active boolean DEFAULT true NOT NULL
);


--
-- Name: TABLE ca_cert_accounts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_cert_accounts IS 'Zero-drift phase 4: known cert/test/bot accounts, segregated in supply and revenue reporting. Registry rows plus the zero-UUID pattern (fn_ca_is_cert_account) identify the fleet even when harness accounts are recreated.';


--
-- Name: ca_club_commission_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_club_commission_daily (
    club_id uuid NOT NULL,
    stat_date date NOT NULL,
    amount numeric DEFAULT 0 NOT NULL,
    rows_counted bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_amount_is_two_decimal_places CHECK (((amount IS NULL) OR (amount = round(amount, 2))))
);


--
-- Name: TABLE ca_club_commission_daily; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_club_commission_daily IS 'Sum of agent_commissions.amount per (club, UTC day of created_at), settled or not. Maintained by the statement-level triggers on agent_commissions; rebuild with fn_rebuild_ca_club_commission_daily().';


--
-- Name: ca_club_player_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_club_player_daily (
    club_id uuid NOT NULL,
    user_id uuid NOT NULL,
    stat_date date NOT NULL,
    cash_net numeric DEFAULT 0 NOT NULL,
    tournament_net numeric DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_club_player_daily; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_club_player_daily IS 'Derived Club Data display facts. wallet_transactions remains authoritative. Maintained by ca_reporting_wallet_insert and repairable with ca_refresh_reporting_rollups.';


--
-- Name: ca_club_rake_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_club_rake_daily (
    club_id uuid NOT NULL,
    stat_date date NOT NULL,
    hands bigint DEFAULT 0 NOT NULL,
    rake numeric DEFAULT 0 NOT NULL,
    bbj numeric DEFAULT 0 NOT NULL,
    pot numeric DEFAULT 0 NOT NULL,
    source_rows bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_club_rake_daily; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_club_rake_daily IS 'Cash rake_records per (club, UTC day), attributed like club_table_daily: a union player''s share goes to their home club in that union, everything unattributable stays with the table''s club. hands = raked hands in which one of the club''s players contributed (every raked hand at the club''s tables for a standalone club); rake = attributed gross rake; bbj = bad-beat drop at the club''s tables; pot = gross pot of raked hands at the club''s tables. Maintained by statement-level triggers on rake_records; rebuild a day range with fn_ca_club_rake_daily_rebuild(start, end); reconciled hourly by fn_club_table_daily_catchup.';


--
-- Name: ca_club_tournament_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_club_tournament_daily (
    club_id uuid NOT NULL,
    tournament_id uuid NOT NULL,
    stat_date date NOT NULL,
    fee numeric DEFAULT 0 NOT NULL,
    winnings numeric DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_club_tournament_daily; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_club_tournament_daily IS 'Derived Club Data tournament fee/P&L facts. wallet_transactions and rake_records remain authoritative.';


--
-- Name: ca_club_tournament_player_daily; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_club_tournament_player_daily (
    club_id uuid NOT NULL,
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    stat_date date NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_club_tournament_player_daily; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_club_tournament_player_daily IS 'Derived distinct tournament participants for Club Data. Horses are deliberately included exactly like every other player.';


--
-- Name: ca_detector_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_detector_registry (
    source text NOT NULL,
    owner text NOT NULL,
    sla_hours integer DEFAULT 24 NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    auto_resolve_hours integer,
    retired_by text,
    note text DEFAULT ''::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_detector_registry_auto_resolve_hours_check CHECK (((auto_resolve_hours IS NULL) OR (auto_resolve_hours > 0))),
    CONSTRAINT ca_detector_registry_sla_hours_check CHECK ((sla_hours > 0)),
    CONSTRAINT ca_detector_registry_status_check CHECK ((status = ANY (ARRAY['active'::text, 'retired'::text])))
);


--
-- Name: TABLE ca_detector_registry; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_detector_registry IS 'Chip standard Phase 6.3: every ca_drift_incidents source has an owner, an SLA and a status; a retired detector files nothing; auto_resolve_hours closes a transient finding not seen again within the window.';


--
-- Name: ca_diamond_balance_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_diamond_balance_audit (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    user_id uuid NOT NULL,
    old_diamonds integer,
    new_diamonds integer,
    delta integer,
    is_cert boolean,
    db_role text,
    app_name text,
    journaled boolean DEFAULT false NOT NULL,
    writer text,
    money_path text
);


--
-- Name: COLUMN ca_diamond_balance_audit.journaled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_diamond_balance_audit.journaled IS 'Whether a diamond_transactions row existed for this user when the trigger ran, i.e. earlier in the same transaction. It is NOT "this movement was journalled": all eight sanctioned money paths write the balance BEFORE the journal row, so an AFTER trigger cannot see their journal row and this reads false for correct movements. The DR6 incident is gated on the writer for exactly that reason. Constant false for the 603 rows written before 2026-09-03.';


--
-- Name: COLUMN ca_diamond_balance_audit.writer; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_diamond_balance_audit.writer IS 'DR6: the innermost PL/pgSQL frame in PG_CONTEXT that is not the trigger itself, i.e. the function that actually wrote profiles.diamonds. NULL means the write came from a plain statement with no function around it. db_role cannot answer this question: every diamond writer is SECURITY DEFINER owned by postgres.';


--
-- Name: COLUMN ca_diamond_balance_audit.money_path; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_diamond_balance_audit.money_path IS 'DR6: current_setting(''app.money_path''), the path the writer DECLARED it was taking. NULL means it declared nothing. Compare with writer: a mismatch is a writer lying about itself.';


--
-- Name: ca_diamond_balance_audit_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ca_diamond_balance_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ca_diamond_balance_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ca_diamond_balance_audit_id_seq OWNED BY public.ca_diamond_balance_audit.id;


--
-- Name: ca_diamond_engine_spend; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_diamond_engine_spend (
    id bigint NOT NULL,
    period text NOT NULL,
    engine text NOT NULL,
    user_id uuid,
    amount bigint NOT NULL,
    journal_id uuid,
    at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_diamond_engine_spend; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_diamond_engine_spend IS 'One row per promotional award. Replaces the running total on diamond_reward_budgets.spent_diamonds, which serialised every award on the platform behind a single row and lost 5,860 of them to lock timeouts on 2026-09-08. journal_id is UNIQUE, so a replay counts once.';


--
-- Name: ca_diamond_engine_spend_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ca_diamond_engine_spend_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ca_diamond_engine_spend_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ca_diamond_engine_spend_id_seq OWNED BY public.ca_diamond_engine_spend.id;


--
-- Name: ca_diamond_house; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_diamond_house (
    id smallint DEFAULT 1 NOT NULL,
    balance numeric(20,0) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_diamond_house_balance_check CHECK ((balance >= (0)::numeric)),
    CONSTRAINT ca_diamond_house_id_check CHECK ((id = 1))
);


--
-- Name: TABLE ca_diamond_house; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_diamond_house IS 'DIAMOND HOUSE ACCOUNT: receives rake, fees, tournament cuts and forfeits; funds guarantees, freerolls, promos and horse bankrolls. Single row. Written only by registered diamond RPCs. Standard DR14.';


--
-- Name: ca_diamond_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_diamond_incidents (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    rule text NOT NULL,
    severity text DEFAULT 'info'::text NOT NULL,
    user_id uuid,
    amount numeric(20,0),
    writer text,
    db_role text DEFAULT CURRENT_USER NOT NULL,
    app_name text DEFAULT COALESCE(current_setting('application_name'::text, true), ''::text) NOT NULL,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    resolved_at timestamp with time zone,
    CONSTRAINT ca_diamond_incidents_severity_check CHECK ((severity = ANY (ARRAY['info'::text, 'warning'::text, 'critical'::text])))
);


--
-- Name: TABLE ca_diamond_incidents; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_diamond_incidents IS 'Log-only refusals and diamond standard incidents (DR1..DR16). A row here is a movement the rule WOULD have refused, or a trial-balance break, with the writer named. Nothing in this table blocks anything.';


--
-- Name: ca_diamond_incidents_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ca_diamond_incidents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ca_diamond_incidents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ca_diamond_incidents_id_seq OWNED BY public.ca_diamond_incidents.id;


--
-- Name: ca_diamond_journal_archive; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_diamond_journal_archive (
    id uuid NOT NULL,
    user_id uuid,
    type text,
    amount integer,
    balance_after integer,
    description text,
    reference_id text,
    created_at timestamp with time zone,
    transaction_type text,
    source text,
    metadata jsonb,
    counterparty text,
    issuance_class text,
    archived_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_profile_id uuid,
    deletion_reason text,
    archived_by_role text DEFAULT CURRENT_USER NOT NULL,
    archived_app text DEFAULT COALESCE(current_setting('application_name'::text, true), ''::text) NOT NULL
);


--
-- Name: TABLE ca_diamond_journal_archive; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_diamond_journal_archive IS 'Diamond journal rows preserved past the deletion of the player or the row. Written by fn_ca_journal_profile_deletion (before the CASCADE fires) and by fn_ca_journal_append_only (when app.ledger_maintenance permits a DELETE). No foreign keys by design: the point is to outlive profiles and auth.users. Diamond Accounting Standard DR5.';


--
-- Name: ca_diamond_rule_modes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_diamond_rule_modes (
    rule text NOT NULL,
    mode text DEFAULT 'log'::text NOT NULL,
    flip_after timestamp with time zone NOT NULL,
    clean_days_required integer DEFAULT 7 NOT NULL,
    flipped_at timestamp with time zone,
    flipped_by text,
    ruling text,
    note text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_diamond_rule_modes_clean_days_required_check CHECK ((clean_days_required >= 0)),
    CONSTRAINT ca_diamond_rule_modes_mode_check CHECK ((mode = ANY (ARRAY['log'::text, 'refuse'::text])))
);


--
-- Name: TABLE ca_diamond_rule_modes; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_diamond_rule_modes IS 'Diamond Accounting Standard: whether each promised-to-refuse rule logs or refuses. Flip with fn_ca_diamond_rule_flip, never by hand (docs/DIAMOND-RULINGS.md ruling 17).';


--
-- Name: chip_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chip_ledger (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    performed_by uuid NOT NULL,
    from_type text NOT NULL,
    from_entity_id uuid,
    from_label text,
    to_type text NOT NULL,
    to_entity_id uuid,
    to_label text,
    amount numeric(15,2) NOT NULL,
    category text DEFAULT 'transfer'::text NOT NULL,
    description text,
    notes text,
    club_id uuid,
    union_id uuid,
    table_id uuid,
    hand_id uuid,
    tournament_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key text,
    correlation_id uuid,
    causation_id uuid,
    settlement_id text,
    epoch_id integer,
    actor_service text,
    db_role text,
    pre_from_balance numeric,
    post_from_balance numeric,
    pre_to_balance numeric,
    post_to_balance numeric,
    status text DEFAULT 'posted'::text NOT NULL,
    metadata jsonb,
    chain_seq bigint,
    prev_hash text,
    row_hash text,
    CONSTRAINT chip_ledger_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT chip_ledger_no_diamond_category_check CHECK (((category !~* '^diamond'::text) AND (category !~* '_diamond'::text))),
    CONSTRAINT chip_ledger_positive_amount CHECK ((amount > (0)::numeric)),
    CONSTRAINT chip_ledger_status_check CHECK ((status = ANY (ARRAY['posted'::text, 'correction'::text, 'reversal'::text]))),
    CONSTRAINT chk_post_from_balance_is_two_decimal_places CHECK (((post_from_balance IS NULL) OR (post_from_balance = round(post_from_balance, 2)))),
    CONSTRAINT chk_post_to_balance_is_two_decimal_places CHECK (((post_to_balance IS NULL) OR (post_to_balance = round(post_to_balance, 2)))),
    CONSTRAINT chk_pre_from_balance_is_two_decimal_places CHECK (((pre_from_balance IS NULL) OR (pre_from_balance = round(pre_from_balance, 2)))),
    CONSTRAINT chk_pre_to_balance_is_two_decimal_places CHECK (((pre_to_balance IS NULL) OR (pre_to_balance = round(pre_to_balance, 2))))
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='1000', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='1000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: ca_financial_epochs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_financial_epochs (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    ended_at timestamp with time zone,
    is_current boolean DEFAULT false NOT NULL
);


--
-- Name: ca_financial_epochs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ca_financial_epochs ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ca_financial_epochs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ca_freeroll_free_buy_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_freeroll_free_buy_log (
    id bigint NOT NULL,
    tournament_id uuid NOT NULL,
    tournament_name text,
    op text NOT NULL,
    status text,
    changed jsonb NOT NULL,
    db_role text DEFAULT CURRENT_USER NOT NULL,
    app_name text DEFAULT COALESCE(current_setting('application_name'::text, true), ''::text) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_freeroll_free_buy_log; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_freeroll_free_buy_log IS 'One row per tournaments INSERT/UPDATE/BACKFILL that fn_freerolls_are_free_buy had to correct. `changed` is {column: {from, to}}. Added 2026-09-02 so the Free Buy rule''s activity is visible: a creator that keeps landing here is a creator that still passes the wrong settings.';


--
-- Name: ca_freeroll_free_buy_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ca_freeroll_free_buy_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ca_freeroll_free_buy_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ca_freeroll_free_buy_log_id_seq OWNED BY public.ca_freeroll_free_buy_log.id;


--
-- Name: ca_frozen_pool_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_frozen_pool_deletions (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    pool text DEFAULT 'public.wallets'::text NOT NULL,
    wallet_id uuid,
    user_id uuid,
    wallet_type text,
    deleted_balance numeric NOT NULL,
    row_created_at timestamp with time zone,
    db_role text,
    app_name text,
    reconstructed boolean DEFAULT false NOT NULL,
    note text
);


--
-- Name: ca_frozen_pool_deletions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ca_frozen_pool_deletions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ca_frozen_pool_deletions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ca_frozen_pool_deletions_id_seq OWNED BY public.ca_frozen_pool_deletions.id;


--
-- Name: ca_hand_financial_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_hand_financial_facts (
    hand_id uuid NOT NULL,
    table_id uuid,
    tournament_id uuid,
    hand_number integer,
    big_blind numeric,
    pot_size numeric,
    rake_amount numeric,
    bbj_amount numeric,
    winners jsonb,
    hand_created_at timestamp with time zone,
    captured_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_bbj_amount_is_two_decimal_places CHECK (((bbj_amount IS NULL) OR (bbj_amount = round(bbj_amount, 2)))),
    CONSTRAINT chk_rake_amount_is_two_decimal_places CHECK (((rake_amount IS NULL) OR (rake_amount = round(rake_amount, 2))))
)
WITH (autovacuum_freeze_max_age='174000000');


--
-- Name: ca_hand_player_idx; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_hand_player_idx (
    user_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    hand_id uuid NOT NULL
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='5000', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='5000', autovacuum_vacuum_insert_threshold='20000', autovacuum_vacuum_insert_scale_factor='0.0', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: ca_hand_player_stat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_hand_player_stat (
    user_id uuid NOT NULL,
    hand_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    is_cash boolean NOT NULL,
    tournament_id uuid,
    game_variant text NOT NULL,
    big_blind numeric NOT NULL,
    small_blind numeric NOT NULL,
    n_players integer,
    seat_position text NOT NULL,
    my_blind numeric NOT NULL,
    won_amt numeric NOT NULL,
    is_winner boolean NOT NULL,
    invested_actions numeric NOT NULL,
    aggro_cnt integer NOT NULL,
    call_cnt integer NOT NULL,
    vpip boolean NOT NULL,
    pfr boolean NOT NULL,
    folded boolean NOT NULL,
    three_bet boolean NOT NULL,
    three_bet_opp boolean NOT NULL,
    faced_three_bet boolean NOT NULL,
    folded_to_three_bet boolean NOT NULL,
    cbet_opp boolean NOT NULL,
    cbet_made boolean NOT NULL,
    showdown boolean NOT NULL,
    hand_secs numeric NOT NULL,
    profit numeric NOT NULL
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='20000', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='20000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: TABLE ca_hand_player_stat; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_hand_player_stat IS 'Precomputed per-(player,hand) statistics. Exists because reading 750 raw hand_history rows costs ~3,730 random page reads (~15s cold) against an 8s statement_timeout, so the Stats page was being CANCELLED on heavy accounts rather than merely being slow. Retention is the most recent 1,000 hands per player, which is ~585k rows, not 14.2m.';


--
-- Name: ca_incident_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_incident_events (
    id bigint NOT NULL,
    incident_id uuid NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    kind text NOT NULL,
    actor uuid,
    actor_label text,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT ca_incident_events_kind_check CHECK ((kind = ANY (ARRAY['created'::text, 'recurred'::text, 'notified'::text, 'escalated'::text, 'status_change'::text, 'repair_action'::text, 'comment'::text, 'assigned'::text, 'acknowledged'::text, 'resolved'::text, 'reopened'::text, 'notify_failed'::text, 'notify_withheld'::text])))
);


--
-- Name: ca_incident_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ca_incident_events ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ca_incident_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ca_incident_file_failures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_incident_file_failures (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    source text,
    dedupe_key text,
    classification text,
    severity text,
    discrepancy numeric,
    sqlstate text,
    message text,
    db_role text DEFAULT CURRENT_USER NOT NULL,
    app_name text DEFAULT COALESCE(current_setting('application_name'::text, true), ''::text) NOT NULL
);


--
-- Name: TABLE ca_incident_file_failures; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_incident_file_failures IS 'Every time fn_ca_raise_drift_incident could not file an incident. The function still swallows the error - it is called from settlement paths and must never roll one back - but the evidence now lands somewhere a person can read instead of only in the Postgres log. Added 2026-09-02 after 901 consecutive silent failures caused by one bad layer value.';


--
-- Name: ca_incident_notify_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_incident_notify_ledger (
    recipient_id uuid NOT NULL,
    finding_key text NOT NULL,
    state_hash text NOT NULL,
    last_kind text,
    last_incident_id uuid,
    last_sent_at timestamp with time zone DEFAULT now() NOT NULL,
    send_count integer DEFAULT 1 NOT NULL
);


--
-- Name: TABLE ca_incident_notify_ledger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_incident_notify_ledger IS 'What was actually delivered, keyed on the FINDING rather than on the incident row. fn_ca_incident_notify sends only when this table has no row for the (recipient, finding) or its state_hash has changed. Replaces the 5-minute digest window, which let every double through because it only collapsed from the third push onward.';


--
-- Name: COLUMN ca_incident_notify_ledger.finding_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_incident_notify_ledger.finding_key IS 'fn_ca_finding_key(dedupe_key, ...): the dedupe key with per-row salts and time buckets removed, plus scope. Two incident rows that are the same finding share it.';


--
-- Name: COLUMN ca_incident_notify_ledger.state_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_incident_notify_ledger.state_hash IS 'kind + severity + classification + layer + scope (+ escalation level). Deliberately excludes the amount: a standing drift whose number jitters is the same finding and must not re-page.';


--
-- Name: ca_incident_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_incident_recipients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scope text DEFAULT 'platform'::text NOT NULL,
    scope_id uuid,
    user_id uuid NOT NULL,
    min_severity text DEFAULT 'warning'::text NOT NULL,
    senior boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_incident_recipients_min_severity_check CHECK ((min_severity = ANY (ARRAY['critical'::text, 'warning'::text, 'info'::text]))),
    CONSTRAINT ca_incident_recipients_scope_check CHECK ((scope = ANY (ARRAY['platform'::text, 'financial_ops'::text, 'technical'::text, 'union'::text, 'club'::text])))
);


--
-- Name: ca_ledger_day_manifest_restatements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_ledger_day_manifest_restatements (
    id bigint NOT NULL,
    day date NOT NULL,
    restated_at timestamp with time zone DEFAULT now() NOT NULL,
    old_row_count bigint,
    new_row_count bigint,
    old_sha256 text,
    new_sha256 text,
    reason text NOT NULL,
    restated_by text,
    application text
);


--
-- Name: TABLE ca_ledger_day_manifest_restatements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_ledger_day_manifest_restatements IS 'Every time a day''s ledger manifest had to change, with the value it held before and why. A sanctioned change to history leaves the attestation corrected rather than silently wrong; the journal rows themselves are in ca_ledger_mutation_log.';


--
-- Name: ca_ledger_day_manifest_restatements_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ca_ledger_day_manifest_restatements ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ca_ledger_day_manifest_restatements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ca_ledger_day_manifests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_ledger_day_manifests (
    day date NOT NULL,
    row_count bigint NOT NULL,
    first_seq bigint,
    last_seq bigint,
    net_amount numeric NOT NULL,
    sha256 text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_checked_at timestamp with time zone,
    restated_at timestamp with time zone,
    CONSTRAINT chk_net_amount_is_two_decimal_places CHECK (((net_amount IS NULL) OR (net_amount = round(net_amount, 2))))
);


--
-- Name: COLUMN ca_ledger_day_manifests.last_checked_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_ledger_day_manifests.last_checked_at IS 'When this day was last re-read from chip_ledger and compared with the stored sha (by the writer or by the rotation in fn_ca_ledger_day_manifest_verify_all). NULL = never re-read since it was written.';


--
-- Name: COLUMN ca_ledger_day_manifests.restated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_ledger_day_manifests.restated_at IS 'When the attested fields last changed. Every change has a row in ca_ledger_day_manifest_restatements, written by the guard, not by convention.';


--
-- Name: ca_ledger_maintenance_kinds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_ledger_maintenance_kinds (
    kind text NOT NULL,
    severity text DEFAULT 'warning'::text NOT NULL,
    note text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_ledger_maintenance_kinds_severity_check CHECK ((severity = ANY (ARRAY['info'::text, 'warning'::text, 'critical'::text])))
);


--
-- Name: TABLE ca_ledger_maintenance_kinds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_ledger_maintenance_kinds IS 'Severity per app.ledger_maintenance reason PREFIX (split_part(reason, '':'', 1)). A kind registered here is filed at that severity by fn_ca_journal_append_only; an unregistered prefix is a warning. The kind must be the exact prefix the writer sets, character for character.';


--
-- Name: ca_ledger_mutation_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_ledger_mutation_log (
    id bigint NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    source_table text NOT NULL,
    operation text NOT NULL,
    db_role text NOT NULL,
    application text,
    reason text NOT NULL,
    old_row jsonb NOT NULL,
    new_row jsonb
);


--
-- Name: ca_ledger_mutation_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ca_ledger_mutation_log ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ca_ledger_mutation_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ca_ledger_write_failures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_ledger_write_failures (
    id bigint NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    club_id uuid,
    user_id uuid,
    delta numeric,
    sqlstate text,
    message text
);


--
-- Name: TABLE ca_ledger_write_failures; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_ledger_write_failures IS 'Ledger writes the club_members trigger had to swallow. The trigger must never refuse a money write, so failures land here instead of raising. Non-empty means the audit trail is losing rows: investigate immediately.';


--
-- Name: ca_ledger_write_failures_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ca_ledger_write_failures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ca_ledger_write_failures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ca_ledger_write_failures_id_seq OWNED BY public.ca_ledger_write_failures.id;


--
-- Name: ca_manual_adjustments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_manual_adjustments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    actor uuid NOT NULL,
    approver uuid,
    reason text NOT NULL,
    amount numeric(15,2) NOT NULL,
    target_kind text NOT NULL,
    target_id uuid,
    tournament_id uuid,
    status text DEFAULT 'proposed'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    approved_at timestamp with time zone,
    rejected_by uuid,
    rejected_at timestamp with time zone,
    decision_note text,
    actor_label text,
    approver_label text,
    asset text DEFAULT 'chips'::text NOT NULL,
    CONSTRAINT ca_manual_adjustments_amount_check CHECK (((amount <> (0)::numeric) AND (amount = round(amount, 2)))),
    CONSTRAINT ca_manual_adjustments_approved_has_approver CHECK (((status <> ALL (ARRAY['approved'::text, 'settled'::text])) OR ((approver IS NOT NULL) AND (approved_at IS NOT NULL)))),
    CONSTRAINT ca_manual_adjustments_asset_check CHECK ((asset = ANY (ARRAY['chips'::text, 'diamonds'::text]))),
    CONSTRAINT ca_manual_adjustments_asset_matches_target CHECK (((asset = 'diamonds'::text) = (target_kind = ANY (ARRAY['diamond_wallet'::text, 'diamond_house'::text])))),
    CONSTRAINT ca_manual_adjustments_four_eyes CHECK (((approver IS NULL) OR (approver <> actor))),
    CONSTRAINT ca_manual_adjustments_reason_check CHECK ((length(btrim(reason)) >= 20)),
    CONSTRAINT ca_manual_adjustments_rejected_has_rejecter CHECK (((status <> 'rejected'::text) OR ((rejected_by IS NOT NULL) AND (rejected_at IS NOT NULL)))),
    CONSTRAINT ca_manual_adjustments_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'approved'::text, 'settled'::text, 'rejected'::text]))),
    CONSTRAINT ca_manual_adjustments_target_kind_check CHECK ((target_kind = ANY (ARRAY['player_wallet'::text, 'promo_wallet'::text, 'club_treasury'::text, 'union_bank'::text, 'union_wallet'::text, 'agent_wallet'::text, 'club_wallet'::text, 'bbj_pool'::text, 'spin_reserve'::text, 'prize_liability'::text, 'bounty_liability'::text, 'diamond_wallet'::text, 'diamond_house'::text])))
);


--
-- Name: TABLE ca_manual_adjustments; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_manual_adjustments IS 'R6 four-eyes register for any manual money movement. One actor proposes, a DIFFERENT approver approves (CHECK approver <> actor). amount > 0 credits the target, < 0 debits it. fn_settle_tournament_obligation.p_adjustment_id is meant to require an approved row here (Lane A3 follow-up). No row here moves money by itself.';


--
-- Name: COLUMN ca_manual_adjustments.asset; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_manual_adjustments.asset IS 'DR13: which asset this manual movement is denominated in. Defaults to chips so every proposal written before 2026-09-03 reads correctly. diamond_wallet and diamond_house are the only diamond target kinds and the asset_matches_target CHECK keeps the two in step.';


--
-- Name: ca_mint_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_mint_ledger (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    op_id text NOT NULL,
    action text NOT NULL,
    asset text NOT NULL,
    holder_type text NOT NULL,
    holder_id uuid NOT NULL,
    holder_label text,
    amount numeric(20,2) NOT NULL,
    balance_before numeric(20,2) NOT NULL,
    balance_after numeric(20,2) NOT NULL,
    supply_after numeric(20,2) NOT NULL,
    reason text NOT NULL,
    performed_by uuid,
    performed_by_label text,
    db_role text DEFAULT CURRENT_USER NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    chip_ledger_id uuid,
    diamond_tx_id uuid,
    origin text GENERATED ALWAYS AS (
CASE
    WHEN (op_id ~~ 'ledger:%'::text) THEN 'journal'::text
    WHEN (op_id ~~ 'register-opening-baseline:%'::text) THEN 'baseline'::text
    WHEN (op_id ~~ 'register-opening-baseline-correction:%'::text) THEN 'baseline'::text
    WHEN (op_id ~~ 'baseline:%'::text) THEN 'baseline'::text
    WHEN (op_id ~~ 'diamond-mint:%'::text) THEN 'diamond-mint'::text
    WHEN (op_id ~~ 'club-opening-grant:%'::text) THEN 'opening-grant'::text
    WHEN (op_id ~~ 'seat_credit_erased:%'::text) THEN 'restoration'::text
    WHEN (op_id ~~ 'seed:%'::text) THEN 'seed'::text
    WHEN (op_id ~~ 'deletion:%'::text) THEN 'deletion'::text
    WHEN (op_id ~~ 'diamond-journal:purchase:%'::text) THEN 'purchase'::text
    WHEN (op_id ~~ 'diamond-journal:reward:%'::text) THEN 'reward'::text
    WHEN (op_id ~~ 'diamond-journal:promotion:%'::text) THEN 'promotion'::text
    WHEN (op_id ~~ 'diamond-journal:refund:%'::text) THEN 'refund'::text
    WHEN (op_id ~~ 'diamond-journal:spend:%'::text) THEN 'spend'::text
    WHEN (op_id ~~ 'diamond-journal:bridge:%'::text) THEN 'bridge'::text
    WHEN (op_id ~~ 'diamond-journal:adjustment:%'::text) THEN 'adjustment'::text
    WHEN (op_id ~~ 'diamond-journal:arena:%'::text) THEN 'arena'::text
    WHEN (op_id ~~ 'diamond-journal:%'::text) THEN 'unclassified'::text
    ELSE 'operator'::text
END) STORED,
    CONSTRAINT ca_mint_ledger_action_check CHECK ((action = ANY (ARRAY['mint'::text, 'burn'::text]))),
    CONSTRAINT ca_mint_ledger_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT ca_mint_ledger_asset_check CHECK ((asset = ANY (ARRAY['chips'::text, 'diamonds'::text]))),
    CONSTRAINT ca_mint_ledger_holder_type_check CHECK ((holder_type = ANY (ARRAY['club'::text, 'union'::text, 'player'::text, 'house'::text, 'circulation'::text]))),
    CONSTRAINT ca_mint_ledger_reason_check CHECK ((length(btrim(reason)) >= 10))
);


--
-- Name: TABLE ca_mint_ledger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_mint_ledger IS 'THE MINT: append-only record of every authorized issuance and retirement of chips and diamonds. Written only by fn_ca_mint and fn_ca_burn.';


--
-- Name: COLUMN ca_mint_ledger.holder_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_mint_ledger.holder_type IS 'club | union | player | house | circulation. circulation = supply acknowledged as already held by players at a baseline (a bookkeeping holder, never a balance).';


--
-- Name: COLUMN ca_mint_ledger.holder_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_mint_ledger.holder_id IS 'The account the issuance or retirement landed on: profiles.id for holder_type ''player'', clubs.id for ''club'', unions.id for ''union''. holder_type ''house'' has no such row - ca_diamond_house is a single-row table keyed id = 1 - so it uses the fixed sentinel 00000000-0000-0000-0000-00000000d1a0. That sentinel is not a user and must never be joined to profiles.';


--
-- Name: COLUMN ca_mint_ledger.supply_after; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_mint_ledger.supply_after IS 'The asset supply OBSERVED as this row was written - an annotation, not a serialised running total. Under simultaneous movements two rows may each omit the other. Making it exact required a global lock held for the caller''s whole transaction, which on 2026-09-08 lost twenty-four movements to lock timeouts. fn_ca_mint_supply(asset) is the authority on supply.';


--
-- Name: COLUMN ca_mint_ledger.origin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_mint_ledger.origin IS 'Derived from op_id: operator (the Mint panel / fn_ca_mint), journal (registered from a chip_ledger leg at commit), baseline (opening baseline or its correction, not issuance), diamond-mint, opening-grant, restoration, seed, deletion; and for diamonds registered from the diamond journal: purchase, reward, promotion, refund, adjustment, arena (issuance) and spend, bridge (retirement).';


--
-- Name: ca_mint_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_mint_policy (
    id integer NOT NULL,
    per_operation_cap_chips numeric NOT NULL,
    rolling_24h_cap_chips numeric NOT NULL,
    per_operation_cap_diamonds numeric NOT NULL,
    rolling_24h_cap_diamonds numeric NOT NULL,
    note text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid,
    CONSTRAINT ca_mint_policy_id_check CHECK ((id = 1)),
    CONSTRAINT ca_mint_policy_per_operation_cap_chips_check CHECK ((per_operation_cap_chips > (0)::numeric)),
    CONSTRAINT ca_mint_policy_per_operation_cap_diamonds_check CHECK ((per_operation_cap_diamonds > (0)::numeric)),
    CONSTRAINT ca_mint_policy_rolling_24h_cap_chips_check CHECK ((rolling_24h_cap_chips > (0)::numeric)),
    CONSTRAINT ca_mint_policy_rolling_24h_cap_diamonds_check CHECK ((rolling_24h_cap_diamonds > (0)::numeric))
);


--
-- Name: ca_money_path_enforcement; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_money_path_enforcement (
    only_row boolean DEFAULT true NOT NULL,
    mode text DEFAULT 'log'::text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL,
    changed_by text DEFAULT SESSION_USER NOT NULL,
    note text,
    CONSTRAINT ca_money_path_enforcement_mode_check CHECK ((mode = ANY (ARRAY['log'::text, 'refuse'::text]))),
    CONSTRAINT ca_money_path_enforcement_only_row_check CHECK (only_row)
);


--
-- Name: TABLE ca_money_path_enforcement; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_money_path_enforcement IS 'R3 enforcement mode for tournament-category wallet credits. mode=log records a violation and lets the write through; mode=refuse aborts it. One row. Flip back with: UPDATE public.ca_money_path_enforcement SET mode = ''log'';';


--
-- Name: ca_money_path_violations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_money_path_violations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    table_name text NOT NULL,
    user_id uuid,
    amount numeric(15,2),
    category text,
    description text,
    related_entity_id uuid,
    money_path text,
    app_name text,
    db_role text
);


--
-- Name: TABLE ca_money_path_violations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_money_path_violations IS 'R3 log-only (Lane A3, 2026-09-02): tournament-category wallet credits that did not come through fn_settle_tournament_obligation. Written by trg_ca_money_path_log on wallet_transactions. Never refuses. db_role is the login role (session_user): authenticator = PostgREST, postgres = psql/migration.';


--
-- Name: ca_op_claims; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_op_claims (
    op_id text NOT NULL,
    fn_name text NOT NULL,
    result jsonb,
    claimed_at timestamp with time zone DEFAULT now() NOT NULL,
    finalized_at timestamp with time zone,
    claimed_by uuid
);


--
-- Name: TABLE ca_op_claims; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_op_claims IS 'Zero-drift phase 3: durable idempotency claims for admin money movers. A row with result IS NOT NULL is a finalized operation; replaying the same op_id returns the stored result instead of moving money twice. Failure paths delete their claim so a corrected retry re-executes.';


--
-- Name: ca_operator_policy; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_operator_policy (
    id boolean DEFAULT true NOT NULL,
    approvals_enabled boolean DEFAULT false NOT NULL,
    allow_self_approve_when_alone boolean DEFAULT true NOT NULL,
    enforce_named_roles boolean DEFAULT false NOT NULL,
    mint_threshold numeric DEFAULT 0 NOT NULL,
    fund_threshold numeric DEFAULT 0 NOT NULL,
    cashout_threshold numeric DEFAULT 0 NOT NULL,
    approval_ttl_minutes integer DEFAULT 1440 NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    restrictions_enforced boolean DEFAULT false NOT NULL,
    CONSTRAINT ca_operator_policy_approval_ttl_minutes_check CHECK ((approval_ttl_minutes > 0)),
    CONSTRAINT ca_operator_policy_id_check CHECK (id)
);


--
-- Name: TABLE ca_operator_policy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_operator_policy IS 'Single row. Safe defaults: approvals off, enforcement off, alone rule on, thresholds 0, TTL 1440 minutes.';


--
-- Name: COLUMN ca_operator_policy.restrictions_enforced; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_operator_policy.restrictions_enforced IS 'False (the default) means every restriction guard OBSERVES: it records what it would have refused into ca_restriction_observations and lets the write through. True means it refuses. Dan owns this switch. Before it is turned on, HorseFleetManager must learn the PLAYER_RESTRICTED: prefix - see PHASE4-CONTRACTS.md section 6.';


--
-- Name: ca_payout_freeze; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_payout_freeze (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scope text NOT NULL,
    reason text NOT NULL,
    opened_by uuid,
    opened_by_label text,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    cleared_by uuid,
    cleared_by_label text,
    cleared_at timestamp with time zone,
    CONSTRAINT ca_payout_freeze_clear_after_open CHECK (((cleared_at IS NULL) OR (cleared_at >= opened_at))),
    CONSTRAINT ca_payout_freeze_reason_check CHECK ((length(btrim(reason)) >= 10)),
    CONSTRAINT ca_payout_freeze_scope_check CHECK ((scope = ANY (ARRAY['tournament_payouts'::text, 'bbj_payouts'::text, 'diamond_issuance'::text, 'diamond_tournament_payouts'::text, 'arena_withdrawals'::text, 'wheel'::text, 'plinko'::text, 'crash'::text])))
);


--
-- Name: TABLE ca_payout_freeze; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_payout_freeze IS 'Kill switch consulted by fn_settle_tournament_obligation: an open row (cleared_at IS NULL) with scope tournament_payouts refuses every settle with payout_frozen. Written ONLY by fn_ca_open_payout_freeze / fn_ca_clear_payout_freeze, which a human calls. Nothing opens it automatically (Lane E, 2026-09-02; tests/law/PayoutFreezeIsHumanOnly.law.test.ts).';


--
-- Name: COLUMN ca_payout_freeze.scope; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.ca_payout_freeze.scope IS 'What an open row refuses. tournament_payouts is read by fn_settle_tournament_obligation and is the only scope any function consults today. diamond_issuance, diamond_tournament_payouts and arena_withdrawals are the names standard 3.4 layer 6 reserves for the diamond paths; the readers arrive with Lanes B, D and H. A row in a scope nobody reads refuses nothing.';


--
-- Name: ca_profile_deletions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_profile_deletions (
    id bigint NOT NULL,
    profile_id uuid NOT NULL,
    username text,
    is_horse boolean,
    diamonds numeric,
    diamond_balance numeric,
    profile_created_at timestamp with time zone,
    deleted_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_by_role text DEFAULT CURRENT_USER NOT NULL,
    application_name text DEFAULT COALESCE(current_setting('application_name'::text, true), ''::text) NOT NULL
);


--
-- Name: TABLE ca_profile_deletions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_profile_deletions IS 'Append-only testimony for every deleted profiles row: identity, diamond holdings, db role and application that removed it. Written by trg_ca_profile_deletion_journal (never blocks). Exists because the 2026-09-02 1,259,900-diamond deletion mystery had no witness (issue #2613).';


--
-- Name: ca_profile_deletions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ca_profile_deletions ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ca_profile_deletions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ca_restriction_observations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_restriction_observations (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    scope text NOT NULL,
    restriction_id uuid,
    observed_at timestamp with time zone DEFAULT now() NOT NULL,
    table_name text NOT NULL,
    op text NOT NULL,
    would_refuse boolean DEFAULT true NOT NULL,
    detail jsonb
);


--
-- Name: TABLE ca_restriction_observations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_restriction_observations IS 'What the restriction guards WOULD have refused while enforcement is off. Retained by age. Nothing reads this on a hot path.';


--
-- Name: ca_restriction_observations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ca_restriction_observations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ca_restriction_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ca_seat_stack_exits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_seat_stack_exits (
    id bigint NOT NULL,
    seat_id uuid,
    table_id uuid NOT NULL,
    user_id uuid NOT NULL,
    club_id uuid,
    seat_number integer,
    stack numeric NOT NULL,
    exit_kind text NOT NULL,
    db_role text,
    app_name text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_seat_stack_exits_exit_kind_check CHECK ((exit_kind = ANY (ARRAY['deleted'::text, 'left'::text]))),
    CONSTRAINT chk_stack_is_two_decimal_places CHECK (((stack IS NULL) OR (stack = round(stack, 2))))
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='1000', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='1000', autovacuum_vacuum_insert_threshold='5000', autovacuum_vacuum_insert_scale_factor='0.0');


--
-- Name: ca_seat_stack_exits_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.ca_seat_stack_exits_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ca_seat_stack_exits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.ca_seat_stack_exits_id_seq OWNED BY public.ca_seat_stack_exits.id;


--
-- Name: ca_settle_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_settle_sources (
    source text NOT NULL,
    note text NOT NULL,
    added_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_settle_sources; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_settle_sources IS 'Chip standard Phase 6.1: the platform sources that may settle a tournament obligation under their own name. engine.* is implicit. Any other source must name an approved ca_manual_adjustments row.';


--
-- Name: ca_treasury_baseline; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ca_treasury_baseline (
    club_id uuid NOT NULL,
    opening_balance numeric NOT NULL,
    ledger_at_baseline numeric NOT NULL,
    unledgered_gap numeric NOT NULL,
    taken_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE ca_treasury_baseline; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.ca_treasury_baseline IS 'Opening club_treasury balances at the 2026-08-31 cutover. Everything before taken_at is acknowledged as unreconstructable; reconcile_ledger_nightly measures chip_ledger flow forward from this line. Mirrors ca_chip_baseline for the player-wallet pool. Do NOT re-baseline: moving the line erases real drift.';


--
-- Name: cash_cluster_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_cluster_events (
    id bigint NOT NULL,
    game_id uuid NOT NULL,
    table_id uuid,
    kind text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: cash_cluster_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cash_cluster_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cash_cluster_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cash_cluster_events_id_seq OWNED BY public.cash_cluster_events.id;


--
-- Name: cash_game_roster; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_game_roster (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    game_id uuid NOT NULL,
    user_id uuid NOT NULL,
    joined_at timestamp with time zone DEFAULT now() NOT NULL,
    left_at timestamp with time zone,
    seat_change_used_at timestamp with time zone
);


--
-- Name: TABLE cash_game_roster; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cash_game_roster IS 'One open row per player per must-move game: joined_at is the must-move order (Dan 2026-09-05). Closed when the last chair in the game empties; a rejoin is a new row at the bottom.';


--
-- Name: cash_games; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_games (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    union_id uuid,
    name text NOT NULL,
    template_name text NOT NULL,
    variant text NOT NULL,
    sb numeric(14,2) NOT NULL,
    bb numeric(14,2) NOT NULL,
    handedness integer NOT NULL,
    ruleset_snapshot jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    state text DEFAULT 'live'::text NOT NULL,
    cap_mains integer DEFAULT 8 NOT NULL,
    allow_second_feeder boolean DEFAULT false NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    must_move boolean DEFAULT true NOT NULL,
    closed_at timestamp with time zone,
    closed_by uuid,
    opening_hold_since timestamp with time zone,
    last_tick_at timestamp with time zone,
    last_tick_actions jsonb,
    opening_hold_rested_until timestamp with time zone,
    CONSTRAINT cash_games_cap_mains_check CHECK (((cap_mains >= 1) AND (cap_mains <= 32))),
    CONSTRAINT cash_games_check CHECK ((bb > sb)),
    CONSTRAINT cash_games_handedness_check CHECK (((handedness >= 2) AND (handedness <= 9))),
    CONSTRAINT cash_games_sb_check CHECK ((sb > (0)::numeric)),
    CONSTRAINT cash_games_state_check CHECK ((state = ANY (ARRAY['live'::text, 'dormant'::text]))),
    CONSTRAINT cash_games_template_name_check CHECK ((template_name = ANY (ARRAY['classic'::text, 'action'::text, 'madness'::text]))),
    CONSTRAINT cash_games_variant_check CHECK ((variant = ANY (ARRAY['nlh'::text, 'plo4'::text, 'plo5'::text, 'plo6'::text, 'plo8'::text, 'flo8'::text, 'flh'::text, 'short_deck'::text, 'pineapple'::text])))
);


--
-- Name: TABLE cash_games; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cash_games IS 'Operation Table Stakes: a cash GAME (the cluster). ruleset_snapshot is the resolved template + host overrides at creation; live games never mutate when the template changes.';


--
-- Name: COLUMN cash_games.must_move; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_games.must_move IS 'R9: true = automated must-move cluster (OPORD 1.4); false = one table the host runs by hand.';


--
-- Name: cash_player_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_player_session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    player_id uuid NOT NULL,
    club_id uuid,
    scope_type text NOT NULL,
    scope_id uuid NOT NULL,
    table_id uuid NOT NULL,
    variant text,
    sb numeric(14,2),
    bb numeric(14,2),
    baseline numeric(14,2) DEFAULT 0 NOT NULL,
    stay_clock_ms integer DEFAULT 600000 NOT NULL,
    rejoin_window_ms integer DEFAULT 7200000 NOT NULL,
    stay_remaining_ms integer DEFAULT 600000 NOT NULL,
    stay_running boolean DEFAULT false NOT NULL,
    stay_last_tick_at timestamp with time zone DEFAULT now() NOT NULL,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    closed_reason text,
    CONSTRAINT cash_player_session_clock_floor CHECK ((stay_clock_ms >= 600000)),
    CONSTRAINT cash_player_session_remaining_nonneg CHECK ((stay_remaining_ms >= 0)),
    CONSTRAINT cash_player_session_scope_type_check CHECK ((scope_type = ANY (ARRAY['table'::text, 'cluster'::text]))),
    CONSTRAINT cash_player_session_window_floor CHECK ((rejoin_window_ms >= 7200000))
);


--
-- Name: TABLE cash_player_session; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cash_player_session IS 'Chip continuity (OPORD 1.3 s6). One open row per player per scope. stay_remaining_ms is as of stay_last_tick_at; derive with fn_cash_stay_remaining_ms.';


--
-- Name: cash_seat_change_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_seat_change_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    game_id uuid NOT NULL,
    user_id uuid NOT NULL,
    from_table_id uuid NOT NULL,
    to_table_id uuid,
    status text DEFAULT 'requested'::text NOT NULL,
    note text,
    move_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone,
    CONSTRAINT cash_seat_change_requests_status_check CHECK ((status = ANY (ARRAY['requested'::text, 'moved'::text, 'cancelled'::text])))
);


--
-- Name: TABLE cash_seat_change_requests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cash_seat_change_requests IS 'A player''s one voluntary table change inside a must-move game (never from or to Main 1). to_table_id NULL = any table but Main 1. requested -> moved (a cash_seat_moves row) | cancelled.';


--
-- Name: cash_seat_moves; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_seat_moves (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    game_id uuid NOT NULL,
    player_id uuid NOT NULL,
    from_table_id uuid NOT NULL,
    to_table_id uuid NOT NULL,
    reason text NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    executed_at timestamp with time zone,
    to_seat_number integer,
    note text,
    announced_at timestamp with time zone,
    swap_move_id uuid,
    ready_at timestamp with time zone,
    source_occupancy_id uuid,
    source_seat_number integer,
    CONSTRAINT cash_seat_moves_reason_check CHECK ((reason = ANY (ARRAY['must_move'::text, 'break'::text, 'seat_change'::text, 'balance'::text]))),
    CONSTRAINT cash_seat_moves_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'done'::text, 'cancelled'::text, 'expired'::text]))),
    CONSTRAINT pending_move_has_original_occupancy CHECK (((state <> 'pending'::text) OR ((source_occupancy_id IS NOT NULL) AND (source_seat_number IS NOT NULL))))
);


--
-- Name: COLUMN cash_seat_moves.announced_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cash_seat_moves.announced_at IS 'When the from-table engine told the player (deal start). Settlement executes announced moves only; an idle table executes any.';


--
-- Name: cashout_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cashout_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    player_id uuid NOT NULL,
    agent_id uuid NOT NULL,
    amount numeric(15,2) NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    player_note text,
    agent_note text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    acknowledged_at timestamp with time zone,
    completed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    CONSTRAINT cashout_requests_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT cashout_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text, 'expired'::text, 'cancelled'::text, 'cancelling'::text, 'completed'::text, 'completing'::text])))
);


--
-- Name: TABLE cashout_requests; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cashout_requests IS 'Player cashout queue. Client writes are barred by three RESTRICTIVE policies; the only write paths are fn_cashout_request / fn_cashout_approve / fn_cashout_release (SECURITY DEFINER) and service_role. Reads are scoped by cashout_read_scoped.';


--
-- Name: chip_ledger_idem; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chip_ledger_idem (
    idempotency_key text NOT NULL,
    leg_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE chip_ledger_idem; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.chip_ledger_idem IS 'One row per keyed chip_ledger leg. Holds the journal''s idempotency guarantee OUTSIDE the journal, so it survives partitioning: a partitioned table''s unique index must include the partition key, which would let the same key through twice in different months. Never partitioned, never dropped with a partition.';


--
-- Name: chip_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chip_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    from_user_id uuid,
    to_user_id uuid,
    amount numeric(14,2) NOT NULL,
    transaction_type text NOT NULL,
    notes text,
    related_cashout_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    balance_after numeric(14,2),
    clawed_back boolean DEFAULT false,
    reversible_until timestamp with time zone,
    is_reversed boolean DEFAULT false,
    table_id uuid
)
WITH (autovacuum_freeze_max_age='150000000');


--
-- Name: COLUMN chip_transactions.balance_after; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.chip_transactions.balance_after IS 'NOT COMPARABLE ACROSS ROWS. Whose balance this is depends on which RPC wrote the row: fn_cashier_send_chips stores the RECIPIENT''s balance, fn_issue_tournament_ticket stores the ISSUER''s - and both write transaction_type = ''peer_transfer'', so the type does not disambiguate it either. Do not aggregate this column. For an unambiguous value read metadata->>''from_balance_after'' / ''to_balance_after'' (send) or metadata->>''issuer_balance_after'' (ticket).';


--
-- Name: rake_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rake_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hand_id uuid,
    table_id uuid,
    club_id uuid,
    rake_amount numeric(18,4) DEFAULT 0 NOT NULL,
    bbj_contribution numeric(18,4) DEFAULT 0,
    pot_size numeric(18,4),
    num_players integer,
    created_at timestamp with time zone DEFAULT now(),
    player_contributions jsonb,
    global_hand_id bigint DEFAULT nextval('public.hand_id_seq'::regclass),
    is_tournament boolean DEFAULT false NOT NULL,
    tournament_id uuid,
    source text DEFAULT 'cash_game'::text,
    metadata jsonb,
    rake_method text DEFAULT 'DEALT_EQUAL'::text NOT NULL,
    returned_uncalled jsonb,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT chk_rake_amount_is_two_decimal_places CHECK (((rake_amount IS NULL) OR (rake_amount = round(rake_amount, 2)))),
    CONSTRAINT rake_records_rake_method_check CHECK ((rake_method = ANY (ARRAY['DEALT_EQUAL'::text, 'WEIGHTED_CONTRIBUTED'::text])))
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='1000', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='1000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: TABLE rake_records; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.rake_records IS 'Durable audit of every rake and BBJ contribution taken.

KNOWN HISTORICAL DISCREPANCY — deliberately left in place (Dan, 2026-08-20).
55 rows in this table are duplicates: the same hand had its rake banked twice,
over-crediting 237.95 chips in total. Cause: when logHandHistory failed, the
hand had no hand_history row, so atomic_distribute_rake and
bbj_record_contribution were called with p_hand_id = NULL — and both deduped on
a partial index predicated on `hand_id IS NOT NULL`, which means a hand with no
history row had no idempotency at all. The RPCs now key idempotency on
(table_id, hand_number) instead, so a null hand id is no longer dangerous, and
as of 2026-08-20 logHandHistory retries and queues rather than giving up (see
server/src/services/supabase/handHistory.ts). The bug cannot recur.

The 55 rows are NOT being deleted. The amount is immaterial, deleting them
would rewrite financial history, and rakeback_stats_applied rows point at them —
removing the rake rows would orphan player rakeback attribution that was
already paid out. Leave them. If a total must exclude them, dedupe on
(table_id, metadata->>''hand_number'') rather than deleting anything.';


--
-- Name: COLUMN rake_records.hand_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rake_records.hand_id IS 'hand_history.id for the hand this rake came from. NOT a foreign key. May DANGLE: horse-only hands are pruned after 7 days (see sp_prune_hand_history) while the rake row is kept forever, so the referenced hand can be gone. That is intended — it means "the hand history expired", not "this rake is unattributable". Do NOT null these out to tidy them: NULL is the unattributable marker that FeeReconciler.auditBBJDrift alarms on, and nulling a valid link would manufacture that alert. NULL here means the link was never established (see fn_relink_rake_record_to_hand). Documented 2026-08-20.';


--
-- Name: COLUMN rake_records.global_hand_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rake_records.global_hand_id IS 'Globally unique sequential hand ID from hand_id_seq. Used in display as SP-XXXXXXXXXX.';


--
-- Name: COLUMN rake_records.is_tournament; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rake_records.is_tournament IS 'True when this record is for tournament buy-in rake (not a cash game hand).';


--
-- Name: club_hand_daily_shard; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.club_hand_daily_shard (
    club_id uuid NOT NULL,
    stat_date date NOT NULL,
    hands bigint DEFAULT 0 NOT NULL,
    rake numeric DEFAULT 0 NOT NULL,
    bbj numeric DEFAULT 0 NOT NULL,
    pot_total numeric DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shard smallint DEFAULT 0 NOT NULL
)
WITH (autovacuum_vacuum_scale_factor='0.05', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: TABLE club_hand_daily_shard; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.club_hand_daily_shard IS 'Sharded per-club daily hand counters. Never read this directly - read the club_hand_daily view, which sums the shards. Sharded 2026-08-27 because one row per club per day was serialising 460,000 hand inserts a day behind a single row lock.';


--
-- Name: club_level_thresholds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.club_level_thresholds (
    level smallint NOT NULL,
    min_members integer NOT NULL,
    tier text NOT NULL,
    tier_label text NOT NULL,
    CONSTRAINT club_level_thresholds_level_check CHECK (((level >= 1) AND (level <= 55))),
    CONSTRAINT club_level_thresholds_min_members_check CHECK ((min_members >= 0))
);


--
-- Name: TABLE club_level_thresholds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.club_level_thresholds IS 'Club level 1-55 keyed on member count. min_members is the lowest member count that reaches that level. Single source of truth: the client mirrors these exact numbers in src/utils/clubLevels.ts.';


--
-- Name: club_member_daily_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.club_member_daily_stats (
    club_id uuid NOT NULL,
    table_id uuid NOT NULL,
    user_id uuid NOT NULL,
    stat_date date NOT NULL,
    hands_played integer DEFAULT 0 NOT NULL,
    hands_won integer DEFAULT 0 NOT NULL,
    total_won numeric DEFAULT 0 NOT NULL,
    profit numeric DEFAULT 0 NOT NULL,
    biggest_pot_won numeric DEFAULT 0 NOT NULL,
    biggest_pot numeric DEFAULT 0 NOT NULL,
    topup_total numeric DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    hands_attributed integer DEFAULT 0 NOT NULL
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.01', autovacuum_analyze_scale_factor='0.01', autovacuum_vacuum_insert_threshold='5000', autovacuum_vacuum_insert_scale_factor='0.0', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: club_member_table_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.club_member_table_state (
    table_id uuid NOT NULL,
    user_id uuid NOT NULL,
    last_stack numeric NOT NULL,
    last_hand_number bigint,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_created_at timestamp with time zone,
    last_hand_id uuid
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.02', autovacuum_analyze_scale_factor='0.01', autovacuum_vacuum_insert_threshold='5000', autovacuum_vacuum_insert_scale_factor='0.0', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: club_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.club_members (
    club_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text DEFAULT 'player'::text,
    agent_id uuid,
    joined_at timestamp with time zone DEFAULT now(),
    parent_agent_id uuid,
    invited_by uuid,
    notes text,
    last_active_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_bot boolean DEFAULT false,
    status text DEFAULT 'active'::text,
    chip_balance numeric(20,2) DEFAULT 0 NOT NULL,
    diamonds integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true,
    orange_ball_status text DEFAULT 'inactive'::text,
    rank_level integer DEFAULT 1,
    credit_limit numeric(15,2) DEFAULT 0,
    credit_used numeric(15,2) DEFAULT 0,
    nickname text,
    last_active timestamp with time zone DEFAULT now(),
    tier text DEFAULT 'bronze'::text,
    trust_score integer DEFAULT 50,
    sessions_played integer DEFAULT 0,
    promo_balance numeric(14,2) DEFAULT 0,
    chips_won bigint DEFAULT 0,
    chips_lost bigint DEFAULT 0,
    commission_rate numeric(5,2) DEFAULT 0,
    rakeback_rate numeric(5,2) DEFAULT 0,
    hands_played integer DEFAULT 0,
    total_rake_paid bigint DEFAULT 0,
    biggest_pot bigint DEFAULT 0,
    locked_chips integer DEFAULT 0,
    player_rakeback_pct numeric(5,4) DEFAULT 0.0000,
    held_chips numeric DEFAULT 0,
    display_name text,
    is_prepaid boolean DEFAULT true,
    promo_received_total numeric(14,2) DEFAULT 0,
    promo_wagered numeric(14,2) DEFAULT 0,
    promo_playthrough_required numeric(14,2) DEFAULT 0,
    missions_completed integer DEFAULT 0,
    membership_lifecycle_status text DEFAULT 'active'::text NOT NULL,
    departed_at timestamp with time zone,
    departed_by uuid,
    departure_reason text,
    CONSTRAINT chk_held_chips_is_two_decimal_places CHECK (((held_chips IS NULL) OR (held_chips = round(held_chips, 2)))),
    CONSTRAINT club_members_bot_house_only CHECK (((NOT COALESCE(is_bot, false)) OR public.fn_ca_house_board_allows_automation(club_id))),
    CONSTRAINT club_members_chip_balance_nonneg CHECK ((chip_balance >= (0)::numeric)),
    CONSTRAINT club_members_membership_lifecycle_check CHECK ((membership_lifecycle_status = ANY (ARRAY['active'::text, 'departed'::text]))),
    CONSTRAINT club_members_promo_balance_nonneg CHECK ((promo_balance >= (0)::numeric)),
    CONSTRAINT club_members_role_check CHECK ((role = ANY (ARRAY['owner'::text, 'co_owner'::text, 'admin'::text, 'super_agent'::text, 'agent'::text, 'sub_agent'::text, 'player'::text])))
);


--
-- Name: COLUMN club_members.role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_members.role IS 'Club job title: owner, co_owner, admin, super_agent, agent, sub_agent, player. Everyone is also a player - nothing in seating or buy-in reads this column. Only fn_club_set_member_role may change it (trg_club_members_role_guard).';


--
-- Name: COLUMN club_members.is_bot; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_members.is_bot IS 'Mirror of profiles.is_horse, kept in step by trg_club_members_bot_follows_horse. profiles.is_horse is authoritative; writing this column directly has no lasting effect.';


--
-- Name: COLUMN club_members.chip_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_members.chip_balance IS 'Per-club player chip balance (UNION LAW club-scoped custody). numeric(20,2) since 2026-08-20: previously integer, which silently rounded every fractional buy-in, cash-out, rakeback and prize once the money path moved through it.';


--
-- Name: COLUMN club_members.promo_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_members.promo_balance IS 'Player promo wallet — received from agent. Can be used at tables. NOT club debt, NOT counted in settlement.';


--
-- Name: COLUMN club_members.promo_received_total; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_members.promo_received_total IS 'Lifetime total promo chips received (from agents). Used for 100-chip cap.';


--
-- Name: COLUMN club_members.promo_wagered; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_members.promo_wagered IS 'Total chips wagered at tables. Must reach promo_received_total * 3 to unlock cashout.';


--
-- Name: COLUMN club_members.promo_playthrough_required; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_members.promo_playthrough_required IS 'Required wagering to unlock cashout = promo_received_total * 3.';


--
-- Name: club_wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.club_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    chip_balance numeric(20,2) DEFAULT 0 NOT NULL,
    period_rake_collected numeric(20,4) DEFAULT 0 NOT NULL,
    period_commission_paid numeric(20,4) DEFAULT 0 NOT NULL,
    period_bbj_contribution numeric(20,4) DEFAULT 0 NOT NULL,
    period_started_at timestamp with time zone DEFAULT now() NOT NULL,
    lifetime_rake_collected numeric(20,4) DEFAULT 0 NOT NULL,
    lifetime_commission_paid numeric(20,4) DEFAULT 0 NOT NULL,
    lifetime_bbj_contribution numeric(20,4) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    insurance_balance numeric(20,2) DEFAULT 0 NOT NULL,
    CONSTRAINT club_wallets_chip_balance_check CHECK ((chip_balance >= (0)::numeric))
);


--
-- Name: COLUMN club_wallets.insurance_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.club_wallets.insurance_balance IS 'Signed insurance underwriting balance (premiums in, payouts out). May be negative: the club absorbs insurance variance. Union clubs bank insurance in union_wallets.insurance_wallet instead.';


--
-- Name: clubs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clubs (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    description text,
    owner_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    is_union boolean DEFAULT false,
    club_id integer DEFAULT (((10000)::double precision + floor((random() * (90000)::double precision))))::integer,
    avatar_url text,
    is_public boolean DEFAULT true,
    requires_approval boolean DEFAULT false,
    gps_restricted boolean DEFAULT false,
    settings jsonb DEFAULT '{"rake_cap": 15, "max_buy_in_bb": 200, "min_buy_in_bb": 40, "allow_straddle": true, "time_bank_seconds": 30, "allow_run_it_twice": true, "default_rake_percent": 5}'::jsonb,
    updated_at timestamp with time zone DEFAULT now(),
    union_id uuid,
    color_theme text DEFAULT 'royal-blue'::text,
    slug text,
    chip_treasury numeric(18,2) DEFAULT 100000,
    total_rake numeric(18,2) DEFAULT 0 NOT NULL,
    online_count integer DEFAULT 0,
    game_types text[] DEFAULT ARRAY['NLH'::text],
    member_count integer DEFAULT 0,
    table_count integer DEFAULT 0,
    promo_balance numeric(14,2) DEFAULT 0,
    code text,
    rake_percent numeric(5,2) DEFAULT 5.0,
    rake_cap_bb numeric(8,2) DEFAULT 3.0,
    max_tables integer DEFAULT 20,
    max_members integer DEFAULT 500,
    status text DEFAULT 'active'::text,
    hands_played bigint DEFAULT 0,
    logo_url text,
    banner_url text,
    game_variants text[] DEFAULT ARRAY['nlh'::text],
    settlement_locked boolean DEFAULT false,
    settlement_locked_until timestamp with time zone,
    auto_settlement_enabled boolean DEFAULT true,
    auto_settlement_day text DEFAULT 'monday'::text,
    auto_settlement_hour integer DEFAULT 10,
    club_commission_rate numeric(5,4) DEFAULT 0.9000,
    insurance_balance numeric(14,2) DEFAULT 0,
    bbj_enabled boolean,
    player_level integer DEFAULT 1,
    hierarchy_level integer DEFAULT 1,
    level integer DEFAULT 1,
    player_threshold_current integer DEFAULT 0,
    player_threshold_next integer DEFAULT 30,
    hierarchy_units numeric(10,2) DEFAULT 0,
    hierarchy_units_rounded_up integer DEFAULT 0,
    hierarchy_threshold_current integer DEFAULT 0,
    hierarchy_threshold_next integer DEFAULT 2,
    tags text[] DEFAULT '{}'::text[],
    average_rating numeric(3,2) DEFAULT 0,
    game_type text DEFAULT 'Texas Holdem'::text,
    settlement_lock_until timestamp with time zone,
    card_image_url text,
    active_players integer DEFAULT 0,
    default_rake_percent numeric(5,2) DEFAULT '-1'::integer,
    rake_cap numeric(18,4) DEFAULT '-1'::integer,
    min_buyin_bb integer DEFAULT 20,
    max_buyin_bb integer DEFAULT 200,
    allow_straddle boolean DEFAULT true,
    allow_run_it_twice boolean DEFAULT true,
    allow_rabbit_hunt boolean DEFAULT false,
    logo text,
    is_private boolean DEFAULT false,
    min_buy_in numeric(18,4) DEFAULT 0,
    max_buy_in numeric(18,4) DEFAULT 0,
    default_game_type text DEFAULT 'NLHE'::text,
    allow_insurance boolean DEFAULT false,
    auto_approve_agents boolean DEFAULT false,
    auto_settlement boolean DEFAULT false,
    active_tables integer DEFAULT 0,
    admin_count integer DEFAULT 0,
    super_agent_count integer DEFAULT 0,
    agent_count integer DEFAULT 0,
    chip_pool numeric(18,2) DEFAULT 0 NOT NULL,
    bbj_rake_enabled boolean DEFAULT true,
    spins_enabled boolean DEFAULT false,
    spins_preseed_amount integer DEFAULT 0,
    spins_wallet_funding text DEFAULT 'PROMO'::text,
    ticker_enabled boolean DEFAULT true NOT NULL,
    guarantee_treasury_floor numeric DEFAULT 0 NOT NULL,
    guarantee_enforcement_enabled boolean DEFAULT true NOT NULL,
    tagline text,
    opening_checklist_started_at timestamp with time zone,
    lobby_message text,
    lobby_message_updated_at timestamp with time zone,
    message_revision bigint DEFAULT 1 NOT NULL,
    lifecycle_status text DEFAULT 'active'::text NOT NULL,
    retired_at timestamp with time zone,
    retired_by uuid,
    retirement_reason text,
    asset text DEFAULT 'chips'::text NOT NULL,
    is_platform boolean DEFAULT false NOT NULL,
    CONSTRAINT clubs_asset_known CHECK ((asset = ANY (ARRAY['chips'::text, 'diamonds'::text]))),
    CONSTRAINT clubs_chip_pool_nonneg CHECK ((chip_pool >= (0)::numeric)),
    CONSTRAINT clubs_chip_treasury_nonneg CHECK ((chip_treasury >= (0)::numeric)),
    CONSTRAINT clubs_description_character_limit CHECK ((char_length(COALESCE(description, ''::text)) <= 500)),
    CONSTRAINT clubs_insurance_balance_nonneg CHECK ((insurance_balance >= (0)::numeric)),
    CONSTRAINT clubs_lifecycle_status_check CHECK ((lifecycle_status = ANY (ARRAY['active'::text, 'retired'::text]))),
    CONSTRAINT clubs_lobby_message_character_limit CHECK ((char_length(COALESCE(lobby_message, ''::text)) <= 240)),
    CONSTRAINT clubs_message_revision_positive CHECK ((message_revision > 0)),
    CONSTRAINT clubs_name_not_blank CHECK ((btrim(name) <> ''::text)),
    CONSTRAINT clubs_promo_balance_nonneg CHECK ((promo_balance >= (0)::numeric)),
    CONSTRAINT clubs_tagline_character_limit CHECK ((char_length(COALESCE(tagline, ''::text)) <= 72)),
    CONSTRAINT clubs_tagline_length CHECK (((tagline IS NULL) OR (char_length(tagline) <= 72))),
    CONSTRAINT poker_arena_diamond_identity CHECK ((((asset = 'chips'::text) AND (NOT is_platform)) OR ((asset = 'diamonds'::text) AND is_platform AND (union_id IS NULL) AND (NOT COALESCE(is_union, false)) AND (COALESCE(chip_treasury, (0)::numeric) = (0)::numeric) AND (COALESCE(chip_pool, (0)::numeric) = (0)::numeric) AND (COALESCE(promo_balance, (0)::numeric) = (0)::numeric) AND (COALESCE(insurance_balance, (0)::numeric) = (0)::numeric))))
);


--
-- Name: COLUMN clubs.promo_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.promo_balance IS 'CANONICAL club promo wallet. Funded by fn_sweep_bbj_promo (unionless clubs) or fn_union_distribute_promo.';


--
-- Name: COLUMN clubs.rake_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.rake_percent IS 'LEGACY DUPLICATE - NOTHING READS THIS. The engine reads clubs.default_rake_percent. A value here has no effect on rake taken and will mislead anyone auditing the database (it misled the 2026-08-27 rake audit). Do not write it; prefer default_rake_percent.';


--
-- Name: COLUMN clubs.rake_cap_bb; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.rake_cap_bb IS 'LEGACY DUPLICATE - NOTHING READS THIS. The engine reads clubs.rake_cap. Do not write it.';


--
-- Name: COLUMN clubs.default_rake_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.default_rake_percent IS 'AUTHORITATIVE. The engine reads this (ServerTableEngineBase.refreshRakeConfig). -1 or NULL means inherit from the RAKE_SCHEDULE in server/src/config/RakeConfig.ts, which is 10% at every stake. The club settings UI writes this column.';


--
-- Name: COLUMN clubs.rake_cap; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.rake_cap IS 'AUTHORITATIVE. The engine reads this as a cap in BIG BLINDS despite the name. -1 or NULL means inherit from the schedule cap.';


--
-- Name: COLUMN clubs.ticker_enabled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.ticker_enabled IS 'Club switch for the top announcement ticker. FALSE suppresses this club''s starting-soon and overlay announcements for every member. Composed with user_table_settings.show_ticker as AND.';


--
-- Name: COLUMN clubs.guarantee_treasury_floor; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.guarantee_treasury_floor IS 'Treasury level below which new guaranteed tournaments are refused. 0 = may not go negative.';


--
-- Name: COLUMN clubs.guarantee_enforcement_enabled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.guarantee_enforcement_enabled IS 'False downgrades the guarantee affordability refusal to a critical alert. Escape hatch only.';


--
-- Name: COLUMN clubs.opening_checklist_started_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.opening_checklist_started_at IS 'Non-null only for standalone clubs created after the new-club checklist launched. Legacy clubs and unions remain null.';


--
-- Name: COLUMN clubs.lobby_message; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.lobby_message IS 'Owner/admin-authored message shown at the top of the club lobby rail, above the club card. The day''s message or anything custom. Falls back to tagline, then to a plain welcome line. Set through fn_set_club_lobby_message.';


--
-- Name: COLUMN clubs.lobby_message_updated_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.lobby_message_updated_at IS 'When lobby_message was last written. Lets the lobby show how fresh the day''s message is.';


--
-- Name: COLUMN clubs.asset; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.asset IS 'What this club is denominated in. Every club is chips except the one platform Diamond Arena club (ruling 16).';


--
-- Name: COLUMN clubs.is_platform; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.clubs.is_platform IS 'True for the single platform-owned club (the Diamond Arena). Not an owner flag: it says the house runs it.';


--
-- Name: content_authors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.content_authors (
    id integer NOT NULL,
    name text NOT NULL,
    gender text,
    location text NOT NULL,
    timezone text NOT NULL,
    birthday date,
    alias text NOT NULL,
    specialty text,
    stakes text,
    bio text,
    voice text,
    avatar_seed text,
    created_at timestamp with time zone DEFAULT now(),
    is_active boolean DEFAULT true,
    profile_id uuid,
    avatar_url text,
    personality jsonb,
    CONSTRAINT content_authors_gender_check CHECK ((gender = ANY (ARRAY['male'::text, 'female'::text, 'other'::text])))
);


--
-- Name: content_authors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.content_authors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: content_authors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.content_authors_id_seq OWNED BY public.content_authors.id;


--
-- Name: daily_challenge_dashboard_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_challenge_dashboard_revisions (
    user_id uuid NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT daily_challenge_dashboard_revisions_revision_check CHECK ((revision > 0))
);

ALTER TABLE ONLY public.daily_challenge_dashboard_revisions REPLICA IDENTITY FULL;


--
-- Name: TABLE daily_challenge_dashboard_revisions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.daily_challenge_dashboard_revisions IS 'Durable per-player Daily Missions revision cursor. Private Broadcast provides the immediate refresh signal.';


--
-- Name: daily_challenge_event_outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_challenge_event_outbox (
    user_id uuid NOT NULL,
    event_key text NOT NULL,
    amounts jsonb NOT NULL,
    magnitudes jsonb DEFAULT '{}'::jsonb NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    dead_lettered_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    threshold_values jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT daily_challenge_event_outbox_threshold_values_check CHECK ((jsonb_typeof(threshold_values) = 'object'::text))
);


--
-- Name: deep_stack_delete_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.deep_stack_delete_attempts (
    id bigint NOT NULL,
    at timestamp with time zone DEFAULT now() NOT NULL,
    source_table text NOT NULL,
    allowed boolean NOT NULL,
    db_user text NOT NULL,
    db_role text NOT NULL,
    application text,
    client_addr text,
    backend_pid integer,
    running_query text,
    old_row jsonb NOT NULL
);


--
-- Name: deep_stack_delete_attempts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.deep_stack_delete_attempts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deep_stack_delete_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.deep_stack_delete_attempts_id_seq OWNED BY public.deep_stack_delete_attempts.id;


--
-- Name: diamond_engine_daily_caps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diamond_engine_daily_caps (
    engine text NOT NULL,
    max_per_user_per_day integer,
    note text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    max_per_user_per_day_vip integer,
    CONSTRAINT ca_vip_cap_is_never_lower CHECK (((max_per_user_per_day_vip IS NULL) OR (max_per_user_per_day IS NULL) OR (max_per_user_per_day_vip >= max_per_user_per_day))),
    CONSTRAINT diamond_engine_daily_caps_positive CHECK (((max_per_user_per_day IS NULL) OR (max_per_user_per_day > 0)))
);


--
-- Name: TABLE diamond_engine_daily_caps; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.diamond_engine_daily_caps IS 'The per-user, per-engine, per-day earning limit - since ruling 21 the ONLY control that refuses an award. A cap must sit ABOVE the design ceiling of its engine (what a player earns completing everything the game assigns in a day) or it refuses the product rather than limiting abuse. daily_challenges: ceiling 2,969 measured over 7,526 user-days, cap 4,000. catalog_v2: observed maximum 260, cap 500.';


--
-- Name: COLUMN diamond_engine_daily_caps.max_per_user_per_day_vip; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.diamond_engine_daily_caps.max_per_user_per_day_vip IS 'The cap for a VIP (is_vip and lifetime or unexpired). award_diamonds_v2 allows 150 where a non-VIP gets 110. NULL = same as max_per_user_per_day.';


--
-- Name: diamond_reward_budgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diamond_reward_budgets (
    period text NOT NULL,
    engine text NOT NULL,
    budget_diamonds bigint,
    spent_diamonds bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ca_budget_is_a_number_or_nothing CHECK (((budget_diamonds IS NULL) OR ((budget_diamonds >= 0) AND (budget_diamonds <= 1000000000)))),
    CONSTRAINT diamond_reward_budgets_budget_diamonds_check CHECK ((budget_diamonds >= 0)),
    CONSTRAINT diamond_reward_budgets_spent_diamonds_check CHECK ((spent_diamonds >= 0))
);


--
-- Name: TABLE diamond_reward_budgets; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.diamond_reward_budgets IS 'One promotional issuance budget line per earn engine per period (YYYY-MM). Values are RULING 18 (docs/DIAMOND-RULINGS.md, 2026-09-07): 250,000 a month platform-wide. Log-only until ruling 17 flips refusal on.';


--
-- Name: COLUMN diamond_reward_budgets.budget_diamonds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.diamond_reward_budgets.budget_diamonds IS 'A PLAN, NOT A LIMIT. Since ruling 21 no platform budget refuses any player - only a per-user budget does (diamond_engine_daily_caps). NULL means no plan has been set. Never write a sentinel here; a bigint-max "unlimited" sat in 2026-10/club_arena_daily and read as a number to everyone after. What an engine should be budgeted is Dan''s decision (CLAUDE.md 10.9); fn_ca_diamond_budget_reality shows which of these numbers are fiction.';


--
-- Name: COLUMN diamond_reward_budgets.spent_diamonds; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.diamond_reward_budgets.spent_diamonds IS 'FROZEN BASELINE, not a running total. It stopped being updated when ca_diamond_engine_spend replaced it: the single row''s lock serialised the whole platform and 5,861 awards were lost in one morning. fn_ca_diamond_engine_spent = this baseline + the append-only journal.';


--
-- Name: diamond_reward_catalog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diamond_reward_catalog (
    action_key text NOT NULL,
    diamonds integer NOT NULL,
    max_per_day integer,
    counts_toward_daily_cap boolean DEFAULT true NOT NULL,
    lifetime boolean DEFAULT false NOT NULL,
    category text,
    active boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: diamond_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diamond_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    amount integer NOT NULL,
    balance_after integer,
    description text,
    reference_id text,
    created_at timestamp with time zone DEFAULT now(),
    transaction_type text,
    source text,
    metadata jsonb DEFAULT '{}'::jsonb,
    counterparty text,
    issuance_class text,
    CONSTRAINT diamond_transactions_issuance_class_chk CHECK (((issuance_class IS NULL) OR (issuance_class = ANY (ARRAY['purchased'::text, 'promotional'::text, 'earned'::text, 'transferred'::text, 'seeded'::text, 'refund'::text, 'spend'::text, 'bridge'::text, 'deletion'::text, 'admin'::text, 'arena'::text, 'house'::text, 'unknown'::text])))),
    CONSTRAINT no_home_games_source CHECK (((source IS NULL) OR (source <> 'home_games'::text)))
);


--
-- Name: COLUMN diamond_transactions.counterparty; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.diamond_transactions.counterparty IS 'The other side of the movement (purchase_clearing, promo_budget:<engine>, revenue:<sink>, player:<uuid>, house, retired, arena_wallet). Standard DR3. Nullable while log-only.';


--
-- Name: COLUMN diamond_transactions.issuance_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.diamond_transactions.issuance_class IS 'purchased | promotional | earned | transferred | seeded | refund | spend | bridge | deletion | admin | arena | house | unknown. Standard DR3.';


--
-- Name: CONSTRAINT no_home_games_source ON diamond_transactions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT no_home_games_source ON public.diamond_transactions IS 'Regulatory: Smarter.Poker cannot pay value to home-game hosts. Enforced at schema level to survive code regressions. See Phase 36 removal migration.';


--
-- Name: diamond_user_daily_awards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diamond_user_daily_awards (
    user_id uuid NOT NULL,
    engine text NOT NULL,
    day date NOT NULL,
    awarded bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE diamond_user_daily_awards; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.diamond_user_daily_awards IS 'DR7. One row per (player, engine, America/Chicago day) with the diamonds that engine credited that player that day. Written by trg_ca_diamond_earn_ledger on diamond_transactions. Horses are players (CLAUDE.md 10.5): this table never filters is_horse.';


--
-- Name: diamond_wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.diamond_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    lifetime_earned integer DEFAULT 0,
    lifetime_spent integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: engine_maintenance_break; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engine_maintenance_break (
    id boolean DEFAULT true NOT NULL,
    phase text NOT NULL,
    announced_at timestamp with time zone DEFAULT now() NOT NULL,
    break_started_at timestamp with time zone,
    break_ends_at timestamp with time zone,
    reason text DEFAULT 'Scheduled Engine Maintenance'::text NOT NULL,
    declared_by text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    enforce_freeze boolean DEFAULT false NOT NULL,
    ownership_token uuid NOT NULL,
    CONSTRAINT counting_down_has_an_end CHECK (((phase <> 'counting_down'::text) OR (break_ends_at IS NOT NULL))),
    CONSTRAINT engine_maintenance_break_id_check CHECK (id),
    CONSTRAINT engine_maintenance_break_phase_check CHECK ((phase = ANY (ARRAY['last_hand'::text, 'counting_down'::text])))
);


--
-- Name: TABLE engine_maintenance_break; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.engine_maintenance_break IS 'Single-row platform maintenance break. Written by the engine at :53 before the hourly :55 restart window and deleted when the break ends. Survives the restart on purpose: the booting engine re-parks its tables until break_ends_at, and browsers seeing 4404 during rehydration read it to show a break screen instead of a dead table. Never gate a table on tables.status = paused instead - cash_tables_needing_engine would abandon the table.';


--
-- Name: engine_maintenance_thaws; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engine_maintenance_thaws (
    freeze_started_at timestamp with time zone NOT NULL,
    thawed_at timestamp with time zone DEFAULT now() NOT NULL,
    frozen_seconds numeric NOT NULL,
    shifted jsonb NOT NULL,
    thawed_by text,
    announced_at timestamp with time zone,
    ownership_token uuid,
    contract_version integer,
    release_target_at timestamp with time zone,
    release_generation integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE engine_maintenance_thaws; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.engine_maintenance_thaws IS 'One row per maintenance freeze that has been thawed. The primary key on the freeze start instant is what makes the thaw idempotent: two engines racing at the end of a break cannot both shift the clocks.';


--
-- Name: engine_recovery_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engine_recovery_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    table_id uuid,
    event text NOT NULL,
    detail text,
    hand_count integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    event_class text DEFAULT 'automatic_recovery'::text NOT NULL,
    CONSTRAINT engine_recovery_events_event_check CHECK ((event = ANY (ARRAY['watchdog_rearm_clock'::text, 'watchdog_forced_action'::text, 'watchdog_kill_rebuild'::text, 'paused_too_long'::text, 'table_closed_under_live_tournament'::text]))),
    CONSTRAINT engine_recovery_events_event_class_check CHECK ((event_class = ANY (ARRAY['automatic_recovery'::text, 'fault_injection'::text])))
);


--
-- Name: TABLE engine_recovery_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.engine_recovery_events IS 'One row per automatic freeze/pause recovery action taken by the game engine. Written best-effort by ServerTableEngine (service_role).';


--
-- Name: COLUMN engine_recovery_events.event_class; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.engine_recovery_events.event_class IS 'Provenance of the recovery action. automatic_recovery is production incident evidence; fault_injection is an explicit drill and never counts toward the production kill-rate alarm.';


--
-- Name: engine_tournament_leases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.engine_tournament_leases (
    tournament_id uuid NOT NULL,
    instance_id text NOT NULL,
    engine_version text,
    acquired_at timestamp with time zone DEFAULT now() NOT NULL,
    heartbeat_at timestamp with time zone DEFAULT now() NOT NULL,
    lease_generation uuid DEFAULT gen_random_uuid() NOT NULL,
    protocol_version integer DEFAULT 1 NOT NULL,
    CONSTRAINT engine_tournament_leases_protocol_version_check CHECK ((protocol_version = ANY (ARRAY[1, 2])))
);


--
-- Name: financial_alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    severity text NOT NULL,
    source text NOT NULL,
    message text NOT NULL,
    context jsonb DEFAULT '{}'::jsonb,
    resolved boolean DEFAULT false NOT NULL,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_by uuid,
    resolution text,
    CONSTRAINT financial_alerts_severity_check CHECK ((severity = ANY (ARRAY['critical'::text, 'warning'::text, 'info'::text])))
);


--
-- Name: COLUMN financial_alerts.resolution; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.financial_alerts.resolution IS 'Why this alert was closed, in prose. Required by CLAUDE.md 10.9 for any money settlement; the column was missing until 2026-09-04, so the documented workflow could not be followed. resolved_by is a uuid and cannot carry it.';


--
-- Name: friendships; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.friendships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    friend_id uuid NOT NULL,
    status text DEFAULT 'pending'::text,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT friendships_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'accepted'::text, 'blocked'::text])))
);


--
-- Name: game_management_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.game_management_events (
    sequence bigint NOT NULL,
    event_id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type text NOT NULL,
    scope_kind text,
    scope_id uuid,
    club_id uuid,
    union_id uuid,
    recipient_id uuid,
    entity_type text,
    entity_id uuid,
    command_id uuid,
    actor_id uuid,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT game_management_events_check CHECK (((scope_id IS NOT NULL) OR (recipient_id IS NOT NULL))),
    CONSTRAINT game_management_events_event_type_check CHECK ((event_type = ANY (ARRAY['game_changed'::text, 'game_command_succeeded'::text, 'game_command_rejected'::text, 'ticker_settings_changed'::text, 'club_identity_changed'::text, 'announcement_changed'::text, 'management_access_changed'::text]))),
    CONSTRAINT game_management_events_scope_kind_check CHECK ((scope_kind = ANY (ARRAY['club'::text, 'union'::text])))
)
WITH (autovacuum_freeze_max_age='141000000');


--
-- Name: TABLE game_management_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.game_management_events IS 'Append-only, compact realtime invalidation feed for authorized Table Management clients.';


--
-- Name: game_management_events_sequence_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.game_management_events ALTER COLUMN sequence ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.game_management_events_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: hand_atomic_commits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hand_atomic_commits (
    table_id uuid NOT NULL,
    hand_number bigint NOT NULL,
    hand_id uuid NOT NULL,
    payload_hash text NOT NULL,
    stack_result jsonb NOT NULL,
    committed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    post_commit_payload jsonb,
    post_commit_request_hash text,
    post_commit_payload_hash text,
    post_commit_completed_at timestamp with time zone,
    post_commit_result jsonb,
    CONSTRAINT hand_atomic_commits_hand_number_check CHECK ((hand_number >= 1000000)),
    CONSTRAINT hand_atomic_commits_payload_hash_check CHECK ((payload_hash ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: COLUMN hand_atomic_commits.post_commit_payload; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_atomic_commits.post_commit_payload IS 'Immutable versioned accepted-hand facts plus fee, promo, insurance, time-bank and add-on obligations committed atomically with this hand.';


--
-- Name: COLUMN hand_atomic_commits.post_commit_request_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_atomic_commits.post_commit_request_hash IS 'SHA-256 of the caller payload before database-owned add-on ids are attached; ambiguous-response replays must match it.';


--
-- Name: COLUMN hand_atomic_commits.post_commit_payload_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_atomic_commits.post_commit_payload_hash IS 'SHA-256 of the canonical payload after the transaction freezes eligible pending add-on ids.';


--
-- Name: COLUMN hand_atomic_commits.post_commit_completed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.hand_atomic_commits.post_commit_completed_at IS 'Set in the same transaction that applies every post-commit obligation; NULL is durable work, never permission to invent it.';


--
-- Name: managed_game_contract_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.managed_game_contract_versions (
    id bigint NOT NULL,
    game_kind text NOT NULL,
    game_id uuid NOT NULL,
    club_id uuid NOT NULL,
    union_id uuid,
    version integer NOT NULL,
    contract jsonb NOT NULL,
    contract_hash text NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    published_by uuid,
    change_reason text DEFAULT 'published'::text NOT NULL,
    CONSTRAINT managed_game_contract_versions_contract_hash_check CHECK ((contract_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT managed_game_contract_versions_game_kind_check CHECK ((game_kind = ANY (ARRAY['table'::text, 'tournament'::text]))),
    CONSTRAINT managed_game_contract_versions_version_check CHECK ((version > 0))
)
WITH (autovacuum_freeze_max_age='147000000');


--
-- Name: TABLE managed_game_contract_versions; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.managed_game_contract_versions IS 'Append-only, hashed snapshots of every advertised cash-table and tournament contract. Operator changes publish a new version; old promises are never rewritten.';


--
-- Name: managed_game_contract_versions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.managed_game_contract_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: managed_game_contract_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.managed_game_contract_versions_id_seq OWNED BY public.managed_game_contract_versions.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text,
    data jsonb DEFAULT '{}'::jsonb,
    read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    is_read boolean DEFAULT false,
    action_url text,
    metadata jsonb DEFAULT '{}'::jsonb,
    actor_id uuid,
    link text,
    read_at timestamp with time zone
);

ALTER TABLE ONLY public.notifications REPLICA IDENTITY FULL;


--
-- Name: player_position_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_position_stats (
    user_id uuid NOT NULL,
    "position" text NOT NULL,
    hands_played integer DEFAULT 0 NOT NULL,
    vpip_count integer DEFAULT 0 NOT NULL,
    pfr_count integer DEFAULT 0 NOT NULL,
    three_bet_count integer DEFAULT 0 NOT NULL,
    fold_to_three_bet_count integer DEFAULT 0 NOT NULL,
    hands_won integer DEFAULT 0 NOT NULL,
    total_profit numeric DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
)
WITH (autovacuum_vacuum_scale_factor='0.02', autovacuum_analyze_scale_factor='0.01', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: tables; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tables (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid,
    name text NOT NULL,
    game_type text DEFAULT 'nlhe'::text,
    stakes text,
    small_blind numeric(15,2) DEFAULT 1,
    big_blind numeric(15,2) DEFAULT 2,
    min_buy_in numeric(15,2) DEFAULT 40,
    max_buy_in numeric(15,2) DEFAULT 200,
    max_players integer DEFAULT 9,
    current_players integer DEFAULT 0,
    status text DEFAULT 'waiting'::text,
    is_private boolean DEFAULT false,
    settings jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    game_variant text DEFAULT 'nlh'::text,
    enable_straddle boolean DEFAULT true,
    run_it_twice boolean DEFAULT true,
    auto_muck boolean DEFAULT true,
    ante numeric(15,2) DEFAULT 0,
    allow_rabbit_hunt boolean DEFAULT true,
    allow_run_it_twice boolean DEFAULT true,
    allow_straddle boolean DEFAULT true,
    game_mode character varying(10) DEFAULT 'regular'::character varying,
    is_vip_only boolean DEFAULT false,
    is_anonymous boolean DEFAULT false,
    ban_chat boolean DEFAULT false,
    label_as_new boolean DEFAULT false,
    is_featured boolean DEFAULT false,
    hide_club_name boolean DEFAULT false,
    is_template boolean DEFAULT false,
    bomb_pot_enabled boolean DEFAULT false,
    double_board boolean DEFAULT false,
    triple_board boolean DEFAULT false,
    pineapple_holdem boolean DEFAULT false,
    seven_deuce_enabled boolean DEFAULT false,
    nit_game boolean DEFAULT false,
    cap_enabled boolean DEFAULT false,
    no_rathole boolean DEFAULT false,
    action_time_seconds integer DEFAULT 15,
    ante_bb numeric(10,2) DEFAULT 0,
    career_percent_min integer DEFAULT 0,
    maintain_percent_min integer DEFAULT 0,
    maintain_hands integer DEFAULT 10,
    auto_start_players integer DEFAULT 2,
    game_length_hours integer DEFAULT 12,
    created_by uuid,
    calltime_enabled boolean DEFAULT false,
    auto_extension boolean DEFAULT false,
    auto_restart boolean DEFAULT false,
    auto_create_table boolean DEFAULT false,
    auto_utg_straddle boolean DEFAULT false,
    voluntary_straddle boolean DEFAULT false,
    insurance_enabled boolean DEFAULT false,
    run_it_mode character varying(20) DEFAULT 'none'::character varying,
    rake_percent numeric(5,2) DEFAULT '-1'::integer,
    rake_cap_bb numeric(5,2) DEFAULT '-1'::integer,
    agent_downline_limit integer,
    buy_in_authorization boolean DEFAULT false,
    restrict_device boolean DEFAULT true,
    restrict_observers boolean DEFAULT false,
    gps_restriction boolean DEFAULT true,
    ip_restriction boolean DEFAULT false,
    pc_emulator_restriction boolean DEFAULT false,
    photo_rotation_verification boolean DEFAULT false,
    short_description text DEFAULT ''::text,
    accelerated_mtt boolean DEFAULT false,
    all_in_or_fold boolean DEFAULT false,
    custom_rebuy_reentry_cost boolean DEFAULT false,
    number_of_rebuys_reentries integer DEFAULT 3,
    add_on_multiplier numeric(3,1) DEFAULT 1.0,
    custom_add_on boolean DEFAULT false,
    add_on_break_length_minutes integer DEFAULT 1,
    ko_bounty boolean DEFAULT false,
    gtd_prize_pool boolean DEFAULT false,
    final_table_deal boolean DEFAULT false,
    big_blind_ante boolean DEFAULT false,
    authorized_to_register boolean DEFAULT false,
    late_registration_level integer DEFAULT 6,
    early_bird_registration boolean DEFAULT false,
    bubble_protection boolean DEFAULT false,
    featured_tournament boolean DEFAULT false,
    min_players_mtt integer DEFAULT 30,
    max_players_mtt integer DEFAULT 300,
    multi_day_mtt boolean DEFAULT false,
    save_start_time boolean DEFAULT false,
    start_time timestamp with time zone,
    restart_tournament_every boolean DEFAULT false,
    tournament_schedule boolean DEFAULT false,
    synchronized_breaks boolean DEFAULT true,
    sng_buy_in numeric(10,2) DEFAULT 0,
    blind_structure character varying(20) DEFAULT 'standard'::character varying,
    payout_structure character varying(50) DEFAULT 'winner_takes_all'::character varying,
    starting_chips integer DEFAULT 1500,
    blinds_up_minutes integer DEFAULT 10,
    next_step_satellite boolean DEFAULT false,
    sng_custom_buy_in boolean DEFAULT false,
    sng_player_count integer DEFAULT 9,
    is_spins boolean DEFAULT false,
    spins_multiplier integer,
    is_deleted boolean DEFAULT false,
    deleted_at timestamp with time zone,
    deleted_by uuid,
    bbj_percent numeric(5,2) DEFAULT 100,
    tournament_id uuid,
    live_state jsonb,
    union_id uuid,
    big_blind_ante_enabled boolean DEFAULT false,
    straddle_enabled boolean DEFAULT false,
    straddle_type text DEFAULT 'utg'::text,
    max_straddles integer DEFAULT 1,
    run_it_twice_enabled boolean DEFAULT false,
    auto_muck_enabled boolean DEFAULT true,
    show_hand_enabled boolean DEFAULT true,
    disconnect_timeout_seconds integer DEFAULT 30,
    max_consecutive_timeouts integer DEFAULT 3,
    prefer_check_over_fold boolean DEFAULT true,
    time_bank_max_uses integer DEFAULT 4,
    time_bank_enabled boolean DEFAULT true,
    ante_enabled boolean DEFAULT false,
    bomb_pot_frequency integer DEFAULT 0,
    bomb_pot_ante_multiplier integer DEFAULT 2,
    wait_for_big_blind boolean DEFAULT true NOT NULL,
    seven_deuce_amount numeric DEFAULT 2 NOT NULL,
    hands_dealt bigint DEFAULT 0 NOT NULL,
    avg_pot numeric(14,2) DEFAULT 0 NOT NULL,
    bomb_pot_double_board boolean DEFAULT false NOT NULL,
    cap_bb numeric(10,2),
    bomb_pot_board_count smallint DEFAULT 1 NOT NULL,
    bomb_pot_trigger_mode text DEFAULT 'every_n_hands'::text NOT NULL,
    bomb_pot_interval_seconds integer,
    bomb_pot_min_players smallint DEFAULT 3 NOT NULL,
    bomb_pot_ante_fixed numeric,
    first_button_seat integer,
    bomb_pot_variant text,
    bomb_pot_next_due_at timestamp with time zone,
    bomb_pot_sched_state jsonb,
    bomb_pot_manual_pending boolean DEFAULT false NOT NULL,
    bomb_pot_button_policy text DEFAULT 'regular'::text NOT NULL,
    bomb_pot_announce_seconds integer,
    min_buy_in_bb integer GENERATED ALWAYS AS (
CASE
    WHEN ((tournament_id IS NULL) AND (COALESCE(big_blind, (0)::numeric) > (0)::numeric) AND (min_buy_in IS NOT NULL)) THEN (ceil((min_buy_in / big_blind)))::integer
    ELSE NULL::integer
END) STORED,
    max_buy_in_bb integer GENERATED ALWAYS AS (
CASE
    WHEN ((tournament_id IS NULL) AND (COALESCE(big_blind, (0)::numeric) > (0)::numeric) AND (max_buy_in IS NOT NULL)) THEN (floor((max_buy_in / big_blind)))::integer
    ELSE NULL::integer
END) STORED,
    min_buyin integer GENERATED ALWAYS AS (
CASE
    WHEN ((tournament_id IS NULL) AND (COALESCE(big_blind, (0)::numeric) > (0)::numeric) AND (min_buy_in IS NOT NULL)) THEN (ceil((min_buy_in / big_blind)))::integer
    ELSE NULL::integer
END) STORED,
    max_buyin integer GENERATED ALWAYS AS (
CASE
    WHEN ((tournament_id IS NULL) AND (COALESCE(big_blind, (0)::numeric) > (0)::numeric) AND (max_buy_in IS NOT NULL)) THEN (floor((max_buy_in / big_blind)))::integer
    ELSE NULL::integer
END) STORED,
    cluster_id uuid,
    role text,
    main_index integer,
    lifecycle text,
    opened_at timestamp with time zone,
    live_at timestamp with time zone,
    break_started_at timestamp with time zone,
    break_eligible_since timestamp with time zone,
    promote_pending boolean DEFAULT false NOT NULL,
    observer_show_cards boolean DEFAULT false NOT NULL,
    terminal_closed_at timestamp with time zone,
    seat_game_scope text,
    seat_admission_key text,
    CONSTRAINT table_game_scope_is_derived CHECK (((seat_game_scope IS NULL) OR (seat_game_scope =
CASE
    WHEN (cluster_id IS NULL) THEN ('table:'::text || (id)::text)
    ELSE ('cluster:'::text || (cluster_id)::text)
END))),
    CONSTRAINT table_seat_admission_is_derived CHECK (((seat_admission_key IS NULL) OR (seat_admission_key =
CASE
    WHEN ((lower(COALESCE(status, ''::text)) = ANY (ARRAY['closed'::text, 'completed'::text, 'cancelled'::text, 'finished'::text])) OR (lifecycle = 'closed'::text) OR COALESCE(is_deleted, false) OR COALESCE(is_template, false)) THEN 'closed'::text
    WHEN (tournament_id IS NOT NULL) THEN ('tournament:'::text || (tournament_id)::text)
    ELSE 'cash'::text
END))),
    CONSTRAINT tables_bomb_pot_board_count_check CHECK (((bomb_pot_board_count >= 1) AND (bomb_pot_board_count <= 3))),
    CONSTRAINT tables_bomb_pot_button_policy_check CHECK ((bomb_pot_button_policy = ANY (ARRAY['regular'::text, 'separate'::text]))),
    CONSTRAINT tables_bomb_pot_trigger_mode_check CHECK ((bomb_pot_trigger_mode = ANY (ARRAY['every_n_hands'::text, 'once_per_orbit'::text, 'timed'::text, 'bomb_pot_only'::text]))),
    CONSTRAINT tables_bomb_pot_variant_check CHECK (((bomb_pot_variant IS NULL) OR ((bomb_pot_variant = ANY (ARRAY['nlh'::text, 'plo4'::text, 'plo5'::text, 'plo6'::text, 'flh'::text, 'flo8'::text])) AND ((lower(COALESCE(game_variant, 'nlh'::text)) = ANY (ARRAY['flh'::text, 'flo8'::text])) = (bomb_pot_variant = ANY (ARRAY['flh'::text, 'flo8'::text])))))),
    CONSTRAINT tables_cash_needs_a_game CHECK (((tournament_id IS NOT NULL) OR (cluster_id IS NOT NULL) OR (status = ANY (ARRAY['closed'::text, 'deleted'::text])) OR COALESCE(is_deleted, false) OR (club_id IS NULL) OR (game_variant IS NULL) OR (COALESCE(small_blind, (0)::numeric) <= (0)::numeric) OR (COALESCE(big_blind, (0)::numeric) <= COALESCE(small_blind, (0)::numeric)))),
    CONSTRAINT tables_game_type_is_format CHECK ((game_type = ANY (ARRAY['cash'::text, 'tournament'::text]))),
    CONSTRAINT tables_lifecycle_check CHECK ((lifecycle = ANY (ARRAY['opening'::text, 'live'::text, 'breaking'::text, 'closed'::text]))),
    CONSTRAINT tables_main_index_check CHECK ((main_index >= 1)),
    CONSTRAINT tables_role_check CHECK ((role = ANY (ARRAY['main'::text, 'feeder'::text]))),
    CONSTRAINT tables_status_check CHECK ((status = ANY (ARRAY['waiting'::text, 'active'::text, 'running'::text, 'paused'::text, 'closed'::text]))),
    CONSTRAINT tables_straddle_type_check CHECK ((straddle_type = 'utg'::text)),
    CONSTRAINT tables_terminal_closed_shape CHECK (((terminal_closed_at IS NULL) OR ((lower(COALESCE(status, ''::text)) = 'closed'::text) AND (lower(COALESCE(lifecycle, ''::text)) = 'closed'::text) AND (NOT (current_players IS DISTINCT FROM 0)))))
)
WITH (autovacuum_vacuum_scale_factor='0.02', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: TABLE tables; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tables IS 'Poker tables, all statuses. DO NOT PRUNE closed rows without reading this: DELETE cascades to table_seats, table_chat, table_activity, table_cashout_history, hand_state_snapshots, insurance_transactions, table_waitlist and favorite_tables, and rake_records.table_id is ON DELETE SET NULL - pruning blanks the table link on historical rake records and destroys financial provenance. 62k closed rows cost 67 MB and the lobby reads open games in 3.5 ms via a partial index, so there is nothing to gain. Investigated 2026-08-23.';


--
-- Name: COLUMN tables.min_buy_in; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.min_buy_in IS 'CANONICAL. Smallest stack this table sells, in CHIPS. Enforced by atomic_table_buyin and read by the engine; every other buy-in column on this table is derived from this one.';


--
-- Name: COLUMN tables.max_buy_in; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.max_buy_in IS 'CANONICAL. Largest stack this table sells, in CHIPS. Enforced by atomic_table_buyin and read by the engine; every other buy-in column on this table is derived from this one.';


--
-- Name: COLUMN tables.double_board; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.double_board IS 'RETIRED 2026-08-29. Write-only: no reader has ever existed in either repo, and TableConfigPage stopped writing it in the same change. The engine reads bomb_pot_double_board; the lobby reads the settings blob. Droppable once a release has passed. Do not start writing it again.';


--
-- Name: COLUMN tables.rake_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.rake_percent IS 'Per-table override. -1 (RAKE_INHERIT) or NULL means inherit from clubs.default_rake_percent, then from the schedule. An override can only LOWER the schedule rate (RakeConfig.ts applies Math.min).';


--
-- Name: COLUMN tables.rake_cap_bb; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.rake_cap_bb IS 'Per-table cap override in BIG BLINDS. -1 or NULL means inherit from clubs.rake_cap, then the schedule cap.';


--
-- Name: COLUMN tables.live_state; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.live_state IS 'Serialized mid-hand game state for crash recovery. Cleared on hand_complete.';


--
-- Name: COLUMN tables.big_blind_ante_enabled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.big_blind_ante_enabled IS 'Bible V8 §4.3: When true, BB posts ante for entire table instead of each player posting individually';


--
-- Name: COLUMN tables.straddle_enabled; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.straddle_enabled IS 'Bible V8 §4.4: When true, UTG straddle is allowed (2x BB)';


--
-- Name: COLUMN tables.straddle_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.straddle_type IS 'Bible V8 §4.4: Only utg allowed — UTG posts 2x BB before preflop action';


--
-- Name: COLUMN tables.max_straddles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.max_straddles IS 'Bible V8 §4.4: Always 1 — only one UTG straddle per hand';


--
-- Name: COLUMN tables.seven_deuce_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.seven_deuce_amount IS '7-2 game: big-blind multiple each other dealt-in player pays a post-flop 7-2 winner. Default 2 BB.';


--
-- Name: COLUMN tables.cap_bb; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.cap_bb IS 'Per-hand betting cap in big blinds. Enforced only when cap_enabled is true. NULL or 0 means uncapped.';


--
-- Name: COLUMN tables.first_button_seat; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.first_button_seat IS 'Seat number of a button DRAWN before the first hand (Spin reveal, beat 3). Read back by TournamentManagerBase.restoreDrawnFirstButtons on engine restart and re-applied ONLY while the table has zero hand_history rows - past the first hand a forced seat beats the live rotation and would throw the button backwards. Cleared once the table has dealt.';


--
-- Name: COLUMN tables.min_buy_in_bb; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.min_buy_in_bb IS 'DERIVED, read-only. ceil(min_buy_in / big_blind). NULL on tournament rows and on rows with no blinds. Write min_buy_in instead.';


--
-- Name: COLUMN tables.max_buy_in_bb; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.max_buy_in_bb IS 'DERIVED, read-only. floor(max_buy_in / big_blind). NULL on tournament rows and on rows with no blinds. Write max_buy_in instead.';


--
-- Name: COLUMN tables.min_buyin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.min_buyin IS 'DERIVED, read-only. Legacy alias of min_buy_in_bb kept so external SELECT lists keep working. Write min_buy_in instead.';


--
-- Name: COLUMN tables.max_buyin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.max_buyin IS 'DERIVED, read-only. Legacy alias of max_buy_in_bb kept so external SELECT lists keep working. Write max_buy_in instead.';


--
-- Name: COLUMN tables.observer_show_cards; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tables.observer_show_cards IS 'When true, non-seated observers may see tabled cards at showdown or during an all-in runout. False is the privacy default.';


--
-- Name: CONSTRAINT tables_cash_needs_a_game ON tables; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON CONSTRAINT tables_cash_needs_a_game ON public.tables IS 'Gate 7 (2026-09-05): an open cash table belongs to a cash_games row. There is no standalone cash table.';


--
-- Name: player_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_stats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    club_id uuid,
    hands_played integer DEFAULT 0,
    total_winnings numeric(15,2) DEFAULT 0 NOT NULL,
    total_losses numeric(15,2) DEFAULT 0,
    total_rake numeric(15,2) DEFAULT 0 NOT NULL,
    vpip numeric(5,2) DEFAULT 0,
    pfr numeric(5,2) DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now(),
    tournaments_played integer DEFAULT 0,
    tournaments_won integer DEFAULT 0,
    hands_dealt bigint DEFAULT 0 NOT NULL,
    sum_big_blind numeric DEFAULT 0 NOT NULL
)
WITH (autovacuum_vacuum_scale_factor='0.02', autovacuum_analyze_scale_factor='0.01', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: COLUMN player_stats.hands_played; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.player_stats.hands_played IS 'LEGACY / rakeback-owned. Maintained by RakebackSettlerService, which only walks RAKED hands and books per settled row, not per seat - measured at 13.4% of true seat-hands on 2026-08-18 (144,956 booked vs 1,083,942 dealt). Do NOT use for a hands leaderboard; use hands_dealt. Kept because rakeback accounting depends on it.';


--
-- Name: COLUMN player_stats.total_winnings; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.player_stats.total_winnings IS 'Sum of pot amounts won, folded in by the hand_history_fold_stats trigger.';


--
-- Name: COLUMN player_stats.total_losses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.player_stats.total_losses IS 'Sum of chips contributed to pots, accumulated by promo_apply_playthrough which the engine calls once per contributing player per cash hand. Profit = total_winnings - total_losses is therefore exact net.';


--
-- Name: COLUMN player_stats.hands_dealt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.player_stats.hands_dealt IS 'Seat-hands: incremented once per seated player per cash hand by the hand_history_fold_stats trigger. This is the TRUE hand count and the one the leaderboard uses. Verified 2026-08-19 at 100.0% of hand_history seat-hands.';


--
-- Name: COLUMN player_stats.sum_big_blind; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.player_stats.sum_big_blind IS 'Sum of big_blind over every cash hand the player was dealt into. Denominator for bb/100 = 100 * (total_winnings - total_losses) / sum_big_blind.';


--
-- Name: poker_diamond_custody; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.poker_diamond_custody (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    arena_id uuid NOT NULL,
    purpose text NOT NULL,
    target_id uuid NOT NULL,
    entry_key text NOT NULL,
    balance bigint DEFAULT 0 NOT NULL,
    state text DEFAULT 'reserved'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    released_at timestamp with time zone,
    seat_id uuid,
    seat_joined_at timestamp with time zone,
    occupancy_id uuid,
    CONSTRAINT poker_diamond_custody_balance_check CHECK (((balance >= 0) AND (balance <= 2147483647))),
    CONSTRAINT poker_diamond_custody_check CHECK (((state = 'released'::text) = (released_at IS NOT NULL))),
    CONSTRAINT poker_diamond_custody_check1 CHECK (((state <> 'released'::text) OR (balance = 0))),
    CONSTRAINT poker_diamond_custody_entry_key_check CHECK (((length(entry_key) >= 1) AND (length(entry_key) <= 160))),
    CONSTRAINT poker_diamond_custody_purpose_check CHECK ((purpose = ANY (ARRAY['cash_seat'::text, 'tournament_entry'::text]))),
    CONSTRAINT poker_diamond_custody_state_check CHECK ((state = ANY (ARRAY['reserved'::text, 'active'::text, 'released'::text]))),
    CONSTRAINT poker_diamond_seat_identity_complete CHECK ((((seat_id IS NULL) AND (seat_joined_at IS NULL) AND (occupancy_id IS NULL)) OR ((purpose = 'cash_seat'::text) AND (seat_id IS NOT NULL) AND (seat_joined_at IS NOT NULL) AND (occupancy_id IS NOT NULL))))
);


--
-- Name: rakeback_stats_applied; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rakeback_stats_applied (
    rake_record_id uuid NOT NULL,
    user_id uuid NOT NULL,
    hands integer,
    rake numeric,
    created_at timestamp with time zone DEFAULT now() NOT NULL
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='1000', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='1000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: settlement_idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settlement_idempotency_keys (
    table_id uuid NOT NULL,
    hand_id uuid NOT NULL,
    status text DEFAULT 'in_flight'::text NOT NULL,
    result jsonb,
    error text,
    attempt_count integer DEFAULT 1 NOT NULL,
    first_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    last_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT settlement_idempotency_keys_status_check CHECK ((status = ANY (ARRAY['in_flight'::text, 'succeeded'::text, 'failed'::text])))
)
WITH (autovacuum_freeze_max_age='132000000');


--
-- Name: signup_errors_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.signup_errors_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: signup_errors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.signup_errors_id_seq OWNED BY public.signup_errors.id;


--
-- Name: social_follows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_follows (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    follower_id uuid,
    following_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: social_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_pages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id uuid,
    page_type text NOT NULL,
    name text NOT NULL,
    slug text,
    description text,
    avatar_url text,
    cover_url text,
    category text DEFAULT 'general'::text,
    website text,
    contact_email text,
    phone text,
    location_city text,
    location_state text,
    location_country text DEFAULT 'US'::text,
    linked_venue_id text,
    linked_entity_type text,
    linked_entity_id text,
    follower_count integer DEFAULT 0,
    post_count integer DEFAULT 0,
    member_count integer DEFAULT 0,
    is_verified boolean DEFAULT false,
    is_public boolean DEFAULT true,
    allow_member_posts boolean DEFAULT true,
    require_post_approval boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    view_count integer DEFAULT 0,
    avg_rating numeric(3,2) DEFAULT 0,
    CONSTRAINT ck_home_group_link_is_home_game CHECK (((linked_entity_type IS DISTINCT FROM 'home_group'::text) OR (page_type = 'home_game'::text))),
    CONSTRAINT social_pages_page_type_check CHECK ((page_type = ANY (ARRAY['venue'::text, 'group'::text, 'brand'::text, 'community'::text, 'club'::text, 'home_game'::text, 'charity'::text])))
);


--
-- Name: COLUMN social_pages.linked_venue_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.social_pages.linked_venue_id IS 'LEGACY: use linked_entity_type=''venue'' + linked_entity_id instead.';


--
-- Name: COLUMN social_pages.linked_entity_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.social_pages.linked_entity_type IS 'Canonical entity linking. Values: home_group, venue, club. Use alongside linked_entity_id.';


--
-- Name: spin_bonus_pools; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spin_bonus_pools (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    balance numeric(12,2) DEFAULT 0 NOT NULL,
    total_deposited numeric(12,2) DEFAULT 0 NOT NULL,
    total_drawn numeric(12,2) DEFAULT 0 NOT NULL,
    spin_count integer DEFAULT 0 NOT NULL,
    bonus_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    seeded_amount numeric DEFAULT 0 NOT NULL,
    ceiling_amount numeric DEFAULT 0 NOT NULL,
    highest_stake numeric DEFAULT 0 NOT NULL,
    surplus_returned numeric DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    owner_kind text DEFAULT 'club'::text NOT NULL,
    offered_max_stake numeric DEFAULT 0 NOT NULL,
    activated_at timestamp with time zone,
    activated_by uuid,
    deactivated_at timestamp with time zone,
    seed_source_wallet text,
    seed_returned_at timestamp with time zone,
    seed_returned_amount numeric DEFAULT 0 NOT NULL,
    required_seed_at_activation numeric DEFAULT 0 NOT NULL,
    CONSTRAINT spin_bonus_pools_balance_check CHECK ((balance >= ('-500'::integer)::numeric)),
    CONSTRAINT spin_bonus_pools_balance_non_negative CHECK ((balance >= (0)::numeric)),
    CONSTRAINT spin_bonus_pools_owner_kind_check CHECK ((owner_kind = ANY (ARRAY['union'::text, 'club'::text])))
);


--
-- Name: COLUMN spin_bonus_pools.club_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.club_id IS 'The OWNER of this reserve, not necessarily a playing club. A union owns one pool shared by all its clubs; a standalone club owns its own. Resolve with fn_spin_reserve_owner(). Named club_id for history - a union is itself a clubs row in this schema.';


--
-- Name: COLUMN spin_bonus_pools.seeded_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.seeded_amount IS 'Seed still owed back to the owner. Drops to zero when repaid; seed_returned_amount keeps the historical total.';


--
-- Name: COLUMN spin_bonus_pools.ceiling_amount; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.ceiling_amount IS 'Once balance reaches this, surplus stops accruing and is returned to the operator.';


--
-- Name: COLUMN spin_bonus_pools.highest_stake; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.highest_stake IS 'Largest Spin buy-in currently offered by this club. Jackpot thresholds are measured against it.';


--
-- Name: COLUMN spin_bonus_pools.is_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.is_active IS 'Whether this owner offers Spins. Set only by fn_spin_activate / fn_spin_deactivate, and read by TournamentRecurringService.activatedSpinOwners when deciding whose boards to open.';


--
-- Name: COLUMN spin_bonus_pools.owner_kind; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.owner_kind IS 'union | club - which kind of entity club_id points at.';


--
-- Name: COLUMN spin_bonus_pools.offered_max_stake; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.offered_max_stake IS 'Largest Spin buy-in this owner offers. Set at activation. Drives the required seed and tier thresholds; highest_stake stays the largest buy-in actually PLAYED.';


--
-- Name: COLUMN spin_bonus_pools.seed_source_wallet; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.seed_source_wallet IS 'The wallet the seed was debited from, so repayment returns to where it came from.';


--
-- Name: COLUMN spin_bonus_pools.required_seed_at_activation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.spin_bonus_pools.required_seed_at_activation IS 'The repayment bar, frozen when the seed was taken. Deliberately NOT recomputed from offered_max_stake, which the owner can change by reactivating - lowering it would repay a large seed after trivial play, raising it would strand one forever.';


--
-- Name: spin_draw_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spin_draw_receipts (
    tournament_id uuid NOT NULL,
    launch_id uuid NOT NULL,
    lease_generation uuid NOT NULL,
    rule_manifest jsonb NOT NULL,
    rule_sha256 text NOT NULL,
    entrants jsonb NOT NULL,
    receipt jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT spin_draw_receipts_entrants_check CHECK ((jsonb_array_length(entrants) = 3)),
    CONSTRAINT spin_draw_receipts_rule_sha256_check CHECK ((rule_sha256 ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: spin_payout_ladder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spin_payout_ladder (
    multiplier numeric NOT NULL,
    structure jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE spin_payout_ladder; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.spin_payout_ladder IS 'The payout ladder each Spin multiplier owes, mirroring SPIN_TIERS in server/src/config/spinSpec.ts. Sub-10x is winner-take-all; 10x is 80/20; 25x/50x/100x are 80/12/8. Kept in the database because the payout auditor runs here and had no way to tell a drawn ladder from an overwritten one.';


--
-- Name: spin_reserve_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spin_reserve_ledger (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    tournament_id uuid,
    kind text NOT NULL,
    amount numeric NOT NULL,
    balance_after numeric NOT NULL,
    multiplier numeric,
    buy_in numeric,
    seats integer,
    house_rake numeric,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT chk_amount_is_two_decimal_places CHECK (((amount IS NULL) OR (amount = round(amount, 2)))),
    CONSTRAINT spin_reserve_ledger_kind_check CHECK ((kind = ANY (ARRAY['seed'::text, 'contribution'::text, 'jackpot_draw'::text, 'surplus_return'::text, 'adjustment'::text, 'merge'::text, 'wallet_return'::text, 'seed_return'::text, 'activation'::text, 'deactivation'::text, 'draw_reversal'::text, 'contribution_reversal'::text])))
);


--
-- Name: TABLE spin_reserve_ledger; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.spin_reserve_ledger IS 'Audit trail for the Spin Reserve Pool. Added 2026-08-20 after production analysis found ~1,160 of Spin margin existing in no ledger at all across 2,091 games.';


--
-- Name: table_seats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_seats (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    table_id uuid NOT NULL,
    seat_number integer NOT NULL,
    user_id uuid,
    player_id integer,
    member_id uuid,
    stack numeric(15,2) DEFAULT 0,
    is_sitting_out boolean DEFAULT false,
    is_away boolean DEFAULT false,
    joined_at timestamp with time zone DEFAULT now(),
    horse_id uuid,
    scheduled_leave_hands integer,
    left_at timestamp with time zone,
    status text DEFAULT 'active'::text,
    leave_pending boolean DEFAULT false,
    auto_rebuy boolean DEFAULT false,
    time_bank_remaining integer DEFAULT 30,
    time_bank_uses_remaining integer DEFAULT 4,
    club_id uuid,
    sit_out_at timestamp with time zone,
    entry_hold text,
    entry_post_agreed boolean DEFAULT false NOT NULL,
    occupancy_id uuid DEFAULT gen_random_uuid() NOT NULL,
    active_game_scope text,
    active_parent_key text,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT active_seat_requires_game_scope CHECK ((((left_at IS NULL) AND (active_game_scope IS NOT NULL) AND (user_id IS NOT NULL) AND (table_id IS NOT NULL)) OR ((left_at IS NOT NULL) AND (active_game_scope IS NULL)))),
    CONSTRAINT active_seat_requires_open_parent CHECK ((((left_at IS NULL) AND (active_parent_key IS NOT NULL) AND (active_parent_key <> 'closed'::text)) OR ((left_at IS NOT NULL) AND (active_parent_key IS NULL)))),
    CONSTRAINT table_seats_entry_hold_check CHECK (((entry_hold IS NULL) OR (entry_hold = ANY (ARRAY['waiting'::text, 'posting'::text, 'moved'::text])))),
    CONSTRAINT table_seats_seat_number_check CHECK (((seat_number >= 1) AND (seat_number <= 10))),
    CONSTRAINT table_seats_stack_nonneg CHECK ((stack >= (0)::numeric))
)
WITH (autovacuum_vacuum_scale_factor='0.02', autovacuum_analyze_scale_factor='0.02', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='1000');


--
-- Name: TABLE table_seats; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.table_seats IS 'Phase 31: user_id migrated TEXT→UUID (Club Arena, no FK — allows guest seats).';


--
-- Name: COLUMN table_seats.club_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.table_seats.club_id IS 'UNION LAW (Dan 2026-08-20): the club whose chips this player sat down with. Rake from this seat belongs to that club only. NULL = legacy seat predating club-scoped buy-ins; attribution falls back to first-joined membership.';


--
-- Name: COLUMN table_seats.sit_out_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.table_seats.sit_out_at IS 'When this seat entered the sitting-out state. Stamped and cleared by trg_stamp_sit_out_at; never written by hand. NULL whenever is_sitting_out is false. The cash-game 5-minute eviction clock reads THIS, not process memory, so that it survives an engine restart (2026-08-28).';


--
-- Name: COLUMN table_seats.entry_hold; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.table_seats.entry_hold IS 'Cash entry hold, so it survives an engine restart. NULL = in the rotation. ''waiting'' = held until the big blind reaches this seat. ''posting'' = post accepted, owes one live big blind on the next deal. Read back by loadSeatedPlayers and restored by restoreEntryHoldsFromSeats(). Added 2026-08-30.';


--
-- Name: COLUMN table_seats.entry_post_agreed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.table_seats.entry_post_agreed IS 'The player has already tapped Post Big Blind and is held only by their seat (the one the small blind or the button is about to reach). The dealing loop replays the agreement until the seat clears. NOT a licence to post from either seat: both hold-outs are re-checked on every replay. Added 2026-08-30.';


--
-- Name: table_waitlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.table_waitlist (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    table_id uuid NOT NULL,
    user_id uuid NOT NULL,
    "position" integer DEFAULT 1 NOT NULL,
    status text DEFAULT 'waiting'::text NOT NULL,
    notified_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    hold_expires_at timestamp with time zone,
    CONSTRAINT table_waitlist_status_check CHECK ((status = ANY (ARRAY['waiting'::text, 'notified'::text, 'seated'::text, 'left'::text, 'cleared'::text, 'expired'::text])))
);

ALTER TABLE ONLY public.table_waitlist REPLICA IDENTITY FULL;


--
-- Name: TABLE table_waitlist; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.table_waitlist IS 'Canonical cash-table waitlist. FIFO by created_at. Replaced the duplicate public.table_waitlists on 2026-08-21.';


--
-- Name: COLUMN table_waitlist."position"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.table_waitlist."position" IS 'VESTIGIAL. Queue order is created_at, everywhere. Kept only so existing SELECTs do not break; do not write a meaningful value here.';


--
-- Name: COLUMN table_waitlist.hold_expires_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.table_waitlist.hold_expires_at IS 'While status=notified and this is in the future, one open seat at the table is reserved exclusively for this player. Set by fn_offer_open_seat (60s), honoured by atomic_table_buyin.';


--
-- Name: tournament_bounties; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_bounties (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    eliminated_player_id uuid NOT NULL,
    collector_player_id uuid NOT NULL,
    bounty_amount numeric(20,2) NOT NULL,
    added_to_collector_bounty numeric(20,2) DEFAULT 0,
    is_mystery_revealed boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    bounty_obligation_id uuid
);


--
-- Name: TABLE tournament_bounties; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_bounties IS 'BUG 015 FIX 2026-04-15 — bounty KO record';


--
-- Name: tournament_bounty_award_recipients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_bounty_award_recipients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    award_id uuid NOT NULL,
    user_id uuid NOT NULL,
    amount_cents bigint NOT NULL,
    is_designated_revealer boolean DEFAULT false NOT NULL,
    paid_at timestamp with time zone,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT tournament_bounty_award_recipients_amount_cents_check CHECK ((amount_cents >= 0))
);


--
-- Name: tournament_bounty_awards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_bounty_awards (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    chest_id uuid NOT NULL,
    table_id uuid,
    hand_id text,
    eliminated_user_id uuid NOT NULL,
    amount_cents bigint NOT NULL,
    tier text NOT NULL,
    status text DEFAULT 'reserved'::text NOT NULL,
    op_id uuid NOT NULL,
    reserved_at timestamp with time zone DEFAULT now() NOT NULL,
    revealed_at timestamp with time zone,
    paid_at timestamp with time zone,
    reveal_deadline_at timestamp with time zone,
    bounty_obligation_id uuid,
    activation_generation bigint,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT tournament_bounty_awards_amount_cents_check CHECK ((amount_cents > 0)),
    CONSTRAINT tournament_bounty_awards_bound_generation_present CHECK (((bounty_obligation_id IS NULL) OR (activation_generation IS NOT NULL))),
    CONSTRAINT tournament_bounty_awards_status_check CHECK ((status = ANY (ARRAY['reserved'::text, 'revealed'::text, 'paid'::text, 'completed'::text, 'void'::text])))
);


--
-- Name: tournament_bounty_chests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_bounty_chests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    seq integer NOT NULL,
    tier text NOT NULL,
    amount_cents bigint NOT NULL,
    status text DEFAULT 'available'::text NOT NULL,
    award_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT tournament_bounty_chests_amount_cents_check CHECK ((amount_cents > 0)),
    CONSTRAINT tournament_bounty_chests_status_check CHECK ((status = ANY (ARRAY['available'::text, 'reserved'::text, 'revealed'::text, 'paid'::text, 'void'::text]))),
    CONSTRAINT tournament_bounty_chests_tier_check CHECK ((tier = ANY (ARRAY['jackpot'::text, 'mega'::text, 'major'::text, 'large'::text, 'medium'::text, 'small'::text, 'base_plus'::text, 'base'::text])))
);


--
-- Name: tournament_bounty_completion_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_bounty_completion_receipts (
    tournament_id uuid NOT NULL,
    winner_user_id uuid,
    mystery_settled_at timestamp with time zone,
    mystery_result jsonb,
    pool_finalized_at timestamp with time zone,
    pool_result jsonb,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tournament_bounty_completion_receipts_check CHECK ((((mystery_settled_at IS NULL) AND (mystery_result IS NULL)) OR ((mystery_settled_at IS NOT NULL) AND (winner_user_id IS NOT NULL) AND (jsonb_typeof(mystery_result) = 'object'::text)))),
    CONSTRAINT tournament_bounty_completion_receipts_check1 CHECK ((((pool_finalized_at IS NULL) AND (pool_result IS NULL)) OR ((pool_finalized_at IS NOT NULL) AND (winner_user_id IS NOT NULL) AND (jsonb_typeof(pool_result) = 'object'::text))))
);


--
-- Name: tournament_bounty_obligations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_bounty_obligations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    eliminated_user_id uuid NOT NULL,
    table_id uuid NOT NULL,
    hand_id uuid NOT NULL,
    hand_number bigint NOT NULL,
    settlement_completed_at timestamp with time zone NOT NULL,
    seat_joined_at timestamp with time zone NOT NULL,
    "position" integer NOT NULL,
    prize numeric(20,2) NOT NULL,
    bubble_refund numeric(20,2) DEFAULT 0 NOT NULL,
    mode text NOT NULL,
    activation_generation bigint DEFAULT 0 NOT NULL,
    head_amount numeric(20,2) NOT NULL,
    knocker_user_id uuid NOT NULL,
    claimants jsonb NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    settled_at timestamp with time zone,
    CONSTRAINT tournament_bounty_obligations_activation_generation_check CHECK ((activation_generation >= 0)),
    CONSTRAINT tournament_bounty_obligations_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT tournament_bounty_obligations_bubble_refund_check CHECK ((bubble_refund >= (0)::numeric)),
    CONSTRAINT tournament_bounty_obligations_check CHECK ((((mode = 'mystery_chest'::text) AND (activation_generation > 0)) OR ((mode <> 'mystery_chest'::text) AND (activation_generation = 0)))),
    CONSTRAINT tournament_bounty_obligations_claimants_check CHECK ((jsonb_typeof(claimants) = 'array'::text)),
    CONSTRAINT tournament_bounty_obligations_hand_number_check CHECK ((hand_number >= 1000000)),
    CONSTRAINT tournament_bounty_obligations_head_amount_check CHECK ((head_amount > (0)::numeric)),
    CONSTRAINT tournament_bounty_obligations_mode_check CHECK ((mode = ANY (ARRAY['regular'::text, 'pko'::text, 'mystery_pre'::text, 'mystery_chest'::text]))),
    CONSTRAINT tournament_bounty_obligations_position_check CHECK (("position" >= 2)),
    CONSTRAINT tournament_bounty_obligations_prize_check CHECK ((prize >= (0)::numeric)),
    CONSTRAINT tournament_bounty_obligations_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'settled'::text])))
);


--
-- Name: TABLE tournament_bounty_obligations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_bounty_obligations IS 'Atomic knockout-to-bounty outbox. Created in the same transaction as the playing/chips<=0 elimination CAS and settled by the payout-ledger transaction.';


--
-- Name: tournament_cancellation_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_cancellation_receipts (
    tournament_id uuid NOT NULL,
    actor_id uuid NOT NULL,
    receipt_version integer DEFAULT 2 NOT NULL,
    source_player_count integer NOT NULL,
    source_player_ids uuid[] NOT NULL,
    refunded_count integer NOT NULL,
    refunded_registration_ids uuid[] NOT NULL,
    refund_line_count integer NOT NULL,
    ticket_return_count integer NOT NULL,
    ticket_return_ids uuid[] NOT NULL,
    total_ticket_returned numeric(15,2) NOT NULL,
    zero_refund_count integer NOT NULL,
    zero_refund_registration_ids uuid[] NOT NULL,
    total_refunded numeric(15,2) NOT NULL,
    fees_reversed numeric(15,2) NOT NULL,
    total_rake_before numeric(15,2) NOT NULL,
    total_rake_after numeric(15,2) NOT NULL,
    closed_table_count integer NOT NULL,
    closed_table_ids uuid[] NOT NULL,
    source_seat_count integer NOT NULL,
    source_seat_ids uuid[] NOT NULL,
    released_seat_count integer NOT NULL,
    released_seat_ids uuid[] NOT NULL,
    fee_reversal_ids uuid[] NOT NULL,
    escrow_closed_at timestamp with time zone NOT NULL,
    escrow_close_note text NOT NULL,
    spin_unwind_tournament_id uuid,
    receipt jsonb NOT NULL,
    settled_at timestamp with time zone NOT NULL,
    CONSTRAINT tournament_cancellation_rece_zero_refund_registration_ids_check CHECK ((array_position(zero_refund_registration_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipt_refunded_registration_ids_check CHECK ((array_position(refunded_registration_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipts_check CHECK ((((fees_reversed)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (fees_reversed >= (0)::numeric) AND (fees_reversed = round(fees_reversed, 2)) AND (fees_reversed <= (total_refunded + total_ticket_returned)))),
    CONSTRAINT tournament_cancellation_receipts_check1 CHECK ((source_player_count = cardinality(source_player_ids))),
    CONSTRAINT tournament_cancellation_receipts_check10 CHECK ((released_seat_count = cardinality(released_seat_ids))),
    CONSTRAINT tournament_cancellation_receipts_check11 CHECK ((released_seat_ids <@ source_seat_ids)),
    CONSTRAINT tournament_cancellation_receipts_check12 CHECK ((((total_rake_before)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND ((total_rake_after)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (total_rake_before >= (0)::numeric) AND (total_rake_after = (0)::numeric) AND (total_rake_before = fees_reversed))),
    CONSTRAINT tournament_cancellation_receipts_check13 CHECK ((escrow_closed_at = settled_at)),
    CONSTRAINT tournament_cancellation_receipts_check14 CHECK (((spin_unwind_tournament_id IS NULL) OR (spin_unwind_tournament_id = tournament_id))),
    CONSTRAINT tournament_cancellation_receipts_check15 CHECK ((NOT (((receipt ->> 'tournament_id'::text))::uuid IS DISTINCT FROM tournament_id))),
    CONSTRAINT tournament_cancellation_receipts_check16 CHECK ((NOT (((receipt ->> 'actor_id'::text))::uuid IS DISTINCT FROM actor_id))),
    CONSTRAINT tournament_cancellation_receipts_check17 CHECK ((NOT (((receipt ->> 'receipt_version'::text))::integer IS DISTINCT FROM receipt_version))),
    CONSTRAINT tournament_cancellation_receipts_check18 CHECK ((NOT (((receipt ->> 'source_player_count'::text))::integer IS DISTINCT FROM source_player_count))),
    CONSTRAINT tournament_cancellation_receipts_check19 CHECK ((NOT (((receipt ->> 'refunded_count'::text))::integer IS DISTINCT FROM refunded_count))),
    CONSTRAINT tournament_cancellation_receipts_check2 CHECK ((refunded_count = cardinality(refunded_registration_ids))),
    CONSTRAINT tournament_cancellation_receipts_check20 CHECK ((NOT (((receipt ->> 'refund_line_count'::text))::integer IS DISTINCT FROM refund_line_count))),
    CONSTRAINT tournament_cancellation_receipts_check21 CHECK ((NOT (((receipt ->> 'ticket_return_count'::text))::integer IS DISTINCT FROM ticket_return_count))),
    CONSTRAINT tournament_cancellation_receipts_check22 CHECK ((NOT (((receipt ->> 'total_ticket_returned'::text))::numeric IS DISTINCT FROM total_ticket_returned))),
    CONSTRAINT tournament_cancellation_receipts_check23 CHECK ((NOT (((receipt ->> 'total_refunded'::text))::numeric IS DISTINCT FROM total_refunded))),
    CONSTRAINT tournament_cancellation_receipts_check24 CHECK ((NOT (((receipt ->> 'fees_reversed'::text))::numeric IS DISTINCT FROM fees_reversed))),
    CONSTRAINT tournament_cancellation_receipts_check25 CHECK ((NOT (((receipt ->> 'closed_table_count'::text))::integer IS DISTINCT FROM closed_table_count))),
    CONSTRAINT tournament_cancellation_receipts_check26 CHECK ((NOT (((receipt ->> 'source_seat_count'::text))::integer IS DISTINCT FROM source_seat_count))),
    CONSTRAINT tournament_cancellation_receipts_check27 CHECK ((NOT (((receipt ->> 'released_seat_count'::text))::integer IS DISTINCT FROM released_seat_count))),
    CONSTRAINT tournament_cancellation_receipts_check28 CHECK ((NOT (((receipt ->> 'settled_at'::text))::timestamp with time zone IS DISTINCT FROM settled_at))),
    CONSTRAINT tournament_cancellation_receipts_check29 CHECK ((jsonb_array_length((receipt -> 'refunds'::text)) = refund_line_count)),
    CONSTRAINT tournament_cancellation_receipts_check3 CHECK ((ticket_return_count = cardinality(ticket_return_ids))),
    CONSTRAINT tournament_cancellation_receipts_check30 CHECK ((jsonb_array_length((receipt -> 'ticket_returns'::text)) = ticket_return_count)),
    CONSTRAINT tournament_cancellation_receipts_check4 CHECK ((zero_refund_count = cardinality(zero_refund_registration_ids))),
    CONSTRAINT tournament_cancellation_receipts_check5 CHECK ((source_player_count = (refunded_count + zero_refund_count))),
    CONSTRAINT tournament_cancellation_receipts_check6 CHECK (((refunded_registration_ids && zero_refund_registration_ids) IS FALSE)),
    CONSTRAINT tournament_cancellation_receipts_check7 CHECK (((refunded_registration_ids || zero_refund_registration_ids) <@ source_player_ids)),
    CONSTRAINT tournament_cancellation_receipts_check8 CHECK ((closed_table_count = cardinality(closed_table_ids))),
    CONSTRAINT tournament_cancellation_receipts_check9 CHECK ((source_seat_count = cardinality(source_seat_ids))),
    CONSTRAINT tournament_cancellation_receipts_closed_table_count_check CHECK ((closed_table_count >= 0)),
    CONSTRAINT tournament_cancellation_receipts_closed_table_ids_check CHECK ((array_position(closed_table_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipts_escrow_close_note_check CHECK ((length(btrim(escrow_close_note)) > 0)),
    CONSTRAINT tournament_cancellation_receipts_fee_reversal_ids_check CHECK ((array_position(fee_reversal_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipts_receipt_check CHECK ((jsonb_typeof(receipt) = 'object'::text)),
    CONSTRAINT tournament_cancellation_receipts_receipt_check1 CHECK ((NOT ((receipt ->> 'status'::text) IS DISTINCT FROM 'CANCELLED'::text))),
    CONSTRAINT tournament_cancellation_receipts_receipt_check2 CHECK ((((receipt ->> 'ok'::text))::boolean IS TRUE)),
    CONSTRAINT tournament_cancellation_receipts_receipt_check3 CHECK ((((receipt ->> 'success'::text))::boolean IS TRUE)),
    CONSTRAINT tournament_cancellation_receipts_receipt_check4 CHECK ((((receipt ->> 'fully_settled'::text))::boolean IS TRUE)),
    CONSTRAINT tournament_cancellation_receipts_receipt_check5 CHECK ((NOT (jsonb_typeof((receipt -> 'refunds'::text)) IS DISTINCT FROM 'array'::text))),
    CONSTRAINT tournament_cancellation_receipts_receipt_check6 CHECK ((NOT (jsonb_typeof((receipt -> 'ticket_returns'::text)) IS DISTINCT FROM 'array'::text))),
    CONSTRAINT tournament_cancellation_receipts_receipt_version_check CHECK ((receipt_version = 2)),
    CONSTRAINT tournament_cancellation_receipts_refund_line_count_check CHECK ((refund_line_count >= 0)),
    CONSTRAINT tournament_cancellation_receipts_refunded_count_check CHECK ((refunded_count >= 0)),
    CONSTRAINT tournament_cancellation_receipts_released_seat_count_check CHECK ((released_seat_count >= 0)),
    CONSTRAINT tournament_cancellation_receipts_released_seat_ids_check CHECK ((array_position(released_seat_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipts_source_player_count_check CHECK ((source_player_count >= 0)),
    CONSTRAINT tournament_cancellation_receipts_source_player_ids_check CHECK ((array_position(source_player_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipts_source_seat_count_check CHECK ((source_seat_count >= 0)),
    CONSTRAINT tournament_cancellation_receipts_source_seat_ids_check CHECK ((array_position(source_seat_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipts_ticket_return_count_check CHECK ((ticket_return_count >= 0)),
    CONSTRAINT tournament_cancellation_receipts_ticket_return_ids_check CHECK ((array_position(ticket_return_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_cancellation_receipts_total_refunded_check CHECK ((((total_refunded)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (total_refunded >= (0)::numeric) AND (total_refunded = round(total_refunded, 2)))),
    CONSTRAINT tournament_cancellation_receipts_total_ticket_returned_check CHECK ((((total_ticket_returned)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (total_ticket_returned >= (0)::numeric) AND (total_ticket_returned = round(total_ticket_returned, 2)))),
    CONSTRAINT tournament_cancellation_receipts_zero_refund_count_check CHECK ((zero_refund_count >= 0))
);


--
-- Name: TABLE tournament_cancellation_receipts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_cancellation_receipts IS 'Immutable terminal proof that evidence-derived refunds, fee reversals and tournament/player/table closeout committed in one atomic_cancel_tournament call.';


--
-- Name: tournament_capacity_table_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_capacity_table_receipts (
    table_id uuid NOT NULL,
    tournament_id uuid NOT NULL,
    manager_wake_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    manager_admitted_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: tournament_deal_votes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_deal_votes (
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tournament_escrow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_escrow (
    tournament_id uuid NOT NULL,
    enforced boolean DEFAULT true NOT NULL,
    gross_in numeric DEFAULT 0 NOT NULL,
    fee_entries_in numeric DEFAULT 0 NOT NULL,
    satellite_fee_in numeric DEFAULT 0 NOT NULL,
    bounty_in numeric DEFAULT 0 NOT NULL,
    overlay_in numeric DEFAULT 0 NOT NULL,
    satellite_in numeric DEFAULT 0 NOT NULL,
    prize_out numeric DEFAULT 0 NOT NULL,
    bounty_out numeric DEFAULT 0 NOT NULL,
    fee_out numeric DEFAULT 0 NOT NULL,
    refund_prize numeric DEFAULT 0 NOT NULL,
    refund_bounty numeric DEFAULT 0 NOT NULL,
    refund_fee numeric DEFAULT 0 NOT NULL,
    prize_balance numeric(15,2) DEFAULT 0 NOT NULL,
    bounty_balance numeric(15,2) DEFAULT 0 NOT NULL,
    fee_balance numeric(15,2) DEFAULT 0 NOT NULL,
    opened_at timestamp with time zone DEFAULT now() NOT NULL,
    opened_from text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    close_note text,
    reserve_out numeric DEFAULT 0 NOT NULL,
    reserve_in numeric DEFAULT 0 NOT NULL,
    terminal_closed_at timestamp with time zone
);


--
-- Name: TABLE tournament_escrow; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_escrow IS 'The tournament escrow as a BALANCE (chip standard Phase 5.1, reserve-aware since 5.2, enforced for every event since the Phase 5 gate). prize_balance = (gross_in - fee_entries_in - bounty_in) + overlay_in + satellite_in - reserve_out + reserve_in - prize_out - refund_prize; bounty_balance = bounty_in - bounty_out - refund_bounty; fee_balance = fee_entries_in + satellite_fee_in - fee_out - refund_fee. Maintained by triggers in the same transaction as each operational row; a payment or refund that would take a bank below zero is refused; a spin''s reserve_out is never refused.';


--
-- Name: COLUMN tournament_escrow.reserve_out; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_escrow.reserve_out IS 'Phase 5.2: what left the prize bank for spin_reserve when the spin pool filled (spin_entry legs)';


--
-- Name: COLUMN tournament_escrow.reserve_in; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_escrow.reserve_in IS 'Phase 5.2: what the draw brought back from spin_reserve as this spin''s prize (spin_prize legs)';


--
-- Name: tournaments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournaments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    game_type text DEFAULT 'NLH'::text NOT NULL,
    variant text,
    buy_in_amount numeric(15,2) NOT NULL,
    buy_in_fee numeric(15,2) NOT NULL,
    guaranteed_prize numeric(15,2) DEFAULT 0,
    start_time timestamp with time zone NOT NULL,
    status text DEFAULT 'ANNOUNCED'::text NOT NULL,
    current_players integer DEFAULT 0,
    max_players integer NOT NULL,
    late_reg_mins integer DEFAULT 60,
    starting_chips integer DEFAULT 10000,
    blind_structure text DEFAULT 'Standard'::text,
    payout_structure text DEFAULT 'Standard'::text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    club_id uuid,
    started_at timestamp with time zone,
    ended_at timestamp with time zone,
    current_level integer DEFAULT 0,
    prize_pool numeric(18,2) DEFAULT 0,
    is_rebuy boolean DEFAULT false,
    add_on_available boolean DEFAULT false,
    rebuy_cost numeric(15,2) DEFAULT 0,
    rebuy_chips integer DEFAULT 0,
    rebuy_levels integer DEFAULT 4,
    addon_cost numeric(15,2) DEFAULT 0,
    addon_chips integer DEFAULT 0,
    min_players integer DEFAULT 3,
    tournament_type text DEFAULT 'MTT'::text,
    is_bounty boolean DEFAULT false,
    bounty_amount numeric(15,2) DEFAULT 0,
    is_pko boolean DEFAULT false,
    is_mystery_bounty boolean DEFAULT false,
    mystery_bounty_min numeric(15,2) DEFAULT 0,
    mystery_bounty_max numeric(15,2) DEFAULT 0,
    is_xmtt boolean DEFAULT false,
    union_id uuid,
    is_multi_day boolean DEFAULT false,
    parent_tournament_id uuid,
    flight_number integer,
    day_number integer DEFAULT 1,
    total_days integer DEFAULT 1,
    flight_end_chips_snapshot jsonb,
    survivors_advance_to uuid,
    is_pinned boolean DEFAULT false,
    spin_multiplier numeric DEFAULT 0,
    is_premium_spin boolean DEFAULT false,
    prize_pool_finalized boolean DEFAULT false,
    is_turbo boolean DEFAULT false,
    blind_speed text DEFAULT 'standard'::text,
    spin_type text DEFAULT 'standard'::text,
    total_rake numeric(18,2) DEFAULT 0 NOT NULL,
    late_reg_levels integer DEFAULT 0,
    addon_levels integer DEFAULT 1,
    is_reentry boolean DEFAULT false,
    satellite_target uuid,
    max_rebuys integer DEFAULT 0,
    max_reentries integer DEFAULT 0,
    level_started_at timestamp with time zone,
    addon_period_triggered boolean DEFAULT false,
    satellite_target_id uuid,
    final_table_triggered boolean DEFAULT false NOT NULL,
    bounty_pool numeric(18,2) DEFAULT 0 NOT NULL,
    bounty_pool_paid numeric DEFAULT 0 NOT NULL,
    on_break boolean DEFAULT false NOT NULL,
    break_started_at timestamp with time zone,
    break_ends_at timestamp with time zone,
    is_private boolean DEFAULT false NOT NULL,
    spin_locked_tiers jsonb,
    short_description text,
    is_vip_only boolean DEFAULT false NOT NULL,
    ban_chat boolean DEFAULT false NOT NULL,
    all_in_or_fold boolean DEFAULT false NOT NULL,
    label_as_new boolean DEFAULT false NOT NULL,
    hide_club_name boolean DEFAULT false NOT NULL,
    action_time_seconds integer DEFAULT 15 NOT NULL,
    table_size integer DEFAULT 9 NOT NULL,
    accelerated_mtt boolean DEFAULT false NOT NULL,
    addon_break_minutes integer DEFAULT 1 NOT NULL,
    big_blind_ante boolean DEFAULT false NOT NULL,
    authorized_to_register boolean DEFAULT false NOT NULL,
    early_bird_enabled boolean DEFAULT false NOT NULL,
    early_bird_chips integer DEFAULT 0 NOT NULL,
    bubble_protection boolean DEFAULT false NOT NULL,
    final_table_deal_enabled boolean DEFAULT false NOT NULL,
    restart_every_minutes integer,
    synchronized_breaks boolean DEFAULT true NOT NULL,
    satellite_seats integer,
    schedule_id uuid,
    mystery_bounty_activation text DEFAULT 'at_the_money'::text NOT NULL,
    mystery_bounty_activation_value numeric,
    mystery_bounty_profile text DEFAULT 'classic'::text NOT NULL,
    mystery_bounty_top_percent numeric DEFAULT 20 NOT NULL,
    mystery_bounty_regular_pool_percent numeric DEFAULT 50 NOT NULL,
    mystery_bounty_pool_percent numeric DEFAULT 50 NOT NULL,
    mystery_bounty_stage text DEFAULT 'pending'::text NOT NULL,
    mystery_bounty_activated_at timestamp with time zone,
    mystery_bounty_activated_players integer,
    mystery_bounty_pool_cents bigint,
    allow_rabbit_hunt boolean DEFAULT true NOT NULL,
    spin_reveal_lag_ms integer,
    addon_period_started_at timestamp with time zone,
    addon_period_ends_at timestamp with time zone,
    payout_percent smallint DEFAULT 10 NOT NULL,
    free_buy boolean DEFAULT false NOT NULL,
    addon_from_start boolean DEFAULT false NOT NULL,
    spin_reveal_at timestamp with time zone,
    mystery_bounty_activation_generation bigint DEFAULT 0 NOT NULL,
    entry_contract_locked boolean DEFAULT false NOT NULL,
    CONSTRAINT tournaments_free_buy_entry_is_free CHECK (((NOT free_buy) OR ((COALESCE(buy_in_amount, (0)::numeric) = (0)::numeric) AND (COALESCE(buy_in_fee, (0)::numeric) = (0)::numeric)))),
    CONSTRAINT tournaments_mystery_activation_chk CHECK ((mystery_bounty_activation = ANY (ARRAY['at_the_money'::text, 'percent_field'::text, 'player_count'::text]))),
    CONSTRAINT tournaments_mystery_activation_generation_nonnegative CHECK ((mystery_bounty_activation_generation >= 0)),
    CONSTRAINT tournaments_mystery_profile_chk CHECK ((mystery_bounty_profile = ANY (ARRAY['balanced'::text, 'classic'::text, 'jackpot'::text]))),
    CONSTRAINT tournaments_mystery_stage_chk CHECK ((mystery_bounty_stage = ANY (ARRAY['pending'::text, 'active'::text, 'complete'::text]))),
    CONSTRAINT tournaments_never_pko_and_mystery CHECK ((NOT (COALESCE(is_pko, false) AND COALESCE(is_mystery_bounty, false)))),
    CONSTRAINT tournaments_no_pko_mystery_hybrid CHECK ((NOT (COALESCE(is_pko, false) AND COALESCE(is_mystery_bounty, false)))),
    CONSTRAINT tournaments_status_check CHECK ((status = ANY (ARRAY['ANNOUNCED'::text, 'REGISTERING'::text, 'LATE_REG'::text, 'RUNNING'::text, 'COMPLETING'::text, 'COMPLETED'::text, 'CANCELLED'::text])))
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='500', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='500', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: COLUMN tournaments.bounty_pool; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.bounty_pool IS 'Total collected into the bounty pool from entries (funded from buy_in_amount). Separate from prize_pool.';


--
-- Name: COLUMN tournaments.bounty_pool_paid; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.bounty_pool_paid IS 'Running total of bounty money paid out. Must never exceed bounty_pool.';


--
-- Name: COLUMN tournaments.on_break; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.on_break IS 'True while this tournament is inside the platform-wide :55 synchronized break. Written by TournamentManagerBase.pauseForBreak, cleared by clearPersistedBreak.';


--
-- Name: COLUMN tournaments.break_started_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.break_started_at IS 'When the break was ANNOUNCED (:55), not when the five minutes began. The last hand on every table still has to land first.';


--
-- Name: COLUMN tournaments.break_ends_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.break_ends_at IS 'When play resumes. Deliberately NULL between :55 and the moment every table has finished its last hand - there is no honest end time during that window, and beginBreakCountdown fills it in. A client that finds this NULL while on_break is true must render the last-hand state, never a guessed countdown.';


--
-- Name: COLUMN tournaments.spin_locked_tiers; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.spin_locked_tiers IS 'Spins only. Tiers the Reserve Pool could not fund at the moment of this draw, as returned by fn_spin_draw_multiplier: [{multiplier, reason, unlocksAt}]. Drives the locked segments on the spin wheel. NULL = not recorded.';


--
-- Name: COLUMN tournaments.synchronized_breaks; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.synchronized_breaks IS 'Does this tournament take the platform-wide :55 synchronized break? FORCED false for SPIN and SNG by tournaments_short_formats_never_break - a 3-handed hyper whose levels are three minutes cannot survive a five-minute stop. MTT/XMTT default true and may opt out (2026-08-22 parity).';


--
-- Name: COLUMN tournaments.mystery_bounty_pool_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.mystery_bounty_pool_percent IS 'Percent of bounty_pool reserved for mystery chests. The remainder (mystery_bounty_regular_pool_percent) funds ordinary knockouts before activation.';


--
-- Name: COLUMN tournaments.mystery_bounty_pool_cents; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.mystery_bounty_pool_cents IS 'The mystery half of the bounty pool in INTEGER CENTS, frozen at activation. Every chest amount sums to exactly this.';


--
-- Name: COLUMN tournaments.allow_rabbit_hunt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.allow_rabbit_hunt IS 'Host toggle. Copied onto each tournament table row at creation; the engine reads tables.allow_rabbit_hunt.';


--
-- Name: COLUMN tournaments.spin_reveal_lag_ms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.spin_reveal_lag_ms IS 'Milliseconds from the third paid seat to the spin reveal broadcast. Written by TournamentManagerBase on the same UPDATE that carries the draw. NULL on a spin that started before 2026-08-31, or one whose draw row write failed.';


--
-- Name: COLUMN tournaments.addon_period_ends_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.addon_period_ends_at IS 'Exclusive end of the single 60-second add-on offer after the rebuy period.';


--
-- Name: COLUMN tournaments.payout_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.payout_percent IS 'What share of the FIELD finishes in the money: 10, 15 or 20 percent. Chosen when the tournament is created. Paid places = ceil(entrants * payout_percent / 100), minimum 1. Drives fn_ca_payout_structure.';


--
-- Name: COLUMN tournaments.free_buy; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.free_buy IS 'Free Buy event: the first entry costs nothing, rebuys and add-ons are paid. Distinct from a freeroll, which never charges.';


--
-- Name: COLUMN tournaments.addon_from_start; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.addon_from_start IS 'Open the add-on window when the event STARTS rather than for 60s after late reg closes. Dan 2026-09-04: players may add on as soon as they sit down and also at the break - one window, one add-on, taken whenever the player likes inside it.';


--
-- Name: COLUMN tournaments.spin_reveal_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournaments.spin_reveal_at IS 'The wall-clock instant the engine anchored this Spin''s reveal to - the same number it puts on the spin_reveal packet as reveal_at. Read by buildSpinDrawFromRow so a client that missed the broadcast animates the wheel against the engine''s clock instead of started_at, which is ~4.2s earlier at the p50 and skips the entire lead-in and countdown. NULL on older rows; the client falls back to started_at.';


--
-- Name: tournament_final_table_deal_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_final_table_deal_batches (
    tournament_id uuid NOT NULL,
    plan_fingerprint text NOT NULL,
    plan jsonb NOT NULL,
    prior_standings_fingerprint text NOT NULL,
    live_input_snapshot jsonb NOT NULL,
    live_input_fingerprint text NOT NULL,
    field_count integer NOT NULL,
    live_count integer NOT NULL,
    structure_place_count integer NOT NULL,
    place_line_count integer NOT NULL,
    deal_line_count integer NOT NULL,
    place_amount numeric(15,2) NOT NULL,
    deal_amount numeric(15,2) NOT NULL,
    amount_owed numeric(15,2) NOT NULL,
    bubble_contract_required boolean NOT NULL,
    bubble_obligation_id uuid,
    bubble_user_id uuid,
    bubble_source text,
    bubble_amount_owed numeric(15,2) NOT NULL,
    bubble_amount_paid_before numeric(15,2) NOT NULL,
    amount_moved numeric(15,2) NOT NULL,
    escrow_prize_before numeric(15,2) NOT NULL,
    escrow_prize_after numeric(15,2),
    deal_table_id uuid NOT NULL,
    chip_leader uuid NOT NULL,
    source text NOT NULL,
    prepared_at timestamp with time zone DEFAULT now() NOT NULL,
    settled_at timestamp with time zone,
    contract_version integer DEFAULT 1 NOT NULL,
    CONSTRAINT tournament_final_deal_contract_version CHECK ((contract_version = ANY (ARRAY[1, 2]))),
    CONSTRAINT tournament_final_table_deal_b_prior_standings_fingerprint_check CHECK ((prior_standings_fingerprint ~ '^[0-9a-f]{32}$'::text)),
    CONSTRAINT tournament_final_table_deal_batche_live_input_fingerprint_check CHECK ((live_input_fingerprint ~ '^[0-9a-f]{32}$'::text)),
    CONSTRAINT tournament_final_table_deal_batches_amount_owed_check CHECK ((amount_owed >= (0)::numeric)),
    CONSTRAINT tournament_final_table_deal_batches_bubble_amount_owed_check CHECK ((bubble_amount_owed >= (0)::numeric)),
    CONSTRAINT tournament_final_table_deal_batches_check CHECK (((bubble_amount_paid_before >= (0)::numeric) AND (bubble_amount_paid_before <= bubble_amount_owed))),
    CONSTRAINT tournament_final_table_deal_batches_check1 CHECK (((amount_moved >= (0)::numeric) AND (amount_moved <= (amount_owed + bubble_amount_owed)))),
    CONSTRAINT tournament_final_table_deal_batches_deal_amount_check CHECK ((deal_amount >= (0)::numeric)),
    CONSTRAINT tournament_final_table_deal_batches_deal_line_count_check CHECK ((deal_line_count >= 2)),
    CONSTRAINT tournament_final_table_deal_batches_escrow_prize_after_check CHECK (((escrow_prize_after IS NULL) OR (escrow_prize_after >= (0)::numeric))),
    CONSTRAINT tournament_final_table_deal_batches_escrow_prize_before_check CHECK ((escrow_prize_before >= (0)::numeric)),
    CONSTRAINT tournament_final_table_deal_batches_field_count_check CHECK ((field_count >= 2)),
    CONSTRAINT tournament_final_table_deal_batches_live_count_check CHECK ((live_count >= 2)),
    CONSTRAINT tournament_final_table_deal_batches_live_input_snapshot_check CHECK ((jsonb_typeof(live_input_snapshot) = 'array'::text)),
    CONSTRAINT tournament_final_table_deal_batches_place_amount_check CHECK ((place_amount >= (0)::numeric)),
    CONSTRAINT tournament_final_table_deal_batches_place_line_count_check CHECK ((place_line_count >= 0)),
    CONSTRAINT tournament_final_table_deal_batches_plan_check CHECK ((jsonb_typeof(plan) = 'array'::text)),
    CONSTRAINT tournament_final_table_deal_batches_plan_fingerprint_check CHECK ((plan_fingerprint ~ '^[0-9a-f]{32}$'::text)),
    CONSTRAINT tournament_final_table_deal_batches_structure_place_count_check CHECK ((structure_place_count >= 1)),
    CONSTRAINT tournament_final_table_deal_bubble_shape CHECK ((((contract_version = 1) AND ((bubble_contract_required AND (bubble_obligation_id IS NOT NULL) AND (bubble_user_id IS NOT NULL) AND (bubble_source = ANY (ARRAY['engine.eliminatePlayer'::text, 'engine.atomicFinalTableDeal'::text])) AND (bubble_amount_owed > (0)::numeric)) OR ((NOT bubble_contract_required) AND (bubble_obligation_id IS NULL) AND (bubble_user_id IS NULL) AND (bubble_source IS NULL) AND (bubble_amount_owed = (0)::numeric) AND (bubble_amount_paid_before = (0)::numeric)))) OR ((contract_version = 2) AND ((bubble_contract_required AND (bubble_obligation_id IS NOT NULL) AND (bubble_user_id IS NOT NULL) AND (bubble_source IS NOT NULL) AND (bubble_source = ANY (ARRAY['engine.eliminatePlayer'::text, 'engine.atomicPlaceSettlement'::text, 'engine.fn_settle_tournament_places'::text, 'engine.fn_settle_tournament_bubble_protection'::text])) AND (bubble_amount_owed > (0)::numeric)) OR ((NOT bubble_contract_required) AND (bubble_obligation_id IS NULL) AND (bubble_user_id IS NULL) AND (bubble_source IS NULL) AND (bubble_amount_owed = (0)::numeric) AND (bubble_amount_paid_before = (0)::numeric))))))
);


--
-- Name: TABLE tournament_final_table_deal_batches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_final_table_deal_batches IS 'Immutable exact-cent final-table-deal plan: prior eliminated structure places plus every live chop share. Only the atomic SECURITY DEFINER settler may write it.';


--
-- Name: tournament_finish_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_finish_receipts (
    tournament_id uuid NOT NULL,
    winner_user_id uuid NOT NULL,
    finish_kind text NOT NULL,
    claimed_at timestamp with time zone DEFAULT now() NOT NULL,
    claim_source text NOT NULL,
    certified_at timestamp with time zone,
    completed_at timestamp with time zone,
    certification_version integer DEFAULT 1 NOT NULL,
    evidence jsonb,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tournament_finish_receipts_certification_version_check CHECK ((certification_version = 1)),
    CONSTRAINT tournament_finish_receipts_check CHECK ((((certified_at IS NULL) AND (completed_at IS NULL) AND (evidence IS NULL)) OR ((certified_at IS NOT NULL) AND (completed_at IS NOT NULL) AND (jsonb_typeof(evidence) = 'object'::text)))),
    CONSTRAINT tournament_finish_receipts_finish_kind_check CHECK ((finish_kind = ANY (ARRAY['normal'::text, 'satellite'::text, 'final_table_deal'::text])))
);


--
-- Name: TABLE tournament_finish_receipts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_finish_receipts IS 'Immutable winner claim and same-transaction financial completion certificate. Only fn_claim_tournament_finish and the COMPLETED guard may write it.';


--
-- Name: tournament_guarantee_overlays; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_guarantee_overlays (
    tournament_id uuid NOT NULL,
    club_id uuid,
    amount numeric(15,2) NOT NULL,
    pool_before numeric(15,2) NOT NULL,
    pool_after numeric(15,2) NOT NULL,
    treasury_after numeric(15,2),
    source text DEFAULT 'engine'::text NOT NULL,
    funded_at timestamp with time zone DEFAULT now() NOT NULL,
    bank_type character varying(10),
    bank_entity_id uuid,
    union_id uuid,
    terminal_closed_at timestamp with time zone
);


--
-- Name: TABLE tournament_guarantee_overlays; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_guarantee_overlays IS 'One row per tournament whose advertised guarantee exceeded player contributions: the overlay the hosting club funded from chip_treasury. PK is the idempotency claim for fn_apply_prize_guarantee.';


--
-- Name: tournament_knockout_candidates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_knockout_candidates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    eliminated_user_id uuid NOT NULL,
    table_id uuid NOT NULL,
    seat_id uuid NOT NULL,
    seat_joined_at timestamp with time zone NOT NULL,
    hand_id uuid NOT NULL,
    hand_number bigint NOT NULL,
    stack_before numeric(20,2) NOT NULL,
    stack_after numeric(20,2) NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    rebuy_prompt_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    resolved_at timestamp with time zone,
    CONSTRAINT tournament_knockout_candidates_hand_number_check CHECK ((hand_number >= 1000000)),
    CONSTRAINT tournament_knockout_candidates_stack_after_check CHECK ((stack_after = (0)::numeric)),
    CONSTRAINT tournament_knockout_candidates_stack_before_check CHECK ((stack_before > (0)::numeric)),
    CONSTRAINT tournament_knockout_candidates_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'rebought'::text, 'eliminated'::text, 'winner'::text])))
);


--
-- Name: tournament_launch_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_launch_receipts (
    tournament_id uuid NOT NULL,
    launch_id uuid NOT NULL,
    started_at timestamp with time zone NOT NULL,
    claimed_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    completed_at timestamp with time zone,
    lease_generation uuid DEFAULT gen_random_uuid() NOT NULL,
    supply_version smallint DEFAULT 0 NOT NULL,
    CONSTRAINT tournament_launch_receipts_supply_version_check CHECK ((supply_version = 0))
);


--
-- Name: COLUMN tournament_launch_receipts.supply_version; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_launch_receipts.supply_version IS 'Launch chip-supply protocol: sealed to 0 until the conserved-supply activation transaction installs version 1.';


--
-- Name: tournament_manager_wakes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_manager_wakes (
    id bigint NOT NULL,
    tournament_id uuid NOT NULL,
    reason text NOT NULL,
    generation bigint DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT tournament_manager_wakes_generation_check CHECK ((generation > 0)),
    CONSTRAINT tournament_manager_wakes_reason_check CHECK ((reason = ANY (ARRAY['rebuy'::text, 'reentry'::text, 'addon'::text, 'late_registration'::text, 'deal_vote'::text, 'bounty_settled'::text])))
);


--
-- Name: tournament_manager_wakes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.tournament_manager_wakes ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tournament_manager_wakes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tournament_mystery_activation_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_mystery_activation_receipts (
    tournament_id uuid NOT NULL,
    activation_generation bigint NOT NULL,
    activated_at timestamp with time zone NOT NULL,
    chest_count integer NOT NULL,
    pool_cents bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tournament_mystery_activation_recei_activation_generation_check CHECK ((activation_generation > 0)),
    CONSTRAINT tournament_mystery_activation_receipts_chest_count_check CHECK ((chest_count > 0)),
    CONSTRAINT tournament_mystery_activation_receipts_pool_cents_check CHECK ((pool_cents > 0))
);


--
-- Name: tournament_obligations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_obligations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    kind text NOT NULL,
    place integer,
    user_id uuid,
    amount_owed numeric(15,2) DEFAULT 0 NOT NULL,
    amount_paid numeric(15,2) DEFAULT 0 NOT NULL,
    source text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    settled_at timestamp with time zone,
    adjustment_id uuid,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT tournament_obligations_amount_owed_check CHECK ((amount_owed >= (0)::numeric)),
    CONSTRAINT tournament_obligations_check CHECK (((amount_paid >= (0)::numeric) AND (amount_paid <= amount_owed))),
    CONSTRAINT tournament_obligations_check1 CHECK (((place IS NOT NULL) OR (user_id IS NOT NULL))),
    CONSTRAINT tournament_obligations_kind_check CHECK ((kind = ANY (ARRAY['place'::text, 'bounty'::text, 'bounty_residual'::text, 'mystery_bounty'::text, 'refund'::text, 'seat'::text, 'satellite_remainder'::text, 'bubble_protection'::text, 'final_table_deal'::text, 'late_reg_adjustment'::text])))
);


--
-- Name: TABLE tournament_obligations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_obligations IS 'What a tournament owes and has paid, one row per place or user. Normal place rows are materialized as a complete fingerprinted batch before fn_settle_tournament_places_atomic moves money.';


--
-- Name: COLUMN tournament_obligations.adjustment_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_obligations.adjustment_id IS 'Phase 6.1: the approved ca_manual_adjustments row a settlement from outside the platform named';


--
-- Name: tournament_payouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_payouts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    "position" integer,
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    source text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key text,
    paid_at timestamp with time zone DEFAULT now() NOT NULL,
    tournament_type text,
    field_size integer,
    prize_pool numeric,
    payout_structure jsonb,
    recorded_by text,
    metadata jsonb,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT chk_prize_pool_is_two_decimal_places CHECK (((prize_pool IS NULL) OR (prize_pool = round(prize_pool, 2)))),
    CONSTRAINT tournament_payouts_amount_check CHECK (((amount >= (0)::numeric) OR (source = 'clawback'::text))),
    CONSTRAINT tournament_payouts_source_check CHECK ((source = ANY (ARRAY['structure'::text, 'reconcile'::text, 'hu_shortfall'::text, 'bounty'::text, 'bounty_residual'::text, 'own_bounty'::text, 'late_reg_adjustment'::text, 'clawback'::text, 'final_table_deal'::text, 'mystery_bounty'::text, 'mystery_bounty_residual'::text, 'spin_backpay'::text, 'overlay_backpay'::text, 'bubble_protection'::text, 'satellite_remainder'::text, 'satellite_seat'::text, 'satellite_ticket'::text, 'finish_position_correction'::text])))
)
WITH (autovacuum_freeze_max_age='171000000');


--
-- Name: COLUMN tournament_payouts.source; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_payouts.source IS 'Closed payout class. There is no default: an unnamed or unknown payment fails before settlement instead of becoming unclassified.';


--
-- Name: COLUMN tournament_payouts.idempotency_key; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_payouts.idempotency_key IS 'The wallet_credit_idempotency key the money moved under. Unique: this is what makes a retried credit, a recovery-watchdog payment and the main path converge on ONE record instead of three.';


--
-- Name: COLUMN tournament_payouts.paid_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_payouts.paid_at IS 'When the record was written. tournament_players has no payment timestamp at all, which is why "when was this paid" was previously unanswerable.';


--
-- Name: COLUMN tournament_payouts.field_size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_payouts.field_size IS 'Entrants the structure was trimmed to when this place was priced. Without it a payout cannot be re-derived, because the structure is trimmed to the field.';


--
-- Name: COLUMN tournament_payouts.payout_structure; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_payouts.payout_structure IS 'Snapshot of the structure that produced this amount. A structure edited later must not be able to change what the evidence says was paid.';


--
-- Name: COLUMN tournament_payouts.recorded_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_payouts.recorded_by IS 'Which path wrote the row: credit_and_log | final_table_deal | backfill_2026_08_31.';


--
-- Name: COLUMN tournament_payouts.metadata; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_payouts.metadata IS 'Facts about this payout that are not the payout structure. Used by satellite seat awards to name the target tournament and the registration row created there.';


--
-- Name: tournament_place_settlement_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_place_settlement_batches (
    tournament_id uuid NOT NULL,
    mode text DEFAULT 'structure'::text NOT NULL,
    plan_fingerprint text NOT NULL,
    place_count integer NOT NULL,
    amount_owed numeric(15,2) NOT NULL,
    escrow_required numeric(15,2) NOT NULL,
    escrow_available numeric(15,2) NOT NULL,
    bubble_contract_required boolean DEFAULT false NOT NULL,
    bubble_obligation_id uuid,
    bubble_user_id uuid,
    bubble_source text,
    bubble_amount_owed numeric(15,2) DEFAULT 0 NOT NULL,
    bubble_amount_paid_before numeric(15,2) DEFAULT 0 NOT NULL,
    source text NOT NULL,
    prepared_at timestamp with time zone DEFAULT now() NOT NULL,
    settled_at timestamp with time zone,
    CONSTRAINT tournament_place_settlement_batches_amount_owed_check CHECK ((amount_owed >= (0)::numeric)),
    CONSTRAINT tournament_place_settlement_batches_bubble_amount_owed_check CHECK ((bubble_amount_owed >= (0)::numeric)),
    CONSTRAINT tournament_place_settlement_batches_check CHECK (((bubble_amount_paid_before >= (0)::numeric) AND (bubble_amount_paid_before <= bubble_amount_owed))),
    CONSTRAINT tournament_place_settlement_batches_check1 CHECK ((((NOT bubble_contract_required) AND (bubble_obligation_id IS NULL) AND (bubble_user_id IS NULL) AND (bubble_source IS NULL) AND (bubble_amount_owed = (0)::numeric) AND (bubble_amount_paid_before = (0)::numeric)) OR (bubble_contract_required AND (bubble_obligation_id IS NOT NULL) AND (bubble_user_id IS NOT NULL) AND (NULLIF(btrim(bubble_source), ''::text) IS NOT NULL) AND (bubble_amount_owed > (0)::numeric)))),
    CONSTRAINT tournament_place_settlement_batches_escrow_available_check CHECK ((escrow_available >= (0)::numeric)),
    CONSTRAINT tournament_place_settlement_batches_escrow_required_check CHECK ((escrow_required >= (0)::numeric)),
    CONSTRAINT tournament_place_settlement_batches_mode_check CHECK ((mode = ANY (ARRAY['structure'::text, 'ruling'::text]))),
    CONSTRAINT tournament_place_settlement_batches_place_count_check CHECK ((place_count >= 0)),
    CONSTRAINT tournament_place_settlement_batches_plan_fingerprint_check CHECK ((plan_fingerprint ~ '^[0-9a-f]{32}$'::text))
);


--
-- Name: TABLE tournament_place_settlement_batches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_place_settlement_batches IS 'Immutable completeness header for one normal tournament place plan and its exact finalized-field Bubble Protection obligation when applicable. The fingerprint covers the ordered place, player and exact-cent entitlement stored in tournament_obligations.';


--
-- Name: COLUMN tournament_place_settlement_batches.mode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_place_settlement_batches.mode IS 'structure: the places came from the prize structure through fn_settle_tournament_places_atomic. ruling: chronology could not certify the result because places already paid disagreed with bust order, so fn_settle_tournament_places_by_ruling settled the remainder against the paid record and recorded the disagreement.';


--
-- Name: tournament_players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_players (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    username text,
    chips integer DEFAULT 0,
    status text DEFAULT 'registered'::text,
    "position" integer,
    prize numeric(15,2) DEFAULT 0,
    rebuys integer DEFAULT 0,
    add_on boolean DEFAULT false,
    registered_at timestamp with time zone DEFAULT now(),
    eliminated_at timestamp with time zone,
    bounties_collected integer DEFAULT 0,
    bounty_winnings numeric(15,2) DEFAULT 0,
    mystery_bounty_value numeric(15,2) DEFAULT 0,
    current_bounty numeric DEFAULT 0,
    table_id uuid,
    seat_number integer,
    chip_count numeric DEFAULT 0,
    club_id uuid,
    is_satellite_qualifier boolean DEFAULT false,
    rebuy_prompt_until timestamp with time zone,
    push_15m_sent boolean DEFAULT false,
    push_2m_sent boolean DEFAULT false,
    source_satellite_id uuid,
    elimination_sequence bigint,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT tournament_players_elimination_sequence_positive CHECK (((elimination_sequence IS NULL) OR (elimination_sequence > 0))),
    CONSTRAINT tournament_players_status_check CHECK ((status = ANY (ARRAY['registered'::text, 'playing'::text, 'eliminated'::text, 'winner'::text])))
);


--
-- Name: COLUMN tournament_players.club_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_players.club_id IS 'UNION LAW (Dan 2026-08-20): the club whose chips paid this entry. Entry fee rake belongs to that club only. NULL = legacy entry predating club-scoped chips; attribution falls back to first-joined membership.';


--
-- Name: COLUMN tournament_players.rebuy_prompt_until; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_players.rebuy_prompt_until IS 'Server-owned deadline for an open rebuy prompt. The elimination sweep must not eliminate a player while now() < rebuy_prompt_until. Cleared on accept or decline. NULL means no prompt is open.';


--
-- Name: COLUMN tournament_players.elimination_sequence; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_players.elimination_sequence IS 'Database-owned order of committed eliminated transitions. Settlement derives final numeric places from this witness; wall-clock timestamps never rank a field.';


--
-- Name: tournament_player_elimination_sequence; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tournament_player_elimination_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tournament_player_elimination_sequence; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tournament_player_elimination_sequence OWNED BY public.tournament_players.elimination_sequence;


--
-- Name: tournament_rake_settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_rake_settlements (
    tournament_id uuid NOT NULL,
    club_id uuid,
    union_id uuid,
    amount numeric(15,2) DEFAULT 0 NOT NULL,
    destination text DEFAULT 'pending'::text NOT NULL,
    source text DEFAULT 'engine'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    settled_at timestamp with time zone,
    attributed_at timestamp with time zone,
    attribution_error text,
    attributed_users integer,
    terminal_closed_at timestamp with time zone
);


--
-- Name: TABLE tournament_rake_settlements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_rake_settlements IS 'One row per terminal tournament: proof its fee-ledger net was credited to a wallet (or was zero). The PK is the idempotency claim for fn_settle_tournament_rake.';


--
-- Name: COLUMN tournament_rake_settlements.attributed_users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_rake_settlements.attributed_users IS 'How many players this settlement actually credited. NULL = never measured (pre-2026-08-31 rows, drained by fn_backpay_tournament_rake_attribution). 0 with members present is a FAILURE, not a completed attribution.';


--
-- Name: tournament_refund_authorizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_refund_authorizations (
    token uuid NOT NULL,
    idempotency_key text NOT NULL,
    tournament_id uuid NOT NULL,
    obligation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    source_wallet_club_id uuid NOT NULL,
    entitlement_id uuid NOT NULL,
    amount_paid_before numeric(15,2) NOT NULL,
    amount_paid_now numeric(15,2) NOT NULL,
    refund_prize numeric(15,2) NOT NULL,
    refund_bounty numeric(15,2) NOT NULL,
    refund_fee numeric(15,2) NOT NULL,
    source text NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT tournament_refund_authorizations_amount_paid_before_check CHECK (((amount_paid_before >= (0)::numeric) AND ((amount_paid_before)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (amount_paid_before = round(amount_paid_before, 2)))),
    CONSTRAINT tournament_refund_authorizations_amount_paid_now_check CHECK ((((amount_paid_now)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (amount_paid_now > (0)::numeric) AND (amount_paid_now = round(amount_paid_now, 2)))),
    CONSTRAINT tournament_refund_authorizations_check CHECK ((amount_paid_now = ((refund_prize + refund_bounty) + refund_fee))),
    CONSTRAINT tournament_refund_authorizations_description_check CHECK ((length(btrim(description)) > 0)),
    CONSTRAINT tournament_refund_authorizations_refund_bounty_check CHECK ((((refund_bounty)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_bounty >= (0)::numeric) AND (refund_bounty = round(refund_bounty, 2)))),
    CONSTRAINT tournament_refund_authorizations_refund_fee_check CHECK ((((refund_fee)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_fee >= (0)::numeric) AND (refund_fee = round(refund_fee, 2)))),
    CONSTRAINT tournament_refund_authorizations_refund_prize_check CHECK ((((refund_prize)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_prize >= (0)::numeric) AND (refund_prize = round(refund_prize, 2)))),
    CONSTRAINT tournament_refund_authorizations_source_check CHECK ((length(btrim(source)) > 0))
);


--
-- Name: TABLE tournament_refund_authorizations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_refund_authorizations IS 'Owner-only one-use capabilities consumed inside the exact wallet-refund transaction. No browser or service role can inspect or mint them.';


--
-- Name: tournament_refund_entitlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_refund_entitlements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    entitlement_kind text NOT NULL,
    charge_category text NOT NULL,
    refund_wallet_club_id uuid NOT NULL,
    gross numeric(15,2) NOT NULL,
    refund_prize numeric(15,2) NOT NULL,
    refund_bounty numeric(15,2) NOT NULL,
    refund_fee numeric(15,2) NOT NULL,
    source_ledger_id uuid NOT NULL,
    registration_id uuid,
    source_satellite_id uuid,
    source_award_place integer,
    source_ticket_id uuid,
    escrow_bucket text NOT NULL,
    evidence_kind text NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT tournament_refund_entitlements_charge_category_check CHECK ((charge_category = ANY (ARRAY['tournament_buyin'::text, 'rebuy'::text, 'addon'::text, 'satellite_seat'::text, 'tournament_ticket'::text]))),
    CONSTRAINT tournament_refund_entitlements_check CHECK ((gross = ((refund_prize + refund_bounty) + refund_fee))),
    CONSTRAINT tournament_refund_entitlements_check1 CHECK (((((entitlement_kind = 'wallet_charge'::text) AND (charge_category = ANY (ARRAY['tournament_buyin'::text, 'rebuy'::text, 'addon'::text])) AND (registration_id IS NULL) AND (source_satellite_id IS NULL) AND (source_award_place IS NULL) AND (source_ticket_id IS NULL) AND (escrow_bucket = 'wallet_gross'::text) AND (evidence_kind = ANY (ARRAY['atomic_wallet_charge'::text, 'cutover_wallet_charge'::text]))) OR ((entitlement_kind = 'satellite_seat'::text) AND (charge_category = 'satellite_seat'::text) AND (registration_id IS NOT NULL) AND (source_satellite_id IS NOT NULL) AND (source_satellite_id <> tournament_id) AND (source_award_place > 0) AND (source_ticket_id IS NULL) AND (escrow_bucket = ANY (ARRAY['satellite_gross'::text, 'satellite_in'::text])) AND (evidence_kind = ANY (ARRAY['atomic_satellite_seat'::text, 'cutover_satellite_seat'::text]))) OR ((entitlement_kind = 'tournament_ticket'::text) AND (charge_category = 'tournament_ticket'::text) AND (registration_id IS NOT NULL) AND (source_satellite_id IS NOT NULL) AND (source_award_place IS NULL) AND (source_ticket_id IS NOT NULL) AND (escrow_bucket = 'ticket_gross'::text) AND (evidence_kind = 'atomic_tournament_ticket'::text))) IS TRUE)),
    CONSTRAINT tournament_refund_entitlements_entitlement_kind_check CHECK ((entitlement_kind = ANY (ARRAY['wallet_charge'::text, 'satellite_seat'::text, 'tournament_ticket'::text]))),
    CONSTRAINT tournament_refund_entitlements_escrow_bucket_check CHECK ((escrow_bucket = ANY (ARRAY['wallet_gross'::text, 'satellite_gross'::text, 'satellite_in'::text, 'ticket_gross'::text]))),
    CONSTRAINT tournament_refund_entitlements_evidence_kind_check CHECK ((evidence_kind = ANY (ARRAY['atomic_wallet_charge'::text, 'cutover_wallet_charge'::text, 'atomic_satellite_seat'::text, 'cutover_satellite_seat'::text, 'atomic_tournament_ticket'::text]))),
    CONSTRAINT tournament_refund_entitlements_gross_check CHECK ((((gross)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (gross > (0)::numeric) AND (gross = round(gross, 2)))),
    CONSTRAINT tournament_refund_entitlements_refund_bounty_check CHECK ((((refund_bounty)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_bounty >= (0)::numeric) AND (refund_bounty = round(refund_bounty, 2)))),
    CONSTRAINT tournament_refund_entitlements_refund_fee_check CHECK ((((refund_fee)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_fee >= (0)::numeric) AND (refund_fee = round(refund_fee, 2)))),
    CONSTRAINT tournament_refund_entitlements_refund_prize_check CHECK ((((refund_prize)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_prize >= (0)::numeric) AND (refund_prize = round(refund_prize, 2))))
);


--
-- Name: TABLE tournament_refund_entitlements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_refund_entitlements IS 'Immutable per-purchase or noncash-entry source facts. Wallet charges may return only to their recorded club wallet; satellite and ticket entries may return only as tournament-entry tickets.';


--
-- Name: tournament_refund_tranches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_refund_tranches (
    wallet_transaction_id uuid NOT NULL,
    idempotency_key text NOT NULL,
    tournament_id uuid NOT NULL,
    obligation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    source_wallet_club_id uuid NOT NULL,
    entitlement_id uuid NOT NULL,
    credit_ledger_id uuid NOT NULL,
    amount_paid_before numeric(15,2) NOT NULL,
    amount_paid_now numeric(15,2) NOT NULL,
    refund_prize numeric(15,2) NOT NULL,
    refund_bounty numeric(15,2) NOT NULL,
    refund_fee numeric(15,2) NOT NULL,
    source text NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT tournament_refund_tranches_amount_paid_before_check CHECK (((amount_paid_before >= (0)::numeric) AND ((amount_paid_before)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (amount_paid_before = round(amount_paid_before, 2)))),
    CONSTRAINT tournament_refund_tranches_amount_paid_now_check CHECK ((((amount_paid_now)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (amount_paid_now > (0)::numeric) AND (amount_paid_now = round(amount_paid_now, 2)))),
    CONSTRAINT tournament_refund_tranches_check CHECK ((amount_paid_now = ((refund_prize + refund_bounty) + refund_fee))),
    CONSTRAINT tournament_refund_tranches_check1 CHECK ((idempotency_key = ((('tourney:'::text || (tournament_id)::text) || ':refund-entitlement:'::text) || (entitlement_id)::text))),
    CONSTRAINT tournament_refund_tranches_description_check CHECK ((length(btrim(description)) > 0)),
    CONSTRAINT tournament_refund_tranches_refund_bounty_check CHECK ((((refund_bounty)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_bounty >= (0)::numeric) AND (refund_bounty = round(refund_bounty, 2)))),
    CONSTRAINT tournament_refund_tranches_refund_fee_check CHECK ((((refund_fee)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_fee >= (0)::numeric) AND (refund_fee = round(refund_fee, 2)))),
    CONSTRAINT tournament_refund_tranches_refund_prize_check CHECK ((((refund_prize)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refund_prize >= (0)::numeric) AND (refund_prize = round(refund_prize, 2)))),
    CONSTRAINT tournament_refund_tranches_source_check CHECK ((length(btrim(source)) > 0))
);


--
-- Name: TABLE tournament_refund_tranches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_refund_tranches IS 'Immutable per-credit refund rail evidence. Each row binds one wallet credit and obligation offset to exact prize, bounty and fee escrow debits.';


--
-- Name: tournament_reminder_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_reminder_receipts (
    tournament_id uuid NOT NULL,
    recipient_user_id uuid NOT NULL,
    scheduled_start_at timestamp with time zone NOT NULL,
    stage text NOT NULL,
    outcome text NOT NULL,
    outbox_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tournament_reminder_receipts_check CHECK (((outcome = 'queued'::text) = (outbox_id IS NOT NULL))),
    CONSTRAINT tournament_reminder_receipts_outcome_check CHECK ((outcome = ANY (ARRAY['queued'::text, 'seated'::text, 'legacy'::text]))),
    CONSTRAINT tournament_reminder_receipts_stage_check CHECK ((stage = ANY (ARRAY['15m'::text, '2m'::text])))
);


--
-- Name: tournament_satellite_awards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_satellite_awards (
    tournament_id uuid NOT NULL,
    place integer NOT NULL,
    user_id uuid NOT NULL,
    delivery_kind text NOT NULL,
    amount numeric(15,2) NOT NULL,
    payout_id uuid NOT NULL,
    payout_source text NOT NULL,
    idempotency_key text NOT NULL,
    registration_id uuid,
    ticket_id uuid,
    obligation_id uuid,
    obligation_kind text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tournament_satellite_awards_amount_check CHECK (((amount > (0)::numeric) AND (amount = round(amount, 2)))),
    CONSTRAINT tournament_satellite_awards_check CHECK (((((delivery_kind = 'seat'::text) AND (registration_id IS NOT NULL) AND (ticket_id IS NULL) AND (obligation_id IS NULL) AND (obligation_kind IS NULL) AND (payout_source = 'satellite_seat'::text)) OR ((delivery_kind = 'cash'::text) AND (registration_id IS NULL) AND (ticket_id IS NULL) AND (obligation_id IS NOT NULL) AND (obligation_kind = ANY (ARRAY['seat'::text, 'place'::text])) AND (payout_source <> 'satellite_seat'::text)) OR ((delivery_kind = 'ticket'::text) AND (registration_id IS NULL) AND (ticket_id IS NOT NULL) AND (obligation_id IS NULL) AND (obligation_kind IS NULL) AND (payout_source = 'satellite_ticket'::text))) IS TRUE)),
    CONSTRAINT tournament_satellite_awards_delivery_kind_check CHECK ((delivery_kind = ANY (ARRAY['seat'::text, 'cash'::text, 'ticket'::text]))),
    CONSTRAINT tournament_satellite_awards_idempotency_key_check CHECK ((length(btrim(idempotency_key)) > 0)),
    CONSTRAINT tournament_satellite_awards_payout_source_check CHECK ((length(btrim(payout_source)) > 0)),
    CONSTRAINT tournament_satellite_awards_place_check CHECK ((place > 0))
);


--
-- Name: TABLE tournament_satellite_awards; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_satellite_awards IS 'Immutable per-place full-ticket delivery evidence. Each line is exactly one actual target seat, one target-scoped noncash ticket, or one exact cash substitution.';


--
-- Name: tournament_satellite_economic_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_satellite_economic_snapshots (
    tournament_id uuid NOT NULL,
    target_tournament_id uuid,
    configured_seats integer NOT NULL,
    ticket_value numeric(15,2) NOT NULL,
    promised_seat_value numeric(15,2) NOT NULL,
    funded_source_pool numeric(15,2),
    source_contract_hash text NOT NULL,
    target_contract_hash text,
    source_started_at timestamp with time zone,
    captured_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    capture_source text NOT NULL,
    CONSTRAINT tournament_satellite_economic_snapsh_source_contract_hash_check CHECK ((source_contract_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT tournament_satellite_economic_snapsh_target_contract_hash_check CHECK ((target_contract_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT tournament_satellite_economic_snapsho_promised_seat_value_check CHECK ((promised_seat_value >= (0)::numeric)),
    CONSTRAINT tournament_satellite_economic_snapshots_capture_source_check CHECK ((capture_source = ANY (ARRAY['start_trigger'::text, 'contract_history'::text]))),
    CONSTRAINT tournament_satellite_economic_snapshots_check CHECK ((promised_seat_value = round(((configured_seats)::numeric * ticket_value), 2))),
    CONSTRAINT tournament_satellite_economic_snapshots_check1 CHECK ((((target_tournament_id IS NULL) AND (ticket_value = (0)::numeric) AND (target_contract_hash IS NULL) AND (configured_seats = 0)) OR ((target_tournament_id IS NOT NULL) AND (ticket_value > (0)::numeric) AND (target_contract_hash IS NOT NULL)))),
    CONSTRAINT tournament_satellite_economic_snapshots_check2 CHECK (((funded_source_pool IS NULL) OR (funded_source_pool >= promised_seat_value))),
    CONSTRAINT tournament_satellite_economic_snapshots_configured_seats_check CHECK ((configured_seats >= 0)),
    CONSTRAINT tournament_satellite_economic_snapshots_ticket_value_check CHECK ((ticket_value >= (0)::numeric))
);


--
-- Name: TABLE tournament_satellite_economic_snapshots; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_satellite_economic_snapshots IS 'Immutable price/seat promise captured from the source start statement after its guarantee overlay. Finish never reprices a ticket from mutable target state.';


--
-- Name: tournament_satellite_entitlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_satellite_entitlements (
    tournament_id uuid NOT NULL,
    "position" integer NOT NULL,
    target_tournament_id uuid,
    award_kind text NOT NULL,
    ticket_value numeric(15,2) DEFAULT 0 NOT NULL,
    remainder_value numeric(15,2) DEFAULT 0 NOT NULL,
    source_pool numeric(15,2) NOT NULL,
    entry_closed_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT tournament_satellite_entitlements_award_kind_check CHECK ((award_kind = ANY (ARRAY['seat_or_cash'::text, 'cash'::text]))),
    CONSTRAINT tournament_satellite_entitlements_check CHECK ((((award_kind = 'seat_or_cash'::text) AND (target_tournament_id IS NOT NULL) AND (ticket_value > (0)::numeric)) OR ((award_kind = 'cash'::text) AND (ticket_value = (0)::numeric) AND (remainder_value > (0)::numeric)))),
    CONSTRAINT tournament_satellite_entitlements_position_check CHECK (("position" > 0)),
    CONSTRAINT tournament_satellite_entitlements_remainder_value_check CHECK ((remainder_value >= (0)::numeric)),
    CONSTRAINT tournament_satellite_entitlements_source_pool_check CHECK ((source_pool >= (0)::numeric)),
    CONSTRAINT tournament_satellite_entitlements_ticket_value_check CHECK ((ticket_value >= (0)::numeric))
);


--
-- Name: TABLE tournament_satellite_entitlements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_satellite_entitlements IS 'Immutable entry-close satellite award plan. One position may carry both a ticket value and the residual cash that belongs to the last seat winner in a short field.';


--
-- Name: tournament_satellite_settlement_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_satellite_settlement_batches (
    tournament_id uuid NOT NULL,
    winner_user_id uuid NOT NULL,
    target_tournament_id uuid,
    plan_fingerprint text NOT NULL,
    entitlement_count integer NOT NULL,
    award_depth integer NOT NULL,
    amount_owed numeric(15,2) NOT NULL,
    source text NOT NULL,
    prepared_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    settled_at timestamp with time zone,
    outcomes jsonb DEFAULT '[]'::jsonb NOT NULL,
    CONSTRAINT tournament_satellite_settlement_batches_amount_owed_check CHECK ((amount_owed >= (0)::numeric)),
    CONSTRAINT tournament_satellite_settlement_batches_award_depth_check CHECK ((award_depth >= 0)),
    CONSTRAINT tournament_satellite_settlement_batches_check CHECK ((((settled_at IS NULL) AND (outcomes = '[]'::jsonb)) OR (settled_at IS NOT NULL))),
    CONSTRAINT tournament_satellite_settlement_batches_check1 CHECK ((((entitlement_count = 0) AND (award_depth = 0)) OR ((entitlement_count = award_depth) AND (award_depth > 0)))),
    CONSTRAINT tournament_satellite_settlement_batches_entitlement_count_check CHECK ((entitlement_count >= 0)),
    CONSTRAINT tournament_satellite_settlement_batches_outcomes_check CHECK ((jsonb_typeof(outcomes) = 'array'::text)),
    CONSTRAINT tournament_satellite_settlement_batches_plan_fingerprint_check CHECK ((plan_fingerprint ~ '^[0-9a-f]{32}$'::text))
);


--
-- Name: TABLE tournament_satellite_settlement_batches; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_satellite_settlement_batches IS 'All-or-none satellite finish receipt. settled_at proves every frozen entitlement and the COMPLETED transition committed in one transaction.';


--
-- Name: tournament_satellite_settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_satellite_settlements (
    tournament_id uuid NOT NULL,
    target_id uuid NOT NULL,
    target_was_missing boolean DEFAULT false NOT NULL,
    target_contract_version bigint,
    winner_id uuid NOT NULL,
    field_size integer NOT NULL,
    advertised_seats integer NOT NULL,
    pool numeric(15,2) NOT NULL,
    target_buy_in numeric(15,2) NOT NULL,
    target_fee numeric(15,2) NOT NULL,
    ticket_cost numeric(15,2) NOT NULL,
    ticket_award_count integer NOT NULL,
    seat_count integer NOT NULL,
    cash_ticket_count integer NOT NULL,
    entry_ticket_count integer NOT NULL,
    remainder numeric(15,2) NOT NULL,
    bubble_user_id uuid,
    bubble_position integer,
    source_table_count integer NOT NULL,
    source_table_ids uuid[] NOT NULL,
    source_seat_count integer NOT NULL,
    source_seat_ids uuid[] NOT NULL,
    released_seat_count integer NOT NULL,
    released_seat_ids uuid[] NOT NULL,
    source_closed_at timestamp with time zone NOT NULL,
    source_escrow_closed_at timestamp with time zone NOT NULL,
    source_escrow_close_note text NOT NULL,
    settled_at timestamp with time zone DEFAULT now() NOT NULL,
    receipt_version integer DEFAULT 2 NOT NULL,
    CONSTRAINT tournament_satellite_settlements_advertised_seats_check CHECK ((advertised_seats >= 0)),
    CONSTRAINT tournament_satellite_settlements_cash_ticket_count_check CHECK ((cash_ticket_count >= 0)),
    CONSTRAINT tournament_satellite_settlements_check CHECK ((target_id <> tournament_id)),
    CONSTRAINT tournament_satellite_settlements_check1 CHECK ((ticket_cost = (target_buy_in + target_fee))),
    CONSTRAINT tournament_satellite_settlements_check10 CHECK ((released_seat_count = cardinality(released_seat_ids))),
    CONSTRAINT tournament_satellite_settlements_check11 CHECK ((source_closed_at <= settled_at)),
    CONSTRAINT tournament_satellite_settlements_check12 CHECK ((source_escrow_closed_at <= settled_at)),
    CONSTRAINT tournament_satellite_settlements_check13 CHECK ((released_seat_ids <@ source_seat_ids)),
    CONSTRAINT tournament_satellite_settlements_check14 CHECK (((((remainder = (0)::numeric) AND (bubble_user_id IS NULL) AND (bubble_position IS NULL)) OR ((remainder > (0)::numeric) AND (bubble_user_id IS NOT NULL) AND (bubble_position = (ticket_award_count + 1)) AND (bubble_position <= field_size))) IS TRUE)),
    CONSTRAINT tournament_satellite_settlements_check2 CHECK ((ticket_award_count = ((seat_count + cash_ticket_count) + entry_ticket_count))),
    CONSTRAINT tournament_satellite_settlements_check3 CHECK ((ticket_award_count <= field_size)),
    CONSTRAINT tournament_satellite_settlements_check4 CHECK ((pool = (((ticket_award_count)::numeric * ticket_cost) + remainder))),
    CONSTRAINT tournament_satellite_settlements_check5 CHECK ((pool >= ((advertised_seats)::numeric * ticket_cost))),
    CONSTRAINT tournament_satellite_settlements_check6 CHECK ((remainder < ticket_cost)),
    CONSTRAINT tournament_satellite_settlements_check7 CHECK (((target_was_missing IS FALSE) AND (target_contract_version IS NULL))),
    CONSTRAINT tournament_satellite_settlements_check8 CHECK ((source_table_count = cardinality(source_table_ids))),
    CONSTRAINT tournament_satellite_settlements_check9 CHECK ((source_seat_count = cardinality(source_seat_ids))),
    CONSTRAINT tournament_satellite_settlements_entry_ticket_count_check CHECK ((entry_ticket_count >= 0)),
    CONSTRAINT tournament_satellite_settlements_field_size_check CHECK ((field_size > 0)),
    CONSTRAINT tournament_satellite_settlements_pool_check CHECK (((pool >= (0)::numeric) AND (pool = round(pool, 2)))),
    CONSTRAINT tournament_satellite_settlements_receipt_version_check CHECK ((receipt_version = 2)),
    CONSTRAINT tournament_satellite_settlements_released_seat_count_check CHECK ((released_seat_count >= 0)),
    CONSTRAINT tournament_satellite_settlements_released_seat_ids_check CHECK ((array_position(released_seat_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_satellite_settlements_remainder_check CHECK (((remainder >= (0)::numeric) AND (remainder = round(remainder, 2)))),
    CONSTRAINT tournament_satellite_settlements_seat_count_check CHECK ((seat_count >= 0)),
    CONSTRAINT tournament_satellite_settlements_source_escrow_close_note_check CHECK ((length(btrim(source_escrow_close_note)) > 0)),
    CONSTRAINT tournament_satellite_settlements_source_seat_count_check CHECK ((source_seat_count >= 0)),
    CONSTRAINT tournament_satellite_settlements_source_seat_ids_check CHECK ((array_position(source_seat_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_satellite_settlements_source_table_count_check CHECK ((source_table_count > 0)),
    CONSTRAINT tournament_satellite_settlements_source_table_ids_check CHECK ((array_position(source_table_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_satellite_settlements_target_buy_in_check CHECK (((target_buy_in >= (0)::numeric) AND (target_buy_in = round(target_buy_in, 2)))),
    CONSTRAINT tournament_satellite_settlements_target_fee_check CHECK (((target_fee >= (0)::numeric) AND (target_fee = round(target_fee, 2)))),
    CONSTRAINT tournament_satellite_settlements_ticket_award_count_check CHECK ((ticket_award_count >= 0)),
    CONSTRAINT tournament_satellite_settlements_ticket_cost_check CHECK (((ticket_cost > (0)::numeric) AND (ticket_cost = round(ticket_cost, 2))))
);


--
-- Name: TABLE tournament_satellite_settlements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_satellite_settlements IS 'Immutable whole-pool satellite settlement header. Final pool = full ticket awards plus at most one next-finisher residual; exact source tables and seats close in the same transaction.';


--
-- Name: tournament_seat_exit_authorizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_seat_exit_authorizations (
    token uuid NOT NULL,
    seat_id uuid NOT NULL,
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    operation text NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT tournament_seat_exit_authorizations_operation_check CHECK ((operation = ANY (ARRAY['unregister'::text, 'cancel'::text, 'satellite_finish'::text, 'terminal_finish'::text, 'move'::text, 'elimination'::text, 'hand_settlement'::text])))
);


--
-- Name: tournament_spin_cancellation_unwinds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_spin_cancellation_unwinds (
    tournament_id uuid NOT NULL,
    pool_id uuid NOT NULL,
    reserve_owner_id uuid NOT NULL,
    original_contribution_id uuid NOT NULL,
    original_draw_id uuid,
    original_entry_journal_id uuid NOT NULL,
    original_draw_journal_id uuid,
    draw_reversal_id uuid,
    draw_reversal_journal_id uuid,
    contribution_reversal_id uuid NOT NULL,
    contribution_reversal_journal_id uuid NOT NULL,
    contribution_amount numeric(15,2) NOT NULL,
    draw_amount numeric(15,2) NOT NULL,
    pool_balance_before numeric(15,2) NOT NULL,
    pool_balance_after numeric(15,2) NOT NULL,
    settled_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT tournament_spin_cancellation_unwinds_check CHECK ((((pool_balance_before)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND ((pool_balance_after)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (pool_balance_before >= (0)::numeric) AND (pool_balance_after >= (0)::numeric))),
    CONSTRAINT tournament_spin_cancellation_unwinds_check1 CHECK ((pool_balance_after = round(((pool_balance_before + draw_amount) - contribution_amount), 2))),
    CONSTRAINT tournament_spin_cancellation_unwinds_check2 CHECK ((((draw_amount = (0)::numeric) AND (original_draw_id IS NULL) AND (original_draw_journal_id IS NULL) AND (draw_reversal_id IS NULL) AND (draw_reversal_journal_id IS NULL)) OR ((draw_amount > (0)::numeric) AND (original_draw_id IS NOT NULL) AND (original_draw_journal_id IS NOT NULL) AND (draw_reversal_id IS NOT NULL) AND (draw_reversal_journal_id IS NOT NULL)))),
    CONSTRAINT tournament_spin_cancellation_unwinds_contribution_amount_check CHECK ((((contribution_amount)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (contribution_amount > (0)::numeric) AND (contribution_amount = round(contribution_amount, 2)))),
    CONSTRAINT tournament_spin_cancellation_unwinds_draw_amount_check CHECK ((((draw_amount)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (draw_amount >= (0)::numeric) AND (draw_amount = round(draw_amount, 2))))
);


--
-- Name: tournament_table_origins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_table_origins (
    table_id uuid NOT NULL,
    tournament_id uuid NOT NULL,
    origin_kind text NOT NULL,
    launch_id uuid,
    launch_lease_generation uuid,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT tournament_table_origins_kind_check CHECK ((((origin_kind = 'launch'::text) AND (launch_id IS NOT NULL) AND (launch_lease_generation IS NOT NULL)) OR ((origin_kind = ANY (ARRAY['prelaunch'::text, 'capacity'::text, 'legacy'::text])) AND (launch_id IS NULL) AND (launch_lease_generation IS NULL))))
);


--
-- Name: tournament_terminal_settlements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_terminal_settlements (
    tournament_id uuid NOT NULL,
    winner_id uuid NOT NULL,
    settlement_mode text NOT NULL,
    started_status text NOT NULL,
    prize_pool numeric(15,2) NOT NULL,
    bounty_pool numeric(15,2) NOT NULL,
    cash_payout_count integer NOT NULL,
    cash_payout_total numeric(15,2) NOT NULL,
    bounty_payout_total numeric(15,2) NOT NULL,
    mystery_was_active boolean NOT NULL,
    mystery_pool_cents bigint NOT NULL,
    cash_receipt jsonb NOT NULL,
    mystery_receipt jsonb NOT NULL,
    bounty_receipt jsonb NOT NULL,
    closed_table_count integer NOT NULL,
    closed_table_ids uuid[] NOT NULL,
    source_seat_count integer NOT NULL,
    source_seat_ids uuid[] NOT NULL,
    released_seat_count integer NOT NULL,
    released_seat_ids uuid[] NOT NULL,
    rake_amount numeric(15,2) NOT NULL,
    rake_destination text NOT NULL,
    rake_settled_at timestamp with time zone NOT NULL,
    rake_attributed_at timestamp with time zone NOT NULL,
    rake_attributed_users integer NOT NULL,
    escrow_closed_at timestamp with time zone NOT NULL,
    escrow_close_note text NOT NULL,
    completed_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    receipt_version integer DEFAULT 1 NOT NULL,
    CONSTRAINT tournament_terminal_settlements_bounty_payout_total_check CHECK (((bounty_payout_total >= (0)::numeric) AND (bounty_payout_total = round(bounty_payout_total, 2)))),
    CONSTRAINT tournament_terminal_settlements_bounty_pool_check CHECK (((bounty_pool >= (0)::numeric) AND (bounty_pool = round(bounty_pool, 2)))),
    CONSTRAINT tournament_terminal_settlements_bounty_receipt_check CHECK ((jsonb_typeof(bounty_receipt) = 'object'::text)),
    CONSTRAINT tournament_terminal_settlements_cash_payout_count_check CHECK ((cash_payout_count >= 0)),
    CONSTRAINT tournament_terminal_settlements_cash_payout_total_check CHECK (((cash_payout_total >= (0)::numeric) AND (cash_payout_total = round(cash_payout_total, 2)))),
    CONSTRAINT tournament_terminal_settlements_cash_receipt_check CHECK ((jsonb_typeof(cash_receipt) = 'object'::text)),
    CONSTRAINT tournament_terminal_settlements_check CHECK ((cash_payout_total = prize_pool)),
    CONSTRAINT tournament_terminal_settlements_check1 CHECK ((bounty_payout_total = bounty_pool)),
    CONSTRAINT tournament_terminal_settlements_check2 CHECK (((mystery_was_active AND (mystery_pool_cents > 0)) OR ((NOT mystery_was_active) AND (mystery_pool_cents = 0)))),
    CONSTRAINT tournament_terminal_settlements_check3 CHECK ((closed_table_count = cardinality(closed_table_ids))),
    CONSTRAINT tournament_terminal_settlements_check4 CHECK ((source_seat_count = cardinality(source_seat_ids))),
    CONSTRAINT tournament_terminal_settlements_check5 CHECK ((released_seat_count = cardinality(released_seat_ids))),
    CONSTRAINT tournament_terminal_settlements_check6 CHECK ((released_seat_ids <@ source_seat_ids)),
    CONSTRAINT tournament_terminal_settlements_check7 CHECK (((rake_settled_at <= settled_at) AND (rake_attributed_at <= settled_at))),
    CONSTRAINT tournament_terminal_settlements_check8 CHECK ((escrow_closed_at <= settled_at)),
    CONSTRAINT tournament_terminal_settlements_check9 CHECK ((completed_at <= settled_at)),
    CONSTRAINT tournament_terminal_settlements_closed_table_count_check CHECK ((closed_table_count >= 0)),
    CONSTRAINT tournament_terminal_settlements_closed_table_ids_check CHECK ((array_position(closed_table_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_terminal_settlements_escrow_close_note_check CHECK ((length(btrim(escrow_close_note)) > 0)),
    CONSTRAINT tournament_terminal_settlements_mystery_pool_cents_check CHECK ((mystery_pool_cents >= 0)),
    CONSTRAINT tournament_terminal_settlements_mystery_receipt_check CHECK ((jsonb_typeof(mystery_receipt) = 'object'::text)),
    CONSTRAINT tournament_terminal_settlements_prize_pool_check CHECK (((prize_pool >= (0)::numeric) AND (prize_pool = round(prize_pool, 2)))),
    CONSTRAINT tournament_terminal_settlements_rake_amount_check CHECK (((rake_amount >= (0)::numeric) AND (rake_amount = round(rake_amount, 2)))),
    CONSTRAINT tournament_terminal_settlements_rake_attributed_users_check CHECK ((rake_attributed_users >= 0)),
    CONSTRAINT tournament_terminal_settlements_rake_destination_check CHECK ((length(btrim(rake_destination)) > 0)),
    CONSTRAINT tournament_terminal_settlements_receipt_version_check CHECK ((receipt_version = 1)),
    CONSTRAINT tournament_terminal_settlements_released_seat_count_check CHECK ((released_seat_count >= 0)),
    CONSTRAINT tournament_terminal_settlements_released_seat_ids_check CHECK ((array_position(released_seat_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_terminal_settlements_settlement_mode_check CHECK ((settlement_mode = ANY (ARRAY['places'::text, 'final_table_deal'::text]))),
    CONSTRAINT tournament_terminal_settlements_source_seat_count_check CHECK ((source_seat_count >= 0)),
    CONSTRAINT tournament_terminal_settlements_source_seat_ids_check CHECK ((array_position(source_seat_ids, NULL::uuid) IS NULL)),
    CONSTRAINT tournament_terminal_settlements_started_status_check CHECK ((started_status = ANY (ARRAY['RUNNING'::text, 'COMPLETING'::text])))
);


--
-- Name: TABLE tournament_terminal_settlements; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_terminal_settlements IS 'Immutable all-or-nothing non-satellite completion receipt: exact cash authority result, bounty close, durable attributed rake, released seats, closed tables and completed lifecycle state.';


--
-- Name: tournament_ticket_admission_authorizations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_ticket_admission_authorizations (
    token uuid DEFAULT gen_random_uuid() NOT NULL,
    ticket_id uuid NOT NULL,
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    registration_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL
);


--
-- Name: TABLE tournament_ticket_admission_authorizations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_ticket_admission_authorizations IS 'Owner-only one-use capabilities consumed by the ticket row guard during atomic tournament admission. Session settings alone never authorize redemption.';


--
-- Name: tournament_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_tickets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    club_id uuid NOT NULL,
    issued_by uuid NOT NULL,
    holder_id uuid NOT NULL,
    value numeric NOT NULL,
    note text,
    status text DEFAULT 'issued'::text NOT NULL,
    redeemed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    redemption_mode text DEFAULT 'wallet_chips'::text NOT NULL,
    source_tournament_id uuid,
    source_satellite_id uuid,
    source_refund_entitlement_id uuid,
    source_satellite_award_place integer,
    entry_prize numeric(15,2),
    entry_bounty numeric(15,2),
    entry_fee numeric(15,2),
    CONSTRAINT tournament_tickets_redemption_mode_check CHECK ((redemption_mode = ANY (ARRAY['wallet_chips'::text, 'tournament_entry_only'::text]))),
    CONSTRAINT tournament_tickets_satellite_entry_contract_check CHECK (((((redemption_mode = 'wallet_chips'::text) AND (source_tournament_id IS NULL) AND (source_satellite_id IS NULL) AND (source_refund_entitlement_id IS NULL) AND (source_satellite_award_place IS NULL) AND (entry_prize IS NULL) AND (entry_bounty IS NULL) AND (entry_fee IS NULL)) OR ((redemption_mode = 'tournament_entry_only'::text) AND (issued_by = '2d1cd6c3-5700-4af9-a271-d4863fdab20d'::uuid) AND (source_tournament_id IS NOT NULL) AND (source_satellite_id IS NOT NULL) AND (((source_refund_entitlement_id IS NOT NULL) AND (source_satellite_award_place IS NULL)) OR ((source_refund_entitlement_id IS NULL) AND (source_satellite_award_place > 0) AND (source_tournament_id <> source_satellite_id))) AND (entry_prize IS NOT NULL) AND (entry_prize >= (0)::numeric) AND (entry_prize = round(entry_prize, 2)) AND (entry_bounty IS NOT NULL) AND (entry_bounty >= (0)::numeric) AND (entry_bounty = round(entry_bounty, 2)) AND (entry_fee IS NOT NULL) AND (entry_fee >= (0)::numeric) AND (entry_fee = round(entry_fee, 2)) AND (value = round(((entry_prize + entry_bounty) + entry_fee), 2)))) IS TRUE)),
    CONSTRAINT tournament_tickets_status_check CHECK ((status = ANY (ARRAY['issued'::text, 'redeemed'::text, 'cancelled'::text]))),
    CONSTRAINT tournament_tickets_value_check CHECK ((value > (0)::numeric))
);


--
-- Name: COLUMN tournament_tickets.redemption_mode; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_tickets.redemption_mode IS 'wallet_chips for cashier-issued value; tournament_entry_only for a direct or returned satellite award that can never be redeemed or cancelled into chips.';


--
-- Name: COLUMN tournament_tickets.source_satellite_award_place; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_tickets.source_satellite_award_place IS 'Immutable source-satellite finish place for a direct noncash target-entry ticket; null for wallet tickets and entitlement-return tickets.';


--
-- Name: tournament_unregistration_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_unregistration_receipts (
    registration_id uuid NOT NULL,
    request_id uuid NOT NULL,
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    source_table_id uuid,
    refunded_chips numeric(15,2) NOT NULL,
    returned_ticket_value numeric(15,2) NOT NULL,
    entitlement_ids uuid[] NOT NULL,
    ticket_ids uuid[] NOT NULL,
    source_wallet_club_ids uuid[] NOT NULL,
    credit_ledger_ids uuid[] NOT NULL,
    wallet_transaction_ids uuid[] NOT NULL,
    fees_reversed numeric(15,2) NOT NULL,
    fee_reversal_ids uuid[] NOT NULL,
    fee_source_rake_record_ids uuid[] NOT NULL,
    seat_number integer,
    seats_taken integer,
    scheduled_start_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone NOT NULL,
    start_authority text DEFAULT 'scheduled_clock'::text NOT NULL,
    CONSTRAINT tournament_unregistration_actual_start_check CHECK ((((start_authority = 'scheduled_clock'::text) AND (settled_at < scheduled_start_at)) OR (start_authority = ANY (ARRAY['spin_actual_start'::text, 'heads_up_sng_actual_start'::text, 'launch_release'::text])))),
    CONSTRAINT tournament_unregistration_receipts_check CHECK (((array_position(entitlement_ids, NULL::uuid) IS NULL) AND (array_position(ticket_ids, NULL::uuid) IS NULL) AND (array_position(source_wallet_club_ids, NULL::uuid) IS NULL) AND (array_position(credit_ledger_ids, NULL::uuid) IS NULL) AND (array_position(wallet_transaction_ids, NULL::uuid) IS NULL) AND (array_position(fee_reversal_ids, NULL::uuid) IS NULL) AND (array_position(fee_source_rake_record_ids, NULL::uuid) IS NULL))),
    CONSTRAINT tournament_unregistration_receipts_check1 CHECK ((cardinality(entitlement_ids) = cardinality(source_wallet_club_ids))),
    CONSTRAINT tournament_unregistration_receipts_check2 CHECK ((cardinality(entitlement_ids) = (cardinality(ticket_ids) + cardinality(wallet_transaction_ids)))),
    CONSTRAINT tournament_unregistration_receipts_check3 CHECK ((cardinality(credit_ledger_ids) = cardinality(wallet_transaction_ids))),
    CONSTRAINT tournament_unregistration_receipts_check4 CHECK (((returned_ticket_value = (0)::numeric) = (cardinality(ticket_ids) = 0))),
    CONSTRAINT tournament_unregistration_receipts_check5 CHECK (((refunded_chips = (0)::numeric) = (cardinality(wallet_transaction_ids) = 0))),
    CONSTRAINT tournament_unregistration_receipts_check6 CHECK (((fees_reversed = (0)::numeric) = (cardinality(fee_reversal_ids) = 0))),
    CONSTRAINT tournament_unregistration_receipts_check7 CHECK (((fees_reversed = (0)::numeric) = (cardinality(fee_source_rake_record_ids) = 0))),
    CONSTRAINT tournament_unregistration_receipts_check8 CHECK ((((source_table_id IS NULL) AND (seat_number IS NULL)) OR ((source_table_id IS NOT NULL) AND (seat_number IS NOT NULL)))),
    CONSTRAINT tournament_unregistration_receipts_fees_reversed_check CHECK (((fees_reversed >= (0)::numeric) AND ((fees_reversed)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (fees_reversed = round(fees_reversed, 2)))),
    CONSTRAINT tournament_unregistration_receipts_refunded_chips_check CHECK (((refunded_chips >= (0)::numeric) AND ((refunded_chips)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (refunded_chips = round(refunded_chips, 2)))),
    CONSTRAINT tournament_unregistration_receipts_returned_ticket_value_check CHECK (((returned_ticket_value >= (0)::numeric) AND ((returned_ticket_value)::text <> ALL (ARRAY['NaN'::text, 'Infinity'::text, '-Infinity'::text])) AND (returned_ticket_value = round(returned_ticket_value, 2))))
);


--
-- Name: TABLE tournament_unregistration_receipts; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_unregistration_receipts IS 'Immutable, request-keyed outcome of one exact pre-start registration removal. It records the scheduled-start cutoff, wallet and tournament-ticket rails separately, and the exact original and reversing rake row ids by fee-recipient club, so a lost response can be replayed without performing a post-start unregister or reconstructing money from mutable tournament pricing or the funding wallet club.';


--
-- Name: COLUMN tournament_unregistration_receipts.start_authority; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tournament_unregistration_receipts.start_authority IS 'scheduled_clock for timed events; spin_actual_start and heads_up_sng_actual_start prove that the fill-window deadline never governed a distinct seat-first product.';


--
-- Name: union_admins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.union_admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    union_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role text DEFAULT 'union_admin'::text NOT NULL,
    permissions jsonb DEFAULT '{"manage_clubs": true, "manage_settlements": true}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT union_admins_role_check CHECK ((role = ANY (ARRAY['union_lead'::text, 'union_admin'::text])))
);


--
-- Name: union_clubs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.union_clubs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    union_id uuid NOT NULL,
    club_id uuid NOT NULL,
    joined_at timestamp with time zone DEFAULT now(),
    club_commission_rate numeric(5,4) DEFAULT 0.9000,
    rate_cash numeric,
    rate_mtt numeric,
    rate_sng numeric,
    rate_spin numeric,
    rate_satellite numeric,
    CONSTRAINT union_clubs_game_rates_are_fractions CHECK ((((rate_cash IS NULL) OR ((rate_cash >= (0)::numeric) AND (rate_cash <= (1)::numeric))) AND ((rate_mtt IS NULL) OR ((rate_mtt >= (0)::numeric) AND (rate_mtt <= (1)::numeric))) AND ((rate_sng IS NULL) OR ((rate_sng >= (0)::numeric) AND (rate_sng <= (1)::numeric))) AND ((rate_spin IS NULL) OR ((rate_spin >= (0)::numeric) AND (rate_spin <= (1)::numeric))) AND ((rate_satellite IS NULL) OR ((rate_satellite >= (0)::numeric) AND (rate_satellite <= (1)::numeric)))))
);


--
-- Name: COLUMN union_clubs.rate_cash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.union_clubs.rate_cash IS 'Rakeback share of this club''s cash-game basis, 0..1. NULL falls back to club_commission_rate, then 0.90.';


--
-- Name: COLUMN union_clubs.rate_mtt; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.union_clubs.rate_mtt IS 'Rakeback share of this club''s MTT basis, 0..1. NULL falls back to club_commission_rate, then 0.90.';


--
-- Name: COLUMN union_clubs.rate_sng; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.union_clubs.rate_sng IS 'Rakeback share of this club''s sit-n-go basis, 0..1. NULL falls back to club_commission_rate, then 0.90.';


--
-- Name: COLUMN union_clubs.rate_spin; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.union_clubs.rate_spin IS 'Rakeback share of this club''s spin basis, 0..1. NULL falls back to club_commission_rate, then 0.90.';


--
-- Name: COLUMN union_clubs.rate_satellite; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.union_clubs.rate_satellite IS 'Rakeback share of this club''s satellite basis, 0..1. NULL falls back to club_commission_rate, then 0.90.';


--
-- Name: union_creators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.union_creators (
    user_id uuid NOT NULL,
    note text,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    added_by uuid
);


--
-- Name: TABLE union_creators; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.union_creators IS 'Who may create a union. Enforced by trg_union_creation_is_allowlisted on public.unions; read by fn_can_create_union. Empty means nobody.';


--
-- Name: union_rake_weekly; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.union_rake_weekly (
    union_id uuid NOT NULL,
    club_id uuid NOT NULL,
    week_start date NOT NULL,
    rake_total numeric DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE union_rake_weekly; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.union_rake_weekly IS 'Derived weekly rake totals per (union, club). Display data for fn_club_money_panel; union_wallet_transactions remains the source of truth. Maintained by trg_union_rake_weekly on INSERT. Verify with fn_union_rake_weekly_verify().';


--
-- Name: union_wallet_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.union_wallet_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    union_id uuid NOT NULL,
    wallet text NOT NULL,
    direction text NOT NULL,
    amount numeric(20,4) NOT NULL,
    balance_after numeric(20,4),
    tx_type text NOT NULL,
    club_id uuid,
    period_id uuid,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_amount_is_two_decimal_places CHECK (((amount IS NULL) OR (amount = round(amount, 2)))),
    CONSTRAINT union_wallet_transactions_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT union_wallet_transactions_direction_check CHECK ((direction = ANY (ARRAY['credit'::text, 'debit'::text]))),
    CONSTRAINT union_wallet_transactions_wallet_check CHECK ((wallet = ANY (ARRAY['chip_balance'::text, 'rake_wallet'::text, 'bbj_wallet'::text, 'promo_wallet'::text, 'insurance_wallet'::text, 'spin_reserve_wallet'::text])))
)
WITH (autovacuum_enabled='true', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='5000', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='5000', autovacuum_vacuum_insert_threshold='5000', autovacuum_vacuum_insert_scale_factor='0.0', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: union_wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.union_wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    union_id uuid NOT NULL,
    chip_balance numeric(20,2) DEFAULT 0 NOT NULL,
    rake_wallet numeric(20,2) DEFAULT 0,
    bbj_wallet numeric(20,2) DEFAULT 0,
    promo_wallet numeric(20,2) DEFAULT 0,
    insurance_wallet numeric(20,2) DEFAULT 0,
    total_rake_collected numeric(20,2) DEFAULT 0,
    total_settlements numeric DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    spin_reserve_wallet numeric(20,2) DEFAULT 0 NOT NULL,
    CONSTRAINT union_wallets_bbj_wallet_nonneg CHECK ((bbj_wallet >= (0)::numeric)),
    CONSTRAINT union_wallets_chip_balance_nonneg CHECK ((chip_balance >= (0)::numeric)),
    CONSTRAINT union_wallets_insurance_wallet_nonneg CHECK ((insurance_wallet >= (0)::numeric)),
    CONSTRAINT union_wallets_promo_wallet_nonneg CHECK ((promo_wallet >= (0)::numeric)),
    CONSTRAINT union_wallets_rake_wallet_nonneg CHECK ((rake_wallet >= (0)::numeric)),
    CONSTRAINT union_wallets_spin_reserve_wallet_nonneg CHECK ((spin_reserve_wallet >= (0)::numeric))
);


--
-- Name: COLUMN union_wallets.spin_reserve_wallet; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.union_wallets.spin_reserve_wallet IS 'Operator capital earmarked for the Spin Reserve Pool: undeployed seed money in, surplus above the pool ceiling back out. Never sourced from player funds. The DEPLOYED reserve is spin_bonus_pools.balance - this wallet holds only what is NOT currently in the pool, so the two never double-count.';


--
-- Name: unions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.unions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    owner_id uuid NOT NULL,
    avatar_url text,
    is_public boolean DEFAULT true,
    member_count integer DEFAULT 0,
    club_count integer DEFAULT 0,
    total_rake numeric(15,2) DEFAULT 0 NOT NULL,
    settings jsonb DEFAULT '{"shared_player_pool": true, "revenue_share_percent": 10, "cross_club_tournaments": true}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    union_code integer,
    main_bbj_balance numeric(14,2) DEFAULT 0,
    backup_bbj_balance numeric(14,2) DEFAULT 0,
    promo_fund_balance numeric(14,2) DEFAULT 0,
    code text,
    insurance_balance numeric(14,2) DEFAULT 0,
    chip_balance numeric(20,4) DEFAULT 0 NOT NULL,
    rake_wallet numeric(20,4) DEFAULT 0 NOT NULL,
    bbj_wallet numeric(20,4) DEFAULT 0 NOT NULL,
    promo_wallet numeric(20,4) DEFAULT 0 NOT NULL,
    auto_settlement boolean DEFAULT false,
    level integer DEFAULT 1,
    player_level integer DEFAULT 1,
    hierarchy_level integer DEFAULT 1,
    total_players integer DEFAULT 0,
    total_admins integer DEFAULT 0,
    total_super_agents integer DEFAULT 0,
    total_agents integer DEFAULT 0,
    hierarchy_units numeric(10,2) DEFAULT 0,
    hierarchy_units_rounded_up integer DEFAULT 0,
    player_threshold_current integer DEFAULT 30,
    player_threshold_next integer DEFAULT 34,
    hierarchy_threshold_current integer DEFAULT 2,
    hierarchy_threshold_next integer DEFAULT 2,
    promo_funded_from_bbj numeric DEFAULT 0 NOT NULL,
    promo_funded_from_bank numeric DEFAULT 0 NOT NULL,
    slug text NOT NULL,
    CONSTRAINT chk_chip_balance_is_two_decimal_places CHECK (((chip_balance IS NULL) OR (chip_balance = round(chip_balance, 2)))),
    CONSTRAINT chk_rake_wallet_is_two_decimal_places CHECK (((rake_wallet IS NULL) OR (rake_wallet = round(rake_wallet, 2))))
);


--
-- Name: COLUMN unions.promo_fund_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.promo_fund_balance IS 'DEPRECATED 2026-08-15. Use unions.promo_wallet. Zero on every row.';


--
-- Name: COLUMN unions.chip_balance; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.chip_balance IS 'DEPRECATED 2026-08-15. Union bank lives on union_wallets.chip_balance.';


--
-- Name: COLUMN unions.rake_wallet; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.rake_wallet IS 'Cumulative rake collected from all member clubs each settlement cycle.';


--
-- Name: COLUMN unions.bbj_wallet; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.bbj_wallet IS 'BBJ pool contributions routed here from club-level settlements.';


--
-- Name: COLUMN unions.promo_wallet; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.promo_wallet IS 'DEPRECATED 2026-08-15. Union promo lives on union_wallets.promo_wallet. Kept at 0.';


--
-- Name: COLUMN unions.promo_funded_from_bbj; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.promo_funded_from_bbj IS 'Lifetime promo chips received from the BBJ 25% slice via fn_sweep_bbj_promo. The main source.';


--
-- Name: COLUMN unions.promo_funded_from_bank; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.promo_funded_from_bank IS 'Lifetime promo chips moved in from unions.chip_balance by the owner via fn_union_fund_promo_from_bank. A transfer, never a mint.';


--
-- Name: COLUMN unions.slug; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.unions.slug IS 'Route identity: /unions/<slug>. Unique, lower-case [a-z0-9-], never a UUID. Filled by trg_unions_set_slug from the name when not supplied.';


--
-- Name: user_daily_streaks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_daily_streaks (
    user_id uuid NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    last_completed_date date,
    total_days_played integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_diamond_balance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_diamond_balance (
    user_id uuid NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    lifetime_earned integer DEFAULT 0 NOT NULL,
    lifetime_spent integer DEFAULT 0 NOT NULL,
    current_streak integer DEFAULT 0 NOT NULL,
    longest_streak integer DEFAULT 0 NOT NULL,
    last_claim_date date,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT user_diamond_balance_balance_check CHECK ((balance >= 0))
);


--
-- Name: user_diamonds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_diamonds (
    user_id uuid NOT NULL,
    balance integer DEFAULT 0 NOT NULL,
    lifetime_earned integer DEFAULT 0 NOT NULL,
    lifetime_spent integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_mfa_factors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_mfa_factors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    secret text NOT NULL,
    enabled boolean DEFAULT false,
    backup_codes text[] DEFAULT ARRAY[]::text[],
    disabled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT extensions.uuid_generate_v4() NOT NULL,
    username text NOT NULL,
    email text,
    avatar_url text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: wallet_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    wallet_type text NOT NULL,
    amount numeric(15,2) NOT NULL,
    type text NOT NULL,
    category text NOT NULL,
    description text,
    related_entity_id uuid,
    table_id uuid,
    hand_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    balance_after numeric,
    terminal_closed_at timestamp with time zone,
    CONSTRAINT wallet_transactions_type_check CHECK ((type = ANY (ARRAY['credit'::text, 'debit'::text]))),
    CONSTRAINT wallet_transactions_wallet_type_check CHECK ((wallet_type = ANY (ARRAY['PLAYER'::text, 'BUSINESS'::text, 'PROMO'::text, 'CLUB'::text, 'UNION'::text, 'PLATFORM'::text])))
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='1000', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='1000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: vip_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vip_points (
    user_id uuid NOT NULL,
    current_points bigint DEFAULT 0 NOT NULL,
    lifetime_points bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: vip_points_carry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vip_points_carry (
    user_id uuid NOT NULL,
    carry numeric(14,4) DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT vip_points_carry_carry_check CHECK (((carry >= (0)::numeric) AND (carry < (1)::numeric)))
);


--
-- Name: vip_points_ledger; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.vip_points_ledger (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    points bigint NOT NULL,
    reason text,
    source_type text DEFAULT 'rake'::text NOT NULL,
    source_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    credit numeric(14,4)
)
WITH (autovacuum_enabled='true', autovacuum_analyze_scale_factor='0.0', autovacuum_analyze_threshold='2000', autovacuum_vacuum_scale_factor='0.0', autovacuum_vacuum_threshold='2000', autovacuum_vacuum_cost_delay='2', autovacuum_vacuum_cost_limit='2000');


--
-- Name: wallet_credit_idempotency; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallet_credit_idempotency (
    key text NOT NULL,
    user_id uuid,
    amount numeric,
    created_at timestamp with time zone DEFAULT now() NOT NULL
)
WITH (autovacuum_freeze_max_age='165000000');


--
-- Name: wallets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.wallets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    wallet_type text NOT NULL,
    balance numeric(15,2) DEFAULT 0 NOT NULL,
    locked_balance numeric(15,2) DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT wallets_wallet_type_check CHECK ((wallet_type = ANY (ARRAY['BUSINESS'::text, 'PLAYER'::text, 'PROMO'::text])))
);


--
-- Name: bbj_hand_evidence_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bbj_hand_evidence_log ALTER COLUMN id SET DEFAULT nextval('public.bbj_hand_evidence_log_id_seq'::regclass);


--
-- Name: ca_diamond_balance_audit id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_balance_audit ALTER COLUMN id SET DEFAULT nextval('public.ca_diamond_balance_audit_id_seq'::regclass);


--
-- Name: ca_diamond_engine_spend id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_engine_spend ALTER COLUMN id SET DEFAULT nextval('public.ca_diamond_engine_spend_id_seq'::regclass);


--
-- Name: ca_diamond_incidents id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_diamond_incidents ALTER COLUMN id SET DEFAULT nextval('public.ca_diamond_incidents_id_seq'::regclass);


--
-- Name: ca_freeroll_free_buy_log id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_freeroll_free_buy_log ALTER COLUMN id SET DEFAULT nextval('public.ca_freeroll_free_buy_log_id_seq'::regclass);


--
-- Name: ca_frozen_pool_deletions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_frozen_pool_deletions ALTER COLUMN id SET DEFAULT nextval('public.ca_frozen_pool_deletions_id_seq'::regclass);


--
-- Name: ca_ledger_write_failures id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_ledger_write_failures ALTER COLUMN id SET DEFAULT nextval('public.ca_ledger_write_failures_id_seq'::regclass);


--
-- Name: ca_seat_stack_exits id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ca_seat_stack_exits ALTER COLUMN id SET DEFAULT nextval('public.ca_seat_stack_exits_id_seq'::regclass);


--
-- Name: cash_cluster_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_cluster_events ALTER COLUMN id SET DEFAULT nextval('public.cash_cluster_events_id_seq'::regclass);


--
-- Name: content_authors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.content_authors ALTER COLUMN id SET DEFAULT nextval('public.content_authors_id_seq'::regclass);


--
-- Name: deep_stack_delete_attempts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.deep_stack_delete_attempts ALTER COLUMN id SET DEFAULT nextval('public.deep_stack_delete_attempts_id_seq'::regclass);


--
-- Name: managed_game_contract_versions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.managed_game_contract_versions ALTER COLUMN id SET DEFAULT nextval('public.managed_game_contract_versions_id_seq'::regclass);


--
-- Name: signup_errors id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.signup_errors ALTER COLUMN id SET DEFAULT nextval('public.signup_errors_id_seq'::regclass);


--
-- PostgreSQL database dump complete
--

\unrestrict uQSNTFTbXhZfmkTNabG3ybUj7oLC0fwfpxjeMhOcHBSb9o3fTNiSwdvzwk1FlHQ

