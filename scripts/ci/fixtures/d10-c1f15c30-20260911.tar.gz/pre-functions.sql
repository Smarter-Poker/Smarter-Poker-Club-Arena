SET check_function_bodies=false;
CREATE OR REPLACE FUNCTION public.fn_ca_house_board_allows_automation(p_club_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE
 SET search_path TO 'public', 'pg_temp'
AS $function$
  -- DERIVED FIRST: the platform club is the house board, and always will be, without anybody
  -- remembering to add it to a list. This is the half that cannot rot.
  SELECT COALESCE((SELECT c.is_platform FROM public.clubs c WHERE c.id = p_club_id), false)
     -- LEGACY, AND IT IS DEBT: four chip house boards that predate clubs.is_platform and carry no
     -- flag of their own. Give them one and these four lines delete themselves.
     OR p_club_id = ANY (ARRAY[
          'a41434bb-8d0c-400a-8f0d-e8b3d65afed4'::uuid,   -- Club JAQK
          'a0000000-0000-0000-0000-000000000001'::uuid,   -- SHARK CLUB
          'fade0000-0000-0000-0000-000000000001'::uuid,   -- Midway Union
          '2a1132b9-5ba2-42e6-9f01-30a7fcffebe3'::uuid    -- Deep Stack Society
        ]);
$function$
;