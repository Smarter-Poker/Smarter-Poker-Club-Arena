"""Offline-only native accounting ruling rehearsal on an owned PG17 cluster."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, hashlib, json, os, subprocess, tempfile

base=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--pg-bin',default='/opt/homebrew/opt/postgresql@17/bin')
parser.add_argument('--d12-migration',type=Path,help='Optional reviewed local D12 migration, applied only after completed D10')
args=parser.parse_args();pg=Path(args.pg_bin).resolve()
assert subprocess.check_output([str(pg/'postgres'),'--version'],text=True).startswith('postgres (PostgreSQL) 17.')
manifest=json.loads((base/'fixture-manifest.json').read_text());case=manifest['case']
assert case == 'D10'
minute=datetime.now(timezone.utc).minute
if minute>=50 or minute<3:
    raise SystemExit('The preserved ruling refuses :50-:03 UTC. Run this local rehearsal outside that window.')
for n,digest in manifest['sha256'].items():
    assert Path(n).name==n and hashlib.sha256((base/n).read_bytes()).hexdigest()==digest,n
work=Path(tempfile.mkdtemp(prefix='ca-e2-owned-',dir='/tmp'));data=work/'data';sock=work/'socket';sock.mkdir(mode=0o700)
runtime=work/'rehearsal';runtime.mkdir()
database='d10_c1f15c30'
for n in manifest['sha256']:
    content=(base/n).read_bytes()
    if n.endswith('.py'):content=content.replace(b'/opt/homebrew/opt/postgresql@17/bin',str(pg).encode())
    (runtime/n).write_bytes(content)
(runtime/'cluster.json').write_text(json.dumps({'cluster':str(work),'socket':str(sock),'port':55498,'database':database}))
env={k:v for k,v in os.environ.items() if not k.startswith('PG')};env['PGTZ']='UTC'
def run(command,log):
    r=subprocess.run(command,cwd=runtime,env=env,text=True,capture_output=True)
    (runtime/log).write_text(r.stdout+r.stderr)
    if r.returncode:raise RuntimeError(f'{log}: '+(r.stderr or r.stdout)[-3000:])
    return r.stdout
started=False
try:
    run([str(pg/'initdb'),'-D',str(data),'--no-locale','-E','UTF8','-U','postgres'],'init.log')
    run([str(pg/'pg_ctl'),'-D',str(data),'-l',str(work/'postgres.log'),'-o',f"-h '' -k {sock} -p 55498",'-w','start'],'start.log');started=True
    psql=[str(pg/'psql'),'-X','-v','ON_ERROR_STOP=1','-h',str(sock),'-p','55498','-U','postgres']
    run(psql+['-d','postgres','-c','CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role BYPASSRLS;'],'roles.log')
    for script in ['load-local.py','verify-pins.py','seed-local.py']:
        run(['python3',str(runtime/script)],script+'.log')
    def sql(n):return run(psql+['-d',database,'-f',str(runtime/n)],n+'.log')
    sql(manifest['migration'])
    sql('before.sql');sql('current-source-pins.sql')
    
    run(['python3',str(runtime/'extract-bust-evidence.py')],'bust-evidence.log')
    run(['python3',str(runtime/'test-paid-evidence.py'),'pre'],'test-pre.log')
    sql(manifest['ruling'])
    run(['python3',str(runtime/'test-paid-evidence.py'),'post'],'test-post.log')
    terminal=run(psql+['-d',database,'-Atc',"SELECT fn_complete_tournament_terminal('"+manifest['eventId']+"','"+manifest['winnerId']+"','places')"],'terminal.log')
    receipt=json.loads(terminal);assert receipt['status']=='COMPLETED'
    (runtime/'terminal-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    run(['python3',str(runtime/'verify-local.py')],'verify.log')
    if args.d12_migration:
        selected=base/'d12-reviewed-preview.sql' if str(args.d12_migration)=='sealed' else args.d12_migration.resolve()
        (runtime/'d12-preview.sql').write_bytes(selected.read_bytes())
        run(['python3',str(runtime/'test-d12-replay.py')],'d12-replay.log')
    output=base/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');output.mkdir(parents=True)
    names=['negative-pre-receipt.json','negative-post-receipt.json','bust-evidence-receipt.json','terminal-receipt.json','verification-receipt.json','pins-receipt.json','terminal.log','verify.log',manifest['ruling']+'.log']

    if args.d12_migration:names+=['d12-replay-receipt.json','d12-replay.log']
    for name in names:(output/name).write_bytes((runtime/name).read_bytes())
    (output/'run.json').write_text(json.dumps({'case':case,'status':'passed','runtime':str(runtime),'fixtureManifestSha256':hashlib.sha256((base/'fixture-manifest.json').read_bytes()).hexdigest()},indent=2)+'\n')
    print(json.dumps({'case':case,'status':'passed','receiptDirectory':str(output)}))
finally:
    if started:subprocess.run([str(pg/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop'],env=env,check=True,capture_output=True)
