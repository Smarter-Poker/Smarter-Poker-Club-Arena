--
-- PostgreSQL database dump
--

\restrict OpsXx4rMteeNabrA593S8FfcqkTYK2THv3v9vI7kGBedVxN9j5gQO0sRaQy3RB4

-- Dumped from database version 17.11 (Homebrew)
-- Dumped by pg_dump version 17.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: chip_ledger_chain_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.chip_ledger_chain_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: player_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.player_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: profiles_player_number_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.profiles_player_number_seq
    START WITH 1255
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- PostgreSQL database dump complete
--

\unrestrict OpsXx4rMteeNabrA593S8FfcqkTYK2THv3v9vI7kGBedVxN9j5gQO0sRaQy3RB4

