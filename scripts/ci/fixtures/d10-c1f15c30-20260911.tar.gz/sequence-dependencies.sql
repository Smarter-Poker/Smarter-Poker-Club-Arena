--
-- PostgreSQL database dump
--

\restrict 6PJXwQCHlbm7fpFtxfFfBd2Ox2FW6BlgGf9LK6O74i2DkH09vwFQOEvFrYmGBvz

-- Dumped from database version 17.11 (Homebrew)
-- Dumped by pg_dump version 17.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hand_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hand_id_seq
    START WITH 1000000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 100;


--
-- Name: SEQUENCE hand_id_seq; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON SEQUENCE public.hand_id_seq IS 'Global sequential hand ID. Every rake-recorded hand gets a unique integer. Display as SP-XXXXXXXXXX.';


--
-- PostgreSQL database dump complete
--

\unrestrict 6PJXwQCHlbm7fpFtxfFfBd2Ox2FW6BlgGf9LK6O74i2DkH09vwFQOEvFrYmGBvz

