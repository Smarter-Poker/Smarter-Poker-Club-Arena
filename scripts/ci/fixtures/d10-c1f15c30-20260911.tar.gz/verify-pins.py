"""Verify the installed, scoped financial composition before any test action."""
from pathlib import Path
import json, subprocess

base = Path(__file__).resolve().parent
state = json.loads((base / 'cluster.json').read_text())
assert state['cluster'].startswith('/tmp/ca-e2-owned-')
assert state['socket'] == state['cluster'] + '/socket'
psql = ['/opt/homebrew/opt/postgresql@17/bin/psql', '-X', '-v', 'ON_ERROR_STOP=1',
        '-h', state['socket'], '-p', str(state['port']), '-U', 'postgres', '-d', state['database'], '-Atc']
def query(sql):
    return json.loads(subprocess.check_output(psql + [sql], text=True))
pins = {}
for filename in ['live-closure-hashes.json','live-additional-hashes.json','live-extra-guard.json']:
    for row in json.loads((base / filename).read_text()):
        pins[row['signature']] = row['body_md5']
for signature, expected in pins.items():
    quoted = signature.replace("'", "''")
    actual = query(f"SELECT to_jsonb(md5(prosrc)) FROM pg_proc WHERE oid='{quoted}'::regprocedure")
    assert actual == expected, (signature, expected, actual)
local_triggers = query("SELECT jsonb_agg(jsonb_build_object('relation',c.relname,'tgname',t.tgname,'tgenabled',t.tgenabled,'definition',pg_get_triggerdef(t.oid),'pretty',pg_get_triggerdef(t.oid,true))) FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid WHERE NOT t.tgisinternal")
lookup = {(r['relation'],r['tgname']):r for r in local_triggers}
triggers = []
for filename in ['live-financial-triggers.json','live-support-triggers.json','live-r1-triggers.json']:
    triggers += json.loads((base / filename).read_text())
for row in triggers:
    local = lookup[(row['relation'],row['tgname'])]
    if 'function_body_md5' in row:
        signature=row['function'].replace("'","''")
        assert query(f"SELECT to_jsonb(md5(prosrc)) FROM pg_proc WHERE oid='{signature}'::regprocedure") == row['function_body_md5']
    assert local['tgenabled'] == row['tgenabled'] and row['definition'] in [local['definition'],local['pretty']], (row,local)
disabled = sorted(row['tgname'] for row in triggers if row['relation']=='tournaments' and row['tgenabled']=='D')
assert len(disabled) == 7
result = {'functionBodiesMatch':len(pins),'triggerDefinitionsAndStatesMatch':len(triggers),
          'disabledTournamentGuards':disabled,'postgres':query("SELECT to_jsonb(current_setting('server_version'))")}
assert result['postgres'].startswith('17.')
(base / 'pins-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
