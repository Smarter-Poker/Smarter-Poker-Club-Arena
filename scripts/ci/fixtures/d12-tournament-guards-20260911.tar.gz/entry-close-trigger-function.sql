CREATE OR REPLACE FUNCTION public.trg_require_satellite_economics_at_entry_close()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.tournaments t
     WHERE t.id=NEW.tournament_id
       AND (lower(COALESCE(t.variant,''))='satellite'
         OR upper(COALESCE(t.tournament_type,''))='SATELLITE'
         OR t.satellite_target_id IS NOT NULL)
  ) AND NOT EXISTS (
    SELECT 1 FROM public.tournament_satellite_economic_snapshots s
     WHERE s.tournament_id=NEW.tournament_id
  ) THEN
    RAISE EXCEPTION 'satellite entry close has no provable start-time economics'
      USING ERRCODE='check_violation';
  END IF;
  RETURN NEW;
END;
$function$
;
