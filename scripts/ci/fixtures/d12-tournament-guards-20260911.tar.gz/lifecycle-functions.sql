CREATE OR REPLACE FUNCTION public.fn_begin_tournament_launch_atomic(p_tournament_id uuid, p_launch_id uuid, p_started_at timestamp with time zone, p_lease_generation uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
 SET statement_timeout TO '30s'
AS $function$
DECLARE
  v_current_generation uuid;
  v_protocol_version integer;
  v_heartbeat_at timestamptz;
  v_receipt_generation uuid;
  v_result jsonb;
BEGIN
  PERFORM pg_advisory_xact_lock_shared(530090, 1);

  IF p_tournament_id IS NULL OR p_launch_id IS NULL OR p_lease_generation IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_launch_request');
  END IF;

  SELECT l.lease_generation, l.protocol_version, l.heartbeat_at
    INTO v_current_generation, v_protocol_version, v_heartbeat_at
    FROM public.engine_tournament_leases l
   WHERE l.tournament_id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND
     OR v_protocol_version IS DISTINCT FROM 2
     OR v_current_generation IS DISTINCT FROM p_lease_generation
     OR v_heartbeat_at < clock_timestamp() - interval '30 seconds' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'launch_lease_lost');
  END IF;

  v_result := public.fn_begin_tournament_launch_before_lease_generation(
    p_tournament_id,
    p_launch_id,
    p_started_at
  );

  IF COALESCE((v_result ->> 'ok')::boolean, false)
     AND NOT COALESCE((v_result ->> 'completed')::boolean, false) THEN
    SELECT r.lease_generation INTO STRICT v_receipt_generation
      FROM public.tournament_launch_receipts r
     WHERE r.tournament_id = p_tournament_id
     FOR UPDATE;
    IF v_receipt_generation IS DISTINCT FROM p_lease_generation THEN
      PERFORM set_config(
        'app.atomic_tournament_launch_lease_adoption',
        p_tournament_id::text || ':' || v_receipt_generation::text || ':' || p_lease_generation::text,
        true
      );
      UPDATE public.tournament_launch_receipts r
         SET lease_generation = p_lease_generation
       WHERE r.tournament_id = p_tournament_id
         AND r.completed_at IS NULL
         AND r.lease_generation = v_receipt_generation;
      IF NOT FOUND THEN
        RAISE EXCEPTION 'tournament launch receipt changed during lease adoption'
          USING ERRCODE = '40001';
      END IF;
    END IF;
  END IF;

  RETURN v_result || jsonb_build_object('lease_generation', p_lease_generation);
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_begin_tournament_launch_atomic(p_tournament_id uuid, p_launch_id uuid, p_started_at timestamp with time zone)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
 SET statement_timeout TO '30s'
AS $function$
DECLARE
  v_protocol_version integer;
BEGIN
  PERFORM pg_advisory_xact_lock_shared(530090, 1);
  SELECT l.protocol_version INTO v_protocol_version
    FROM public.engine_tournament_leases l
   WHERE l.tournament_id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND OR v_protocol_version >= 2 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'legacy_launch_protocol_closed');
  END IF;
  RETURN public.fn_begin_tournament_launch_before_lease_generation(
    p_tournament_id,
    p_launch_id,
    p_started_at
  );
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_close_tournament_addon_period(p_tournament_id uuid, p_source text DEFAULT 'engine.addon_period_end'::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_t public.tournaments%ROWTYPE;
  v_result jsonb;
BEGIN
  SELECT * INTO v_t
    FROM public.tournaments
   WHERE id=p_tournament_id
   FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','not_found'); END IF;
  IF v_t.addon_period_started_at IS NULL OR v_t.addon_period_ends_at IS NULL THEN
    RETURN jsonb_build_object('ok',false,'reason','addon_period_not_started');
  END IF;
  IF clock_timestamp()<v_t.addon_period_ends_at
     AND NOT COALESCE(v_t.prize_pool_finalized,false) THEN
    RETURN jsonb_build_object(
      'ok',false,'reason','addon_period_open','ends_at',v_t.addon_period_ends_at);
  END IF;

  v_result := public.fn_finalize_tournament_entry_pool_locked(
    p_tournament_id,p_source,'addon');
  IF COALESCE((v_result->>'ok')::boolean,false) IS NOT TRUE THEN
    RAISE EXCEPTION 'Add-on close could not fund/finalize its prize pool: %',
      COALESCE(v_result->>'reason','unknown') USING ERRCODE='55000';
  END IF;
  RETURN v_result || jsonb_build_object(
    'closed',true,'ends_at',v_t.addon_period_ends_at);
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_close_tournament_entry_window(p_tournament_id uuid, p_source text DEFAULT 'engine.entry_window_close'::text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_t public.tournaments%ROWTYPE;
  v_deadline timestamptz;
  v_retry_ms bigint;
  v_mode text;
BEGIN
  SELECT * INTO v_t
    FROM public.tournaments t
   WHERE t.id=p_tournament_id
   FOR UPDATE;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok',false,'reason','not_found'); END IF;
  IF v_t.status<>'RUNNING' THEN
    RETURN jsonb_build_object(
      'ok',false,'reason','tournament_not_running','status',v_t.status);
  END IF;

  IF COALESCE(v_t.late_reg_levels,v_t.rebuy_levels,0)>0 THEN
    v_mode := 'levels';
    IF COALESCE(v_t.current_level,0)<COALESCE(v_t.late_reg_levels,v_t.rebuy_levels,0)
       AND NOT COALESCE(v_t.prize_pool_finalized,false) THEN
      RETURN jsonb_build_object(
        'ok',true,'entry_closed',false,'window_mode',v_mode,
        'retry_after_ms',NULL);
    END IF;
  ELSIF COALESCE(v_t.late_reg_mins,0)>0 THEN
    v_mode := 'minutes';
    IF v_t.started_at IS NULL THEN
      RETURN jsonb_build_object(
        'ok',false,'reason','started_at_required_for_minutes_window',
        'window_mode',v_mode);
    END IF;
    v_deadline := v_t.started_at+make_interval(mins=>v_t.late_reg_mins);
    IF clock_timestamp()<v_deadline
       AND NOT COALESCE(v_t.prize_pool_finalized,false) THEN
      v_retry_ms := GREATEST(
        ceil(extract(epoch FROM (v_deadline-clock_timestamp()))*1000),0)::bigint;
      RETURN jsonb_build_object(
        'ok',true,'entry_closed',false,'window_mode',v_mode,
        'retry_after_ms',v_retry_ms);
    END IF;
  ELSE
    v_mode := 'immediate';
  END IF;

  -- Add-on chips can still change the final pool. Close entry now, but let the
  -- persisted add-on deadline own finalization and its receipt.
  IF COALESCE(v_t.add_on_available,false)
     AND NOT COALESCE(v_t.prize_pool_finalized,false) THEN
    RETURN jsonb_build_object(
      'ok',true,'entry_closed',true,'window_mode',v_mode,
      'finalized',false,'finalization_deferred',true,
      'reason','addon_required','retry_after_ms',NULL);
  END IF;

  RETURN public.fn_finalize_tournament_entry_pool_locked(
    p_tournament_id,p_source,v_mode);
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_complete_tournament_launch_atomic(p_tournament_id uuid, p_launch_id uuid, p_lease_generation uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
 SET statement_timeout TO '30s'
AS $function$
DECLARE
  v_current_generation uuid;
  v_protocol_version integer;
  v_heartbeat_at timestamptz;
  v_receipt_generation uuid;
  v_receipt_launch_id uuid;
  v_result jsonb;
BEGIN
  IF p_tournament_id IS NULL OR p_launch_id IS NULL OR p_lease_generation IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_launch_request');
  END IF;

  SELECT l.lease_generation, l.protocol_version, l.heartbeat_at
    INTO v_current_generation, v_protocol_version, v_heartbeat_at
    FROM public.engine_tournament_leases l
   WHERE l.tournament_id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND
     OR v_protocol_version IS DISTINCT FROM 2
     OR v_current_generation IS DISTINCT FROM p_lease_generation
     OR v_heartbeat_at < clock_timestamp() - interval '30 seconds' THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'launch_lease_lost');
  END IF;

  SELECT r.launch_id, r.lease_generation
    INTO v_receipt_launch_id, v_receipt_generation
    FROM public.tournament_launch_receipts r
   WHERE r.tournament_id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND
     OR v_receipt_launch_id IS DISTINCT FROM p_launch_id
     OR v_receipt_generation IS DISTINCT FROM p_lease_generation THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'launch_receipt_mismatch');
  END IF;

  v_result := public.fn_complete_tournament_launch_before_lease_generation(
    p_tournament_id,
    p_launch_id
  );
  RETURN v_result || jsonb_build_object('lease_generation', p_lease_generation);
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_complete_tournament_launch_atomic(p_tournament_id uuid, p_launch_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
 SET statement_timeout TO '30s'
AS $function$
DECLARE
  v_protocol_version integer;
BEGIN
  SELECT l.protocol_version INTO v_protocol_version
    FROM public.engine_tournament_leases l
   WHERE l.tournament_id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND OR v_protocol_version >= 2 THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'legacy_launch_protocol_closed');
  END IF;
  RETURN public.fn_complete_tournament_launch_before_lease_generation(
    p_tournament_id,
    p_launch_id
  );
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_settle_tournament_refund_exact(p_tournament_id uuid, p_user_id uuid, p_source_wallet_club_id uuid, p_total_owed numeric, p_refund_prize numeric, p_refund_bounty numeric, p_refund_fee numeric, p_source text, p_description text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_total numeric := round(COALESCE(p_total_owed,0),2);
  v_prize numeric := round(COALESCE(p_refund_prize,0),2);
  v_bounty numeric := round(COALESCE(p_refund_bounty,0),2);
  v_fee numeric := round(COALESCE(p_refund_fee,0),2);
  v_ob public.tournament_obligations%ROWTYPE;
  v_seeded_paid numeric := 0;
  v_pay numeric;
  v_key text;
  v_rows integer;
  v_token uuid;
  v_source_debits numeric;
  v_source_credits numeric;
  v_balance_before numeric;
  v_balance_after numeric;
  v_credit_ledger_id uuid;
  v_wallet_transaction_id uuid;
  v_prev_category text;
  v_prev_counterparty text;
  v_prev_counterparty_entity text;
  v_prev_tournament text;
  v_prev_tournament_id text;
  v_prev_idempotency text;
  v_entitlement record;
BEGIN
  IF p_tournament_id IS NULL OR p_user_id IS NULL
     OR p_source_wallet_club_id IS NULL
     OR p_total_owed IS NULL OR p_refund_prize IS NULL
     OR p_refund_bounty IS NULL OR p_refund_fee IS NULL
     OR p_total_owed::text IN ('NaN','Infinity','-Infinity')
     OR p_refund_prize::text IN ('NaN','Infinity','-Infinity')
     OR p_refund_bounty::text IN ('NaN','Infinity','-Infinity')
     OR p_refund_fee::text IN ('NaN','Infinity','-Infinity')
     OR p_total_owed IS DISTINCT FROM v_total
     OR p_refund_prize IS DISTINCT FROM v_prize
     OR p_refund_bounty IS DISTINCT FROM v_bounty
     OR p_refund_fee IS DISTINCT FROM v_fee
     OR v_total <= 0 OR v_prize < 0 OR v_bounty < 0 OR v_fee < 0
     OR p_source IS NULL OR length(btrim(p_source)) = 0
     OR p_description IS NULL OR length(btrim(p_description)) = 0 THEN
    RAISE EXCEPTION 'exact refund payer received an invalid contract'
      USING ERRCODE = '22003';
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM public.ca_settle_sources s
     WHERE s.source = lower(btrim(p_source))) THEN
    RAISE EXCEPTION 'exact refund source % is not a platform authority',p_source
      USING ERRCODE = '42501';
  END IF;

  PERFORM 1 FROM public.tournaments t
   WHERE t.id = p_tournament_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'exact refund tournament % does not exist',p_tournament_id
      USING ERRCODE = 'P0002';
  END IF;
  PERFORM public.fn_ca_escrow_apply(
    p_tournament_id,'exact refund escrow prelock');

  SELECT * INTO v_ob FROM public.tournament_obligations o
   WHERE o.tournament_id = p_tournament_id
     AND o.kind = 'refund' AND o.place IS NULL AND o.user_id = p_user_id
   FOR UPDATE;
  IF NOT FOUND THEN
    SELECT round(COALESCE(sum(w.amount),0),2) INTO v_seeded_paid
      FROM public.wallet_transactions w
     WHERE w.related_entity_id = p_tournament_id
       AND w.user_id = p_user_id AND w.type = 'credit'
       AND lower(w.category) IN ('refund','tournament_refund');
    IF v_seeded_paid > v_total THEN
      RAISE EXCEPTION 'refund ledger already exceeds exact entitlement'
        USING ERRCODE = 'P0404';
    END IF;
    INSERT INTO public.tournament_obligations(
      tournament_id,kind,place,user_id,amount_owed,amount_paid,source)
    VALUES(
      p_tournament_id,'refund',NULL,p_user_id,v_total,v_seeded_paid,p_source)
    RETURNING * INTO v_ob;
  ELSE
    IF v_ob.amount_owed::text IN ('NaN','Infinity','-Infinity')
       OR v_ob.amount_paid::text IN ('NaN','Infinity','-Infinity')
       OR v_ob.amount_owed < 0 OR v_ob.amount_paid < 0
       OR v_ob.amount_paid > v_ob.amount_owed
       OR v_total < v_ob.amount_owed THEN
      RAISE EXCEPTION 'existing refund obligation is incompatible with exact entitlement'
        USING ERRCODE = 'P0404';
    END IF;
  END IF;

  v_pay := round(v_total - v_ob.amount_paid,2);
  IF v_pay <= 0 OR v_pay IS DISTINCT FROM round(v_prize + v_bounty + v_fee,2) THEN
    RAISE EXCEPTION
      'exact refund components %, %, % do not equal newly owed amount %',
      v_prize,v_bounty,v_fee,v_pay USING ERRCODE = '23514';
  END IF;

  -- The caller cannot choose money. Resolve one deterministic, still-open
  -- immutable entitlement whose stored club and rails exactly match this
  -- tranche. Satellite entry value is ordinary funded target escrow under
  -- the approved cash rule. Its original transfer must be proved exactly;
  -- a ticket already issued for this entitlement consumes that same value.
  SELECT e.* INTO v_entitlement
    FROM public.tournament_refund_entitlements e
   WHERE e.tournament_id=p_tournament_id AND e.user_id=p_user_id
     AND e.refund_wallet_club_id = p_source_wallet_club_id
     AND e.gross = v_pay
     AND e.refund_prize = v_prize
     AND e.refund_bounty = v_bounty
     AND e.refund_fee = v_fee
     AND NOT EXISTS (
       SELECT 1 FROM public.tournament_refund_tranches tr
        WHERE tr.entitlement_id=e.id)
     AND e.entitlement_kind IN ('wallet_charge','satellite_seat','tournament_ticket')
     AND NOT EXISTS (
       SELECT 1 FROM public.tournament_tickets tk
        WHERE tk.source_refund_entitlement_id=e.id)
   ORDER BY e.entitlement_kind,e.id
   LIMIT 1;
  IF v_entitlement.id IS NULL THEN
    RAISE EXCEPTION
      'refund source club and component rails do not match one immutable entitlement'
      USING ERRCODE = 'P0404';
  END IF;
  SELECT count(*) INTO v_rows FROM public.chip_ledger l
   WHERE l.id=v_entitlement.source_ledger_id
     AND l.club_id=v_entitlement.refund_wallet_club_id
     AND l.to_type='prize_liability'
     AND l.to_entity_id=v_entitlement.tournament_id
     AND l.amount=v_entitlement.gross
     AND (
       (v_entitlement.entitlement_kind='wallet_charge'
        AND l.tournament_id=v_entitlement.tournament_id
        AND l.from_type='player_wallet'
        AND l.from_entity_id=v_entitlement.user_id
        AND lower(l.category)=v_entitlement.charge_category)
       OR (v_entitlement.entitlement_kind='satellite_seat'
        AND l.from_type='prize_liability'
        AND l.from_entity_id=v_entitlement.source_satellite_id
        AND l.metadata->>'user_id'=v_entitlement.user_id::text
        AND l.metadata->>'registration_id'=v_entitlement.registration_id::text)
       OR (v_entitlement.entitlement_kind='tournament_ticket'
        AND l.tournament_id=v_entitlement.tournament_id
        AND l.from_type='escrow'
        AND l.from_entity_id=v_entitlement.source_ticket_id
        AND l.category='ticket_redeem'
        AND l.metadata->>'user_id'=v_entitlement.user_id::text
        AND l.metadata->>'registration_id'=v_entitlement.registration_id::text
        AND EXISTS (
          SELECT 1 FROM public.tournament_tickets tk
           WHERE tk.id=v_entitlement.source_ticket_id
             AND tk.holder_id=v_entitlement.user_id AND tk.status='redeemed'
             AND tk.redemption_mode='tournament_entry_only'
             AND tk.value=v_entitlement.gross
             AND tk.entry_prize=v_entitlement.refund_prize
             AND tk.entry_bounty=v_entitlement.refund_bounty
             AND tk.entry_fee=v_entitlement.refund_fee
             AND tk.source_satellite_id=v_entitlement.source_satellite_id)));
  IF v_rows <> 1 THEN
    RAISE EXCEPTION 'refund entitlement lost its exact funded source'
      USING ERRCODE = 'P0404';
  END IF;
  v_key := 'tourney:' || p_tournament_id::text
           || ':refund-entitlement:'
           || v_entitlement.id::text;

  v_token := gen_random_uuid();
  INSERT INTO public.tournament_refund_authorizations(
    token,idempotency_key,tournament_id,obligation_id,user_id,
    source_wallet_club_id,entitlement_id,
    amount_paid_before,amount_paid_now,refund_prize,refund_bounty,refund_fee,
    source,description,created_at)
  VALUES(
    v_token,v_key,p_tournament_id,v_ob.id,p_user_id,
    p_source_wallet_club_id,v_entitlement.id,
    v_ob.amount_paid,v_pay,v_prize,v_bounty,v_fee,
    lower(btrim(p_source)),p_description,transaction_timestamp());
  -- Wallet debits and funded satellite transfers are separate sources.
  -- The immutable entitlement fixes the recipient club. Existing cash refunds
  -- reduce capacity; a value already returned as a ticket cannot fund cash.
  SELECT round(COALESCE(sum(l.amount),0),2) INTO v_source_debits
    FROM public.chip_ledger l
   WHERE l.tournament_id = p_tournament_id
     AND l.club_id = p_source_wallet_club_id
     AND l.from_type = 'player_wallet'
     AND l.from_entity_id = p_user_id
     AND l.to_type = 'prize_liability'
     AND l.to_entity_id = p_tournament_id
     AND l.category IN ('tournament_buyin','rebuy','addon');
  SELECT v_source_debits + round(COALESCE(sum(e.gross),0),2)
    INTO v_source_debits
    FROM public.tournament_refund_entitlements e
    JOIN public.chip_ledger l ON l.id=e.source_ledger_id
   WHERE e.tournament_id=p_tournament_id AND e.user_id=p_user_id
     AND e.refund_wallet_club_id=p_source_wallet_club_id
     AND e.entitlement_kind IN ('satellite_seat','tournament_ticket')
     AND l.club_id=e.refund_wallet_club_id
     AND l.to_type='prize_liability' AND l.to_entity_id=e.tournament_id
     AND l.amount=e.gross
     AND l.metadata->>'user_id'=e.user_id::text
     AND l.metadata->>'registration_id'=e.registration_id::text
     AND ((e.entitlement_kind='satellite_seat'
           AND l.from_type='prize_liability'
           AND l.from_entity_id=e.source_satellite_id)
       OR (e.entitlement_kind='tournament_ticket'
           AND l.from_type='escrow' AND l.from_entity_id=e.source_ticket_id
           AND l.category='ticket_redeem'))
     AND NOT EXISTS (
       SELECT 1 FROM public.tournament_tickets tk
        WHERE tk.source_refund_entitlement_id=e.id);
  SELECT round(COALESCE(sum(l.amount),0),2) INTO v_source_credits
    FROM public.chip_ledger l
   WHERE l.tournament_id = p_tournament_id
     AND l.club_id = p_source_wallet_club_id
     AND l.from_type = 'prize_liability'
     AND l.from_entity_id = p_tournament_id
     AND l.to_type = 'player_wallet'
     AND l.to_entity_id = p_user_id
     AND l.category IN ('refund','tournament_refund');
  IF v_source_debits IS NULL OR v_source_credits IS NULL
     OR v_source_debits::text IN ('NaN','Infinity','-Infinity')
     OR v_source_credits::text IN ('NaN','Infinity','-Infinity')
     OR v_source_debits < 0 OR v_source_credits < 0
     OR round(v_source_debits-v_source_credits,2) < v_pay THEN
    RAISE EXCEPTION
      'source club % has only % of exact tournament debit left for refund %',
      p_source_wallet_club_id,
      round(v_source_debits-v_source_credits,2),v_pay
      USING ERRCODE = 'P0404';
  END IF;

  SELECT m.chip_balance INTO v_balance_before
    FROM public.club_members m
   WHERE m.user_id = p_user_id AND m.club_id = p_source_wallet_club_id
   FOR UPDATE;
  IF NOT FOUND OR v_balance_before IS NULL
     OR v_balance_before::text IN ('NaN','Infinity','-Infinity')
     OR v_balance_before IS DISTINCT FROM round(v_balance_before,2) THEN
    RAISE EXCEPTION
      'exact source wallet % for player % is absent or invalid',
      p_source_wallet_club_id,p_user_id USING ERRCODE = 'P0404';
  END IF;

  INSERT INTO public.wallet_credit_idempotency(key,user_id,amount)
  VALUES(v_key,p_user_id,v_pay)
  ON CONFLICT(key) DO NOTHING;
  GET DIAGNOSTICS v_rows = ROW_COUNT;
  IF v_rows <> 1 THEN
    RAISE EXCEPTION 'exact refund credit key % was already claimed',v_key
      USING ERRCODE = '23505';
  END IF;

  v_prev_category := current_setting('app.ledger_category',true);
  v_prev_counterparty := current_setting('app.ledger_counterparty',true);
  v_prev_counterparty_entity := current_setting(
    'app.ledger_counterparty_entity',true);
  v_prev_tournament := current_setting('app.ledger_tournament',true);
  v_prev_tournament_id := current_setting('app.ledger_tournament_id',true);
  v_prev_idempotency := current_setting('app.ledger_idempotency_key',true);
  PERFORM public.fn_ca_declare_ledger(
    'refund','prize_liability',p_tournament_id,NULL,v_key,NULL);
  PERFORM set_config('app.ledger_tournament',p_tournament_id::text,true);
  PERFORM set_config('app.ledger_tournament_id',p_tournament_id::text,true);
  UPDATE public.club_members
     SET chip_balance = chip_balance + v_pay,updated_at = now()
   WHERE user_id = p_user_id AND club_id = p_source_wallet_club_id
     AND chip_balance IS NOT DISTINCT FROM v_balance_before
  RETURNING chip_balance INTO v_balance_after;
  PERFORM set_config('app.ledger_category',COALESCE(v_prev_category,''),true);
  PERFORM set_config('app.ledger_counterparty',COALESCE(v_prev_counterparty,''),true);
  PERFORM set_config('app.ledger_counterparty_entity',
                     COALESCE(v_prev_counterparty_entity,''),true);
  PERFORM set_config('app.ledger_tournament',COALESCE(v_prev_tournament,''),true);
  PERFORM set_config('app.ledger_tournament_id',COALESCE(v_prev_tournament_id,''),true);
  PERFORM set_config('app.ledger_idempotency_key',COALESCE(v_prev_idempotency,''),true);
  IF v_balance_after IS NULL
     OR v_balance_after IS DISTINCT FROM round(v_balance_before+v_pay,2) THEN
    RAISE EXCEPTION 'exact source wallet changed during refund'
      USING ERRCODE = '40001';
  END IF;
  SELECT count(*),min(l.id::text)::uuid INTO v_rows,v_credit_ledger_id
    FROM public.chip_ledger l
   WHERE l.idempotency_key = v_key
     AND l.tournament_id = p_tournament_id
     AND l.club_id = p_source_wallet_club_id
     AND l.from_type = 'prize_liability'
     AND l.from_entity_id = p_tournament_id
     AND l.to_type = 'player_wallet'
     AND l.to_entity_id = p_user_id
     AND l.category = 'refund' AND l.amount = v_pay;
  IF v_rows <> 1 OR v_credit_ledger_id IS NULL THEN
    RAISE EXCEPTION 'exact source-wallet credit % has no single journal row',v_key
      USING ERRCODE = 'P0404';
  END IF;

  PERFORM set_config('app.ca_exact_refund_token',v_token::text,true);
  INSERT INTO public.wallet_transactions(
    user_id,wallet_type,amount,type,category,description,
    related_entity_id,table_id,hand_id,balance_after)
  VALUES(
    p_user_id,'PLAYER',v_pay,'credit','refund',p_description,
    p_tournament_id,NULL,NULL,v_balance_after)
  RETURNING id INTO v_wallet_transaction_id;
  PERFORM set_config('app.ca_exact_refund_token','',true);
  IF EXISTS (
    SELECT 1 FROM public.tournament_refund_authorizations a
     WHERE a.token = v_token) THEN
    RAISE EXCEPTION 'exact refund authorization % was not consumed',v_token
      USING ERRCODE = 'P0404';
  END IF;

  SELECT count(*) INTO v_rows FROM public.tournament_refund_tranches tr
   WHERE tr.wallet_transaction_id = v_wallet_transaction_id
     AND tr.idempotency_key = v_key
     AND tr.tournament_id = p_tournament_id
     AND tr.obligation_id = v_ob.id AND tr.user_id = p_user_id
     AND tr.source_wallet_club_id = p_source_wallet_club_id
     AND tr.entitlement_id = v_entitlement.id
     AND tr.credit_ledger_id = v_credit_ledger_id
     AND tr.amount_paid_before = v_ob.amount_paid
     AND tr.amount_paid_now = v_pay
     AND tr.refund_prize = v_prize
     AND tr.refund_bounty = v_bounty
     AND tr.refund_fee = v_fee
     AND tr.source = lower(btrim(p_source))
     AND tr.description = p_description;
  IF v_rows <> 1 THEN
    RAISE EXCEPTION 'exact refund credit % has no single component receipt',v_key
      USING ERRCODE = 'P0404';
  END IF;

  UPDATE public.tournament_obligations
     SET amount_paid = amount_paid + v_pay,
         amount_owed = v_total,
         source = p_source,
         updated_at = now(),settled_at = now()
   WHERE id = v_ob.id AND amount_paid = v_ob.amount_paid
  RETURNING * INTO v_ob;
  IF v_ob.id IS NULL OR v_ob.amount_paid IS DISTINCT FROM v_total THEN
    RAISE EXCEPTION 'exact refund obligation did not close at %',v_total
      USING ERRCODE = '40001';
  END IF;
  RETURN jsonb_build_object(
    'ok',true,'fully_settled',true,'remaining',0,
    'obligation_id',v_ob.id,'idempotency_key',v_key,
    'entitlement_id',v_entitlement.id,
    'entitlement_kind',v_entitlement.entitlement_kind,
    'source_wallet_club_id',p_source_wallet_club_id,
    'credit_ledger_id',v_credit_ledger_id,
    'wallet_transaction_id',v_wallet_transaction_id,
    'already_paid',round(v_total-v_pay,2),'paid',v_pay,
    'amount_owed',v_total,'amount_paid',v_total,
    'refund_prize',v_prize,'refund_bounty',v_bounty,'refund_fee',v_fee);
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_begin_tournament_launch_before_lease_generation(p_tournament_id uuid, p_launch_id uuid, p_started_at timestamp with time zone)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
 SET statement_timeout TO '30s'
AS $function$
DECLARE
  v_existing public.tournament_launch_receipts%ROWTYPE;
  v_status text;
  v_tournament_started_at timestamptz;
  v_requested_started_at timestamptz := COALESCE(p_started_at, transaction_timestamp());
BEGIN
  PERFORM pg_advisory_xact_lock_shared(530090, 1);

  IF p_tournament_id IS NULL OR p_launch_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'invalid_launch_request');
  END IF;

  SELECT * INTO v_existing
    FROM public.tournament_launch_receipts r
   WHERE r.tournament_id = p_tournament_id
   FOR UPDATE;
  IF FOUND THEN
    IF p_started_at IS NOT NULL
       AND v_existing.launch_id = p_launch_id
       AND v_existing.started_at IS DISTINCT FROM p_started_at THEN
      RETURN jsonb_build_object('ok', false, 'reason', 'launch_request_mismatch');
    END IF;
    SELECT t.status, t.started_at INTO v_status, v_tournament_started_at
      FROM public.tournaments t
     WHERE t.id = p_tournament_id
     FOR UPDATE;
    IF NOT FOUND
       OR (v_existing.completed_at IS NULL AND v_status <> 'REGISTERING')
       OR (v_existing.completed_at IS NOT NULL
           AND (v_status <> 'RUNNING'
                OR v_tournament_started_at IS DISTINCT FROM v_existing.started_at)) THEN
      RETURN jsonb_build_object('ok', false, 'reason', 'launch_receipt_state_mismatch');
    END IF;
    RETURN jsonb_build_object(
      'ok', true,
      'claimed', true,
      'launch_id', v_existing.launch_id,
      'replay', true,
      'started_at', v_existing.started_at,
      'completed', v_existing.completed_at IS NOT NULL,
      'status', v_status
    );
  END IF;

  IF public.fn_entry_purchases_frozen() THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'platform_frozen');
  END IF;

  SELECT t.status, t.started_at INTO v_status, v_tournament_started_at
    FROM public.tournaments t
   WHERE t.id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'tournament_not_found');
  END IF;
  IF v_status <> 'REGISTERING' THEN
    RETURN jsonb_build_object(
      'ok', false,
      'reason', 'launch_status_changed',
      'status', v_status
    );
  END IF;
  IF v_tournament_started_at IS NOT NULL
     AND v_tournament_started_at IS DISTINCT FROM v_requested_started_at THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'launch_started_at_mismatch');
  END IF;

  INSERT INTO public.tournament_launch_receipts (
    tournament_id, launch_id, started_at
  ) VALUES (
    p_tournament_id, p_launch_id, v_requested_started_at
  );

  RETURN jsonb_build_object(
    'ok', true,
    'claimed', true,
    'launch_id', p_launch_id,
    'replay', false,
    'started_at', v_requested_started_at,
    'completed', false
  );
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_complete_tournament_launch_before_lease_generation(p_tournament_id uuid, p_launch_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_receipt public.tournament_launch_receipts%ROWTYPE;
  v_status text;
  v_started_at timestamptz;
  v_completed_at timestamptz := transaction_timestamp();
  v_required_field integer;
  v_active_count bigint;
  v_bad_roster_count bigint;
  v_live_seat_count bigint;
  v_bad_live_seat_count bigint;
  v_distinct_live_users bigint;
  v_distinct_live_coordinates bigint;
  v_matching_roster_seats bigint;
  v_bad_table_count bigint;
  v_is_paid_spin boolean;
  v_spin_multiplier numeric;
  v_spin_ledger_count bigint;
  v_spin_ledger_multiplier numeric;
BEGIN
  SELECT * INTO v_receipt
    FROM public.tournament_launch_receipts r
   WHERE r.tournament_id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND OR v_receipt.launch_id <> p_launch_id THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'launch_receipt_mismatch');
  END IF;
  IF v_receipt.completed_at IS NOT NULL THEN
    SELECT t.status, t.started_at INTO v_status, v_started_at
      FROM public.tournaments t
     WHERE t.id = p_tournament_id;
    IF NOT FOUND OR v_status <> 'RUNNING'
       OR v_started_at IS DISTINCT FROM v_receipt.started_at THEN
      RETURN jsonb_build_object('ok', false, 'reason', 'launch_receipt_state_mismatch');
    END IF;
    RETURN jsonb_build_object(
      'ok', true,
      'completed', true,
      'replay', true,
      'status', v_status,
      'started_at', v_started_at,
      'completed_at', v_receipt.completed_at
    );
  END IF;

  SELECT t.status,
         t.started_at,
         CASE WHEN COALESCE(t.max_players, 0) > 0
              THEN GREATEST(2, LEAST(3, t.max_players))
              ELSE 3 END,
         ((lower(COALESCE(t.variant, '')) = 'spin'
           OR upper(COALESCE(t.tournament_type, '')) = 'SPIN')
          AND COALESCE(t.buy_in_amount, 0) > 0),
         t.spin_multiplier
    INTO v_status, v_started_at, v_required_field,
         v_is_paid_spin, v_spin_multiplier
    FROM public.tournaments t
   WHERE t.id = p_tournament_id
   FOR UPDATE;
  IF NOT FOUND OR v_status <> 'REGISTERING'
     OR (v_started_at IS NOT NULL AND v_started_at IS DISTINCT FROM v_receipt.started_at) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'launch_receipt_state_mismatch');
  END IF;

  /* Completion is the status transaction, so it owns the final database
     proof too. Every registration/admission path locks this tournament row:
     one that committed first is visible here and makes completion refuse;
     one waiting behind us observes RUNNING and rolls back. This removes the
     proof-to-complete race that no sequence of client reads can close. */
  SELECT count(*),
         count(*) FILTER (
           WHERE p.status <> 'playing'
              OR p.user_id IS NULL
              OR COALESCE(p.chips, 0) < 0
              OR p.table_id IS NULL
              OR p.seat_number IS NULL
              OR p.seat_number <= 0
         )
    INTO v_active_count, v_bad_roster_count
    FROM public.tournament_players p
   WHERE p.tournament_id = p_tournament_id
     AND p.status IN ('registered', 'playing');

  IF (SELECT COALESCE(sum(p2.chips), 0)
         FROM public.tournament_players p2
        WHERE p2.tournament_id = p_tournament_id
          AND p2.status IN ('registered', 'playing'))
      < v_active_count * COALESCE(
          (SELECT t2.starting_chips FROM public.tournaments t2
            WHERE t2.id = p_tournament_id), 0)
     OR (SELECT COALESCE(sum(s2.stack), 0)
           FROM public.table_seats s2
           JOIN public.tables t3 ON t3.id = s2.table_id
          WHERE t3.tournament_id = p_tournament_id
            AND s2.left_at IS NULL)
        < v_active_count * COALESCE(
            (SELECT t2.starting_chips FROM public.tournaments t2
              WHERE t2.id = p_tournament_id), 0) THEN
    RETURN jsonb_build_object(
      'ok', false,
      'reason', 'launch_stacks_uncredited',
      'active_players', v_active_count
    );
  END IF;

  IF v_is_paid_spin AND v_active_count = 2
     AND COALESCE(
       (public.fn_prove_played_spin_launch_recovery(p_tournament_id)->>'ok')::boolean,
       false
     ) THEN
    v_required_field := 2;
  END IF;

  IF v_active_count < v_required_field OR v_bad_roster_count <> 0 THEN
    RETURN jsonb_build_object(
      'ok', false,
      'reason', 'launch_roster_unproven',
      'active_players', v_active_count,
      'required_players', v_required_field,
      'invalid_players', v_bad_roster_count
    );
  END IF;

  SELECT count(*),
         count(*) FILTER (
           WHERE s.user_id IS NULL
              OR COALESCE(s.stack, 0) < 0
              OR s.seat_number IS NULL
              OR s.seat_number <= 0
              OR s.seat_number > COALESCE(t.max_players, 0)
         ),
         count(DISTINCT s.user_id),
         count(DISTINCT (s.table_id, s.seat_number))
    INTO v_live_seat_count, v_bad_live_seat_count,
         v_distinct_live_users, v_distinct_live_coordinates
    FROM public.table_seats s
    JOIN public.tables t ON t.id = s.table_id
   WHERE t.tournament_id = p_tournament_id
     AND s.left_at IS NULL;

  SELECT count(*) INTO v_matching_roster_seats
    FROM public.tournament_players p
    JOIN public.table_seats s
      ON s.user_id = p.user_id
     AND s.table_id = p.table_id
     AND s.seat_number = p.seat_number
     AND s.left_at IS NULL
    JOIN public.tables t
      ON t.id = s.table_id
     AND t.tournament_id = p_tournament_id
   WHERE p.tournament_id = p_tournament_id
     AND p.status IN ('registered', 'playing');

  IF v_live_seat_count <> v_active_count
     OR v_bad_live_seat_count <> 0
     OR v_distinct_live_users <> v_active_count
     OR v_distinct_live_coordinates <> v_active_count
     OR v_matching_roster_seats <> v_active_count THEN
    RETURN jsonb_build_object(
      'ok', false,
      'reason', 'launch_seats_unproven',
      'active_players', v_active_count,
      'live_seats', v_live_seat_count,
      'matching_seats', v_matching_roster_seats
    );
  END IF;

  SELECT count(*) INTO v_bad_table_count
    FROM public.tables t
    LEFT JOIN (
      SELECT s.table_id, count(*) AS live_count
        FROM public.table_seats s
       WHERE s.left_at IS NULL
       GROUP BY s.table_id
    ) seats ON seats.table_id = t.id
   WHERE t.tournament_id = p_tournament_id
     AND (seats.table_id IS NULL
          OR t.status NOT IN ('running', 'waiting')
          OR t.current_players IS DISTINCT FROM seats.live_count);

  IF v_bad_table_count <> 0 THEN
    RETURN jsonb_build_object(
      'ok', false,
      'reason', 'launch_tables_unproven',
      'invalid_tables', v_bad_table_count
    );
  END IF;

  IF v_is_paid_spin THEN
    SELECT count(*), min(l.multiplier)
      INTO v_spin_ledger_count, v_spin_ledger_multiplier
      FROM public.spin_reserve_ledger l
     WHERE l.tournament_id = p_tournament_id
       AND l.kind = 'jackpot_draw';
    IF v_spin_ledger_count <> 1
       OR COALESCE(v_spin_multiplier, 0) <= 0
       OR v_spin_ledger_multiplier IS DISTINCT FROM v_spin_multiplier THEN
      RETURN jsonb_build_object(
        'ok', false,
        'reason', 'launch_spin_settlement_unproven',
        'draw_rows', v_spin_ledger_count
      );
    END IF;
  END IF;

  PERFORM set_config(
    'app.atomic_tournament_launch',
    p_tournament_id::text || ':' || p_launch_id::text,
    true
  );
  UPDATE public.tournaments
     SET status = 'RUNNING',
         started_at = v_receipt.started_at
   WHERE id = p_tournament_id
     AND status = 'REGISTERING';
  IF NOT FOUND THEN
    RAISE EXCEPTION 'tournament launch status changed inside its completion transaction'
      USING ERRCODE = '40001';
  END IF;

  UPDATE public.tournament_launch_receipts
     SET completed_at = v_completed_at
   WHERE tournament_id = p_tournament_id
     AND launch_id = p_launch_id
     AND completed_at IS NULL;
  RETURN jsonb_build_object(
    'ok', true,
    'completed', true,
    'replay', false,
    'status', 'RUNNING',
    'started_at', v_receipt.started_at,
    'completed_at', v_completed_at
  );
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_finalize_tournament_entry_pool_locked(p_tournament_id uuid, p_source text, p_close_mode text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_t public.tournaments%ROWTYPE;
  v_receipt public.tournament_entry_close_receipts%ROWTYPE;
  v_result jsonb;
  v_field integer;
  v_structure jsonb;
  v_wake_id bigint;
  v_pool numeric;
  v_is_satellite boolean;
BEGIN
  IF p_close_mode NOT IN ('levels','minutes','immediate','addon') THEN
    RAISE EXCEPTION 'Invalid tournament entry close mode' USING ERRCODE='22023';
  END IF;
  SELECT * INTO v_t
    FROM public.tournaments t
   WHERE t.id=p_tournament_id
   FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok',false,'reason','not_found');
  END IF;
  IF v_t.status<>'RUNNING' THEN
    RETURN jsonb_build_object(
      'ok',false,'reason','tournament_not_running','status',v_t.status);
  END IF;

  SELECT * INTO v_receipt
    FROM public.tournament_entry_close_receipts r
   WHERE r.tournament_id=p_tournament_id
   FOR UPDATE;
  IF FOUND THEN
    -- A DB-first/old-engine window may have consumed the first wake without
    -- understanding this receipt. Re-emit only when no unconsumed row remains;
    -- never increment the generation a current sweep is already processing.
    IF v_receipt.reprice_completed_at IS NULL
       AND (v_receipt.manager_wake_id IS NULL OR NOT EXISTS (
         SELECT 1 FROM public.tournament_manager_wakes w
          WHERE w.id=v_receipt.manager_wake_id AND w.consumed_at IS NULL
       )) THEN
      v_wake_id := public.fn_emit_tournament_manager_wake(
        p_tournament_id,'late_registration');
      UPDATE public.tournament_entry_close_receipts
         SET manager_wake_id=v_wake_id,updated_at=clock_timestamp()
       WHERE tournament_id=p_tournament_id
       RETURNING * INTO v_receipt;
    END IF;
    RETURN jsonb_build_object(
      'ok',true,'entry_closed',true,'finalized',true,
      'already_finalized',true,'close_mode',v_receipt.close_mode,
      'prize_pool',v_receipt.final_prize_pool,
      'payout_structure',v_receipt.payout_structure_snapshot,
      'reprice_pending',v_receipt.reprice_completed_at IS NULL,
      'retry_after_ms',NULL
    );
  END IF;

  SELECT count(*)::integer INTO v_field
    FROM public.tournament_players tp
   WHERE tp.tournament_id=p_tournament_id;
  IF v_field<1 THEN
    RAISE EXCEPTION 'Entry cannot close without a readable final field'
      USING ERRCODE='55000';
  END IF;

  v_is_satellite := lower(COALESCE(v_t.variant,''))='satellite'
                 OR upper(COALESCE(v_t.tournament_type,''))='SATELLITE'
                 OR v_t.satellite_target_id IS NOT NULL;

  -- Spins own the wheel-derived structure. Every other format uses the
  -- database's canonical payout-percent generator for the final field. This
  -- includes satellites: their finish path awards seats rather than cash, but
  -- hand-for-hand and display readers still require the stored field ladder.
  IF lower(COALESCE(v_t.variant,''))<>'spin'
     AND upper(COALESCE(v_t.tournament_type,''))<>'SPIN' THEN
    v_structure := public.fn_ca_payout_structure(
      v_field,COALESCE(v_t.payout_percent,10));
    IF jsonb_array_length(v_structure)=0 THEN
      RAISE EXCEPTION 'Final payout structure is unreadable' USING ERRCODE='55000';
    END IF;
    UPDATE public.tournaments
       SET payout_structure=v_structure::text
     WHERE id=p_tournament_id;
  ELSE
    v_structure := public.fn_safe_jsonb_array(v_t.payout_structure::text);
    IF jsonb_array_length(v_structure)=0 THEN
      RAISE EXCEPTION 'Spin payout structure is unreadable' USING ERRCODE='55000';
    END IF;
  END IF;

  IF COALESCE(v_t.prize_pool_finalized,false) THEN
    v_result := jsonb_build_object(
      'ok',true,'already_finalized',true,'prize_pool',COALESCE(v_t.prize_pool,0));
  ELSE
    v_result := public.fn_apply_prize_guarantee(
      p_tournament_id,COALESCE(NULLIF(btrim(p_source),''),'engine.entry_window_close'));
  END IF;
  IF COALESCE((v_result->>'ok')::boolean,false) IS NOT TRUE
     OR v_result->>'prize_pool' IS NULL THEN
    RAISE EXCEPTION 'Entry close could not fund/finalize its prize pool: %',
      COALESCE(v_result->>'reason','unreadable result') USING ERRCODE='55000';
  END IF;
  v_pool := (v_result->>'prize_pool')::numeric;

  SELECT * INTO v_t FROM public.tournaments WHERE id=p_tournament_id;
  IF COALESCE(v_t.prize_pool_finalized,false) IS NOT TRUE
     OR round(COALESCE(v_t.prize_pool,0),2)<>round(v_pool,2) THEN
    RAISE EXCEPTION 'Entry close returned without an exact funded pool marker'
      USING ERRCODE='55000';
  END IF;

  -- Satellites keep the canonical field ladder for readers, but never cash-
  -- reprice eliminated finishers from it. Their immutable seat-or-cash plus
  -- remainder entitlements are materialized by the atomic satellite contract
  -- from this final funded pool; marking generic reprice complete prevents a
  -- manager from paying the display ladder as cash first.
  INSERT INTO public.tournament_entry_close_receipts(
    tournament_id,close_mode,entry_closed_at,final_prize_pool,
    payout_structure_snapshot,reprice_completed_at
  ) VALUES (
    p_tournament_id,p_close_mode,clock_timestamp(),v_pool,
    v_structure,CASE WHEN v_is_satellite THEN clock_timestamp() ELSE NULL END
  )
  RETURNING * INTO v_receipt;
  v_wake_id := public.fn_emit_tournament_manager_wake(
    p_tournament_id,'late_registration');
  UPDATE public.tournament_entry_close_receipts
     SET manager_wake_id=v_wake_id,updated_at=clock_timestamp()
   WHERE tournament_id=p_tournament_id;

  RETURN v_result || jsonb_build_object(
    'ok',true,'entry_closed',true,'finalized',true,
    'close_mode',p_close_mode,'payout_structure',v_structure,
    'reprice_pending',NOT v_is_satellite,'retry_after_ms',NULL
  );
END;
$function$
;

CREATE OR REPLACE FUNCTION public.atomic_cancel_tournament(p_tournament_id uuid, p_admin_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'extensions', 'pg_temp'
 SET statement_timeout TO '120s'
AS $function$
DECLARE
  v_uid uuid := auth.uid();
  v_actor uuid := COALESCE(
    auth.uid(),p_admin_id,'2d1cd6c3-5700-4af9-a271-d4863fdab20d'::uuid);
  v_t public.tournaments%ROWTYPE;
  v_stored public.tournament_cancellation_receipts%ROWTYPE;
  v_e public.tournament_escrow%ROWTYPE;
  v_player record;
  v_entitlement public.tournament_refund_entitlements%ROWTYPE;
  v_fee record;
  v_contribution public.spin_reserve_ledger%ROWTYPE;
  v_draw public.spin_reserve_ledger%ROWTYPE;
  v_pool public.spin_bonus_pools%ROWTYPE;
  v_settle jsonb;
  v_receipt jsonb;
  v_refunds jsonb := '[]'::jsonb;
  v_ticket_returns jsonb := '[]'::jsonb;
  v_source_player_ids uuid[] := ARRAY[]::uuid[];
  v_refunded_registration_ids uuid[] := ARRAY[]::uuid[];
  v_ticket_return_ids uuid[] := ARRAY[]::uuid[];
  v_zero_refund_registration_ids uuid[] := ARRAY[]::uuid[];
  v_closed_table_ids uuid[] := ARRAY[]::uuid[];
  v_source_seat_ids uuid[] := ARRAY[]::uuid[];
  v_released_seat_ids uuid[] := ARRAY[]::uuid[];
  v_fee_reversal_ids uuid[] := ARRAY[]::uuid[];
  v_registration_id uuid;
  v_fee_reversal_id uuid;
  v_original_entry_journal_id uuid;
  v_original_draw_journal_id uuid;
  v_draw_reversal_id uuid;
  v_draw_reversal_journal_id uuid;
  v_contribution_reversal_id uuid;
  v_contribution_reversal_journal_id uuid;
  v_spin_unwind_id uuid;
  v_source_player_count integer := 0;
  v_refunded_count integer := 0;
  v_refund_line_count integer := 0;
  v_ticket_return_count integer := 0;
  v_zero_refund_count integer := 0;
  v_closed_table_count integer := 0;
  v_source_seat_count integer := 0;
  v_released_seat_count integer := 0;
  v_total_refunded numeric := 0;
  v_total_ticket_returned numeric := 0;
  v_fees_reversed numeric := 0;
  v_total_rake_before numeric := 0;
  v_total_rake_after numeric := 0;
  v_total_owed numeric;
  v_draw_amount numeric := 0;
  v_pool_balance_before numeric;
  v_pool_balance_after numeric;
  v_rows integer;
  v_journal_count integer;
  v_cancelled_at timestamptz := transaction_timestamp();
  v_close_note constant text := 'atomic cancellation receipt: exact zero';
BEGIN
  -- Every terminal authority takes this lock before any row lock. Cancellation,
  -- satellite finish and cash finish can touch the same wallets and event rows.
  PERFORM public.fn_ca_lock_settlement_lane_global();
  IF p_tournament_id IS NULL THEN
    RAISE EXCEPTION 'Tournament id is required' USING ERRCODE = '22004';
  END IF;

  SELECT * INTO v_t FROM public.tournaments t
   WHERE t.id=p_tournament_id FOR UPDATE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Tournament not found' USING ERRCODE = 'P0002';
  END IF;
  IF v_uid IS NOT NULL
     AND NOT public.fn_can_create_games(v_t.club_id,v_uid) THEN
    RAISE EXCEPTION 'Only the governed game operator may cancel a tournament'
      USING ERRCODE = '42501';
  END IF;

  SELECT * INTO v_stored FROM public.tournament_cancellation_receipts h
   WHERE h.tournament_id=p_tournament_id FOR UPDATE;
  IF FOUND THEN
    RETURN public.fn_ca_tournament_cancellation_receipt(p_tournament_id,NULL);
  END IF;
  IF upper(COALESCE(v_t.status::text,'')) IN
       ('COMPLETED','CANCELLED','CANCELED','COMPLETING') THEN
    RAISE EXCEPTION 'Tournament is already %',v_t.status USING ERRCODE='55000';
  END IF;

  -- A tournament that has started is resumed or settled, never voided.
  -- start_time is a schedule/fill deadline; it is not proof that play began.
  -- The stored receipt above remains replayable without another cancellation.
  IF v_t.started_at IS NOT NULL
     OR upper(COALESCE(v_t.status::text,'')) IN ('RUNNING','BREAK')
     OR COALESCE(v_t.spin_multiplier,0)>0
     OR EXISTS (SELECT 1 FROM public.tournament_launch_receipts r
                 WHERE r.tournament_id=p_tournament_id AND r.completed_at IS NOT NULL)
     OR EXISTS (SELECT 1 FROM public.spin_draw_receipts r
                 WHERE r.tournament_id=p_tournament_id)
     OR EXISTS (SELECT 1 FROM public.spin_reserve_ledger r
                 WHERE r.tournament_id=p_tournament_id AND r.kind='jackpot_draw')
     OR EXISTS (SELECT 1 FROM public.hand_history hh
                 WHERE hh.tournament_id=p_tournament_id)
     OR EXISTS (SELECT 1 FROM public.tables tb
                 JOIN public.hand_history hh ON hh.table_id=tb.id
                 WHERE tb.tournament_id=p_tournament_id)
     OR EXISTS (SELECT 1 FROM public.tournament_obligations o
                 WHERE o.tournament_id=p_tournament_id
                   AND o.kind<>'refund' AND o.amount_paid>0) THEN
    RAISE EXCEPTION
      'Tournament has started or committed awards; resume or settle it instead of cancelling'
      USING ERRCODE='55000';
  END IF;

  -- Freeze every identity before any payer runs. Any concurrent registration,
  -- seat move or hand settlement either committed before these locks and is in
  -- the receipt, or waits behind this transaction and sees a terminal parent.
  PERFORM 1 FROM public.tournament_players tp
   WHERE tp.tournament_id=p_tournament_id
   ORDER BY tp.user_id,tp.id FOR UPDATE;
  PERFORM 1 FROM public.tables tb
   WHERE tb.tournament_id=p_tournament_id ORDER BY tb.id FOR UPDATE;
  PERFORM 1 FROM public.table_seats s
   JOIN public.tables tb ON tb.id=s.table_id
   WHERE tb.tournament_id=p_tournament_id
   ORDER BY s.table_id,s.id FOR UPDATE OF s;
  SELECT COALESCE(array_agg(tp.id ORDER BY tp.id),ARRAY[]::uuid[])
    INTO v_source_player_ids FROM public.tournament_players tp
   WHERE tp.tournament_id=p_tournament_id;
  SELECT COALESCE(array_agg(tb.id ORDER BY tb.id),ARRAY[]::uuid[])
    INTO v_closed_table_ids FROM public.tables tb
   WHERE tb.tournament_id=p_tournament_id;
  SELECT COALESCE(array_agg(s.id ORDER BY s.table_id,s.id),ARRAY[]::uuid[])
    INTO v_source_seat_ids FROM public.table_seats s
    JOIN public.tables tb ON tb.id=s.table_id
   WHERE tb.tournament_id=p_tournament_id;
  v_source_player_count := cardinality(v_source_player_ids);
  v_closed_table_count := cardinality(v_closed_table_ids);
  v_source_seat_count := cardinality(v_source_seat_ids);

  PERFORM public.fn_ca_escrow_apply(
    p_tournament_id,'atomic cancellation escrow prelock');
  SELECT * INTO v_e FROM public.tournament_escrow e
   WHERE e.tournament_id=p_tournament_id FOR UPDATE;
  IF v_e.tournament_id IS NULL OR v_e.enforced IS DISTINCT FROM true
     OR v_t.prize_pool IS DISTINCT FROM v_e.prize_balance
     OR v_t.bounty_pool IS DISTINCT FROM v_e.bounty_balance
     OR v_t.total_rake IS DISTINCT FROM v_e.fee_balance THEN
    RAISE EXCEPTION 'tournament % caches do not equal exact escrow before cancellation',
      p_tournament_id USING ERRCODE='P0404';
  END IF;

  -- A booked Spin first gives back its draw, then withdraws this event's own
  -- contribution. Each pool movement creates its strict journal before the
  -- matching immutable reversal row and all four ids are stored together.
  PERFORM 1 FROM public.spin_reserve_ledger r
   WHERE r.tournament_id=p_tournament_id ORDER BY r.created_at,r.id FOR UPDATE;
  SELECT * INTO v_contribution FROM public.spin_reserve_ledger r
   WHERE r.tournament_id=p_tournament_id AND r.kind='contribution';
  IF FOUND THEN
    IF (SELECT count(*) FROM public.spin_reserve_ledger r
         WHERE r.tournament_id=p_tournament_id AND r.kind='contribution') <> 1
       OR EXISTS (SELECT 1 FROM public.spin_reserve_ledger r
                   WHERE r.tournament_id=p_tournament_id
                     AND r.kind IN ('draw_reversal','contribution_reversal'))
       OR EXISTS (SELECT 1 FROM public.tournament_spin_cancellation_unwinds u
                   WHERE u.tournament_id=p_tournament_id) THEN
      RAISE EXCEPTION 'Spin % has an ambiguous or partially unwound reserve contract',
        p_tournament_id USING ERRCODE='P0404';
    END IF;
    SELECT * INTO v_draw FROM public.spin_reserve_ledger r
     WHERE r.tournament_id=p_tournament_id AND r.kind='jackpot_draw';
    IF FOUND AND (SELECT count(*) FROM public.spin_reserve_ledger r
                   WHERE r.tournament_id=p_tournament_id
                     AND r.kind='jackpot_draw') <> 1 THEN
      RAISE EXCEPTION 'Spin % has more than one immutable draw',p_tournament_id
        USING ERRCODE='P0404';
    END IF;
    SELECT * INTO v_pool FROM public.spin_bonus_pools p
     WHERE p.club_id=v_contribution.club_id FOR UPDATE;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Spin % original reserve owner is missing',p_tournament_id
        USING ERRCODE='P0404';
    END IF;
    v_pool_balance_before := v_pool.balance;
    IF v_pool_balance_before IS NULL
       OR v_pool_balance_before::text IN ('NaN','Infinity','-Infinity')
       OR v_pool_balance_before<0 THEN
      RAISE EXCEPTION 'Spin % reserve balance is invalid',p_tournament_id
        USING ERRCODE='22003';
    END IF;
    SELECT count(*),(array_agg(l.id ORDER BY l.created_at,l.id))[1]
      INTO v_journal_count,v_original_entry_journal_id
      FROM public.chip_ledger l
     WHERE l.tournament_id=p_tournament_id
       AND l.category='spin_entry'
       AND l.from_type='prize_liability'
       AND l.from_entity_id=p_tournament_id
       AND l.to_type='spin_reserve' AND l.to_entity_id=v_pool.id
       AND l.amount=v_contribution.amount;
    IF v_journal_count<>1 OR v_contribution.amount<=0 THEN
      RAISE EXCEPTION 'Spin % contribution has no single exact journal',p_tournament_id
        USING ERRCODE='P0404';
    END IF;

    IF v_draw.id IS NOT NULL THEN
      IF v_draw.club_id IS DISTINCT FROM v_contribution.club_id
         OR v_draw.amount>=0 THEN
        RAISE EXCEPTION 'Spin % draw disagrees with its contribution owner',p_tournament_id
          USING ERRCODE='P0404';
      END IF;
      v_draw_amount := round(-v_draw.amount,2);
      SELECT count(*),(array_agg(l.id ORDER BY l.created_at,l.id))[1]
        INTO v_journal_count,v_original_draw_journal_id
        FROM public.chip_ledger l
       WHERE l.tournament_id=p_tournament_id
         AND l.category='spin_prize'
         AND l.from_type='spin_reserve' AND l.from_entity_id=v_pool.id
         AND l.to_type='prize_liability' AND l.to_entity_id=p_tournament_id
         AND l.amount=v_draw_amount;
      IF v_journal_count<>1 THEN
        RAISE EXCEPTION 'Spin % draw has no single exact journal',p_tournament_id
          USING ERRCODE='P0404';
      END IF;
      PERFORM public.fn_ca_declare_ledger(
        'reversal','prize_liability',p_tournament_id,NULL,
        'spin:'||p_tournament_id::text||':cancel:draw',NULL);
      UPDATE public.spin_bonus_pools
         SET balance=balance+v_draw_amount,updated_at=now()
       WHERE id=v_pool.id RETURNING balance INTO v_pool_balance_after;
      IF NOT FOUND THEN
        RAISE EXCEPTION 'Spin % reserve vanished during draw reversal',p_tournament_id
          USING ERRCODE='40001';
      END IF;
      INSERT INTO public.spin_reserve_ledger
        (club_id,tournament_id,kind,amount,balance_after,multiplier,
         buy_in,seats,house_rake,note)
      VALUES
        (v_draw.club_id,p_tournament_id,'draw_reversal',v_draw_amount,
         v_pool_balance_after,v_draw.multiplier,v_draw.buy_in,v_draw.seats,
         v_draw.house_rake,'atomic cancellation reversed the exact reserve draw')
      RETURNING id INTO v_draw_reversal_id;
      SELECT count(*),(array_agg(l.id ORDER BY l.created_at,l.id))[1]
        INTO v_journal_count,v_draw_reversal_journal_id
        FROM public.chip_ledger l
       WHERE l.idempotency_key='spin:'||p_tournament_id::text||':cancel:draw'
         AND l.tournament_id=p_tournament_id AND l.category='reversal'
         AND l.from_type='prize_liability' AND l.from_entity_id=p_tournament_id
         AND l.to_type='spin_reserve' AND l.to_entity_id=v_pool.id
         AND l.amount=v_draw_amount;
      IF v_journal_count<>1 THEN
        RAISE EXCEPTION 'Spin % draw reversal has no single exact journal',p_tournament_id
          USING ERRCODE='P0404';
      END IF;
    ELSE
      v_pool_balance_after := v_pool_balance_before;
    END IF;

    IF v_pool_balance_after<v_contribution.amount THEN
      RAISE EXCEPTION 'Spin % reserve cannot return its own contribution',p_tournament_id
        USING ERRCODE='P0403';
    END IF;
    PERFORM public.fn_ca_declare_ledger(
      'reversal','prize_liability',p_tournament_id,NULL,
      'spin:'||p_tournament_id::text||':cancel:entry',NULL);
    UPDATE public.spin_bonus_pools
       SET balance=balance-v_contribution.amount,updated_at=now()
     WHERE id=v_pool.id RETURNING balance INTO v_pool_balance_after;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Spin % reserve vanished during contribution reversal',p_tournament_id
        USING ERRCODE='40001';
    END IF;
    INSERT INTO public.spin_reserve_ledger
      (club_id,tournament_id,kind,amount,balance_after,multiplier,
       buy_in,seats,house_rake,note)
    VALUES
      (v_contribution.club_id,p_tournament_id,'contribution_reversal',
       -v_contribution.amount,v_pool_balance_after,v_contribution.multiplier,
       v_contribution.buy_in,v_contribution.seats,v_contribution.house_rake,
       'atomic cancellation returned the exact entry contribution')
    RETURNING id INTO v_contribution_reversal_id;
    SELECT count(*),(array_agg(l.id ORDER BY l.created_at,l.id))[1]
      INTO v_journal_count,v_contribution_reversal_journal_id
      FROM public.chip_ledger l
     WHERE l.idempotency_key='spin:'||p_tournament_id::text||':cancel:entry'
       AND l.tournament_id=p_tournament_id AND l.category='reversal'
       AND l.from_type='spin_reserve' AND l.from_entity_id=v_pool.id
       AND l.to_type='prize_liability' AND l.to_entity_id=p_tournament_id
       AND l.amount=v_contribution.amount;
    IF v_journal_count<>1 THEN
      RAISE EXCEPTION 'Spin % contribution reversal has no single exact journal',
        p_tournament_id USING ERRCODE='P0404';
    END IF;
    INSERT INTO public.tournament_spin_cancellation_unwinds(
      tournament_id,pool_id,reserve_owner_id,
      original_contribution_id,original_draw_id,
      original_entry_journal_id,original_draw_journal_id,
      draw_reversal_id,draw_reversal_journal_id,
      contribution_reversal_id,contribution_reversal_journal_id,
      contribution_amount,draw_amount,pool_balance_before,pool_balance_after,
      settled_at)
    VALUES(
      p_tournament_id,v_pool.id,v_contribution.club_id,
      v_contribution.id,v_draw.id,
      v_original_entry_journal_id,v_original_draw_journal_id,
      v_draw_reversal_id,v_draw_reversal_journal_id,
      v_contribution_reversal_id,v_contribution_reversal_journal_id,
      v_contribution.amount,v_draw_amount,v_pool_balance_before,
      v_pool_balance_after,v_cancelled_at)
    RETURNING tournament_id INTO v_spin_unwind_id;
  ELSIF EXISTS (
    SELECT 1 FROM public.spin_reserve_ledger r
     WHERE r.tournament_id=p_tournament_id
       AND r.kind IN ('jackpot_draw','draw_reversal','contribution_reversal')) THEN
    RAISE EXCEPTION 'Spin % has reserve evidence without its contribution',p_tournament_id
      USING ERRCODE='P0404';
  END IF;

  -- Return each unconsumed funded entitlement as cash to its recorded club.
  -- The exact refund payer proves wallet, satellite transfer or redeemed-ticket
  -- funding and excludes value already returned as a ticket. Stored historical
  -- cancellation receipts continue to replay through their original evidence.
  IF EXISTS (
    SELECT 1 FROM public.tournament_refund_entitlements e
    JOIN public.tournament_players tp ON tp.id=e.registration_id
    JOIN public.tournament_tickets tk
      ON tk.source_refund_entitlement_id=e.id
   WHERE e.tournament_id=p_tournament_id
     AND tp.tournament_id=p_tournament_id) THEN
    RAISE EXCEPTION 'active qualifier roster already has an unreceipted return ticket'
      USING ERRCODE='P0404';
  END IF;
  IF EXISTS (
    SELECT 1 FROM public.tournament_refund_entitlements e
    LEFT JOIN public.tournament_players tp
      ON tp.tournament_id=e.tournament_id AND tp.user_id=e.user_id
   WHERE e.tournament_id=p_tournament_id
     AND (tp.id IS NULL OR (e.entitlement_kind IN (
            'satellite_seat','tournament_ticket')
          AND e.registration_id IS DISTINCT FROM tp.id))) THEN
    RAISE EXCEPTION 'refund entitlement is detached from the frozen roster'
      USING ERRCODE='P0404';
  END IF;
  FOR v_player IN
    SELECT DISTINCT ON (tp.user_id) tp.id,tp.user_id
      FROM public.tournament_players tp
     WHERE tp.tournament_id=p_tournament_id AND tp.user_id IS NOT NULL
     ORDER BY tp.user_id,tp.id
  LOOP
    -- The owner-only plan validates every source ledger, wallet debit and
    -- escrow rail. Identity comes from the locked entitlement table below.
    PERFORM 1 FROM public.fn_ca_tournament_refund_plan(
      p_tournament_id,v_player.user_id);
    LOOP
      SELECT e.* INTO v_entitlement
        FROM public.tournament_refund_entitlements e
       WHERE e.tournament_id=p_tournament_id
         AND e.user_id=v_player.user_id
         AND NOT EXISTS (
           SELECT 1 FROM public.tournament_refund_tranches tr
            WHERE tr.entitlement_id=e.id)
         AND NOT EXISTS (
           SELECT 1 FROM public.tournament_tickets tk
            WHERE tk.source_refund_entitlement_id=e.id)
       ORDER BY e.entitlement_kind,e.id
       LIMIT 1 FOR UPDATE OF e;
      EXIT WHEN NOT FOUND;
      v_registration_id:=COALESCE(v_entitlement.registration_id,v_player.id);
      IF v_entitlement.entitlement_kind IN (
          'wallet_charge','satellite_seat','tournament_ticket') THEN
        SELECT COALESCE(o.amount_paid,0)+v_entitlement.gross
          INTO v_total_owed FROM public.tournament_obligations o
         WHERE o.tournament_id=p_tournament_id AND o.kind='refund'
           AND o.place IS NULL AND o.user_id=v_player.user_id FOR UPDATE;
        IF NOT FOUND THEN v_total_owed:=v_entitlement.gross; END IF;
        v_settle:=public.fn_settle_tournament_refund_exact(
          p_tournament_id,v_player.user_id,
          v_entitlement.refund_wallet_club_id,v_total_owed,
          v_entitlement.refund_prize,v_entitlement.refund_bounty,
          v_entitlement.refund_fee,'atomic_cancel_tournament',
          'Tournament cancellation refund: '||COALESCE(v_t.name,'Unknown'));
        IF COALESCE((v_settle->>'ok')::boolean,false) IS NOT TRUE
           OR COALESCE((v_settle->>'fully_settled')::boolean,false) IS NOT TRUE
           OR COALESCE((v_settle->>'remaining')::numeric,-1)<>0
           OR (v_settle->>'entitlement_id')::uuid
                IS DISTINCT FROM v_entitlement.id
           OR v_settle->>'entitlement_kind' IS DISTINCT FROM v_entitlement.entitlement_kind
           OR (v_settle->>'paid')::numeric IS DISTINCT FROM v_entitlement.gross
           OR (v_settle->>'refund_prize')::numeric
                IS DISTINCT FROM v_entitlement.refund_prize
           OR (v_settle->>'refund_bounty')::numeric
                IS DISTINCT FROM v_entitlement.refund_bounty
           OR (v_settle->>'refund_fee')::numeric
                IS DISTINCT FROM v_entitlement.refund_fee THEN
          RAISE EXCEPTION 'exact cancellation refund refused entitlement %: %',
            v_entitlement.id,v_settle USING ERRCODE='55000';
        END IF;
        v_refunds:=v_refunds||jsonb_build_array(jsonb_build_object(
          'registration_id',v_registration_id,
          'user_id',v_player.user_id,
          'entitlement_id',v_entitlement.id,
          'entitlement_kind',v_entitlement.entitlement_kind,
          'source_wallet_club_id',v_entitlement.refund_wallet_club_id,
          'gross_paid',v_entitlement.gross,
          'amount_paid_before',(v_settle->>'already_paid')::numeric,
          'amount_paid_now',(v_settle->>'paid')::numeric,
          'refund_prize',(v_settle->>'refund_prize')::numeric,
          'refund_bounty',(v_settle->>'refund_bounty')::numeric,
          'refund_fee',(v_settle->>'refund_fee')::numeric,
          'obligation_id',(v_settle->>'obligation_id')::uuid,
          'idempotency_key',v_settle->>'idempotency_key',
          'credit_ledger_id',(v_settle->>'credit_ledger_id')::uuid,
          'wallet_transaction_id',(v_settle->>'wallet_transaction_id')::uuid));
        v_refund_line_count:=v_refund_line_count+1;
        v_total_refunded:=round(
          v_total_refunded+(v_settle->>'paid')::numeric,2);
      ELSE
        RAISE EXCEPTION 'unknown cancellation entitlement kind %',
          v_entitlement.entitlement_kind USING ERRCODE='P0404';
      END IF;
      IF NOT v_registration_id=ANY(v_refunded_registration_ids) THEN
        v_refunded_registration_ids:=array_append(
          v_refunded_registration_ids,v_registration_id);
      END IF;
    END LOOP;
  END LOOP;
  SELECT COALESCE(array_agg(id ORDER BY id),ARRAY[]::uuid[])
    INTO v_refunded_registration_ids
    FROM unnest(v_refunded_registration_ids) ids(id);
  SELECT COALESCE(array_agg(id ORDER BY id),ARRAY[]::uuid[])
    INTO v_zero_refund_registration_ids
    FROM unnest(v_source_player_ids) ids(id)
   WHERE NOT id=ANY(v_refunded_registration_ids);
  v_refunded_count:=cardinality(v_refunded_registration_ids);
  v_zero_refund_count:=cardinality(v_zero_refund_registration_ids);

  IF EXISTS (
    SELECT 1 FROM public.tournament_players tp
     WHERE tp.tournament_id=p_tournament_id AND tp.user_id IS NOT NULL
       AND EXISTS (SELECT 1 FROM public.fn_ca_tournament_refund_plan(
                    p_tournament_id,tp.user_id))) THEN
    RAISE EXCEPTION 'cancellation left a refundable entitlement unpaid'
      USING ERRCODE='55000';
  END IF;

  -- Rake reversal is attribution only: the exact refund payer already returned
  -- the fee component from escrow. Reverse each current player's net fee and
  -- each aggregate Spin source exactly once, retaining immutable source ids.
  IF EXISTS (SELECT 1 FROM public.rake_records r
              WHERE r.tournament_id=p_tournament_id
                AND r.source='atomic_cancel_tournament') THEN
    RAISE EXCEPTION 'unreceipted cancellation rake evidence already exists'
      USING ERRCODE='P0404';
  END IF;
  SELECT round(COALESCE(sum(r.rake_amount),0),2)
    INTO v_total_rake_before FROM public.rake_records r
   WHERE r.tournament_id=p_tournament_id AND r.is_tournament;
  IF v_total_rake_before<0
     OR v_total_rake_before::text IN ('NaN','Infinity','-Infinity')
     OR round(COALESCE(v_t.total_rake,0),2) IS DISTINCT FROM v_total_rake_before THEN
    RAISE EXCEPTION 'tournament % rake cache and evidence disagree',p_tournament_id
      USING ERRCODE='P0404';
  END IF;

  FOR v_fee IN
    SELECT tp.user_id,r.club_id,
           round(sum(r.rake_amount),2) AS amount,
           jsonb_agg(r.id ORDER BY r.id) AS source_ids
      FROM (SELECT DISTINCT p.user_id FROM public.tournament_players p
             WHERE p.tournament_id=p_tournament_id AND p.user_id IS NOT NULL) tp
      JOIN public.rake_records r
        ON r.tournament_id=p_tournament_id AND r.is_tournament
       AND r.metadata->>'user_id'=tp.user_id::text
     GROUP BY tp.user_id,r.club_id HAVING round(sum(r.rake_amount),2)>0
     ORDER BY tp.user_id,r.club_id
  LOOP
    INSERT INTO public.rake_records(
      hand_id,table_id,club_id,rake_amount,pot_size,num_players,
      bbj_contribution,is_tournament,tournament_id,source,metadata)
    VALUES(NULL,NULL,v_fee.club_id,-v_fee.amount,v_fee.amount,1,0,true,
      p_tournament_id,'atomic_cancel_tournament',jsonb_build_object(
        'kind','tournament_fee_refund','user_id',v_fee.user_id,
        'original_rake_record_ids',v_fee.source_ids))
    RETURNING id INTO v_fee_reversal_id;
    v_fee_reversal_ids:=array_append(v_fee_reversal_ids,v_fee_reversal_id);
    v_fees_reversed:=round(v_fees_reversed+v_fee.amount,2);
  END LOOP;
  FOR v_fee IN
    SELECT r.*,round(r.rake_amount+COALESCE((SELECT sum(rr.rake_amount)
      FROM public.rake_records rr WHERE rr.tournament_id=p_tournament_id
       AND rr.source='atomic_cancel_tournament'
       AND rr.metadata->>'original_rake_record_id'=r.id::text),0),2) AS amount
      FROM public.rake_records r
     WHERE r.tournament_id=p_tournament_id AND r.is_tournament
       AND r.source IN ('fn_spin_book_entry','fn_spin_settle_game')
       AND r.rake_amount>0 AND NULLIF(r.metadata->>'user_id','') IS NULL
     ORDER BY r.id FOR UPDATE
  LOOP
    IF v_fee.amount>0 THEN
      INSERT INTO public.rake_records(
        hand_id,table_id,club_id,rake_amount,pot_size,num_players,
        bbj_contribution,is_tournament,tournament_id,source,
        player_contributions,metadata)
      VALUES(NULL,NULL,v_fee.club_id,-v_fee.amount,v_fee.pot_size,
        v_fee.num_players,0,true,p_tournament_id,'atomic_cancel_tournament',
        v_fee.player_contributions,jsonb_build_object(
          'kind','spin_rake_refund','original_source',v_fee.source,
          'original_rake_record_id',v_fee.id))
      RETURNING id INTO v_fee_reversal_id;
      v_fee_reversal_ids:=array_append(v_fee_reversal_ids,v_fee_reversal_id);
      v_fees_reversed:=round(v_fees_reversed+v_fee.amount,2);
    END IF;
  END LOOP;
  SELECT round(COALESCE(sum(r.rake_amount),0),2)
    INTO v_total_rake_after FROM public.rake_records r
   WHERE r.tournament_id=p_tournament_id AND r.is_tournament;
  IF v_total_rake_after IS DISTINCT FROM 0::numeric
     OR v_fees_reversed IS DISTINCT FROM v_total_rake_before THEN
    RAISE EXCEPTION 'tournament % fee reversal did not close exactly',p_tournament_id
      USING ERRCODE='P0404';
  END IF;

  SELECT * INTO v_e FROM public.tournament_escrow e
   WHERE e.tournament_id=p_tournament_id FOR UPDATE;
  IF v_e.tournament_id IS NULL OR v_e.enforced IS DISTINCT FROM true
     OR v_e.prize_balance IS DISTINCT FROM 0::numeric
     OR v_e.bounty_balance IS DISTINCT FROM 0::numeric
     OR v_e.fee_balance IS DISTINCT FROM 0::numeric THEN
    RAISE EXCEPTION 'tournament % cancellation did not close all escrow banks',
      p_tournament_id USING ERRCODE='P0404';
  END IF;
  UPDATE public.tournament_escrow
     SET closed_at=v_cancelled_at,close_note=v_close_note,updated_at=now()
   WHERE tournament_id=p_tournament_id AND closed_at IS NULL
     AND prize_balance=0 AND bounty_balance=0 AND fee_balance=0;
  GET DIAGNOSTICS v_rows=ROW_COUNT;
  IF v_rows<>1 THEN
    RAISE EXCEPTION 'tournament % lost its exact-zero escrow close',p_tournament_id
      USING ERRCODE='40001';
  END IF;

  UPDATE public.tournament_players
     SET status='eliminated',eliminated_at=v_cancelled_at,
         chips=0,current_bounty=0
   WHERE tournament_id=p_tournament_id;
  WITH released AS (
    UPDATE public.table_seats s
       SET left_at=v_cancelled_at,status='left',leave_pending=false,
           is_sitting_out=false,is_away=false,sit_out_at=NULL,
           scheduled_leave_hands=NULL
      FROM public.tables tb
     WHERE tb.id=s.table_id AND tb.tournament_id=p_tournament_id
       AND s.left_at IS NULL RETURNING s.id)
  SELECT COALESCE(array_agg(id ORDER BY id),ARRAY[]::uuid[])
    INTO v_released_seat_ids FROM released;
  v_released_seat_count:=cardinality(v_released_seat_ids);
  UPDATE public.table_seats s
     SET status='left',leave_pending=false,is_sitting_out=false,is_away=false,
         sit_out_at=NULL,scheduled_leave_hands=NULL
   WHERE s.id=ANY(v_source_seat_ids) AND s.left_at IS NOT NULL;

  UPDATE public.tournaments
     SET status='CANCELLED',ended_at=v_cancelled_at,updated_at=now(),
         prize_pool=0,bounty_pool=0,total_rake=0,current_players=0,
         on_break=false,break_started_at=NULL,break_ends_at=NULL
   WHERE id=p_tournament_id
     AND upper(COALESCE(status::text,'')) NOT IN
         ('COMPLETED','CANCELLED','CANCELED','COMPLETING');
  GET DIAGNOSTICS v_rows=ROW_COUNT;
  IF v_rows<>1 THEN
    RAISE EXCEPTION 'tournament % lost its cancellation lifecycle claim',
      p_tournament_id USING ERRCODE='40001';
  END IF;
  UPDATE public.tables
     SET status='closed',lifecycle='closed',current_players=0,
         terminal_closed_at=v_cancelled_at,updated_at=now()
   WHERE tournament_id=p_tournament_id;
  GET DIAGNOSTICS v_rows=ROW_COUNT;
  IF v_rows<>v_closed_table_count THEN
    RAISE EXCEPTION 'tournament % did not close every table',p_tournament_id
      USING ERRCODE='40001';
  END IF;

  SELECT COALESCE(array_agg(id ORDER BY id),ARRAY[]::uuid[])
    INTO v_fee_reversal_ids FROM unnest(v_fee_reversal_ids) ids(id);
  SELECT COALESCE(array_agg(id ORDER BY id),ARRAY[]::uuid[])
    INTO v_ticket_return_ids FROM unnest(v_ticket_return_ids) ids(id);
  v_receipt:=jsonb_build_object(
    'ok',true,'success',true,'fully_settled',true,'receipt_version',2,
    'tournament_id',p_tournament_id,'actor_id',v_actor,'status','CANCELLED',
    'source_player_count',v_source_player_count,
    'refunded_count',v_refunded_count,'refund_line_count',v_refund_line_count,
    'ticket_return_count',v_ticket_return_count,
    'total_ticket_returned',v_total_ticket_returned,
    'total_refunded',v_total_refunded,'fees_reversed',v_fees_reversed,
    'closed_table_count',v_closed_table_count,
    'source_seat_count',v_source_seat_count,
    'released_seat_count',v_released_seat_count,
    'refunds',v_refunds,'ticket_returns',v_ticket_returns,
    'settled_at',v_cancelled_at);
  INSERT INTO public.tournament_cancellation_receipts(
    tournament_id,actor_id,receipt_version,
    source_player_count,source_player_ids,
    refunded_count,refunded_registration_ids,refund_line_count,
    ticket_return_count,ticket_return_ids,total_ticket_returned,
    zero_refund_count,zero_refund_registration_ids,
    total_refunded,fees_reversed,total_rake_before,total_rake_after,
    closed_table_count,closed_table_ids,source_seat_count,source_seat_ids,
    released_seat_count,released_seat_ids,fee_reversal_ids,
    escrow_closed_at,escrow_close_note,spin_unwind_tournament_id,
    receipt,settled_at)
  VALUES(
    p_tournament_id,v_actor,2,
    v_source_player_count,v_source_player_ids,
    v_refunded_count,v_refunded_registration_ids,v_refund_line_count,
    v_ticket_return_count,v_ticket_return_ids,v_total_ticket_returned,
    v_zero_refund_count,v_zero_refund_registration_ids,
    v_total_refunded,v_fees_reversed,v_total_rake_before,v_total_rake_after,
    v_closed_table_count,v_closed_table_ids,v_source_seat_count,v_source_seat_ids,
    v_released_seat_count,v_released_seat_ids,v_fee_reversal_ids,
    v_cancelled_at,v_close_note,v_spin_unwind_id,v_receipt,v_cancelled_at);

  RETURN public.fn_ca_tournament_cancellation_receipt(p_tournament_id,v_actor);
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_prove_played_spin_launch_recovery(p_tournament_id uuid)
 RETURNS jsonb
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
 SET row_security TO 'off'
 SET statement_timeout TO '10s'
AS $function$
WITH contract AS (
  SELECT t.id,
         t.status::text AS status,
         lower(COALESCE(t.variant, '')) AS variant,
         upper(COALESCE(t.tournament_type, '')) AS tournament_type,
         t.max_players,
         t.buy_in_amount AS buy_in,
         t.starting_chips,
         round(t.buy_in_amount * 3 * public.fn_spin_rake_rate(t.buy_in_amount), 2)
           AS expected_house_rake,
         round(t.buy_in_amount * 3
               * (1 - public.fn_spin_rake_rate(t.buy_in_amount)), 2)
           AS expected_reserve_in
    FROM public.tournaments t
   WHERE t.id = p_tournament_id
), roster AS (
  SELECT count(*) AS roster_count,
         count(DISTINCT tp.user_id) AS roster_users,
         count(*) FILTER (WHERE tp.status = 'playing') AS active_players,
         count(*) FILTER (WHERE tp.status = 'playing' AND tp.chips > 0)
           AS positive_active_players,
         count(*) FILTER (WHERE tp.status = 'eliminated') AS eliminated_players,
         count(*) FILTER (WHERE tp.status NOT IN ('playing', 'eliminated')) AS other_players,
         count(*) FILTER (WHERE tp.chips IS NULL OR tp.chips < 0) AS invalid_stacks,
         count(*) FILTER (WHERE tp.status = 'eliminated' AND tp.chips = 0)
           AS zero_stack_eliminations,
         COALESCE(sum(tp.chips), 0) AS roster_chips,
         COALESCE(
           array_agg(tp.user_id ORDER BY tp.user_id)
             FILTER (WHERE tp.user_id IS NOT NULL),
           ARRAY[]::uuid[]
         ) AS original_player_ids,
         COALESCE(
           array_agg(tp.user_id ORDER BY tp.user_id)
             FILTER (WHERE tp.status = 'playing'),
           ARRAY[]::uuid[]
         ) AS active_player_ids
    FROM public.tournament_players tp
   WHERE tp.tournament_id = p_tournament_id
), entitlements AS (
  SELECT count(e.id) AS entitlement_count,
         count(DISTINCT e.user_id) AS entitlement_users,
         count(DISTINCT e.user_id) FILTER (
           WHERE EXISTS (
             SELECT 1
               FROM public.tournament_players tp
              WHERE tp.tournament_id = p_tournament_id
                AND tp.user_id = e.user_id
           )
         ) AS roster_entitlement_users,
         min(e.gross) AS min_gross,
         max(e.gross) AS max_gross,
         round(COALESCE(sum(e.gross), 0), 2) AS gross_total
    FROM public.tournament_refund_entitlements e
   WHERE e.tournament_id = p_tournament_id
     AND e.entitlement_kind = 'wallet_charge'
     AND e.charge_category = 'tournament_buyin'
), payments AS (
  SELECT count(w.id) AS payment_count,
         count(DISTINCT w.user_id) AS paid_users,
         count(DISTINCT w.user_id) FILTER (
           WHERE EXISTS (
             SELECT 1
               FROM public.tournament_players tp
              WHERE tp.tournament_id = p_tournament_id
                AND tp.user_id = w.user_id
           )
         ) AS roster_paid_users,
         min(w.amount) AS min_amount,
         max(w.amount) AS max_amount,
         round(COALESCE(sum(w.amount), 0), 2) AS payment_total
    FROM public.wallet_transactions w
   WHERE w.related_entity_id = p_tournament_id
     AND w.type = 'debit'
     AND w.category = 'tournament_buyin'
), charge_evidence AS (
  SELECT count(l.id) AS source_charge_count,
         count(l.id) FILTER (
           WHERE l.tournament_id = e.tournament_id
             AND l.club_id = e.refund_wallet_club_id
             AND l.from_type = 'player_wallet'
             AND l.from_entity_id = e.user_id
             AND l.to_type = 'prize_liability'
             AND l.to_entity_id = e.tournament_id
             AND l.category = e.charge_category
             AND l.amount = e.gross
         ) AS exact_source_charges
    FROM public.tournament_refund_entitlements e
    LEFT JOIN public.chip_ledger l ON l.id = e.source_ledger_id
   WHERE e.tournament_id = p_tournament_id
     AND e.entitlement_kind = 'wallet_charge'
     AND e.charge_category = 'tournament_buyin'
), reserve_evidence AS (
  SELECT count(sr.id) FILTER (WHERE sr.kind = 'contribution') AS contribution_count,
         count(sr.id) FILTER (WHERE sr.kind = 'jackpot_draw') AS draw_count,
         (array_agg(sr.id ORDER BY sr.created_at, sr.id)
           FILTER (WHERE sr.kind = 'contribution'))[1] AS contribution_id,
         (array_agg(sr.id ORDER BY sr.created_at, sr.id)
           FILTER (WHERE sr.kind = 'jackpot_draw'))[1] AS draw_id,
         (array_agg(sr.club_id ORDER BY sr.created_at, sr.id)
           FILTER (WHERE sr.kind = 'contribution'))[1] AS contribution_owner,
         (array_agg(sr.club_id ORDER BY sr.created_at, sr.id)
           FILTER (WHERE sr.kind = 'jackpot_draw'))[1] AS draw_owner,
         min(sr.amount) FILTER (WHERE sr.kind = 'contribution') AS contribution_amount,
         min(sr.buy_in) FILTER (WHERE sr.kind = 'contribution') AS contribution_buy_in,
         min(sr.seats) FILTER (WHERE sr.kind = 'contribution') AS contribution_seats,
         min(sr.house_rake) FILTER (WHERE sr.kind = 'contribution') AS contribution_rake,
         min(sr.balance_after) FILTER (WHERE sr.kind = 'contribution')
           AS contribution_balance,
         min(sr.amount) FILTER (WHERE sr.kind = 'jackpot_draw') AS draw_amount,
         min(sr.buy_in) FILTER (WHERE sr.kind = 'jackpot_draw') AS draw_buy_in,
         min(sr.seats) FILTER (WHERE sr.kind = 'jackpot_draw') AS draw_seats,
         min(sr.multiplier) FILTER (WHERE sr.kind = 'jackpot_draw') AS draw_multiplier,
         min(sr.balance_after) FILTER (WHERE sr.kind = 'jackpot_draw') AS draw_balance,
         min(sr.created_at) FILTER (WHERE sr.kind = 'jackpot_draw') AS draw_created_at
    FROM public.spin_reserve_ledger sr
   WHERE sr.tournament_id = p_tournament_id
     AND sr.kind IN ('contribution', 'jackpot_draw')
), reserve_pool AS (
  SELECT count(p.id) AS pool_count,
         (array_agg(p.id ORDER BY p.id))[1] AS pool_id
    FROM public.spin_bonus_pools p
    CROSS JOIN reserve_evidence r
   WHERE p.club_id = r.draw_owner
), journals AS (
  SELECT count(l.id) FILTER (WHERE l.category = 'spin_entry') AS entry_journal_count,
         count(l.id) FILTER (WHERE l.category = 'spin_prize') AS draw_journal_count,
         count(l.id) FILTER (
           WHERE l.category = 'spin_entry'
             AND l.from_type = 'prize_liability'
             AND l.from_entity_id = p_tournament_id
             AND l.to_type = 'spin_reserve'
             AND l.to_entity_id = p.pool_id
             AND l.amount = c.expected_reserve_in
             AND l.post_to_balance IS NOT DISTINCT FROM r.contribution_balance
         ) AS exact_entry_journals,
         count(l.id) FILTER (
           WHERE l.category = 'spin_prize'
             AND l.from_type = 'spin_reserve'
             AND l.from_entity_id = p.pool_id
             AND l.to_type = 'prize_liability'
             AND l.to_entity_id = p_tournament_id
             AND l.amount = round(-r.draw_amount, 2)
             AND l.post_from_balance IS NOT DISTINCT FROM r.draw_balance
         ) AS exact_draw_journals
    FROM contract c
    CROSS JOIN reserve_evidence r
    CROSS JOIN reserve_pool p
    LEFT JOIN public.chip_ledger l
      ON l.tournament_id = p_tournament_id
     AND l.category IN ('spin_entry', 'spin_prize')
   GROUP BY c.expected_reserve_in, r.contribution_balance, r.draw_amount,
            r.draw_balance, p.pool_id
), table_evidence AS (
  SELECT count(t.id) AS table_count,
         count(t.id) FILTER (WHERE t.status IN ('running', 'waiting')) AS open_tables,
         (array_agg(t.id ORDER BY t.created_at, t.id)
           FILTER (WHERE t.status IN ('running', 'waiting')))[1] AS table_id,
         min(t.current_players) FILTER (WHERE t.status IN ('running', 'waiting'))
           AS current_players,
         min(t.max_players) FILTER (WHERE t.status IN ('running', 'waiting'))
           AS table_capacity
    FROM public.tables t
   WHERE t.tournament_id = p_tournament_id
), live_seats AS (
  SELECT count(s.id) AS live_seats,
         count(DISTINCT s.user_id) AS live_users,
         count(DISTINCT (s.table_id, s.seat_number)) AS live_coordinates,
         count(DISTINCT s.table_id) AS live_tables,
         count(s.id) FILTER (
           WHERE s.stack IS NULL
              OR s.stack::text IN ('NaN', 'Infinity', '-Infinity')
              OR s.stack < 0
         ) AS invalid_live_stacks,
         count(s.id) FILTER (WHERE s.stack > 0) AS positive_live_seats,
         count(s.id) FILTER (
           WHERE EXISTS (
             SELECT 1
               FROM public.tournament_players tp
              WHERE tp.tournament_id = p_tournament_id
                AND tp.user_id = s.user_id
                AND tp.status = 'playing'
                AND tp.table_id = s.table_id
                AND tp.seat_number = s.seat_number
                AND tp.chips IS NOT DISTINCT FROM s.stack
           )
         ) AS matching_active_seats,
         COALESCE(sum(s.stack), 0) AS seat_chips
    FROM public.table_seats s
    JOIN public.tables t ON t.id = s.table_id
   WHERE t.tournament_id = p_tournament_id
     AND s.left_at IS NULL
), vacated_seat AS (
  SELECT count(DISTINCT tp.user_id) AS vacated_eliminated_players
    FROM public.tournament_players tp
   WHERE tp.tournament_id = p_tournament_id
     AND tp.status = 'eliminated'
     AND EXISTS (
       SELECT 1
         FROM public.table_seats s
         JOIN public.tables t ON t.id = s.table_id
        WHERE t.tournament_id = p_tournament_id
          AND s.user_id = tp.user_id
          AND s.left_at IS NOT NULL
     )
), hands AS (
  SELECT count(h.id) FILTER (WHERE h.created_at >= r.draw_created_at) AS hand_count
    FROM reserve_evidence r
    LEFT JOIN public.hand_history h
      ON h.tournament_id = p_tournament_id
    LEFT JOIN public.tables t
      ON t.id = h.table_id
     AND t.tournament_id = p_tournament_id
   WHERE h.id IS NULL OR t.id IS NOT NULL
), escrow AS (
  SELECT count(e.tournament_id) AS escrow_count,
         min(e.reserve_out) AS reserve_out,
         min(e.reserve_in) AS escrow_reserve_in,
         min(e.prize_balance) AS prize_balance
    FROM public.tournament_escrow e
   WHERE e.tournament_id = p_tournament_id
), facts AS (
  SELECT c.*,
         r.*,
         e.*,
         pay.*,
         charge.*,
         re.*,
         pool.*,
         j.*,
         te.*,
         ls.*,
         vs.*,
         h.*,
         esc.*,
         (c.starting_chips * 3)::numeric AS funding_floor
    FROM (SELECT 1) seed
    LEFT JOIN contract c ON true
    CROSS JOIN roster r
    CROSS JOIN entitlements e
    CROSS JOIN payments pay
    CROSS JOIN charge_evidence charge
    CROSS JOIN reserve_evidence re
    CROSS JOIN reserve_pool pool
    CROSS JOIN journals j
    CROSS JOIN table_evidence te
    CROSS JOIN live_seats ls
    CROSS JOIN vacated_seat vs
    CROSS JOIN hands h
    CROSS JOIN escrow esc
), verdict AS (
  SELECT f.*,
         (f.id IS NOT NULL
          AND f.status = 'REGISTERING'
          AND (f.variant = 'spin' OR f.tournament_type = 'SPIN')
          AND f.variant <> 'sng'
          AND f.tournament_type <> 'SNG'
          AND f.max_players = 3
          AND f.buy_in IS NOT NULL
          AND f.buy_in::text NOT IN ('NaN', 'Infinity', '-Infinity')
          AND f.buy_in > 0
          AND f.starting_chips IS NOT NULL
          AND f.starting_chips > 0
          AND f.roster_count = 3
          AND f.roster_users = 3
          AND f.active_players = 2
          AND f.positive_active_players = 2
          AND f.eliminated_players = 1
          AND f.other_players = 0
          AND f.invalid_stacks = 0
          AND f.zero_stack_eliminations = 1
          AND f.roster_chips = f.funding_floor
          AND f.entitlement_count = 3
          AND f.entitlement_users = 3
          AND f.roster_entitlement_users = 3
          AND f.min_gross = f.buy_in
          AND f.max_gross = f.buy_in
          AND f.gross_total = round(f.buy_in * 3, 2)
          AND f.payment_count = 3
          AND f.paid_users = 3
          AND f.roster_paid_users = 3
          AND f.min_amount = f.buy_in
          AND f.max_amount = f.buy_in
          AND f.payment_total = round(f.buy_in * 3, 2)
          AND f.source_charge_count = 3
          AND f.exact_source_charges = 3
          AND f.contribution_count = 1
          AND f.draw_count = 1
          AND f.contribution_owner IS NOT NULL
          AND f.contribution_owner = f.draw_owner
          AND f.contribution_amount = f.expected_reserve_in
          AND f.contribution_buy_in = f.buy_in
          AND f.contribution_seats = 3
          AND f.contribution_rake = f.expected_house_rake
          AND f.draw_amount IS NOT NULL
          AND round(-f.draw_amount, 2) = round(f.buy_in * f.draw_multiplier, 2)
          AND f.draw_buy_in = f.buy_in
          AND f.draw_seats = 3
          AND f.draw_multiplier > 0
          AND f.pool_count = 1
          AND f.entry_journal_count = 1
          AND f.draw_journal_count = 1
          AND f.exact_entry_journals = 1
          AND f.exact_draw_journals = 1
          AND f.escrow_count = 1
          AND f.reserve_out = f.expected_reserve_in
          AND f.escrow_reserve_in = round(-f.draw_amount, 2)
          AND f.prize_balance = round(-f.draw_amount, 2)
          AND f.table_count = 1
          AND f.open_tables = 1
          AND f.current_players = 2
          AND f.table_capacity = 3
          AND f.live_seats = 2
          AND f.live_users = 2
          AND f.live_coordinates = 2
          AND f.live_tables = 1
          AND f.invalid_live_stacks = 0
          AND f.positive_live_seats = 2
          AND f.matching_active_seats = 2
          AND f.seat_chips = f.funding_floor
          AND f.seat_chips = f.roster_chips
          AND f.vacated_eliminated_players = 1
          AND f.hand_count >= 1) AS ok
    FROM facts f
)
SELECT CASE WHEN v.ok THEN
  jsonb_build_object(
    'ok', true,
    'recovery_mode', 'played_vacated_spin',
    'tournament_id', p_tournament_id,
    'original_field', 3,
    'active_field', 2,
    'eliminated_players', v.eliminated_players,
    'paid_users', v.paid_users,
    'entitlement_users', v.entitlement_users,
    'live_seats', v.live_seats,
    'hand_count', v.hand_count,
    'funding_floor', v.funding_floor,
    'roster_chips', v.roster_chips,
    'seat_chips', v.seat_chips,
    'original_player_ids', to_jsonb(v.original_player_ids),
    'active_player_ids', to_jsonb(v.active_player_ids)
  )
ELSE
  jsonb_build_object(
    'ok', false,
    'reason', 'played_spin_launch_recovery_unproven',
    'tournament_id', p_tournament_id
  )
END
  FROM verdict v;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_ca_tournament_refund_plan(p_tournament_id uuid, p_user_id uuid)
 RETURNS TABLE(source_wallet_club_id uuid, gross_remaining numeric, prize_remaining numeric, bounty_remaining numeric, fee_remaining numeric, debit_count bigint)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
DECLARE
  v_escrow public.tournament_escrow%ROWTYPE;
  v_wallet_count bigint;
  v_wallet_total numeric;
  v_charge_count bigint;
  v_charge_total numeric;
  v_refund_count bigint;
  v_refund_total numeric;
  v_tranche_count bigint;
  v_tranche_total numeric;
  v_wallet_gross numeric;
  v_direct_fee numeric;
  v_satellite_fee numeric;
  v_bounty numeric;
  v_satellite_in numeric;
  v_invalid bigint;
BEGIN
  IF p_tournament_id IS NULL OR p_user_id IS NULL THEN
    RAISE EXCEPTION 'refund plan requires tournament and player ids'
      USING ERRCODE = '22004';
  END IF;
  PERFORM 1 FROM public.tournaments t
   WHERE t.id=p_tournament_id FOR SHARE;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'refund plan tournament % does not exist',p_tournament_id
      USING ERRCODE = 'P0002';
  END IF;
  PERFORM 1 FROM public.tournament_refund_entitlements e
   WHERE e.tournament_id=p_tournament_id
   ORDER BY e.user_id,e.entitlement_kind,e.id FOR SHARE;
  PERFORM 1 FROM public.tournament_refund_tranches tr
   WHERE tr.tournament_id=p_tournament_id
   ORDER BY tr.user_id,tr.entitlement_id FOR SHARE;

  SELECT count(*),round(COALESCE(sum(w.amount),0),2)
    INTO v_wallet_count,v_wallet_total
    FROM public.wallet_transactions w
   WHERE w.related_entity_id=p_tournament_id AND w.type='debit'
     AND lower(w.category) IN ('tournament_buyin','rebuy','addon');
  SELECT count(*),round(COALESCE(sum(e.gross),0),2)
    INTO v_charge_count,v_charge_total
    FROM public.tournament_refund_entitlements e
   WHERE e.tournament_id=p_tournament_id
     AND e.entitlement_kind='wallet_charge';
  IF v_wallet_count IS DISTINCT FROM v_charge_count
     OR v_wallet_total IS DISTINCT FROM v_charge_total THEN
    RAISE EXCEPTION
      'tournament % wallet charges and immutable entitlements disagree',
      p_tournament_id USING ERRCODE = 'P0404';
  END IF;

  SELECT count(*) INTO v_invalid
    FROM public.tournament_refund_entitlements e
    LEFT JOIN public.chip_ledger l ON l.id=e.source_ledger_id
   WHERE e.tournament_id=p_tournament_id
     AND (
       l.id IS NULL OR l.club_id IS DISTINCT FROM e.refund_wallet_club_id
       OR l.amount IS DISTINCT FROM e.gross
       OR (e.entitlement_kind='wallet_charge' AND (
         l.tournament_id IS DISTINCT FROM e.tournament_id
         OR l.from_type IS DISTINCT FROM 'player_wallet'
         OR l.from_entity_id IS DISTINCT FROM e.user_id
         OR l.to_type IS DISTINCT FROM 'prize_liability'
         OR l.to_entity_id IS DISTINCT FROM e.tournament_id
         OR lower(l.category) IS DISTINCT FROM e.charge_category))
       OR (e.entitlement_kind='satellite_seat' AND (
         l.from_type IS DISTINCT FROM 'prize_liability'
         OR l.from_entity_id IS DISTINCT FROM e.source_satellite_id
         OR l.to_type IS DISTINCT FROM 'prize_liability'
         OR l.to_entity_id IS DISTINCT FROM e.tournament_id
         OR l.metadata->>'user_id' IS DISTINCT FROM e.user_id::text
         OR l.metadata->>'registration_id' IS DISTINCT FROM
              e.registration_id::text))
       OR (e.entitlement_kind='tournament_ticket' AND (
         l.tournament_id IS DISTINCT FROM e.tournament_id
         OR l.from_type IS DISTINCT FROM 'escrow'
         OR l.from_entity_id IS DISTINCT FROM e.source_ticket_id
         OR l.to_type IS DISTINCT FROM 'prize_liability'
         OR l.to_entity_id IS DISTINCT FROM e.tournament_id
         OR l.category IS DISTINCT FROM 'ticket_redeem'
         OR l.metadata->>'user_id' IS DISTINCT FROM e.user_id::text
         OR l.metadata->>'registration_id' IS DISTINCT FROM
              e.registration_id::text))
     );
  IF v_invalid <> 0 THEN
    RAISE EXCEPTION 'tournament % has % invalid refund entitlement sources',
      p_tournament_id,v_invalid USING ERRCODE = 'P0404';
  END IF;

  SELECT round(COALESCE(sum(CASE
           WHEN e.escrow_bucket IN ('wallet_gross','ticket_gross')
             THEN e.gross
           WHEN e.escrow_bucket='satellite_gross'
             THEN e.refund_prize+e.refund_bounty ELSE 0 END),0),2),
         round(COALESCE(sum(CASE
           WHEN e.entitlement_kind IN ('wallet_charge','tournament_ticket')
             THEN e.refund_fee
           ELSE 0 END),0),2),
         round(COALESCE(sum(CASE
           WHEN e.entitlement_kind='satellite_seat' THEN e.refund_fee
           ELSE 0 END),0),2),
         round(COALESCE(sum(CASE
           WHEN e.escrow_bucket IN (
             'wallet_gross','satellite_gross','ticket_gross')
             THEN e.refund_bounty ELSE 0 END),0),2),
         round(COALESCE(sum(CASE
           WHEN e.escrow_bucket='satellite_in'
             THEN e.refund_prize+e.refund_bounty ELSE 0 END),0),2)
    INTO v_wallet_gross,v_direct_fee,v_satellite_fee,v_bounty,v_satellite_in
    FROM public.tournament_refund_entitlements e
   WHERE e.tournament_id=p_tournament_id;
  SELECT * INTO v_escrow FROM public.tournament_escrow e
   WHERE e.tournament_id=p_tournament_id FOR SHARE;
  IF v_escrow.tournament_id IS NULL
     OR v_escrow.enforced IS DISTINCT FROM true
     OR v_escrow.gross_in IS DISTINCT FROM v_wallet_gross
     OR v_escrow.fee_entries_in IS DISTINCT FROM v_direct_fee
     OR v_escrow.satellite_fee_in IS DISTINCT FROM v_satellite_fee
     OR v_escrow.bounty_in IS DISTINCT FROM v_bounty
     OR v_escrow.satellite_in IS DISTINCT FROM v_satellite_in THEN
    RAISE EXCEPTION
      'tournament % escrow does not equal its immutable entitlement rails',
      p_tournament_id USING ERRCODE = 'P0404';
  END IF;

  SELECT count(*),round(COALESCE(sum(w.amount),0),2)
    INTO v_refund_count,v_refund_total
    FROM public.wallet_transactions w
   WHERE w.related_entity_id=p_tournament_id AND w.user_id=p_user_id
     AND w.type='credit'
     AND lower(w.category) IN ('refund','tournament_refund');
  SELECT count(*),round(COALESCE(sum(tr.amount_paid_now),0),2)
    INTO v_tranche_count,v_tranche_total
    FROM public.tournament_refund_tranches tr
   WHERE tr.tournament_id=p_tournament_id AND tr.user_id=p_user_id;
  IF v_refund_count IS DISTINCT FROM v_tranche_count
     OR v_refund_total IS DISTINCT FROM v_tranche_total THEN
    RAISE EXCEPTION
      'player % tournament % has refund money without exact entitlement tranches',
      p_user_id,p_tournament_id USING ERRCODE = 'P0404';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.tournament_refund_tranches tr
    JOIN public.tournament_refund_entitlements e ON e.id=tr.entitlement_id
    WHERE tr.tournament_id=p_tournament_id AND (
      e.tournament_id IS DISTINCT FROM tr.tournament_id
      OR e.user_id IS DISTINCT FROM tr.user_id
      OR e.refund_wallet_club_id IS DISTINCT FROM tr.source_wallet_club_id
      OR e.gross IS DISTINCT FROM tr.amount_paid_now
      OR e.refund_prize IS DISTINCT FROM tr.refund_prize
      OR e.refund_bounty IS DISTINCT FROM tr.refund_bounty
      OR e.refund_fee IS DISTINCT FROM tr.refund_fee)
  ) THEN
    RAISE EXCEPTION 'tournament % has a tranche detached from its entitlement',
      p_tournament_id USING ERRCODE = 'P0404';
  END IF;

  RETURN QUERY
  SELECT e.refund_wallet_club_id,e.gross,e.refund_prize,e.refund_bounty,
         e.refund_fee,1::bigint
    FROM public.tournament_refund_entitlements e
   WHERE e.tournament_id=p_tournament_id AND e.user_id=p_user_id
     AND e.entitlement_kind='wallet_charge'
     AND NOT EXISTS (
       SELECT 1 FROM public.tournament_refund_tranches tr
        WHERE tr.entitlement_id=e.id)
     AND NOT EXISTS (
       SELECT 1 FROM public.tournament_tickets tk
        WHERE tk.source_refund_entitlement_id=e.id)
   ORDER BY e.entitlement_kind,e.id;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.trg_require_satellite_economics_at_entry_close()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
BEGIN
  IF EXISTS (
    SELECT 1 FROM public.tournaments t
     WHERE t.id=NEW.tournament_id
       AND (lower(COALESCE(t.variant,''))='satellite'
         OR upper(COALESCE(t.tournament_type,''))='SATELLITE'
         OR t.satellite_target_id IS NOT NULL)
  ) AND NOT EXISTS (
    SELECT 1 FROM public.tournament_satellite_economic_snapshots s
     WHERE s.tournament_id=NEW.tournament_id
  ) THEN
    RAISE EXCEPTION 'satellite entry close has no provable start-time economics'
      USING ERRCODE='check_violation';
  END IF;
  RETURN NEW;
END;
$function$
;

CREATE OR REPLACE FUNCTION public.fn_satellite_target_is_deliverable(p_target_id uuid)
 RETURNS boolean
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public', 'pg_temp'
AS $function$
  -- Mirrors the admission refusal in fn_settle_satellite_tournament_pre_money_path_gate
  -- exactly: every flag must be a known false, and neither Spin spelling.
  -- A missing target is not deliverable either (the authority refuses it).
  SELECT COALESCE((
    SELECT t.is_bounty IS FALSE
       AND t.is_pko IS FALSE
       AND t.is_mystery_bounty IS FALSE
       AND t.is_premium_spin IS FALSE
       AND lower(COALESCE(t.variant, '')) <> 'spin'
       AND upper(COALESCE(t.tournament_type, '')) <> 'SPIN'
      FROM public.tournaments t
     WHERE t.id = p_target_id
  ), false)
$function$
;
