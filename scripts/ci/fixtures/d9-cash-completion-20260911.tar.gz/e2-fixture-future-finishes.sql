-- LOCAL FIXTURE ONLY. These eleven future hand outcomes are hypothetical.
-- Existing 155 eliminated entrants, their witnesses and all money rows remain
-- the captured event. No status is toggled to restamp its elimination order.
CREATE SCHEMA e2;
CREATE TABLE e2.before_players AS SELECT * FROM public.tournament_players;
CREATE TABLE e2.before_members AS SELECT * FROM public.club_members;
CREATE TABLE e2.before_ledger AS SELECT * FROM public.chip_ledger;
CREATE TABLE e2.before_wallet_transactions AS SELECT * FROM public.wallet_transactions;
CREATE TABLE e2.before_payouts AS SELECT * FROM public.tournament_payouts;
CREATE TABLE e2.before_escrow AS SELECT * FROM public.tournament_escrow;
CREATE TABLE e2.future_finishes AS
SELECT p.user_id,p.chips, s.id AS seat_id,s.joined_at,s.table_id,
       row_number() OVER (ORDER BY p.chips,p.user_id)::integer AS ordinal,
       (13-row_number() OVER (ORDER BY p.chips,p.user_id))::integer AS final_place
FROM public.tournament_players p JOIN public.table_seats s
  ON s.user_id=p.user_id AND s.left_at IS NULL
WHERE p.tournament_id='bee519fa-ff07-438c-9542-d386fc821908' AND p.status='playing';

DO $$ BEGIN
  IF (SELECT count(*) FROM e2.future_finishes)<>12 THEN
    RAISE EXCEPTION 'fixture requires exactly twelve current survivors';
  END IF;
END $$;

-- Fixture restoration, not the behavior under test. Like restoring the
-- original dump, this installs explicit accepted-hand inputs before any door.
BEGIN;
SET LOCAL session_replication_role=replica;
SELECT setval('public.tournament_player_elimination_sequence',
  (SELECT max(elimination_sequence)+1 FROM public.tournament_players),false);
DO $$ DECLARE r record; h uuid; internal_h uuid; at_time timestamptz;
  result jsonb; winner uuid; BEGIN
  SELECT user_id INTO winner FROM e2.future_finishes WHERE ordinal=12;
  FOR r IN SELECT * FROM e2.future_finishes WHERE ordinal<12 ORDER BY ordinal LOOP
    h:=md5('e2-hypothetical-hand:'||r.user_id)::uuid;
    internal_h:=md5('e2-hypothetical-settlement:'||r.user_id)::uuid;
    at_time:=(SELECT max(committed_at) FROM public.hand_atomic_commits)
      + interval '1 minute';
    result:=jsonb_build_object('hand_id',internal_h,'table_id',r.table_id,
      'hand_number',90000000+r.ordinal,'written',jsonb_build_object(r.user_id,0));
    INSERT INTO public.hand_history(id,table_id,hand_number)
      VALUES(h,r.table_id,90000000+r.ordinal);
    INSERT INTO public.hand_atomic_commits
      (table_id,hand_number,hand_id,payload_hash,stack_result,committed_at)
      VALUES(r.table_id,90000000+r.ordinal,h,
        encode(extensions.digest('e2-fixture-payload:'||r.user_id,'sha256'),'hex'),result,at_time);
    INSERT INTO public.settlement_idempotency_keys
      (table_id,hand_id,status,completed_at,result)
      VALUES(r.table_id,internal_h,'succeeded',at_time,result);
    INSERT INTO public.tournament_knockout_candidates
      (id,tournament_id,eliminated_user_id,table_id,seat_id,seat_joined_at,
       hand_id,hand_number,stack_before,stack_after,state,created_at)
      VALUES(md5('e2-hypothetical-knockout:'||r.user_id)::uuid,
        'bee519fa-ff07-438c-9542-d386fc821908',r.user_id,r.table_id,r.seat_id,
        r.joined_at,h,90000000+r.ordinal,r.chips,0,'pending',at_time);
    UPDATE public.tournament_players SET chips=0 WHERE user_id=r.user_id;
    UPDATE public.table_seats SET stack=0 WHERE id=r.seat_id;
  END LOOP;
  UPDATE public.tournament_players SET chips=(SELECT sum(chips) FROM e2.future_finishes)
    WHERE user_id=winner;
  UPDATE public.table_seats SET stack=(SELECT sum(chips) FROM e2.future_finishes)
    WHERE user_id=winner AND left_at IS NULL;
END $$;
COMMIT;
SHOW session_replication_role;

-- The actual elimination doors run with normal trigger execution. Positive
-- cached prizes explicitly cover busts inside the paid range.
CREATE TABLE e2.elimination_results(user_id uuid,place integer,result jsonb);
DO $$ DECLARE r record; answer jsonb; amount numeric; BEGIN
  IF current_setting('session_replication_role')<>'origin' THEN
    RAISE EXCEPTION 'test requires normal trigger execution';
  END IF;
  FOR r IN SELECT * FROM e2.future_finishes WHERE ordinal<12 ORDER BY ordinal LOOP
    SELECT a.amount INTO amount
      FROM public.fn_ca_tournament_place_amounts('bee519fa-ff07-438c-9542-d386fc821908') a
      WHERE a.place=r.final_place;
    answer:=public.fn_eliminate_tournament_player_atomic(
      'bee519fa-ff07-438c-9542-d386fc821908',r.user_id,r.final_place,amount,0);
    INSERT INTO e2.elimination_results VALUES(r.user_id,r.final_place,answer);
    IF coalesce((answer->>'ok')::boolean,false) IS NOT TRUE THEN
      RAISE EXCEPTION 'real elimination refused place %: %',r.final_place,answer;
    END IF;
  END LOOP;
END $$;
SELECT 'paid_range_busts' AS check_name,count(*) AS successful_busts,
  (SELECT count(*) FROM public.tournament_obligations WHERE kind='place') AS place_obligations,
  (SELECT count(*) FROM public.tournament_payouts) AS payouts
FROM e2.elimination_results;
