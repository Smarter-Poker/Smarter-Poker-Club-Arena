from pathlib import Path
import json, subprocess

base = Path(__file__).resolve().parent
state = json.loads((base / 'cluster.json').read_text())
assert state['cluster'].startswith('/tmp/ca-e2-owned-')
psql = ['/opt/homebrew/opt/postgresql@17/bin/psql', '-X', '-v', 'ON_ERROR_STOP=1',
        '-h', state['socket'], '-p', str(state['port']), '-U', 'postgres', '-d', state['database']]
def read(name):
    return json.loads((base / name).read_text())
core, witnesses, tables, money, support = [read('live-event-' + n + '.json')
    for n in ['core', 'witnesses', 'tables', 'money', 'support']]
users = {p['user_id'] for p in core['players']}
users.add(support['club']['owner_id'])
users.add('2d1cd6c3-5700-4af9-a271-d4863fdab20d')
for key in ['created_by', 'creator_id', 'owner_id']:
    if core['tournament'].get(key): users.add(core['tournament'][key])
users.discard(None)
hashes = {(h['table_id'], h['hand_number']): h['payload_hash'] for h in support['commit_hashes']}
for c in witnesses['commits']:
    c['payload_hash'] = hashes[(c['table_id'], c['hand_number'])]
hand_keys = {c['hand_id']: {'id': c['hand_id'], 'table_id': c['table_id'],
    'hand_number': c['hand_number']} for c in witnesses['candidates']}
data = [
    ('auth.users', [{'id': u} for u in sorted(users)]),
    ('public.users', [{'id': u, 'username': 'e2_' + u.replace('-', '')} for u in sorted(users)]),
    ('public.profiles', [{'id': u, 'username': 'e2_' + u.replace('-', '')} for u in sorted(users)]),
    ('public.clubs', [support['club']]),
    ('public.club_wallets', [support['club_wallet']]),
    ('public.club_members', money['members']),
    ('public.tournaments', [core['tournament']]),
    ('public.tournament_players', core['players']),
    ('public.tables', tables['tables']),
    ('public.table_seats', tables['seats']),
    ('public.hand_history', list(hand_keys.values())),
    ('public.hand_atomic_commits', witnesses['commits']),
    ('public.settlement_idempotency_keys', tables['settlement_receipts']),
    ('public.tournament_knockout_candidates', witnesses['candidates']),
    ('public.tournament_escrow', [core['escrow']]),
    ('public.chip_ledger', money['ledger']),
    ('public.wallet_transactions', money['wallet_transactions']),
    ('public.tournament_obligations', money['obligations'] or []),
    ('public.tournament_payouts', money['payouts'] or []),
    ('public.tournament_guarantee_overlays', money['overlays'] or []),
]
controls = read('live-controls.json')
data += [('public.ca_' + key, value or []) for key, value in controls.items()]
catalog = json.loads(subprocess.check_output(psql + ['-Atc', "SELECT jsonb_agg(jsonb_build_object('table',table_schema||'.'||table_name,'column',column_name,'generated',is_generated)) FROM information_schema.columns WHERE table_schema IN ('public','auth');"], text=True))
known = {}
for c in catalog: known.setdefault(c['table'], {})[c['column']] = c['generated']
sql = ['BEGIN;', 'SET LOCAL session_replication_role=replica;']
counts = {}
for table, rows in data:
    counts[table] = len(rows)
    for row in rows:
        unknown = set(row) - set(known[table])
        if unknown: raise RuntimeError(f'{table}: donor missing current columns {sorted(unknown)}')
        row = {k: v for k, v in row.items() if known[table][k] == 'NEVER'}
        cols = ','.join('"' + k + '"' for k in row)
        value = json.dumps(row, separators=(',', ':')).replace("'", "''")
        sql.append(f"INSERT INTO {table} ({cols}) OVERRIDING SYSTEM VALUE SELECT {cols} FROM jsonb_populate_record(NULL::{table},'{value}'::jsonb);")
sql += ['COMMIT;', 'SHOW session_replication_role;']
(base / 'seed.sql').write_text('\n'.join(sql) + '\n')
result = subprocess.run(psql + ['-f', str(base / 'seed.sql')], text=True, capture_output=True)
(base / 'seed.log').write_text(result.stdout + result.stderr)
print(json.dumps({'rowCounts': counts, 'exitCode': result.returncode, 'lastOutput': result.stdout[-200:], 'error': result.stderr[-2500:]}, indent=2))
raise SystemExit(result.returncode)
