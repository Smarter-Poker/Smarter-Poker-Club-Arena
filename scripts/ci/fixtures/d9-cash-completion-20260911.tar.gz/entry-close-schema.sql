--
-- PostgreSQL database dump
--

\restrict bbpKF4Roniwb3d8J97bOjeD93M7lnWt4MNXOPEgstIfTDVMflIVsStDQXpSgEXz

-- Dumped from database version 17.11 (Homebrew)
-- Dumped by pg_dump version 17.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tournament_entry_close_receipts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_entry_close_receipts (
    tournament_id uuid NOT NULL,
    close_mode text NOT NULL,
    entry_closed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    final_prize_pool numeric NOT NULL,
    payout_structure_snapshot jsonb NOT NULL,
    manager_wake_id bigint,
    reprice_completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT tournament_entry_close_receipts_close_mode_check CHECK ((close_mode = ANY (ARRAY['levels'::text, 'minutes'::text, 'immediate'::text, 'addon'::text]))),
    CONSTRAINT tournament_entry_close_receipts_final_prize_pool_check CHECK ((final_prize_pool >= (0)::numeric))
);


--
-- Name: tournament_entry_close_receipts tournament_entry_close_receipts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_entry_close_receipts
    ADD CONSTRAINT tournament_entry_close_receipts_pkey PRIMARY KEY (tournament_id);


--
-- Name: idx_tournament_entry_close_receipts_pending; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tournament_entry_close_receipts_pending ON public.tournament_entry_close_receipts USING btree (entry_closed_at, tournament_id) WHERE (reprice_completed_at IS NULL);


--
-- Name: tournament_entry_close_receipts aaa_require_satellite_economics_at_entry_close; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER aaa_require_satellite_economics_at_entry_close BEFORE INSERT ON public.tournament_entry_close_receipts FOR EACH ROW EXECUTE FUNCTION public.trg_require_satellite_economics_at_entry_close();


--
-- Name: tournament_entry_close_receipts tournament_entry_close_receipts_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_entry_close_receipts
    ADD CONSTRAINT tournament_entry_close_receipts_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournaments(id) ON DELETE RESTRICT;


--
-- Name: tournament_entry_close_receipts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_entry_close_receipts ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict bbpKF4Roniwb3d8J97bOjeD93M7lnWt4MNXOPEgstIfTDVMflIVsStDQXpSgEXz

