"""Sealed offline D9 cash completion and unchanged modern E2 path on PostgreSQL17."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,tempfile
base=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--pg-bin',default='/opt/homebrew/opt/postgresql@17/bin');args=p.parse_args();pg=Path(args.pg_bin).resolve()
assert subprocess.check_output([str(pg/'postgres'),'--version'],text=True).startswith('postgres (PostgreSQL) 17.')
m=json.loads((base/'completion-manifest.json').read_text());assert m['case']=='D9-cash-completion'
for n,h in m['sha256'].items():assert Path(n).name==n and hashlib.sha256((base/n).read_bytes()).hexdigest()==h,n
work=Path(tempfile.mkdtemp(prefix='ca-e2-owned-',dir='/tmp'));data=work/'data';sock=work/'socket';sock.mkdir(mode=0o700);runtime=work/'rehearsal';runtime.mkdir()
for n in m['sha256']:
 content=(base/n).read_bytes()
 if n.endswith('.py'):content=content.replace(b'/opt/homebrew/opt/postgresql@17/bin',str(pg).encode())
 (runtime/n).write_bytes(content)
state={'cluster':str(work),'socket':str(sock),'port':55498,'database':'d9_legacy_completion'};(runtime/'cluster.json').write_text(json.dumps(state))
env={k:v for k,v in os.environ.items() if not k.startswith('PG')};env['PGTZ']='UTC'
def run(command,log,folder=runtime):
 r=subprocess.run(command,cwd=folder,env=env,text=True,capture_output=True);(folder/log).write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError(f'{log}: '+(r.stderr or r.stdout)[-3500:])
 return r.stdout
started=False
try:
 run([str(pg/'initdb'),'-D',str(data),'--no-locale','-E','UTF8','-U','postgres'],'init.log')
 run([str(pg/'pg_ctl'),'-D',str(data),'-l',str(work/'postgres.log'),'-o',f"-h '' -k {sock} -p 55498",'-w','start'],'start.log');started=True
 psql=[str(pg/'psql'),'-X','-v','ON_ERROR_STOP=1','-h',str(sock),'-p','55498','-U','postgres']
 run(psql+['-d','postgres','-c','CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role BYPASSRLS;'],'roles.log')
 for script in ['load-local.py','verify-pins.py','verify-extra-schema.py','seed-local.py']:run(['python3',str(runtime/script)],script+'.log')
 migrations=['restore-observed-acls.sql','shared-late-status-migration.sql','d12-reviewed-preview.sql','20260911163920_accepted_tournament_settlement_facts.sql','integration.sql']
 for n in migrations:
  if n=='integration.sql':
   run(psql+['-d',state['database'],'-c','GRANT EXECUTE ON FUNCTION public.fn_ca_verify_terminal_place_batch(uuid,boolean) TO authenticated;'],'acl-drift-grant.log')
   rejected=subprocess.run(psql+['-d',state['database'],'-f',str(runtime/n)],cwd=runtime,env=env,text=True,capture_output=True)
   (runtime/'acl-drift-refusal.log').write_text(rejected.stdout+rejected.stderr)
   assert rejected.returncode and 'legacy terminal verifier private permission prerequisite differs' in rejected.stderr
   absent=run(psql+['-d',state['database'],'-Atc',"SELECT to_regclass('public.tournament_legacy_finish_evidence') IS NULL;"],'acl-drift-no-writes.log')
   assert absent.strip()=='t'
   run(psql+['-d',state['database'],'-c','REVOKE ALL ON FUNCTION public.fn_ca_verify_terminal_place_batch(uuid,boolean) FROM authenticated;'],'acl-drift-restore.log')
   run(psql+['-d',state['database'],'-c','GRANT EXECUTE ON FUNCTION public.fn_settle_tournament_places(uuid,uuid) TO authenticated;'],'payer-acl-drift-grant.log')
   rejected=subprocess.run(psql+['-d',state['database'],'-f',str(runtime/n)],cwd=runtime,env=env,text=True,capture_output=True)
   (runtime/'payer-acl-drift-refusal.log').write_text(rejected.stdout+rejected.stderr)
   assert rejected.returncode and 'legacy place settlement permission prerequisite differs' in rejected.stderr
   absent=run(psql+['-d',state['database'],'-Atc',"SELECT to_regclass('public.tournament_legacy_finish_evidence') IS NULL;"],'payer-acl-drift-no-writes.log')
   assert absent.strip()=='t'
   run(psql+['-d',state['database'],'-c','REVOKE ALL ON FUNCTION public.fn_settle_tournament_places(uuid,uuid) FROM authenticated;'],'payer-acl-drift-restore.log')
  run(psql+['-d',state['database'],'-f',str(runtime/n)],n+'.log')
 run(['python3',str(runtime/'test-cash-completion.py')],'test-cash-completion.log')
 # The unchanged ordinary modern path receives real preserved E2 facts plus
 # its original11 hypothetical future busts, never a historical resequence.
 modern=work/'modern-regression';modern.mkdir()
 for n in m['sha256']:
  name=n.removeprefix('e2-fixture-');content=(runtime/n).read_bytes()
  if n=='load-local.py':content=content.replace(b'd9_legacy_completion',b'd9_e2_regression')
  if not n.startswith('e2-fixture-') and (runtime/('e2-fixture-'+name)).exists():continue
  (modern/name).write_bytes(content)
 state['database']='d9_e2_regression';(modern/'cluster.json').write_text(json.dumps(state))
 for script in ['load-local.py','seed-local.py']:run(['python3',str(modern/script)],script+'.log',modern)
 for n in migrations+['future-finishes.sql']:run(psql+['-d',state['database'],'-f',str(modern/n)],n+'.log',modern)
 terminal=run(psql+['-d',state['database'],'-Atc',"SELECT fn_complete_tournament_terminal('bee519fa-ff07-438c-9542-d386fc821908','8327a08a-77e7-4f33-be45-e086a718c9e2','places');"],'terminal.log',modern)
 assert json.loads(terminal)['status']=='COMPLETED'
 run(['python3',str(modern/'verify-local.py')],'verify.log',modern)
 seals=run(psql+['-d',state['database'],'-Atc','SELECT count(*) FROM tournament_legacy_finish_evidence;'],'legacy-seals.log',modern);assert int(seals.strip())==0
 output=base/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');output.mkdir(parents=True)
 for n in ['pins-receipt.json','cash-completion-receipt.json']:(output/n).write_bytes((runtime/n).read_bytes())
 (output/'modern-e2-verification-receipt.json').write_bytes((modern/'verification-receipt.json').read_bytes())
 (output/'run.json').write_text(json.dumps({'status':'passed','case':m['case'],'runtime':str(runtime),'modernRuntime':str(modern),'manifestSha256':hashlib.sha256((base/'completion-manifest.json').read_bytes()).hexdigest(),'cashCompleted':21,'cohort28Remaining':7,'satelliteHistoricalEconomicsOutstanding':3,'revivalRefusals':3,'chipMismatchRefusals':1,'broaderCohortAdditionalUnfinished':11,'broaderCohortAdditionalPaidHistory':1,'productionWrites':0,'privateAclDriftRefused':True,'placePayerAclDriftRefused':True},indent=2)+'\n')
 print(json.dumps({'status':'passed','receiptDirectory':str(output)}))
finally:
 if started:subprocess.run([str(pg/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop'],env=env,check=True,capture_output=True)
