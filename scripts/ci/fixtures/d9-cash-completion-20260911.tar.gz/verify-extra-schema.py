from pathlib import Path
import json,subprocess
b=Path(__file__).resolve().parent;s=json.loads((b/'cluster.json').read_text())
p=['/opt/homebrew/opt/postgresql@17/bin/psql','-X','-h',s['socket'],'-p',str(s['port']),'-U','postgres','-d',s['database'],'-Atc']
sql="""SELECT jsonb_build_object('columns',(SELECT jsonb_agg(jsonb_build_object('name',a.attname,'type',format_type(a.atttypid,a.atttypmod),'notnull',a.attnotnull,'default',pg_get_expr(d.adbin,d.adrelid)) ORDER BY a.attnum) FROM pg_attribute a LEFT JOIN pg_attrdef d ON d.adrelid=a.attrelid AND d.adnum=a.attnum WHERE a.attrelid='public.tournament_entry_close_receipts'::regclass AND a.attnum>0 AND NOT a.attisdropped),'constraints',(SELECT jsonb_agg(pg_get_constraintdef(c.oid) ORDER BY c.conname) FROM pg_constraint c WHERE c.conrelid='public.tournament_entry_close_receipts'::regclass),'triggers',(SELECT jsonb_agg(jsonb_build_object('name',tgname,'enabled',tgenabled,'definition',pg_get_triggerdef(oid))) FROM pg_trigger WHERE tgrelid='public.tournament_entry_close_receipts'::regclass AND NOT tgisinternal));"""
actual=json.loads(subprocess.check_output(p+[sql],text=True));expected=json.loads((b/'live-entry-close-schema-pin.json').read_text());assert actual==expected,(actual,expected)
print('Narrow entry-close schema, constraints, trigger definition and state match current catalog')
