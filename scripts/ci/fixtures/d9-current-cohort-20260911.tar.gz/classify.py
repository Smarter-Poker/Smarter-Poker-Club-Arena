"""Classify captured D9 evidence without choosing paid winners or writing SQL."""
from pathlib import Path
from decimal import Decimal
from datetime import datetime
import collections,hashlib,json

base=Path(__file__).resolve().parent
manifest=base/'input-manifest.json'
if manifest.exists():
    for name,expected in json.loads(manifest.read_text())['sha256'].items():
        assert Path(name).name==name and hashlib.sha256((base/name).read_bytes()).hexdigest()==expected,name
events=sum([json.loads((base/f'live-batch-{i}.json').read_text()) for i in range(1,5)],[])
witnesses=sum([json.loads((base/f'live-witness-batch-{i}.json').read_text()) for i in range(1,5)],[])
lookup={(r['tournament_id'],r['user_id']):r for r in witnesses}
inventory={r['id']:r for r in json.loads((base/'live-candidate-events.json').read_text()) if r['start_time'].startswith('2026-09-08')}
assert len(events)==40 and len({e['id'] for e in events})==40 and set(inventory)=={e['id'] for e in events}
assert len(witnesses)==134 and all(w['is_horse'] is True for w in witnesses)
counts=collections.Counter();pools=collections.defaultdict(Decimal);report=[]
for event in sorted(events,key=lambda e:(inventory[e['id']]['start_time'],e['id'])):
    players=event['players'];positive=[p for p in players if Decimal(str(p['chips']))>0]
    paid=sum(Decimal(str(p['amount'])) for p in event['payouts'])
    paid_obligation=sum(Decimal(str(o['amount_paid'])) for o in event['obligations'])
    proven=True;chips_match=True
    for player in players:
        witness=lookup[event['id'],player['user_id']]
        last=witness['last_observation'];zero=witness['last_zero']
        if not last or Decimal(str(last['written']))!=Decimal(str(player['chips'])):chips_match=False
        if player in positive and (not last or Decimal(str(last['written']))<=0):proven=False
        if player not in positive:
            if not zero or not last or Decimal(str(last['written']))!=0:proven=False
            elif datetime.fromisoformat(zero['completed_at'])>datetime.fromisoformat(last['completed_at']):proven=False
    if paid>0 or paid_obligation>0:
        category='paid_history_requires_compatible_ruling'
    elif len(positive)==1 and proven:
        category='unpaid_finish_evidenced_pending_native_prerequisites'
    else:
        category='unpaid_no_valid_finish_exact_refund_candidate'
    null_sequences=sum(p['status']=='eliminated' and p['elimination_sequence'] is None for p in players)
    counts[category]+=1;pools[category]+=Decimal(str(event['prize_pool']))
    item={'id':event['id'],'name':inventory[event['id']]['name'],'variant':inventory[event['id']]['variant'],
          'status':event['status'],'fieldSize':len(players),'allEntrantsHorses':True,
          'pool':str(event['prize_pool']),'paidPlaceAmount':str(paid),'remainingPrizeEscrow':str(event['escrow']['prize_balance']),
          'positivePlayerCount':len(positive),'liveSeatCount':len(event['live_seat_users']),
          'recordedPositivePlayers':[{'userId':p['user_id'],'chips':p['chips']} for p in positive],
          'acceptedObservationsMatchAllPlayerChips':chips_match,'acceptedFinishIdentityProven':proven,'nullEliminationSequences':null_sequences,
          'classification':category,'nativeBatchRehearsed':False,
          'existingContractVersion':event['contracts'][-1]['version'] if event['contracts'] else None,
          'payoutStructureSha256':hashlib.sha256(event['payout_structure'].encode()).hexdigest(),
          'eventEvidenceSha256':hashlib.sha256(json.dumps(event,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
    if category=='paid_history_requires_compatible_ruling':
        item['prerequisites']=['Preserve all four paid rows and exact receipt identities.','Resolve the zero-chip playing row from accepted hand evidence without choosing a new winner.','Resolve missing historical sequence compatibility without status toggles or resequencing.','Prove normal completion and any true-order debt separately; no blanket entry refund.']
        item['paidLadderAlreadyMatchesCurrent']=all(p['payout_structure']['payout_structure']==event['payout_structure'] for p in event['payouts'])
    elif category=='unpaid_finish_evidenced_pending_native_prerequisites':
        item['prerequisites']=['Shared migration 20260911110000 first.','Prove compatibility for NULL historical sequences in the ordinary terminal door without status toggles.','Native PG17 final payment and replay rehearsal in a batch of at most ten.']
    else:
        item['prerequisites']=['Shared migration 20260911110000 first.','Rehearse exact entry refunds and terminal cancellation using real entry and reserve/fee receipts, in a batch of at most ten.','Do not invent a winner or equate advertised pool with entry refund amount.']
    if not chips_match:item['prerequisites'].append('Reconcile the captured roster/accepted-stack mismatch without overwriting chips or discarding this event.')
    report.append(item)
assert dict(counts)=={'unpaid_no_valid_finish_exact_refund_candidate':11,'unpaid_finish_evidenced_pending_native_prerequisites':28,'paid_history_requires_compatible_ruling':1},dict(counts)
summary={'captureDate':'2026-09-11','sourceBaseCommit':'5a550b6343f613a7134011b41d69cdad613642f7','productionProjectId':'kuklfnapbkmacvwxktbh','currentEvents':40,'historicalReportedEvents':79,'currentPoolTotal':str(sum(pools.values())),'totalPlayers':134,'allHorses':True,'eliminatedRowsWithNullSequence':sum(r['nullEliminationSequences'] for r in report),'counts':dict(counts),'poolTotalsByClass':{k:str(v) for k,v in pools.items()},'noProductionWrites':True,'noWinnersSelected':True,'nativeBatchesStillRequired':True,'events':report}
(base/'classification-receipt.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='events'},indent=2))
