"""Offline-only private legacy witness rehearsal on an owned PG17 cluster."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,tempfile
base=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--pg-bin',default='/opt/homebrew/opt/postgresql@17/bin');args=parser.parse_args();pg=Path(args.pg_bin).resolve()
assert subprocess.check_output([str(pg/'postgres'),'--version'],text=True).startswith('postgres (PostgreSQL) 17.')
manifest=json.loads((base/'fixture-manifest.json').read_text());assert manifest['case']=='D9-private-witness'
for n,digest in manifest['sha256'].items():assert Path(n).name==n and hashlib.sha256((base/n).read_bytes()).hexdigest()==digest,n
work=Path(tempfile.mkdtemp(prefix='ca-e2-owned-',dir='/tmp'));data=work/'data';sock=work/'socket';sock.mkdir(mode=0o700);runtime=work/'rehearsal';runtime.mkdir()
for n in manifest['sha256']:
 content=(base/n).read_bytes()
 if n.endswith('.py'):content=content.replace(b'/opt/homebrew/opt/postgresql@17/bin',str(pg).encode())
 (runtime/n).write_bytes(content)
(runtime/'cluster.json').write_text(json.dumps({'cluster':str(work),'socket':str(sock),'port':55498,'database':'d9_legacy_28'}))
env={k:v for k,v in os.environ.items() if not k.startswith('PG')};env['PGTZ']='UTC'
def run(command,log):
 r=subprocess.run(command,cwd=runtime,env=env,text=True,capture_output=True);(runtime/log).write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError(f'{log}: '+(r.stderr or r.stdout)[-3000:])
 return r.stdout
started=False
try:
 run([str(pg/'initdb'),'-D',str(data),'--no-locale','-E','UTF8','-U','postgres'],'init.log')
 run([str(pg/'pg_ctl'),'-D',str(data),'-l',str(work/'postgres.log'),'-o',f"-h '' -k {sock} -p 55498",'-w','start'],'start.log');started=True
 psql=[str(pg/'psql'),'-X','-v','ON_ERROR_STOP=1','-h',str(sock),'-p','55498','-U','postgres']
 run(psql+['-d','postgres','-c','CREATE ROLE anon; CREATE ROLE authenticated; CREATE ROLE service_role BYPASSRLS;'],'roles.log')
 for script in ['load-local.py','verify-pins.py','seed-local.py']:run(['python3',str(runtime/script)],script+'.log')
 run(psql+['-d','d9_legacy_28','-f',str(runtime/manifest['migration'])],'migration.log')
 for script in ['test-accepted-fact.py','test-finish-witness.py']:run(['python3',str(runtime/script)],script+'.log')
 output=base/'runs'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');output.mkdir(parents=True)
 for name in ['pins-receipt.json','accepted-fact-test-receipt.json','finish-witness-results.json','finish-witness-test-receipt.json']:(output/name).write_bytes((runtime/name).read_bytes())
 (output/'run.json').write_text(json.dumps({'case':manifest['case'],'status':'passed','runtime':str(runtime),'fixtureManifestSha256':hashlib.sha256((base/'fixture-manifest.json').read_bytes()).hexdigest(),'productionWrites':0,'normalCompletionNotYetRehearsed':True},indent=2)+'\n')
 print(json.dumps({'case':manifest['case'],'status':'passed','receiptDirectory':str(output)}))
finally:
 if started:subprocess.run([str(pg/'pg_ctl'),'-D',str(data),'-m','fast','-w','stop'],env=env,check=True,capture_output=True)
