from pathlib import Path
import json,subprocess
base=Path(__file__).resolve().parent
state=json.loads((base/'cluster.json').read_text())
assert state['cluster'].startswith('/tmp/ca-e2-owned-') and state['database']=='d9_legacy_28'
psql=['/opt/homebrew/opt/postgresql@17/bin/psql','-X','-v','ON_ERROR_STOP=1','-h',state['socket'],'-p',str(state['port']),'-U','postgres','-d',state['database']]
data={}
coremap={'tournaments':'tournaments','players':'tournament_players','tables':'tables','seats':'table_seats','commits':'hand_atomic_commits','candidates':'tournament_knockout_candidates','escrows':'tournament_escrow','settlement_receipts':'settlement_idempotency_keys'}
supportmap={'clubs':'clubs','unions':'unions','club_wallets':'club_wallets','union_wallets':'union_wallets','members':'club_members','contracts':'managed_game_contract_versions','ledger':'chip_ledger','wallet_transactions':'wallet_transactions','payouts':'tournament_payouts','obligations':'tournament_obligations','entitlements':'tournament_refund_entitlements','rake_records':'rake_records','wakes':'tournament_manager_wakes','wallet_credit_idempotency':'wallet_credit_idempotency','place_batches':'tournament_place_settlement_batches','terminal_receipts':'tournament_terminal_settlements','spin_bonus_pools':'spin_bonus_pools','spin_draw_receipts':'spin_draw_receipts','spin_payout_ladder':'spin_payout_ladder','spin_reserve_ledger':'spin_reserve_ledger'}
for batch in range(1,4):
 for kind,mapping in [('core',coremap),('support',supportmap)]:
  values=json.loads((base/f'live-batch-{batch}-{kind}.json').read_text())
  assert not(set(values)-set(mapping)),set(values)-set(mapping)
  for key,rows in values.items():data.setdefault('public.'+mapping[key],[]).extend(rows or [])
# Shared wallet/club snapshots may differ in unrelated current balances across capture times.
# Use the first observed row for each immutable primary identity; event money rows retain exact capture.
keys={'public.club_members':lambda r:(r['club_id'],r['user_id']),'public.settlement_idempotency_keys':lambda r:(r['table_id'],r['hand_id']),'public.tournament_escrow':lambda r:r['tournament_id'],'public.spin_payout_ladder':lambda r:r['multiplier'],'public.wallet_credit_idempotency':lambda r:r['key']}
for table,rows in data.items():
 seen={}
 for row in rows:
  identity=keys.get(table,lambda r:r['id'])(row)
  if identity not in seen:seen[identity]=row
 data[table]=list(seen.values())
users={p['user_id'] for p in data['public.tournament_players']}
for table in ['public.tournaments','public.clubs','public.unions']:
 for row in data[table]:
  for key in ['created_by','creator_id','owner_id']:
   if row.get(key):users.add(row[key])
users.add('2d1cd6c3-5700-4af9-a271-d4863fdab20d')
# Identity-only rows satisfy the genuine schema's FKs. No payout or money function is stubbed.
data['auth.users']=[{'id':u} for u in sorted(users)]
for table in ['public.users','public.profiles']:
 data[table]=[{'id':u,'username':'d9_'+u.replace('-','')} for u in sorted(users)]
controls=json.loads((base/'live-controls.json').read_text())
data.update({'public.ca_'+key:rows or [] for key,rows in controls.items()})
catalog=json.loads(subprocess.check_output(psql+['-Atc',"SELECT jsonb_agg(jsonb_build_object('table',table_schema||'.'||table_name,'column',column_name,'generated',is_generated)) FROM information_schema.columns WHERE table_schema IN ('public','auth');"],text=True))
known={}
for c in catalog:known.setdefault(c['table'],{})[c['column']]=c['generated']
sql=['BEGIN;','SET LOCAL session_replication_role=replica;']
for table,rows in data.items():
 for row in rows:
  unknown=set(row)-set(known[table]);assert not unknown,(table,unknown)
  row={k:v for k,v in row.items() if known[table][k]=='NEVER'}
  cols=','.join('"'+k+'"' for k in row);value=json.dumps(row,separators=(',',':')).replace("'","''")
  sql.append(f"INSERT INTO {table} ({cols}) OVERRIDING SYSTEM VALUE SELECT {cols} FROM jsonb_populate_record(NULL::{table},'{value}'::jsonb);")
sql += ["SELECT setval('public.tournament_player_elimination_sequence',1,false);",'COMMIT;','SHOW session_replication_role;']
(base/'seed.sql').write_text('\n'.join(sql)+'\n')
r=subprocess.run(psql+['-f',str(base/'seed.sql')],text=True,capture_output=True)
(base/'seed.log').write_text(r.stdout+r.stderr)
print(json.dumps({'counts':{k:len(v) for k,v in data.items()},'exitCode':r.returncode,'error':r.stderr[-3000:]},indent=2))
raise SystemExit(r.returncode)
