--
-- PostgreSQL database dump
--

\restrict vSuc4ZfnTiffx75eM2UcWURiBHXVZvdAhdAjBuC8Nw1WalkzfuJJVW7p5EVXfdE

-- Dumped from database version 17.11 (Homebrew)
-- Dumped by pg_dump version 17.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tournament_satellite_remainders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tournament_satellite_remainders (
    tournament_id uuid NOT NULL,
    user_id uuid NOT NULL,
    place integer NOT NULL,
    amount numeric(15,2) NOT NULL,
    payout_id uuid NOT NULL,
    payout_source text NOT NULL,
    payout_position integer,
    idempotency_key text NOT NULL,
    obligation_id uuid NOT NULL,
    obligation_kind text NOT NULL,
    obligation_place integer,
    evidence_kind text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tournament_satellite_remainders_amount_check CHECK (((amount > (0)::numeric) AND (amount = round(amount, 2)))),
    CONSTRAINT tournament_satellite_remainders_check CHECK ((((evidence_kind = 'atomic'::text) AND (NOT (payout_position IS DISTINCT FROM place)) AND (NOT (obligation_place IS DISTINCT FROM place)) AND (idempotency_key = ((('tourney:'::text || (tournament_id)::text) || ':satellite_remainder:place:'::text) || (place)::text))) OR ((evidence_kind = 'legacy_20260908_682'::text) AND (tournament_id = '682045c5-cb07-47ed-ad0e-adbff9cb41af'::uuid) AND (user_id = '146cf7a5-7f99-4dd3-858d-26dae69d9c80'::uuid) AND (place = 2) AND (amount = 85.00) AND (payout_id = '0de0bc80-dd26-4631-b7f5-3baf0fb4a9da'::uuid) AND (payout_position IS NULL) AND (idempotency_key = 'tourney:682045c5-cb07-47ed-ad0e-adbff9cb41af:obl:a15db36e-6684-4edd-be48-277bfb3113ba:0'::text) AND (obligation_id = 'a15db36e-6684-4edd-be48-277bfb3113ba'::uuid) AND (obligation_place IS NULL)))),
    CONSTRAINT tournament_satellite_remainders_evidence_kind_check CHECK ((evidence_kind = ANY (ARRAY['atomic'::text, 'legacy_20260908_682'::text]))),
    CONSTRAINT tournament_satellite_remainders_idempotency_key_check CHECK ((length(btrim(idempotency_key)) > 0)),
    CONSTRAINT tournament_satellite_remainders_obligation_kind_check CHECK ((obligation_kind = 'satellite_remainder'::text)),
    CONSTRAINT tournament_satellite_remainders_payout_source_check CHECK ((payout_source = 'satellite_remainder'::text)),
    CONSTRAINT tournament_satellite_remainders_place_check CHECK ((place > 0))
);


--
-- Name: TABLE tournament_satellite_remainders; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.tournament_satellite_remainders IS 'Immutable evidence for the one next-finisher residual. Atomic rows bind the canonical place key; the single named legacy row preserves its original append-only financial evidence.';


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_remainders
    ADD CONSTRAINT tournament_satellite_remainders_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_obligation_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_remainders
    ADD CONSTRAINT tournament_satellite_remainders_obligation_id_key UNIQUE (obligation_id);


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_payout_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_remainders
    ADD CONSTRAINT tournament_satellite_remainders_payout_id_key UNIQUE (payout_id);


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_remainders
    ADD CONSTRAINT tournament_satellite_remainders_pkey PRIMARY KEY (tournament_id);


--
-- Name: tournament_satellite_remainders terminal_tournament_evidence_is_immutable; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER terminal_tournament_evidence_is_immutable BEFORE INSERT OR DELETE OR UPDATE ON public.tournament_satellite_remainders FOR EACH ROW EXECUTE FUNCTION public.fn_terminal_tournament_evidence_is_immutable();


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_append_only; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tournament_satellite_remainders_append_only BEFORE DELETE OR UPDATE ON public.tournament_satellite_remainders FOR EACH ROW EXECUTE FUNCTION public.fn_satellite_settlement_receipts_are_append_only();


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_obligation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_remainders
    ADD CONSTRAINT tournament_satellite_remainders_obligation_id_fkey FOREIGN KEY (obligation_id) REFERENCES public.tournament_obligations(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_payout_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_remainders
    ADD CONSTRAINT tournament_satellite_remainders_payout_id_fkey FOREIGN KEY (payout_id) REFERENCES public.tournament_payouts(id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_remainders tournament_satellite_remainders_tournament_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tournament_satellite_remainders
    ADD CONSTRAINT tournament_satellite_remainders_tournament_id_fkey FOREIGN KEY (tournament_id) REFERENCES public.tournament_satellite_settlements(tournament_id) ON DELETE RESTRICT;


--
-- Name: tournament_satellite_remainders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tournament_satellite_remainders ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict vSuc4ZfnTiffx75eM2UcWURiBHXVZvdAhdAjBuC8Nw1WalkzfuJJVW7p5EVXfdE

