from pathlib import Path
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
import json, subprocess, hashlib

base = Path(__file__).resolve().parent
state = json.loads((base / 'cluster.json').read_text())
assert state['cluster'].startswith('/tmp/ca-e2-owned-')
psql = ['/opt/homebrew/opt/postgresql@17/bin/psql', '-X', '-v', 'ON_ERROR_STOP=1',
        '-h', state['socket'], '-p', str(state['port']), '-U', 'postgres', '-d', state['database'], '-Atc']
def query(sql):
    r = subprocess.run(psql + [sql], capture_output=True, text=True, check=True)
    if r.stderr.strip(): raise RuntimeError(r.stderr)
    return json.loads(r.stdout)
def read(name): return json.loads((base / name).read_text())
def stamp(value): return datetime.fromisoformat(value)

core, witness = read('live-event-core.json'), read('live-event-witnesses.json')
commits = {(c['table_id'], c['hand_number'], c['hand_id']): c for c in witness['commits']}
old = [p for p in core['players'] if p['status'] == 'eliminated']
ranked = []
for player in old:
    candidates = [c for c in witness['candidates'] if c['eliminated_user_id'] == player['user_id'] and c['state'] == 'eliminated']
    if candidates:
        c = max(candidates, key=lambda x: (x['hand_number'], x['id']))
        peers = [x for x in witness['candidates'] if (x['table_id'], x['hand_number'], x['hand_id']) == (c['table_id'], c['hand_number'], c['hand_id'])]
        a = commits.get((c['table_id'], c['hand_number'], c['hand_id']))
        at = stamp(a['committed_at']) if a else min(stamp(x['created_at']) for x in peers)
        at += timedelta(microseconds=sum((Decimal(str(x['stack_before'])), x['eliminated_user_id']) < (Decimal(str(c['stack_before'])), c['eliminated_user_id']) for x in peers))
    else:
        at = stamp(player['eliminated_at'])
    ranked.append((player, at))
# Stable id is the final ascending tie-break. Time/recording sequence descend.
ranked.sort(key=lambda row: row[0]['id'])
ranked.sort(key=lambda row: (row[1], row[0]['elimination_sequence']), reverse=True)
survivors = sorted((p for p in core['players'] if p['status'] == 'playing'), key=lambda p: (p['chips'], p['user_id']), reverse=True)
expected = {p['user_id']: i + 1 for i, p in enumerate(survivors)}
expected.update({p['user_id']: i + 13 for i, (p, _) in enumerate(ranked)})
actual = query('SELECT jsonb_agg(to_jsonb(p) ORDER BY id) FROM public.tournament_players p')
assert len(actual) == len(expected) == 167
assert all(p['position'] == expected[p['user_id']] for p in actual)
old_ids = {p['id']: p for p in old}
assert all(all(p[k] == old_ids[p['id']][k] for k in ['status','elimination_sequence','chips']) and stamp(p['eliminated_at']) == stamp(old_ids[p['id']]['eliminated_at']) for p in actual if p['id'] in old_ids)

ladder = json.loads(core['tournament']['payout_structure'], parse_float=Decimal)
bps = [int((Decimal(str(x['percentage'])) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP)) for x in ladder]
pool = int(Decimal(str(core['tournament']['prize_pool'])) * 100)
remaining, amounts = pool, {}
for index, (row, bp) in enumerate(zip(ladder, bps)):
    cents = remaining if index == len(ladder)-1 else min(remaining, int((Decimal(pool) * bp / sum(bps)).quantize(Decimal(1), rounding=ROUND_HALF_UP)))
    amounts[row['place']] = cents
    remaining -= cents
assert remaining == 0
payouts = query('SELECT jsonb_agg(to_jsonb(p) ORDER BY position) FROM public.tournament_payouts p')
assert len(payouts) == 17
assert all(expected[p['user_id']] == p['position'] and int(Decimal(str(p['amount'])) * 100) == amounts[p['position']] for p in payouts)

proof = query("""SELECT jsonb_build_object(
 'status',(SELECT status FROM public.tournaments),
 'payout_cents',(SELECT round(sum(amount)*100)::bigint FROM public.tournament_payouts),
 'obligation_cents',(SELECT round(sum(amount_paid)*100)::bigint FROM public.tournament_obligations WHERE kind='place'),
 'member_credit_cents',(SELECT round(sum(m.chip_balance-b.chip_balance)*100)::bigint FROM public.club_members m JOIN e2.before_members b USING(club_id,user_id)),
 'new_ledger_cents',(SELECT round(sum(l.amount)*100)::bigint FROM public.chip_ledger l LEFT JOIN e2.before_ledger b USING(id) WHERE b.id IS NULL),
 'new_wallet_receipt_cents',(SELECT round(sum(w.amount)*100)::bigint FROM public.wallet_transactions w LEFT JOIN e2.before_wallet_transactions b USING(id) WHERE b.id IS NULL),
 'original_ledger_unchanged',NOT EXISTS(SELECT 1 FROM e2.before_ledger b LEFT JOIN public.chip_ledger l USING(id) WHERE to_jsonb(b) IS DISTINCT FROM to_jsonb(l)),
 'original_wallet_financial_fields_unchanged',NOT EXISTS(SELECT 1 FROM e2.before_wallet_transactions b LEFT JOIN public.wallet_transactions w USING(id) WHERE to_jsonb(b)-'terminal_closed_at' IS DISTINCT FROM to_jsonb(w)-'terminal_closed_at'),
 'original_wallet_terminal_markers_correct',NOT EXISTS(SELECT 1 FROM e2.before_wallet_transactions b LEFT JOIN public.wallet_transactions w USING(id) WHERE w.terminal_closed_at IS DISTINCT FROM coalesce(b.terminal_closed_at,(SELECT ended_at FROM public.tournaments))),
 'original_wallet_terminal_markers_added',(SELECT count(*) FROM e2.before_wallet_transactions b JOIN public.wallet_transactions w USING(id) WHERE b.terminal_closed_at IS NULL AND w.terminal_closed_at IS NOT NULL),
 'original_payouts_unchanged',NOT EXISTS(SELECT 1 FROM e2.before_payouts b LEFT JOIN public.tournament_payouts p USING(id) WHERE to_jsonb(b) IS DISTINCT FROM to_jsonb(p)),
 'terminal_receipts',(SELECT count(*) FROM public.tournament_terminal_settlements),
 'escrow',(SELECT to_jsonb(e) FROM public.tournament_escrow e),
 'active_seats',(SELECT count(*) FROM public.table_seats WHERE left_at IS NULL),
 'closed_tables',(SELECT count(*) FROM public.tables WHERE status='closed'),
 'trigger_execution',current_setting('session_replication_role'))""")
assert proof['status'] == 'COMPLETED' and proof['trigger_execution'] == 'origin'
for key in ['payout_cents','obligation_cents','member_credit_cents','new_ledger_cents','new_wallet_receipt_cents']: assert proof[key] == 30400, (key,proof[key])
for key in ['original_ledger_unchanged','original_wallet_financial_fields_unchanged','original_wallet_terminal_markers_correct','original_payouts_unchanged']: assert proof[key], key
assert proof['terminal_receipts'] == 1 and proof['active_seats'] == 0
assert all(Decimal(str(proof['escrow'][key])) == 0 for key in ['prize_balance','bounty_balance','fee_balance'])
assert proof['escrow']['enforced'] is True and proof['escrow']['closed_at']

hash_tables = ['tournament_players','tournament_payouts','tournament_obligations','tournament_terminal_settlements','tournament_escrow','chip_ledger','wallet_transactions','club_members','tables','table_seats']
def state_hashes():
    return {t: query(f"SELECT to_jsonb(md5(coalesce(jsonb_agg(j ORDER BY j::text),'[]'::jsonb)::text)) FROM (SELECT to_jsonb(x) j FROM public.{t} x) s") for t in hash_tables}
before = state_hashes()
winner = survivors[0]['user_id']
replay = query(f"SELECT public.fn_complete_tournament_terminal('bee519fa-ff07-438c-9542-d386fc821908','{winner}','places')")
after = state_hashes()
assert before == after and replay['status'] == 'COMPLETED'
result = {'verifiedAt':datetime.now(timezone.utc).isoformat(),'eventId':core['tournament']['id'],
 'mode':'current-installed-seven-guards-disabled','resequencingToggles':0,
 'hypotheticalFutureBusts':11,'historicalEliminatedRows':155,
 'historicalPositionsCorrected':sum(p['position'] != expected[p['user_id']] for p in old),
 'nativePaidRangeBustsCreatePlaceObligations':False,'expectedOrderAll167Matches':True,
 'historicalStatusTimeSequenceChipsUnchanged':True,'financialProof':proof,
 'payouts':[{'place':p['position'],'userId':p['user_id'],'cents':int(Decimal(str(p['amount']))*100)} for p in payouts],
 'idempotentTerminalReplay':{'unchanged':True,'beforeHashes':before,'afterHashes':after}}
(base / 'verification-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':proof['status'],'paidCents':proof['payout_cents'],'historicalPositionsCorrected':result['historicalPositionsCorrected'],'idempotentReplay':True,'expectedOrderAll167Matches':True}))
