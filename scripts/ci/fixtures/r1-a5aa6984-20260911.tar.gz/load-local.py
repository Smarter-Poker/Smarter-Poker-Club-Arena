from pathlib import Path
import json, subprocess

base = Path(__file__).resolve().parent
state = json.loads((base / 'cluster.json').read_text())
assert state['cluster'].startswith('/tmp/ca-e2-owned-')
assert state['socket'] == state['cluster'] + '/socket'
assert state['database'] == 'r1_a5aa6984'
psql = ['/opt/homebrew/opt/postgresql@17/bin/psql', '-X', '-v', 'ON_ERROR_STOP=1',
        '-h', state['socket'], '-p', str(state['port']), '-U', 'postgres']

def run(args):
    result = subprocess.run(psql + args, text=True, capture_output=True)
    with (base / 'load.log').open('a') as log:
        log.write(result.stdout + result.stderr)
    if result.returncode:
        print(result.stderr[-2200:])
        raise SystemExit(result.returncode)

(base / 'load.log').write_text('')
run(['-d', 'postgres', '-c', 'DROP DATABASE IF EXISTS r1_a5aa6984;'])
run(['-d', 'postgres', '-c', 'CREATE DATABASE r1_a5aa6984;'])
run(['-d', state['database'], '-c', 'CREATE SCHEMA auth; CREATE SCHEMA extensions; '
     'CREATE EXTENSION pgcrypto WITH SCHEMA extensions; '
     'CREATE EXTENSION pg_trgm WITH SCHEMA public; '
     'CREATE EXTENSION "uuid-ossp" WITH SCHEMA extensions;'])
for filename in ['sequence-dependencies.sql', 'runtime-sequences.sql', 'auth-functions.sql', 'pre-functions.sql', 'pre-data.sql', 'current-functions.sql', 'additional-functions.sql', 'post-functions.sql', 'post-data.sql', 'current-extra-guard.sql']:
    run(['-d', state['database'], '-f', str(base / filename)])
    print('Loaded ' + filename)
