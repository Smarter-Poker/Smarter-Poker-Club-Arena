from pathlib import Path
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
import json, subprocess

base=Path(__file__).resolve().parent
state=json.loads((base/'cluster.json').read_text())
assert state['cluster'].startswith('/tmp/ca-e2-owned-') and state['database']=='r1_a5aa6984'
psql=['/opt/homebrew/opt/postgresql@17/bin/psql','-X','-v','ON_ERROR_STOP=1','-h',state['socket'],'-p',str(state['port']),'-U','postgres','-d',state['database'],'-Atc']
def query(sql):
    r=subprocess.run(psql+[sql],capture_output=True,text=True,check=True)
    if r.stderr.strip(): raise RuntimeError(r.stderr)
    return json.loads(r.stdout)
def read(n):return json.loads((base/n).read_text())
core=read('live-event-core.json');witness=read('live-event-witnesses.json')
winner='4f7f8abb-ba34-464c-9ecb-0ab7a972a978';river='dca6c345-c2ab-456f-98d9-dfbca3a43f7d'
commits={x['hand_id']:x for x in witness['commits']};ranked=[]
for player in core['players']:
    if player['user_id']==winner:continue
    ks=[k for k in witness['candidates'] if k['eliminated_user_id']==player['user_id'] and (k['state']=='eliminated' or player['user_id']==river)]
    if ks:
        k=max(ks,key=lambda k:(k['hand_number'],k['id']));a=commits.get(k['hand_id'])
        peers=[s for s in witness['candidates'] if (s['table_id'],s['hand_number'],s['hand_id'])==(k['table_id'],k['hand_number'],k['hand_id'])]
        at=datetime.fromisoformat(a['committed_at']) if a else min(datetime.fromisoformat(s['created_at']) for s in peers)
        at+=timedelta(microseconds=sum((Decimal(str(s['stack_before'])),s['eliminated_user_id'])<(Decimal(str(k['stack_before'])),k['eliminated_user_id']) for s in peers))
    else:at=datetime.fromisoformat(player['eliminated_at'])
    ranked.append((player,at))
ranked.sort(key=lambda x:x[0]['id']);ranked.sort(key=lambda x:(x[1],x[0]['elimination_sequence'] or 999999999),reverse=True)
expected={winner:1};expected.update({p['user_id']:i+2 for i,(p,_) in enumerate(ranked)})
actual=query('SELECT jsonb_agg(to_jsonb(p)) FROM tournament_players p')
assert len(actual)==100 and all(p['position']==expected[p['user_id']] for p in actual)
assert expected[river]==100
ladder=json.loads(core['tournament']['payout_structure'],parse_float=Decimal)
bps=[int((Decimal(str(x['percentage']))*100).quantize(Decimal(1),rounding=ROUND_HALF_UP)) for x in ladder]
remaining=9930;amounts={}
for i,(row,bp) in enumerate(zip(ladder,bps)):
    amount=remaining if i==len(ladder)-1 else min(remaining,int((Decimal(9930)*bp/sum(bps)).quantize(Decimal(1),rounding=ROUND_HALF_UP)))
    amounts[row['place']]=amount;remaining-=amount
payouts=query('SELECT jsonb_agg(to_jsonb(p) ORDER BY position) FROM tournament_payouts p')
assert len(payouts)==10 and sum(int(Decimal(str(p['amount']))*100) for p in payouts)==9930
assert all(expected[p['user_id']]==p['position'] and int(Decimal(str(p['amount']))*100)==amounts[p['position']] for p in payouts)
proof=query("""SELECT jsonb_build_object(
 'status',(SELECT status FROM tournaments),'escrow',(SELECT to_jsonb(e) FROM tournament_escrow e),
 'member_credit',(SELECT sum(m.chip_balance-b.chip_balance) FROM club_members m JOIN r1.before_members b USING(club_id,user_id)),
 'union_rake_credit',(SELECT sum(w.rake_wallet-b.rake_wallet) FROM union_wallets w JOIN r1.before_union_wallets b USING(id)),
 'rake_settlement',(SELECT to_jsonb(r) FROM tournament_rake_settlements r),
 'new_ledger_total',(SELECT sum(l.amount) FROM chip_ledger l LEFT JOIN r1.before_ledger b USING(id) WHERE b.id IS NULL),
 'original_ledger_unchanged',NOT EXISTS(SELECT 1 FROM r1.before_ledger b LEFT JOIN chip_ledger l USING(id) WHERE to_jsonb(b) IS DISTINCT FROM to_jsonb(l)),
 'original_wallet_financial_fields_unchanged',NOT EXISTS(SELECT 1 FROM r1.before_wallet_transactions b LEFT JOIN wallet_transactions w USING(id) WHERE to_jsonb(b)-'terminal_closed_at' IS DISTINCT FROM to_jsonb(w)-'terminal_closed_at'),
 'original_entitlements_unchanged',NOT EXISTS(SELECT 1 FROM r1.before_entitlements b LEFT JOIN tournament_refund_entitlements e USING(id) WHERE to_jsonb(b) IS DISTINCT FROM to_jsonb(e)),
 'terminal_receipts',(SELECT count(*) FROM tournament_terminal_settlements),
 'remaining_live_seats',(SELECT count(*) FROM table_seats WHERE left_at IS NULL),
 'pending_wakes',(SELECT count(*) FROM tournament_manager_wakes WHERE consumed_at IS NULL),
 'trigger_execution',current_setting('session_replication_role'))""")
assert proof['status']=='COMPLETED' and proof['trigger_execution']=='origin'
assert Decimal(str(proof['member_credit']))==Decimal('99.30')
assert Decimal(str(proof['union_rake_credit']))==Decimal('2.70')
assert Decimal(str(proof['new_ledger_total']))==Decimal('102.00')
assert proof['rake_settlement']['attributed_at'] and proof['rake_settlement']['attribution_error'] is None
for key in ['original_ledger_unchanged','original_wallet_financial_fields_unchanged','original_entitlements_unchanged']:assert proof[key],key
assert all(Decimal(str(proof['escrow'][k]))==0 for k in ['prize_balance','fee_balance','bounty_balance'])
assert proof['escrow']['closed_at'] and proof['terminal_receipts']==1 and proof['remaining_live_seats']==0 and proof['pending_wakes']==0
tables=['tournaments','tournament_players','tournament_payouts','tournament_obligations','tournament_terminal_settlements','tournament_escrow','chip_ledger','wallet_transactions','club_members','union_wallets','club_wallets','tables','table_seats','tournament_manager_wakes','tournament_knockout_candidates','hand_atomic_commits','tournament_refund_entitlements']
def hashes():return {t:query(f"SELECT to_jsonb(md5(coalesce(jsonb_agg(j ORDER BY j::text),'[]')::text)) FROM (SELECT to_jsonb(x) j FROM {t} x) s") for t in tables}
before=hashes();replay=query("SELECT fn_complete_tournament_terminal('a5aa6984-6c1c-4b59-aeb7-9e7878853bdd','"+winner+"','places')");after=hashes()
assert before==after and replay['status']=='COMPLETED'
receipt={'verifiedAt':datetime.now(timezone.utc).isoformat(),'eventId':core['tournament']['id'],'expectedOrderAll100Matches':True,'riverFinalPlace':100,'resequencingToggles':0,'D8UndeliveredRebuyDebtUnchanged':{'userId':river,'amount':'1.00','walletReceiptId':'77480914-a763-4033-9b2e-ab3be78cac36'},'proof':proof,'payouts':[{'place':p['position'],'userId':p['user_id'],'amount':p['amount']} for p in payouts],'idempotentTerminalReplay':{'unchanged':True,'beforeHashes':before,'afterHashes':after}}
(base/'verification-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':'COMPLETED','payouts':10,'prizes':'99.30','unionRake':'2.70','riverPlace':100,'D8Debt':'1.00','idempotentReplay':True}))
